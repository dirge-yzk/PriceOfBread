﻿using System.Collections.Generic;
using System.Linq;
namespace PriceOfBread.SimCore;

/// <summary>
/// 全体のチューニング係数（§9-A/§9-D）。財ごとのパラメータは Good／Producer 側が持つ。
/// 値は最終的に §8 の sweep で導出する（ここは段0/1 が健全に動く暫定値）。
///
/// ★★★**判定順序（作者裁定 2026-08-01・最上位。08_バランス調整方針 §1 の4段順序を差し替える）**：
///   **ゲームが破綻しない ＞ 正しい挙動（リアリティ・納得感）＞ バランス（史実忠実度の帯）**
/// ⚠**「帯が悪くなった」というだけで機構を差し戻さない。** 差し戻すのは破綻（クラッシュ・保存則違反・デッドロック・テスト赤）か、
///   挙動が明らかに不自然になる場合に限る。★より正しい機構で帯が悪化したときは**採用したうえで、悪化した数値と
///   「較正で取り戻す対象である」ことを、この行内コメントと docs の両方に必ず書く**。
/// ⚠**記録を欠いた採用は認められない**——帯の劣化が「意図した負債」なのか「未検出の不具合」なのかが後から区別できなくなるため。
/// </summary>
public sealed class Coefficients
{
    // --- 市場（§9-A）---
    public double PriceAdjustSpeed = 0.13;   // 価格の積分項：在庫ギャップ駆動（§9-A 仕組み1）。0.08→0.13＝価格の変動をより顕著に（ユーザー要望）
    public double FlowAdjustSpeed = 0.48;    // 価格の比例項：需給差駆動＝振動の減衰（設計判断A）。需給差を**自然有界な (D−S)/(D+S)∈[−1,1]** で測る（旧 (D−S)/S は S→0 で∞＝FlowCap で蓋が必要だった）。平常域は (D−S)/(D+S)≈x/2 なので旧0.24の2倍=0.48でゲインを温存し、崩壊時は±1で連続有界（蓋不要）
    public double PriceElasticity = 0.5;     // 段B：日次価格探索の需給の価格弾力性。実効需要 eD=D×(rp/P)^ε・実効供給 eS=S×(P/rp)^ε ＝価格が参照から離れると需要減・供給増で**押し戻す復元力**。均衡 P*=rp×(D/S)^(1/2ε) は有限＝クランプが張り付かず外側の安全網へ降格。P=rp(平衡)では eD=D,eS=S＝段Aと同一なので平常較正への影響は小。0=段A（弾力性なし）
    // 加速度的な価格是正（要望）：平衡(100%)近くは緩やか、端ほど急峻。倍率＝Center＋(Edge−Center)×ndist^Power。
    // ndist＝|ln(価格/参照価格)|÷ln(1/床係数)＝床5%・天井2000%で1.0（対称）。50%/150%は今までと同等以下、5%/2000%は直ちに是正。
    public double PriceAmpLnScale = 2.9957;  // amp曲線の端の対数距離（=ln20）。旧は床係数に連動していたが、安全網クランプ幅とは別概念なので分離（クランプを広げてもamp曲線＝是正の強さは不変）。既定はln(20)で従来同値
    public double PriceAmpCenter = 0.7;      // 100%付近の調整倍率（<1＝張り付かない範囲は今までより静か）
    public double PriceAmpEdge = 8.0;        // 床5%/天井2000%での調整倍率（≫1＝極端な乖離は直ちに是正）
    public double PriceAmpPower = 3.0;       // 増幅の凸度（高いほど中間は平坦・端だけ急峻＝加速度的）
    public double SupplyAdjustSpeed = 0.15;  // 供給能力調整の速さ（§9-A 仕組み4）。0.12→0.15＝供給が価格に速く追従しコブウェブ振動を減らす（価格二極化の緩和）。0.18は工業最先進の英を強くしすぎ常勝化したため0.15に抑制
    // ※適応的期待（供給を期待価格EMAに反応）を試したが二極化が悪化（49→40%）＝二極化はコブウェブ振動でなく供給能力不足（実需要に届かない）が主因と判明・撤回
    public double SupplySlope = 0.5;         // 供給曲線の傾き（オプションB）：価格が mc×(1+これ) で能力上限
    // ★再点火発注の決済（点火2026-08-01・作者指摘「実装の形としては正だが、実装方法としてスマートでない。同等かよりリアリティのある挙動を確保できるなら差し替えて」）。
    // 0＝旧（現物だけが動き、代金も所得も発生しない）／1＝止まった工場の持ち主が貯蓄から払い、売った側が受け取る。
    // ⚠**発注量・配給・物量の消費は1つも変えない**＝作者が意図した「上位工場を先に建ててから下流を整備する」プレイの余地はそのまま残る。
    public double ReignitionOrderSettles = 1.0;
    public double ReignitionDemandFrac = 0.03;  // 入力需要の再点火トリクル＝採算が合えば「作りたい量」のこの割合を最低需要に（産出の床に代わるデッドロック防止。死んだ工場も需要を残し価格で蘇生＝無から有なし）
    public double PriceFactorMin = 0.4;      // 価格弾力の下クランプ
    public double PriceFactorMax = 1.4;      // 価格弾力の上クランプ
    // 交差弾力性（B-2）：主食内の相対価格で需要を再配分（パン高騰→芋へ＝飢饉の核心）。基準＝主食の(価格/参照価格)の幾何平均、平均の財は不変、安い財ほど需要↑。0で無効。
    public double CrossElasticity = 0.6;     // 主食間の代替の強さ（相対価格の指数）。上限/下限は PriceFactorMin/Max を流用
    // 価格の床/天井＝参照価格×これ。段B（弾力性均衡）で**非load-bearingの安全網**に降格：弾力性の復元力が価格を帯のはるか内側で抑えるため通常は張り付かない
    // （検証：0.002/500 まで広げても119＋33/33/33が緑＝旧コメントの「撤去で10件破綻」を解消）。残す理由は真の供給0＝死財（D>0,S=0）の病的∞発散を防ぐ最後の砦のみ。
    public double PriceFloorFactor = 0.01;    // 暴落の底（安全網）
    public double PriceCeilFactor = 100.0;    // 暴騰の天井（安全網）
    public double SoftBandSharpness = 8.0;    // 価格安全網(SoftBand)の対数空間飽和の鋭さ（→∞でハードクランプ。旧 MarketFlow関数内 const 8.0 を係数化＝sweep対象）
    // ※FlowCap は撤廃（段A）：需給差を (D−S)/(D+S) で測れば本質的に[−1,1]有界＝S→0 の D/ε 爆発が原理的に起きず、絶対上限の蓋が不要になった
    // 在庫目標は処理量（総需要）に比例させる＝凍結値だと高処理量財の在庫項が常に大負になり価格が床へ叩き落とされる（価格シグナルの破れ）
    public double TargetStockBuffer = 1.0;   // 在庫目標 ＝ 総需要 × これ（≒保有したい在庫＝数期分の需要）。⚠DesiredInventoryCover と対＝セットでのみ動かす（下記参照）
    // === テーマH（産業組織・固定資本・住宅）===
    public double InventoryAdjustGain = 0.1;     // メッツラー在庫循環＝在庫についての期待。05-B1（2026-07-29）点火：期待導入の最初の一歩（増幅側＝恐慌を増やす方向・05 §5）。0で旧恒等
    public double DesiredInventoryCover = 1.0;   // 望ましい在庫＝これ×LastDemand（TargetStockBufferと一致＝定常でギャップ0）。⚠TargetStockBuffer と対＝一致しないと定常でギャップが残る。片方だけ動かさない（GridReplaceRate/GridDecayRateと同型）
    public double TargetStockFloor = 1.0;    // 在庫目標の下限（需要≈0でのゼロ除算回避）＝**「量として意味を持たない」の既存の物差し**（下の幻の生産のスナップもこの実用スケールを流用する）
    // ★墓標（2026-08-22・需要と供給の組み換え＝点火と削除）：労働配分の重みは「需要量×Scale」から「準レント×単位能力×Scale」＋配分信念EMAへ**無条件**に切替（EconomyStep の prodW 注記）。
    //   LaborRentWeight（構造スイッチ）・CrowdRentExpectation（混雑予期＝効果−2.4回・赤1件）・LaborFloorMix（均等床0.15＝準レント下では不要）・ExportDemandWeight（0.25の別建て加算＝価格に輸出が載るので次元不整合）は削除。
    //   測定＝準レント＋信念EMA＋床撤去＝硬性ゲート全緑・405緑・savetest 0.0E+000。大国8の1人あたり実質GDP＝エピソード7.1/試合・最大DD51%（基線2.8/31%・裸8.1/53.5%）。
    /* ★貿易の数量則書き換え（2026-08-22・docs/202608/20260822_貿易数量則の書き換え_設計_部分完了.md）。用量反応で「式の形が律速」を確定した後の段階実装。
       S1 暦＝TradeMonthlyClearing：国際清算を四半期1回→月次（MonthSettle の後）。量の式が月次規模を読むのに清算が四半期＝単位混在の是正（正しさの修正＝栓ではない）。
         0＝追加呼び出しゼロ＝ビット恒等。読み手は ClearingsPerYear / MonthsPerClearing で年換算・月割を揃える（×4.0 の直書きを残さない）。
       S3 価格法則＝PriceLawSeesExports：MarketFlow の flow 項の需要側に LastExport を足す。現行は輸入が在庫と供給の**両方**に載るのに輸出は在庫にしか載らない
         （BilateralMarket:460-461 と MarketFlow:27）＝輸出州の産出>需要を「過剰供給」と読み価格が崩れ→profitFactor（地元価格）が産出を絞る→輸出余剰が消える
         ＝**輸出する州ほど罰される非対称**（用量反応×100腕が2.91%で飽和した正体の有力候補＝天井でなくこの均衡）。0＝旧式を逐語に通る＝ビット恒等。
       どちらも 0/1 の構造スイッチ（中間値に意味なし＝運用禁止）。 */
    public double TradeMonthlyClearing = 1.0;   // ★点火2026-08-30（貿易数量則ラウンド・batch10段階測定→フルスタック採用）
    public double TradeLedgerFix = 1.0;     // S2台帳衛生（案E・2026-08-30）：人口の主食純輸入をゼロ化前の前清算値（Market.PrevImport/Export）で読む。0＝旧（常に0を見る＝発火不能）＝厳密恒等
    public double TradeArbitrageClearing = 1.0;   // ★点火2026-08-30＝世界貿易/GDP 0.5%→42〜66%（1914断面42%≈史実40%）・開放度次元が初の非ゼロ   // **S4主フラグ**（2026-08-30・docs/202608 §1）：数量則を水準式へ＝買い X=min(価格静止,物理)・売り Y=min(価格静止,在庫−地元分)・次善へ回る反復＋支払能力（Apply集合）。TradeSpeed は ON で不読。0＝旧（定数速度×自州規模）＝厳密恒等
    public double TradeCapacityHard = 1.0;        // ★点火2026-08-30＝hard腕が本国96.7(基線同値)/経済41.2(最高)/ハーネス0で最良・容量投資が意味を持つ形        // S4-1（TradeArbitrageClearing>0 のときのみ意味）：容量を同期制約に＝capLeft 両端減算・θ乗算撤去・potential 新定義。0＝影計測（capLeft を切らない・θ/potential は新定義で書く）
    public double PriceLawSeesExports = 1.0;   // ★点火2026-08-30（単独では清/西の人口コスト＝S4と同時なら消滅を実測・記録doc参照）
    public int ClearingsPerYear => TradeMonthlyClearing > 0 ? Calendar.MonthsPerYear : Calendar.QuartersPerYear;   // 国際清算の年あたり回数（年換算の単位ヘルパー）
    public int MonthsPerClearing => TradeMonthlyClearing > 0 ? 1 : Calendar.MonthsPerQuarter;                    // 1清算が覆う月数（月割の単位ヘルパー）
    /* ★幻の生産の根絶（作者2度指摘・2026-08-10）＝1783年に内燃機関が「生産量0.0kなのに生産シェア3%・清が世界の12%」、
       自動車が0.0kで「世界の5%」、廃棄率が 12,543,372%。
       根＝EconomyStep :459 の追従式 `Output += SupplyAdjustSpeed × (target − Output)`。**目標が0でも産出は幾何級数で
       減るだけで決してゼロに到達しない**。工場の種火（Simulation :775 の Output=0.5）とRGOの初期値50が、技術ゲートで
       target=0 のまま 0.85^n の残り火として何十年も残り、**ノイズ同士の比**が世界シェア・順位になっていた。
       廃棄率は分母が 1e-8 級の産出になって発散する（腐敗は初期在庫200から実量で出るため分子は実数）。
       ①未発明（技術ゲート=0）＝**製法が存在しない**＝在庫や慣性の話ではないので即0。
       ②目標が立たない月（採算割れ・投入涸れ）の残り火＝これ×TargetStockFloor 未満なら0へ。
         ⚠target>0（少量でも作りたい月）は対象外＝**本当に少量作っている州は殺さない**。
       0＝①②とも不発＝現行と厳密恒等（挙動変更なので戻せる形で置く）。1.0＝在庫目標の下限1単位＝生産タブが
       「工場が立っている」と数える閾値（Output>1）と同じ実用スケール＝新しいマジックナンバーを作らない。 */
    public double PhantomOutputSnapFloor = 1.0;
    /* ★幻の**工場**（作者スクリーンショット2026-08-10・日本1783/01/01）＝機関銃が「技術不足・生産量0.0k」なのに
       州別テーブルの民営工場が 江戸2・大阪1・横浜1・京都1・仙台1・長崎1・北九州1 ＝**1783年に機関銃工場が7つ**。
       根＝操業規模の目標 `scaleTarget = Clamp(1+利幅, floor, ScaleMax)`（EconomyStep :1842）は**技術ゲートを知らない**
       ＝作れない財でも Scale が1.0付近へ育つ。Scale は労働の取り分の重み `prodW = LastDemand × Scale`（:274）でもあるので、
       未発明の財に労働者が張り付いていたことにもなる。
       Scale=0 は**既存の倒産経路と同じ値**（:1863 の「Scale0で労働も配分されない」）＝新しい機構を作らない。
       ⚠対象は「技術ゲートが0の財」だけ（全財0スタートは採らない＝労働が配分されず農場まで止まり、巨大な開始過渡になる）。
       **2026-08-11に点火（1.0）**＝バッチ scale0 が硬性緑・8軸合計 319.2→319.8（雑音圏）・◎7割帯 17→19。
       労働配分が動くので帯は揺れるが「作れない財に労働者が張り付かない」＝正しい挙動を優先（0で旧挙動へ戻せる）。 */
    public double TechGatedScaleZero = 1.0;
    // ⚠撤去2026-08-22: LaborFloorMix（均等床0.15）＝準レント配分では不要（価格上昇が重みを自動で戻す）・作者裁定「ラッダイトは必須」＝職人と工場の27倍の非対称も同時に消える。墓標は上の準レント注記。
    // --- 企業の操業規模（参入退出。採算で伸縮し供給を需要へ寄せる＝価格二極化の是正・§9-A 仕組み4）---
    public double ScaleAdjustSpeed = 0.05;   // 操業規模が採算の目標へ寄る速さ（緩やか＝供給の振動を防ぐ）
    public double ScaleFloor = 0.1;          // 採算が悪い工場の最小規模（≒閉鎖。0でなく＝需要回復で再開できる）
    public double ScaleMax = 3.0;            // 採算が良い工場の最大規模（拡張＝希少財へ労働を集める）
    // 工場の倒産・有限責任（数期移動平均の採算で退出）。有効化済み（旧・既定オフの理由＝床は過剰供給(グルット)の症状であり、
    // 本来黒字（参照価格なら採算可）の財まで、しかも工業化前で需要の低い必須資本財まで倒産させ、工業化が崩壊するため＝
    // グルット是正後に true 化。保存則は不変＝倒産は産出0で損失を出さない）。
    public bool FactoryBankruptcyEnabled = true;   // 倒産機構（恐慌カスケードの核）。手法A（資本財は倒産せず）＋手法B（品薄で数量再開）で回復可能な不況を狙う
    // 倒産退出の実効化2026-07-10（キュー2＝損失financing 30/30の構造対処）：手法Aのtier免除（Producer/Intermediateは倒産しない）を解除し、
    // 中間財・資本財の慢性赤字も退出させる。プローブ実測（seeds1-3）＝LossFinancedの受け手は資本家≈99%・手法A保護下の「倒産マージン割れ」
    // 慢性赤字が Producer≈110万+Intermediate≈90万 生産者・月（肥料/砂糖(甜菜糖)/精密工作機械が主）＝退出できない工場が損失を垂れ流し負債化していた。
    // サプライチェーンの連鎖断絶は手法B（品薄の数量再開＝FactoryReentryMargin/shortage）＋再点火トリクル（死んでも投入需要は残る→価格で蘇生）が受ける。
    // 負債は帳消ししない（Bank.Loansに残る＝銀行信頼へ）・倒産は産出0のみで貨幣非接触＝保存則不変。Service（役務＝学校/病院/役所/労働）は常に免除。0で旧挙動（最終消費財のみ倒産）＝休眠可。
    public double FactoryBankruptcyAllTiers = 1.0;
    public double FactoryMarginSmoothing = 0.025;  // 採算EMAの平滑係数（小＝長い移動平均＝一過性の赤字では潰れない。0.025≒3年＝持続的危機のみ倒産）
    public double FactoryBankruptcyMargin = -0.85; // 平滑採算がこれ未満で倒産（原価の15%以下で売り続け＝極度の慢性赤字のみ。死のスパイラル防止）
    public double FactoryReentryMargin = -0.05;    // 倒産中、現採算がこれ超で新規参入（やや赤字でも再開＝恐慌からの早い回復）
    public double FactoryReentryScale = 0.3;       // 新規参入時の操業規模（小さく入って採算が良ければ拡張）

    // --- pop 意思決定（§9-D・段1）---
    public double Mobility = 0.02;            // 階級間の再配分速度（緩和）
    public double MigrationTemperature = 0.15; // softmax 温度（低温＝ほぼ最善へ）

    // --- 技術・教育（§2.8／§9-H・段2）---
    // 供給曲線（オプションB）が過剰能力を吸収するので、技術は本来の変革的スケールでよい。
    public double AdoptionCeiling = 0.5;          // 暗黙の世界水準＝孤立国でも基礎技術はここまで採用できる（単一国の採用上限）
    public double FrontierCeiling = 6.0;          // 技術の安全上限（革新は逓減するので実際は届かない＝張り付き防止）
    public double EliteForFullTech = 0.5;         // 基礎採用/革新に要るエリート水準（厳しい＝乏しい社会は失敗型）
    public double TechGrowthRate = 0.015;         // 基礎採用（暗黙の世界水準まで）の線形速さ＝単一国の挙動を温存
    public double EliteForCatchup = 0.25;         // 世界世界の技術水準からの後追いに要るエリート（緩い＝コピーは発明より易しい＝後発のブースト）
    public double CatchupFraction = 0.5;          // 後追い採用で届く先端比率＝永遠の二番手（先端に並ぶには自前の革新＝自由＋公教育が要る）。改修2026-06-28：0.7→0.5＝巨大人口の非革新国（清/印）の技術が先端の半分で頭打ち＝欧州の革新優位を実数化（ユーザー指示「技術力で差がでるように」）
    // 後発国のキャッチアップ（最終調整2026-06-29・ユーザー指示「後発国の追い上げで覇権を争えるように」）：**近代化した（自由＋公教育＝FrontierCapable）後発国**は吸収能力が高く、
    // 前線の高い比率まで追い上げられる（Gerschenkron＝独・米が英を追い越す史実）。非近代化の巨人（清/印＝検閲/宗教教育）は CatchupFraction 0.5 据え置き＝置いていかれる（均質化を避け、前線を「争える」状態に）。
    public double CatchupFractionAdvanced = 0.97; // 近代化(FrontierCapable)後発国が後追いで届く先端比率（≒並んでから自前革新で追い越す）。CatchupFraction と同値で旧挙動（差なし）
    // ★2026-08-02（作者裁定「頻繁に上位が入れ替わるのは好ましくないので、上がりづらく、落ちづらいスコアにすべきだ」）：
    // 序列に使う国力を在庫化する1四半期あたりの追従率。1=毎期フローに一致（旧恒等・休眠）／小さいほど慣性が強い。
    // 0.02≒半減期35四半期≒9年＝列強の地位を得るにも失うにも十年単位かかる（史実の列強概念＝蓄積された地位）。
    // ⚠これは「首位交代は多いほど良い（目標3）」という旧指標と真っ向から逆を向く。作者裁定が優先。
    // ★ColonizeByMiddlePowers は撤去（作者裁定2026-08-23の1本化）＝行為者のランク条件そのものが無くなった（国力比の要求余剰戦力が代わりに律速する）。
    // ⚠実測で差し戻し（2026-08-02）：R6（中堅を無条件に許可）は**全次元±0.0＝完全に無効果**＝AI側(Diplomacy の
    //   TryAiColonize 呼び出し)が列強にしか試させておらず Colonize に到達していなかった。資格判定を CanActAsColonizer の
    //   1本に出して両経路を揃えたうえで R6b（既に海外領を持つ中堅のみ）を測ると、硬性ゲートが3つ赤
    //   （異常2・ハーネス1/10・損失financing 41.7%が2/10）で、狙った植民地次元まで 35.8→30.8 と**逆に悪化**した。
    //   原因＝既存の帝国保有国（西5.7→6.0・仏2.7→3.0）が過剰拡張して財政が破綻する。英は1.6→1.3で改善すらしない。
    //   ★英の植民地（史実21・許容10.5〜31.5）に届かせるには、ランクの錠でなく標的の数・膨張度のコスト・
    //   AiColonizeChance の側を扱う必要がある＝別ラウンドの課題として記録。
    public double ScoreInertiaRate = 0.02;
    public double CapitalAbsorptionBlend = 1.0;   // ★2026-08-02：外資の headroom（＝遅れている国ほど資本を呼ぶ無条件のポンプ）に、技術側と**同じ**吸収能力（clamp(Elite/EliteForFullTech)×報道自由）を掛ける混合比。技術側は CatchupAbsorptionBlend で既に是正済みなのに資本側だけ素通りで、1913年の工業化がダホメ4.02〜英3.56と全球で密集し、国力スコアの8割を占める水準量が横並びになる＝史実の列強が上位7に入れない主因（実測 final.txt：参照8カ国すべて定員外）。1=吸収でスケール・0=旧恒等（休眠）
    public double CatchupAbsorptionBlend = 1.0;   // 収束是正2026-07-10：後追いの二値ゲート（自由0.6+公教育→天井0.5→0.97へジャンプ）を吸収能力＝clamp(Elite/EliteForFullTech)×報道自由で連続補間する混合比。二値ゲートは全球収束の主因（後追い0.13/四半期は前線前進≈0.006の約20倍＝資格国は必ず前線に張り付く）。資格国のみ吸収でスケール（非資格は旧0.5天井＝宗教教育の逆転防止）。1=連続（公教育化しても識字低×検閲の清印は中間天井＝史実・英独仏は吸収≈1で従来どおり）・0=二値（旧恒等・休眠可）。較正は単一国＝前線0で後追い経路が走らず構造的に中立
    public double AdoptionRateAdvanced = 0.13;    // 近代化後発国の後追い速さ（基礎 AdoptionRate 0.06 より速い＝制度が整えば急速に追いつく）。AdoptionRate と同値で旧挙動。速いほど挑戦者が早く競争力を持つ
    public double AdoptionRate = 0.06;            // 世界の技術水準後追いの速さ（ギャップ比例＝遅れているほど速い＝後発のブースト）
    public double InnovationRate = 0.012;         // 革新の速さ（自由＋公教育が世界の技術水準を押し上げる）
    public double InnovationScale = 3.0;          // 革新の逓減スケール（技術がこれを超えると伸びにくい＝先端の張り付き防止）
    public double FrontierFreedomThreshold = 0.6; // 世界の技術水準解禁（革新）の自由度閾値
    public double InnovationEliteSubstitute = 1.0; // 【#22点火2026-07-15＝1.0・革新の自由度緩和】自由の代替＝高エリート技術力(w.Elite≥EliteForFullTech)＋高行政効率(w.AdminEfficiency≥InnovationAdminThreshold)でも革新可に。0=自由必須（現行と厳密恒等）・>0で検閲下でも有能な官僚制の国（ドイツ帝国/明治日本）が革新可＝史実の「権威主義的近代化」。公教育条件は維持
    public double InnovationAdminThreshold = 0.85;  // 【#22＝0.85・的絞り】自由代替に要る行政効率の閾値（独帝国級の卓越した官僚制のみ）。InnovationEliteSubstitute=0では未使用
    // ★2026-08-12（技術の全球収束・第2次）：CapitalAbsorptionBlend / CatchupAbsorptionBlend は**吸収能力**でスケールする正しい形だが、
    //   その吸収能力（AbsorptionOf）が識字×報道自由**しか**測っていない＝経済の中身が1つも入っていない。
    //   実測（techtrace seed1）：1923年の技術がラオス4.18＞プロイセン4.14＞ダホメ王国4.13＞イギリス3.98。
    //   ダホメ王国は識字57%・公教育・報道自由なので吸収=1.0＝先端の97%へ速度0.13で吸い寄せられる。**自給自足の王国が学校を建てただけで英に並ぶ**。
    //   欠けている物理は2つ＝①採用には技術を載せる**資本**が要る（所得）②革新の速さは割合でなく研究基盤の**絶対規模**で決まる。
    public double AbsorptionIncomeWeight = 0.0;   // 吸収能力に1人あたり所得を入れる重み。0=旧挙動に厳密恒等（休眠）／1=参照所得未満なら比例で吸収が落ちる
    public double AbsorptionIncomeRef = 0.0;      // 吸収が満点になる1人あたり所得（0で機構ごと不走行）。技術・資本の**両方**の吸収に効く（同じ写像を書き分けない＝既存の設計方針）
    public double ResearchScaleWeight = 0.0;      // 革新の速さを研究基盤の**絶対規模**（世俗教育層の人数）でスケールする重み。0=旧挙動に厳密恒等（休眠）
    public double ResearchBaseRefPop = 0.0;       // 研究基盤の参照人数（この規模で倍率1.0＝恒等点）。0で機構ごと不走行。逓減は平方根＝人口10倍で研究速度3.2倍

    // --- 制度・改革（研究C＝カードに代わる離散選択。社会の閾値で解禁し施行＝恒久ブースト）---
    public double PatentInnovationBonus = 1.5;    // 特許制度：技術成長 ×これ（革新を加速）
    public double JointStockInvestBonus = 1.6;    // 株式会社：工業化投資 ×これ（中産の資本が株で工業へ＝資本調達の拡大の proxy）
    public double EquityHeatEuphoria = 0.05;      // 株式バブル（金融改革②）：与信過熱(FinancialHeat 0..1.5)×これ を投資ハードルから減じる＝過熱→株高→投資ブーム→Confidence崩壊で恐慌。較正(Heat=0)中立
    // ⚠撤去2026-08-28（作者裁定④）: RailwayProductivityBonus(0.15)＝鉄道の州生産性ブースト＝輸送の代理（読み手ごと削除・Institutions.cs の墓標を参照）
    public double PatentEliteThreshold = 0.4;     // 特許の解禁エリート水準
    public double JointStockIndThreshold = 0.3;   // 株式会社の解禁工業化度
    public double RailwayIndThreshold = 0.8;      // 鉄道の解禁工業化度
    // ★高等教育（2026-08-17・作者裁定「近代化投資は研究者や技師を増やす補助金として／まず高等教育から順に」）。
    //   研究者＝インテリ（医者/技師/研究者）の4人目。上流階級（Closed＝貴族・聖職者）とは別カテゴリ＝既存のブロック構造と一致するので
    //   機構は増えない（`intel × 係数` の行が1本増えるだけ）。**総量保存**＝教師/官僚/医者の取り分から切り出す（新しい人は湧かない）。
    //   ⚠⚠0＝研究者0人＝**POPを pops に並べない**（実測2026-08-17：Size=0 の空POPを並べると Pops.Count が 13→14 になり、
    //   EconomyStep のスクラッチ配列長・労働配分・地代分配のループ長が変わって軌道が動いた＝勝者が英→米）＝厳密恒等。点火時は 0.25 目安（教師0.30/官僚0.25/医者0.20/研究者0.25）。
    public double ResearcherFrac = 0.0;           // インテリのうち研究者になる割合（0=休眠＝厳密恒等）。教師/官僚/医者から按分で取る
    public double UniversityProductivity = 2.0;   // 大学1単位の高等教育の産出（研究者1人あたり）。教育5.0/医療4.0/行政3.0 より低い＝希少で高価
    // ★段②（2026-08-17）：高等教育の需要と、それを昇格資格に使う度合い。⚠どちらも0＝厳密恒等（休眠フラグ規律）。
    public double HigherEduNeedPerEducated = 0.0; // 高等教育の必要量＝これ×前月EducationFill×識字×人数（0=需要ゼロ＝厳密恒等）
    public double PromotionGateHigherEdu = 0.0;   // 技師・研究者への昇格を高等教育の充足で絞る度合い（0=絞らない＝厳密恒等／1=買えていない分だけ資格が消える）
    // ★段③（2026-08-17）：近代化投資のうち高等教育の学費補助へ回す割合。残りは従来どおり建設予約（StateBuildQueue）。
    //   ⚠0=全額が建設＝**現行と厳密恒等**。1=全額が人材（作者の意図する最終形）。段階移行のレバー＝途中値で実測しながら寄せる。
    public double ModernizationToHigherEdu = 0.0;
    // ★段④ 招聘（2026-08-17・設計「大衆は自発的に動く。技師は呼ばれて動く」＝主語が違うので式も別）。
    //   ⚠RecruitCostPerHead=0 で経路に入らない＝**厳密恒等**（0除算も踏まない）。ModernizationToRecruit=0 でも予算が立たない＝二重の休眠。
    //   ★史実の規模：お雇い外国人は明治日本の最盛期でも**数千人**（大衆移民は数百万人）＝「予算で買える人数」が自然な上限。
    public double ModernizationToRecruit = 0.05;   // ★点火2026-08-29（夜間R16クラスタA/B batch30＝帯中立・破綻0）：近代化予算のうち招聘へ回す割合
    public double RecruitCostPerHead = 100.0;      // ★点火2026-08-29（R16同席）：技師1人を呼ぶ基礎費用。⚠実費はこれ×相手が豊かなほどの割増×距離
    public double RecruitPremiumScale = 0.5;       // 割増の物差し＝相手国の機会がこれだけ上回ると費用が2倍（★お雇い外国人は大臣より高給）
    public double RecruitMaxFracOfSource = 0.02;   // 1四半期に1国から抜ける上限（送出側の規模比）。⚠技師は桁違いに少ないので上限が要る（大衆と同じ式なら先進国が一瞬で空になる）
    public double RecruitDistanceScale = 10000.0;  // ★点火2026-08-29（R16同席）：招聘の距離割増の物差し（1万kmで費用2倍）。⚠遠いほど高くつく（渡航・家族同伴・契約年数）

    // --- 政治（§9-E／§A-11・段3）---
    // 政体閾値の人口正規化：動員（改革派＋急進派＝Σ規模×意識）は人口に比例するので、保持力も「人口あたりの強度」として
    // 比較する＝実効保持力 = Coercion × (総人口 / これ)。これにより BaseCoercion/これ が「革命に要る平均意識」の閾値になり
    // 人口に依存しない＝教育（意識の上限）と圧政の選択が明治/徳川/失敗を分ける。基準1000（小シナリオは×1で不変）。
    // 維持費も同じ係数で嵩む（大人口の統制には比例した警察・軍＝統制の代償・§6.2）。
    public double PoliticalReferencePop = 1000.0;     // 政体力学の基準人口（保持力・維持費の人口あたり強度の分母）
    public double ConsciousnessSpeed = 0.015;         // 意識の緩和速度（四半期）。19世紀の政治意識の浸透は緩慢＝自由化は一世代かけて醸成される（抑圧が時を稼ぐ）
    public double UrbanConsciousnessBoost = 1.5;      // 都市pop の意識加速
    public double NewsConsciousnessFloor = 0.3;       // 1934拡張E3：意識のpress項の自由分を「内容の自由×紙の実在」の積へ＝floor+(1−floor)×NewsFill。1.0=旧式と厳密一致（保護弁）。0.3=新聞を読めない社会は自由でも意識3割
    // ★★★生活水準の参照点（2026-08-19・作者裁定）：不満は【水準】ではなく【低下】から生まれる。
    //   旧＝want = 1 − 生活水準（★水準そのもの）＝「ずっと貧しい国はずっと不満」＝徳川日本/清が常に爆発寸前になり、
    //   個別に「徳川パス温存」で抑え込んでいた。★参照点にすれば構造的に解ける。
    // ★★点火 2026-08-21（既定0→1.0）＝作者裁定「**失望**＝機構として正しいので存在するべき。露骨に壊れて調整困難なら休眠でよい」。
    //   A/B実測（世代減衰の上に重ねた差分・selfplay-batch 10）＝**壊れていない**：硬性ゲート全緑（破綻0/デッドロック0/異常0）・
    //   人口 27.1→**34.3**（+7.1・日本90%＝「ずっと貧しい国はずっと不満」が消えた＝徳川パスの安定化そのもの）・
    //   本国 +3.3・植民地 +2.5・法 +1.2・列強 +1.3・政体 ±0／⚠経済 32.5→22.5（−10.0＝記録して進む・破綻しない＞正しい挙動＞バランス）。
    public double LivingRefWeight = 1.0;              // 旧式と新式の混合比∈[0,1]。0＝want=1−生活水準（旧式）／1＝want=**失望**（参照点−生活水準）。
                                                      // ⚠ConsciousnessFromSchoolingStock と同じ混合の作法。
    public double LivingRefSpeed = 0.03;              // 参照点が今の生活水準へ寄る四半期速度（★半減期≒6年＝MilitancySpeed と同じ桁＝「暮らしの慣れ」）。
                                                      // ⚠LivingRefWeight=0 では未使用。
    public double MilitancySpeed = 0.03;              // 闘争度の緩和速度
    public double ParliamentSeatOnOpen = 1.0;   // ★2026-08-04（作者指摘「議会の存在感が薄い」）：開院時に議席を1回だけ確定する。旧＝選挙政体の PartySeats は最初の総選挙（16四半期後）まで全て0で、開幕の4年間は議会が法に一切効かない空席だった（1783年の英には1780年総選挙の議会が現に座っている＝初期化漏れ）。式は非選挙政体が毎期使っている SnapshotSeats と同一＝新しい判断を持ち込まない。0で旧＝空席（厳密恒等）
    public int ElectionIntervalQuarters = 16;         // 議会選挙の間隔（四半期）。16＝4年（自由な政体で与党が交代する周期）
    // 議会の力学（既存の正統性→保持力→政体遷移に信号を流す。ParliamentEnabled の国のみ＝較正不変）。
    public double PartyDominanceThreshold = 0.6;      // 一党支配と見なす議席シェアの閾値（これ超で多元性が崩れ始める）
    public double DominanceLegitimacyErosion = 0.05;  // 一党支配が正統性を削る強さ（支配＝多元的正統性の喪失→権威主義へ漂流）。**ストック意味論2026-07-10＝旧0.5（水準）×RegenRate0.02（平衡対応 erosion=regen×水準）＝四半期フローへ再スケール**
    public double DominanceCoupWeight = 2.5;          // 一党支配が与党の独裁形態（社会→プロ独裁/自由→ブルジョア独裁/保守→軍政）の引力点を押し上げる強さ。不安定国限定（下記ゲート）なので強くできる＝不安定な一党支配国でのみ独裁が引力点に
    public double DominanceInstabilitySatisfaction = 0.66; // 一党支配→独裁化（正統性侵食＋独裁引力）が働く平均満足度の上限。これ超（満足した安定国＝英0.87/米0.90）では立憲/共和の一党優位は独裁化しない＝経済危機の共和国（低満足）だけがワイマール型で独裁化
    public double ConstMonarchyErosion = 0.02;       // 立憲君主制：議会の反王党派（自由+社会の議席）が王冠の正統性を削る＝議会優勢→共和へ（君主の形骸化）。**ストック意味論＝旧0.2×regen0.02**
    public double ParliamentLawWeight = 1.2;          // 法案可決/スライダー律速に効く議席の重み（議席×党選好を NetSupport/OpposingPower に加算）。社会党多数→富裕ブロックの梯子を票で乗り越え参政権拡大＝選挙が法を動かす
    public double LandReformRentCap = 0.3;            // 土地改革：RGO地代（地主取り分）の上限（地代>0.3の国を再分配。小作0.5も自作0.3へ）
    public double SerfEmancipationRentCap = 0.5;      // 農奴解放：地代の上限（農奴制1.0→小作0.5へ。自作/小作の国＝既に0.5以下には効かない＝農奴国だけ解放）
    public double CornLawImportPenalty = 1.0;         // 穀物法：主食の輸入閾値への上乗せ（高関税相当＝輸入を阻む→国内パン高騰）
    public double WantWeight = 0.8;                   // 不満(1-充足)の闘争度寄与（満たされた階級は穏健＝改革派）
    // 倍率排除⑥b-2：MilitaryBurdenMilitancy（軍拡負担の闘争度直接加算・圧政>2500閾値）と MilitaryTensionReliefScale（緊張緩和）は撤去。軍の維持コストは財政連鎖→満足度経路へ集約
    public double PoliticalDistanceWeight = 0.25;     // 政治の空間モデル：意識×dist(POPの理想点, 現政体座標) の闘争度寄与（旧 VoiceWeight＝参政権ギャップの一般化＝4軸全体の乖離）
    public double GoldStandardIndThreshold = 3.5;     // AI挙動：金本位を**自力で**志向する工業化の下限（発展した交易経済の制度＝未発展では足枷の損が勝る。era は工業化から創発）。
                                                      // 【1.5→3.5・2026-08-21・銀本位点火の一部（4係数一括・Coefficients の銀本位墓標参照）＝1.5は前線が1793年に4カ国・1803年に16カ国越え＝金の早期氾濫の根。
                                                      //   3.5＝前線だけが自力で届く値（1853年前後）→残りは MonetaryPeerPullScale の交易網の引力が政治経由で運ぶ＝「英に引かれて雪崩」の形。
                                                      //   ⚠3.0は仏=銀のまま・ペルシャ=金と構成が崩れる（E2実測）。単独で戻さない＝銀の梯子と引力と一括】
    public double SuffrageReformThreshold = 0.5;      // AI挙動：大衆の闘争度がこれを超えると AI は参政権を AdultMale へ拡大（革命を改革で回避＝Reform Acts）
    public double FiscalStressBufferMonths = 5.0;     // AI挙動（監査2026-07-11 リ4）：財政逼迫の物差し＝月次義務（維持費+利払い+行政・軍装備請求権）の何か月分を安全水準とするか。国庫がこれを下回るほど逼迫度→1（旧＝絶対額50,000固定を53カ国へ一律適用＝小国が恒久破産モード・大国は無風の規模非中立）。義務教育の解禁は3倍水準（旧150,000と同比）
    public double TraditionalistLawGate = 1.0;        // ⚠**現在1.0＝live**（コメント是正2026-08-12：旧コメントは「0.0＝完全休眠＝一行も実行されていない」と書いていたが実値は 1.0 で、SelfPlay.ModernizationLawsGated が毎期これを読んでいる）。⚠**この注記は2026-08-19の実測で棄却された（旧文：「外圧(a)＝緊張>40 は鎖国の島国には恒久的に来ないため、日本は140年間 Religious のまま凍結する」）。**
                                                      // ★実測（eduprobe・seed1789）＝日本の緊張は **1788年29.2 → 1800年148.5 → 1853年198.8**。本ゲートは**1800年以降ずっと「通す」**（教義がMilitaristへ移るため）。
                                                      // ⚠幕府自体も1788〜1800の間に緊張>40 で倒れて Absolutist になっている。**凍結の原因は本ゲートではない。**
                                                      // ★★真因は別の2つ（docs/202608 の日本調査）：①**政体の参加軸cap**（Government.cs の PolityLeverRanges）＝幕府も絶対王政も参加軸0.00で
                                                      //   cap判定0.15に届かず、**1876年に参政権拡大の純支持が+0.01とプラスでも構造で否決**される／②**倒幕が空振り**＝ShogunateEnd の行き先（Absolutist）も参加軸0.00で参政権が1段も上がらない。
                                                      // ⚠この誤診が残っていると次の担当者が同じ場所を疑うので、訂正を明記する。外圧(b)（全球最強との軍事比較）は2026-07-09に「常時真で不発」として撤去済みで、残る脱出口は緊張>40 と 大衆闘争>0.5 の2本だけ。近接の技術差（黒船の本義）を測る条件が無い。（第2段2-3是正2026-07-27）。AI挙動（裁定2026-07-09・黒船動学）：伝統教義（旧支配層が支配・非軍国）のAIは**外圧なしの平時**には近代化法（教育法・参政権・女性財産権）を目標に置かない。外圧＝緊張>40（黒船）／存亡の脅威（軍比>SurvivalThreatRatio）／大衆闘争>0.5（内圧）のいずれか。幕府「稀だが残る」裁定の維持：高正統性の伝統体制がマンデート余白で自己近代化し全滅するのを防ぐ。外圧＝黒船が来れば近代化が始まる。経済目標は据え置き＝鎖国の幕府も経済は回す。0で旧挙動（休眠可能）
    public double SuffrageConcession = 1.0;           // ★2026-08-04：2.0→1.0（作者指示「参政権は固く」）。革命脅威下でエリートが参政権拡大に譲歩する強さ（trad/modern の反対 −1 に threat×これを加算）。旧2.0では**闘争度0.5で反対が完全に消える**＝平時の軽い不満で梯子が外れ、英1790/清1799に男子普通選挙が通っていた。1.0＝闘争度が最大に達してようやく反対が消える＝史実の改革法（1832/1867/1884）が要した「革命寸前の圧力」に対応
    public double ModernEliteSubCensusVoice = 0.3;    // 倍率排除②：制限選挙(Census)未満での近代エリート（ブルジョワ）の実効発言権。富の clout で票なしでも一定の声（議会は≥Censusでのみ走るので0.3/0.1の差は実害なし＝統合の安全弁）
    public double IdeologyVoiceFloor = 0.7;           // 倍率排除②：国民イデオロギー集計で参政権ゲート外の層が持つ最低寄与（公共圏の機運）。票はこの上に増幅して乗る。1.0=参政権無関係(旧)・0.0=完全排除(無参政権→自由化不能の罠)
    // ★★休眠（2026-08-19・日本調査で判明した全世界の問題）：識字の世代減衰を**世代交代のぶんだけ**に掛ける。
    //   ⚠現状は「学校が減ると**大人が字を忘れる**」形になっており、実測で**イギリスの識字も1853年0.841→1936年0.595**へ落ちている
    //   （★日本固有ではなく全世界＝識字を読む全ての量に効く）。⚠日本は1788年の開始時点で全階級が Literacy>EducationFill なので
    //   **1か月目から減衰が始まる**（初期識字と教育市場の供給力が world.json の時点で噛み合っていない）。
    // ★正しい形＝**識字は個人の一生ものであり、失われるのは世代が入れ替わるとき**。年齢コホート（OldShare＝老年の退出／
    //   ChildShare＝就学不足の子供）が既にあるので、減衰をその割合に掛けるだけでよい＝**新しい状態も定数もゼロ**。
    //   0＝旧式（全人口に掛ける）／1＝世代交代ぶんのみ。
    // ★★点火 2026-08-21（既定0→1）＝A/B実測（selfplay-batch 10・同一ソース）：経済規模 25.0→**32.5**（+7.5）・政体exact 41.3→43.9（+2.6）／
    //   法 65.8→61.7（−4.1）・領土本国 84.2→78.3（−5.9）・硬性ゲート緑。⚠帯の混合は記録して進む（破綻しない＞正しい挙動＞バランス）。
    //   ★決め手＝initcheck 実測で**48/61カ国が「支えの無い識字」を持ち**（教育市場の充足は開始直後0.00〜0.09）、
    //   旧式では世界中の識字が根拠なく溶けていた（英0.84→0.60も同根）。「大人が字を忘れる」は機構として誤り。
    public double LiteracyDecayIsGenerational = 1;
    // ★★休眠（2026-08-20）：**反動の担い手を「富の水準」から「地位の喪失」へ**。0で旧式（厳密恒等）／1で新経路。
    // ⚠**実測で反動が枯れている**（全断面で中央0.00・最大0.02）。原因＝旧式 `2.0 × 闘争度 × conserv` は
    //   **闘争度と富の両方が高いPOP**を要求するが、富裕層は満足度が高くて闘争度が立たず、闘争度の高い貧困層は conserv≈0
    //   ＝**この2条件は現物では両立しない**（積がほぼ常に0）。対して左翼側は `2.0 × 闘争度 × (1−conserv)` ＝
    //   **貧しくて不満**という実在する組み合わせなので共産主義は中央0.12まで立つ＝**不満が左にしか流れない構造**の正体。
    // ⚠さらに下流で **ファシズムの燃料が (反動 + 国民主義)** なので、反動が枯れるとファシズムも立たない（実測1934年で中央0.01）。
    // ★史実の反動の担い手は「脅かされた富裕層」ではなく**失った、あるいは失いつつある層**：
    //   ワイマールの国家人民党＝東エルベの農業経営者・俸給生活者・**旧軍将校**／ヴァンデの反革命＝**農民と司祭**／
    //   仏復古王政＝地方の小貴族と聖職者。⇒ **効くのは富の水準ではなく地位の喪失**
    //   （＝検証で確定した「アサーニャ1931は満額俸給を払ったのに最大のクーデタを招いた＝金ではなく地位・自律・名誉」と同型）。
    // ★代理は既存量：<see cref="PowerShares.PrivilegeIntact"/> の毀損（特権を失いつつある）。⚠新しい状態はゼロ。
    public double ReactionFromLoss = 0;
    public double RoyalistGate = 1.0;   // ★2026-08-19（作者裁定「天命とは別に、政治意識層の中に王権支持者を入れる」）：10 王党派の供給の強さ。
                                        // ★点火2026-08-29（夜間R16クラスタA/B batch30＝帯中立・破綻0）。0なら1行も走らず r[10]=0（9ファシズムと同じ作法）。
                                        // ⚠実測の根拠：王権シェアが全13断面・全64カ国で14〜18%の頭打ち＝「意識が上がる＝議会支持」の一本道になっていた。
    public double IdeologyAffinitySlope = 2.3;        // 倍率排除⑧：政体×思想の制度座標の距離→親和の傾き（親和=clamp(2−slope×距離,−1,2)）。大＝近い思想だけに高親和（政体引力が鋭い）・小＝なだらか。手書き9×9表の置換の主要較正ノブ
    public double PolityCoordDriftWeight = 0.4;       // 倍率排除⑧段階2：現政体の参加軸を実際の参政権へドリフトする割合（0=固定/段階1・1=完全に実参政権）。広い参政権の立憲は安定・狭い立憲は共和へ。較正中立（sweepは実参政権=建国参政権でドリフト≒0）
    public double ReformPressureBoost = 0.5;          // 外圧が改革派の力を増す（明治の追い風 §A-11）※§8 導出：均衡分布（エリート天井ゲートで元値に復帰）
    // 倍率排除⑥：政体別 erosion(絶対0.07/軍政0.22)を制度ギャップで一本化。意識ある社会が要求する代表/自由(RepresentationThreshold)と
    // 実効(Freedom＝参政権＋報道法から創発)の差が正統性を侵食する＝閉じた体制ほど・意識が高いほど削れる。代表的な体制(Freedom≥閾値)は侵食ゼロ。
    public double LegitimacyErosionRate = 0.0175;     // 制度ギャップ1単位あたりの正統性侵食（四半期フロー）。**ストック意味論2026-07-10＝旧0.175（水準）×RegenRate0.02**＝平衡 leg=1−erosion/regen が旧水準に一致（Absolutist Freedom0.20で平衡0.93=旧と同じ・到達に時定数1/regen≈12.5年の経路依存が乗る）
    public double RepresentationThreshold = 0.6;      // この Freedom 以上の体制は代表的＝意識による正統性侵食を受けない（旧 authMonarchy 以外 erosion=0 の連続版）。世界の技術水準閾値と同水準
    public double ReformMilitancyRelief = 0.5;        // 政体転換時に勝者・中立の闘争度が下がる係数
    // --- 革命ダイナミクス（便乗・失脚・軍事クーデター。仏革命の再現＋専制の不安定化＋政体の多様化）---
    public double BandwagonSensitivity = 0.45;        // 便乗の勢い＝(改革派+急進派)/保持力×これ（0..1）。革命が近いほど大衆が雪崩を打つ。低い＝雪崩が起きにくく自由化の臨界に達しにくい
    public double BandwagonWeight = 0.32;             // 勢いある運動が無学な民の政治意識を引き上げる強さ（教育に依らず＝専制の安定を崩す）。低い＝無学な大衆は容易には扇動されない
    public double BandwagonMilitancy = 0.35;          // 勢いある運動が大衆の闘争度を煽る強さ（無自覚な層ほど扇動される）
    public double DeposedMilitancySpike = 0.6;        // 革命で失脚した集団のPOPの闘争度の急騰（反革命＝国内不安定＝仏革命の再現）
    public double RevolutionTerror = 0.25;             // 政（タスクB恐怖政治）【採用2026-07-14＝0.25・急進革命限定版】＝exact38→39(歴代最良)・清13→11・首位交代58.7→61.7（0.15はexact36で劣る＝0.25採用）急進革命(共和/プロレタリア独裁/アナーキー)の勝利時のみ失脚した旧支配層をSize×これ粛清＋Savings×これ没収→大衆へ再分配。0=休眠。旧R5(全失脚革命に適用)は◎−4で保留したがタスクBは的を絞り再挑戦：革命で失脚した旧支配層（Closed＝貴族聖職／ProletarianDictatorshipではModernEliteも）のPOPを、特権剥奪に留まらず物理的に粛清・亡命でSizeのこの割合だけ縮小（仏革命の断頭台・ロシア革命の白系亡命）。人口台帳へ計上（保存）。0=既定＝死亡0で現行と厳密一致。決着1回あたりの累積粛清率
    // 内戦（拮抗した暴力革命・分離独立）：即フリップでなく数年の戦乱を経て決着＝生産低下・戦死・正統性低下。
    public double CivilWarDurationYears = 4.0;        // 内戦の継続年数
    public double CivilWarLandslideRatio = 1.8;       // 動員が圧政×これ未満＝拮抗→内戦／超＝圧勝で即フリップ
    public double CivilWarConscriptRate = 0.03;       // 内戦中の四半期徴集率（大衆→兵士）。労働喪失で生産減＋火器需要↑が創発（外科的penalty不要）。軍需は別途×2
    // 分離独立（§9-E拡張）：州の関税利害が国政策と乖離＋州の不満で分離圧力。中央の保持力（圧政×正統性÷人口規模）を超えると離脱→内戦（再統合戦）。稀に。
    public double SecessionPressureScale = 1.0;       // 分離圧力＝関税乖離(0..2)×州平均闘争度×これ
    public double CultureSecessionWeight = 1.0;       // #13 文化/宗教の異質性が分離圧力を増幅：首都と文化・宗教が違う州ほど分離志向↑（分離圧力 ×(1+これ×文化距離0..1)）。同一/未設定で0＝較正中立＝多民族帝国(墺洪/オスマン)の分裂を文化ラベルから創発
    public double SecessionThreshold = 1.43;          // 分離圧力(最大2)がこれ超＋中央の保持力を上回ると離脱（高め＝極端な乖離×極端な不満のみ＝稀）
    // ★2026-08-01の調整（0.00002→0.000005）。⚠**保持力の上限が分離の閾値に届いていなかった**＝実測で確定：
    //   正統性項 = Legitimacy/(1+これ×人口) の最大値は 英0.751・仏0.611・露0.618・**清0.125**。
    //   圧政項の最大 0.715 を足しても 英1.466・仏1.326・露1.333・清0.840 で、閾値 SecessionThreshold=1.43 に**届かない**。
    //   ＝百万の軍と完璧な正統性を持つ帝国でも、文化的圧力が1.43を超えれば州を1つも引き止められない＝保持の機構が飾りだった。
    //   実測の帰結＝英5州→1州・露15州→6州・清22州→1州（人口の99%喪失）。人口次元の「英×0.99」は**人口ではなく領土の話**だった。
    // ★0.000005 で正統性項は 英0.92・仏0.86・露0.86・清0.36 になり、圧政項と合わせて閾値を超えうる＝
    //   **強く正統な国は帝国を保てる／弱く正統性を欠く国は割れる**という本来の形になる。
    public double SecessionHoldPerPop = 0.000005;      // 中央の保持力＝圧政×正統性をこれ×人口で割る（大国ほど辺境を抑えにくい）
    public double CivilWarCasualtyRate = 0.003;       // 内戦の四半期死亡率（大衆・兵士。4年で約5%）
    public double CivilWarLegitimacyDrain = 0.03;     // 内戦中の正統性低下（四半期）
    public double MilitaryCoupWeight = 1.4;           // 兵士の政治力＝規模×(0.2+不満)×これ。保持力と市民運動の双方を超えると軍事独裁（新軍主義）。高すぎると市民革命を奪う
    public double WarExhaustionCoupBoost = 2.0;       // 厭戦→クーデタ：厭戦%に比例して兵士の政治力を増幅（厭戦軍が権力掌握＝戦争崩壊型の軍事独裁）。単一国較正は厭戦0で無影響
    public double IndustrializedTechThreshold = 0.25;  // 経路分類：工業化とみなす技術水準（§B-5。失敗0.1<これ<採用0.5）
    public double IndustrializedUrbanThreshold = 0.45; // 経路分類：工業化とみなす都市率（高め＝都市化単独では誤分類しない・技術主導）

    // --- 画一的な政体遷移（イデオロギー駆動）。支持(政体)=国民イデオロギー集計·親和。引力点-現政体>保持力で遷移 ---
    public double PolityInertia = 0.4;           // 保持力＝PolityInertia×正統性。支持差がこれを超えると遷移（正統性が高い体制は粘る・権威主義下で意識↑＝正統性侵食で倒れやすく）
    public double MilitaryCoupSupport = 0.6;     // 軍部の力（SoldierForce/保持力）を軍事独裁の支持に上乗せ（クーデタは銃が要る＝イデオロギーだけでない）
    // 窮乏チャネル（パンの蜂起＝1789）：意識（識字・教育）が低くても、窮乏で闘争度が暴動水準を超えた群衆は革命的脅威になる。
    // 史実の革命は識字でなく飢えが起こした＝意識ゲートとは別の経路。挑戦力（radical）に上乗せ。平穏な大衆（低闘争）には発火しない＝徳川パス温存。
    public double RiotMilitancyThreshold = 0.5;  // 群衆が暴動＝革命的脅威になる闘争度の閾値（これ以下は蜂起しない＝平穏な抑圧は留まる）
    public double DesperationChallengeWeight = 1.0; // 閾値超の怒り（窮乏）が radical 挑戦力に寄与する強さ（意識非依存＝飢えた群衆そのもの）。0.5では圧政を超えられず罠のまま＝1.0で権威国が蜂起で脱出
    public double DesperationConsciousnessGate = 1.0;   // 二重計上監査C1（2026-07-11）：窮乏チャネル×=(1−これ×Consciousness)＝高意識militantの二重計上を直交化（1で完全ゲート）。DesperationChallengeWeightの補償とセットで有効化。0で旧（休眠可）
    public double FiscalDefaultPanic = 0.8;      // 財政破綻（連合を養えない＝債務不履行）が信用を崩す強さ＝経済悪化の段階（信用収縮→恐慌→不満→政治）。外科的な政体フリップは廃止。FiscalEnabled時のみ
    // --- 国債（赤字の借金。国内＝資本家の余剰貯蓄でクラウディングアウト／海外＝開放度依存。焦げ付き→経済悪化、対外不履行→介入）---
    public double BondAppetite = 0.15;           // 資本家の余剰貯蓄のうち国債購入に回る割合（工場投資と食い合う＝クラウディングアウト）
    public double ForeignBondCapacity = 0.05;    // 海外の購入余力＝開放度(1-Tariff)×GDP×これ×金利誘引。海外債は対外資本流入（保存＝BaseMoney+CumulativeTradeFlow同時）
    public double BondRolloverFrac = 0.01;       // R9（国債の満期構造）＝**2026-07-23点火（C〜H中4）**：毎月ストックのうち満期到来し現行市場金利GovBondRateへ乗り換わる割合∈[0,1]。旧1.0=永久/浮動（金利変動が全ストックへ即時波及＝英3%コンソルの固定クーポンが再現不能）。0.01≈平均満期8年強＝コンソル（超長期）と短期債の混合の近似＝金利スパイラルの即時全額波及を緩和・高債務国の財政破綻が史実的に緩やかに
    public double BondBaseRate = 0.04;           // 国債の基礎金利
    public double BondRateDebtScale = 1.44;      // 金利上昇＝×(債務/年GDP)。債務が嵩むほど高金利（スパイラル）。財7単位フリップ2026-07-26＝旧0.12（月次GDP比）×12＝代数恒等
    public double BondRateDebtQuad = 0.0;        // 監査2026-07-05（F2）：国債金利の債務二次項＝×(債務/年GDP)²。高債務での非線形スパイク（買い手希少性）を表現。0=無効（現行の線形のみ＝厳密一致）。#17で有効化検討（有効化時は年GDP単位＝旧月次値の144倍相当）
    public double BondRepayFrac = 0.05;          // 国庫に余剰がある時に返済する債務の割合（健全国は減債）
    public double AusterityStartDebt = 0.2;      // 債務/GDP がこれ超で緊縮開始（借金がかさむほど弱者救済を削り逆進課税を上げる＝赤字を貸し手に響かない形で閉じる負のフィードバック）
    public double AusterityRange = 0.8;          // ここ幅で緊縮が0→満額（債務/GDP = Start+Range で弱者救済ゼロ・逆進課税が最大上乗せ）
    public double AusterityTaxHike = 0.5;        // 満額緊縮時に人頭税・消費税へ上乗せする逆進課税の幅（貴族免除の人頭税＝負担は弱者に集中）
    public double DevaluationCapFrac = 0.05;     // 四半期に切り下げ（インフレ税）で吸える総貯蓄の上限割合。超過赤字は underfunding（連合の薄給＝圧政減）で優雅に劣化＝構造的に過大な連合は経済を枯渇させず萎む
    public double FiatIssueFrac = 0.2;   /* リアリティ群点火2026-07-18＝不換シニョリッジ(インフレ税) */           // 不換シニョリッジ（fiat-expansion-as-haircut-not-issue）：赤字補填の切り下げのうち、popから取らず新規発行する割合＝マネーストック膨張(M↑→P↑)。CumulativeFiatIssuedに積みInvariantsのexpectedに算入。0で全額ヘアカット＝現行恒等
    public double DebtDistressRatio = 2.0;        // 債務/GDP がこれを超えると信用力が尽き新規国債が売れない（債権者は支払不能国に貸さない）＝債務の発散とスパイラルを断つ
    public double BondRateMax = 0.30;            // 国債金利の上限（年率）。これ以上は市場が値付けせず＝事実上の債務不履行（利払いを切り下げ/薄給で処理）
    // 国債二次流通（改修2026-06-28・金融改革①）：信認シグナルの内生化。BondPrice=BondBaseRate/GovBondRate（永久債＝利回り上昇で価格暴落）。切り下げ常習＝信認喪失で利回り高止まり、外資逃避と連動。
    public double BondRateDistrustScale = 0.06;  // 累積切り下げ/名目GDP比 が国債金利に上乗せ（信認の喪失＝切り下げ常習国は構造的に高金利・債券価格低迷）。0で旧挙動
    public double BondYieldFlightWeight = 1.5;   // 国債の利回りスプレッド(GovBondRate−BondBaseRate)が対外信用(CapitalMarket)を下げる強さ＝国債暴落→資本逃避→為替減価→さらに金利↑のバーリング危機ループ。0で旧挙動
    // === 借金ボタン（2026-06-22・自動国債発行を置換）：1回押す＝GDP×これ を借入＋1スタック。スタックは公共サービス支出に上限ペナルティ ===
    public double BorrowFractionOfGdp = 0.10;    // 借金ボタン1回でGDPのこの割合を借入（資本家貯蓄＋外資から調達＝保存）。1回=1スタック
    public double MaxBorrowStacks = 20.0;        // スタック上限。出費上限＝公共サービス支出 ×max(0,1−stacks/これ)。20スタックでサービス0%（＝もう借りても国が回らない）。返済でスタック減・返せねば のべくり
    // ソブリン・デフォルト（2026-06-23）：借入上限に張り付き返済できない国は信用が尽き**債務不履行**＝致命的ペナルティ（安易な逃げ道でない＝破滅）。
    public int DefaultTriggerQuarters = 8;       // 借入上限(MaxBorrowStacks)に連続でこの四半期 張り付くとデフォルト（≒2年の支払不能で破綻宣言）
    public double DefaultLegitimacyHit = 0.5;    // デフォルト時の正統性崩壊（→闘争度↑・革命リスク）。信用と威信の喪失
    public double DefaultMilitancyHit = 0.25;    // デフォルト時の大衆の闘争度スパイク（経済混乱→暴動）
    public int DefaultCooldownQuarters = 24;     // デフォルト後の借入禁止（信用回復まで＝6年）。この間は赤字を切り下げ/薄給で凌ぐしかない
    public double CrowdingOutWeight = 1.5;       // クラウディングアウト（金利チャネル）：政府の国債金利プレミアム(GovBondRate−基礎)×これ を民間投資のハードルレートに上乗せ。＝政府借入が民間投資を締め出す（高債務国で工業化↓・金本位の信用国は弱い＝条件付き）
    // ⚠**この較正の出所に注意**（2026-08-01訂正）：「既定圧政400で≈0.5」は BaseCoercion を独立に掃引する**単一国の較正世界**の数字で、
    //   多国シムでは圧政は兵数×即応度から出る（CoercionPerSoldier・2026-06-23の一本化）ので400は現れない。値の妥当性は多国側で測り直すこと。
    public double CrimeOrderPerPop = 0.8;        // 治安の必要圧政（人口あたり強度）。秩序＝Coercion÷(基準人口×これ)＝Coercion/800（既定圧政400で≈0.5＝平時は微小・不況/不満で発火）。0.4は圧政400で秩序1.0に飽和し犯罪が死んでいた→0.8で活性化
    public double CrimeBase = 0.01;              // 秩序が完全に崩れた時の月次窃盗率の上限（被害者の貯蓄比）
    public double CrimeMilitancyWeight = 1.0;    // 犯罪率に効く「貧しく不満な大衆」の重み（闘争度×不充足）
    public double CrimeUrbanWeight = 0.6;        // B-4：都市化（過密スラム・匿名性・相対的剥奪）が犯罪を増幅＝犯罪率×(1+これ×都市人口比)。19世紀ロンドン/パリのスラム犯罪
    // === テーマG（社会・不満・格差・犯罪）＝**大半が有効化済み**（CrimeSatPenalty/CrimeWealthFear/CorruptionLegitimacyErosion/InequalityMilitancy＝live・StrikeMilitancyThresholdの土台のみ残）。台帳訂正2026-07-12（監査 死22）===
    public double CrimeSatPenalty = 0.5;         // 犯罪→満足度の還流（crime-is-dead-end）：crimeRate×これ を地域全POPの満足度から減算（治安崩壊＝非物質厚生の毀損）。第(iii)段2026-07-09で0.5へ有効化済み
    public double CrimeWealthFearWeight = 0.5;   // 財産不安（theft-no-property-disincentive）：富裕POP(wealthRel>1)ほど犯罪被害の満足度減を強める＝『失う物を守る』反動を満足度経由でIdeologyへ。**0.5で有効化済み**（台帳訂正2026-07-12・旧注記「既定0」は誤り）
    public double CorruptionLegitimacyErosion = 0.015;// 腐敗→正統性侵食（corruption-only-fiscal-leak）：(1−AdminEfficiency)×avgConsc×これ をlegから減算＝意識ある社会ほど縁故主義を許さない。較正は行政財なしAdminEff=1で0。**ストック意味論＝旧0.15×regen0.02**
    // ★物理削除2026-08-21【墓標・再点火禁止】：WelfareTargeting（休眠0.0・D群却下2026-07-18）＝福祉フラット加算 WelfareSatComponent の困窮targeting配分。
    //   基質（WelfareSatBonus＝満足度への直接加算）が作者裁定2026-08-17/19で撤去されたため、配分係数だけ残しても対象が存在しない＝道連れで削除。
    public double InequalityMilitancy = 0.15;     // 格差→闘争度（no-inequality-relative-deprivation）：max(0,gini−中立アンカー)×これ を国一律で闘争度に加算（EthnicUnrestと同型）。第(iv)段2026-07-09＝定数アンカーでは開幕から系統押上げ（0.05でも梯子外しテストを壊す）→**初回実測ジニの自動アンカー（GiniNeutral<0）へ再設計し0.15で採用**（アンカー後も0.3は梯子外しを壊し0.15は保持＝bisect実測。#17のSearchで再訪可）＝格差の悪化分のみ不満化
    public double GiniNeutral = -1.0;               // 中立の基準ジニ。**負＝その世界の初回実測ジニを自動アンカー（World.GiniNeutralAuto・既定）**＝各国の初期格差を中立点に差分0で撹乱を断つ。非負＝固定基準（テスト用。較正世界の実測は0.0007＝ginidumpコマンド）
    public double StrikeProductionHit = 0.25;     // 本国の労働争議減産（no-graduated-unrest-stages）：組合容認かつ高闘争地域でstrikeIntensity×これ だけ操業停止。**0.25で有効化済み**（台帳訂正2026-07-12・旧注記「既定0＝不発」は誤り）
    public double StrikeMilitancyThreshold = 0.5; // ストライキ開始の地域平均闘争度の中間閾値（革命未満の争議段）。StrikeProductionHit=0なら土台のみ
    public double LaborUnionToleratedOutputMul = 0.95;  // 労働組合(容認)の工場出力乗数＝賃上げ/ストで▲5%（資本が反対する理由）。旧・スイッチ直書き0.95を係数化（H・値据え置き）
    public double LaborUnionControlledOutputMul = 0.98;  // 労働組合(統制)の工場出力乗数＝御用組合で▲2%。旧・スイッチ直書き0.98を係数化（H・値据え置き）
    // === テーマF（政治・近代化回路）===
    public double CorruptionFromOpacity = 0.25;   // 説明責任係数（corruption-only-funding-shortfall）：閉鎖性(低報道自由×低メリトクラシー)がAdminEfficiencyを割り引く。有効AdminEff×=(1−これ×(1−PressFreedom)×(1−Meritocracy))。0で恒等
    public double IncumbencyBias = 0.0;   /* D群却下2026-07-18＝休眠復帰 */          // 現職効果（elections-deterministic-plurality）：在任与党の議席に慣性を上積み。0で純多数決（現行恒等）
    // --- 政府・政策（介入レバー。スライダーは利益集団の力で律速して漸進）---
    public double PolicyBaseSpeed = 0.12;        // スライダーが目標へ寄る基本速さ（四半期）
    public double PolicyResistanceWeight = 4.0;  // 力ある集団の抵抗の強さ（速さ ÷ (1+これ×力)）
    // --- 役務（サービス財）の経済：教育者の生産性は法で切替（聖職者の宗教学校＝少人数しか教えられない＝供給希少）---
    public double ClergyEduProductivity = 2.0;   // 聖職者1人あたりの教育算出（宗教学校）。少＝下層に行き渡らず識字が低位で頭打ち（創発）
    public double TeacherEduProductivity = 5.0;  // 教師1人あたりの教育算出（公教育・義務教育）。供給≈需要で教師が食える価格になり、拡大は教師階級の成長（昇格）で起きる
    // --- 電化（電力＝稼働率ブースト。時代クランプなし＝発電・送電の価格が下がると採算が立ち電化の波が創発）---
    public double ElecPerOutput = 0.25;          // 産出1単位あたりの電力消費（電化を選んだ工場）
    public double ElecBoost = 0.3;               // 完全電化時の能力上乗せ（夜間操業・機械駆動）。買えた電力の割合に比例
    public double ElecLaborSave = 0.4;           // 完全電化時に労働力の投入が何割減るか（機械化＝人手の節約）
    public double LaborSaveRate = 0.25;           // 技術的失業（no-labor-saving-tech-unemployment）：機械化工場の労働投入の最大逓減率。実効労働係数×=(1−これ×機械化度)。0で電化以外の労働節約なし（現行恒等）
    public double LaborSaveIndHalf = 1.0;        // 機械化（労働節約）が半分に達する工業化度。飽和カーブで有界。LaborSaveRate=0なら未使用
    // RGO効率化（電化のRGO版）：作物→肥料／漁業→帆船／畜産→飼料／鉱山→工具。買えた率(EffFill)に比例して産出↑。
    public double EffPerOutput = 0.08;            // RGO産出1単位あたりの効率化材消費（profit-gateで割に合う時だけ買う）
    public double EffBoost     = 0.3;             // 完全充足時のRGO産出の上乗せ（肥料/飼料/漁船/工具が満たされた時）
    public double GridBuildRate = 0.1;           // 送電容量の不足分を月に何割ずつ敷設するか（投資家の残予算の範囲で）
    public double FillInertia = 0.25;            // 電化率(ElecFill)・効率化率(EffFill)が目標へ寄る月次速度（設備の慣性＝ゆっくり進み剥がれる）。旧・EconomyStep直書き0.25×2を集約（sweep対象化・DRY）
    public double ElecFillIrreversibility = 1.0; // **1.0点火済み（稼働中）**（第2段2-8是正2026-07-27：旧注記「#17で有効化検討」は点火後も残った嘘）。監査2026-07-05（E4）：電化の不可逆性＝設備ロックイン。0=無効（採算で毎期進退）・1で電化率は下がらない（投資済み発電設備は石炭安でも剥がさない＝史実の電化一方通行）。中間は下落速度を(1−これ)倍に減速。緩和は裁定待ち（史実では電化はほぼ不可逆＝現状も擁護可）
    // 蒸気動力（電化と完全に同型＝据付資本財）：原動機(蒸気機関)の発明後(SteamScale>0)、採算が合えば工場が石炭を焚いて稼働率↑（SteamBoost）。
    // 1789年は水車/畜力＝無ブースト・石炭を焚かない。蒸気の普及（≈1820s〜）は技術水準と石炭価格から創発（暦年ゲートなし）。電化が安くなると電力が蒸気を代替（(1−ElecFill)）。
    // 石炭需要は蒸気を採った工場にのみ立つ＝石炭価格＝工業活動の体温計（より忠実）／石炭ショックが費用→マージン→規模で蒸気産業に波及。EnergyPerOutput=0 or 石炭good非搭載で無効（較正中立）。
    public double EnergyPerOutput = 0.05;        // 蒸気動力化した工場の産出1単位あたりの石炭（燃料）消費。energyOnガード(石炭good搭載時のみ)で安全。0=従来(中立)
    public double SteamBoost = 0.3;              // 完全蒸気動力時の能力上乗せ（蒸気機関＝水車/畜力を超える出力。電化のElecBoostと対称）。買えた石炭の割合(SteamFill)に比例
    public double SteamTechOnset = 0.25;         // 蒸気機関が動力として採用可能になる技術水準（≈工業化開始 IndustrializedTechThreshold と同水準＝産業革命の動力転換）。これ未満は水車/畜力のみ＝石炭を焚かない
    public double SteamTechWidth = 0.5;          // onset から full 解禁までの技術幅（蒸気の普及帯。電化のAdvancedTechWidthと同役）
    // --- 女性・子供（構成属性。POP分割はしない）---
    public double FemalePartBase = 0.4;          // 女性の労働参加率の基礎（紡績女工・農婦・家事奉公＝19世紀の現実）。賃金保持(財産権)なしの構造的参加率
    public double FemalePartProperty = 0.7;      // 女性財産権法の下での参加率（自分の賃金を持てる＝働く誘因。労働供給+2割）
    public double ChildWorkFactor = 0.5;         // 児童労働の半人前係数（働く子供は0.5人分の労働力を算出）
    // 倍率排除④：労働供給の時間配分化（労働/教育/休息）。女性参加・児童労働の2値切替を、家計困窮(満足)・賃金保持(財産権)・就学(教育充足)から創発させる連続モデルへ。
    // 較正harness（教育財なし・法デフォルト）では retention=0・no-school で旧式に恒等一致＝較正中立（WorkHoursと同型）。創発は教育財のある実ゲームでのみ発現。
    public double WomenRightsFollowSpeed = 0.15;  // 女性財産権法→賃金保持(WomenWageRetention)の月次収束速度（法は離散だが社会的確立は連続）
    public double ChildLaborFollowSpeed = 0.15;   // 児童労働法→合法度(ChildLaborLegal)の月次収束速度（禁止は取締りで徐々に浸透）
    public double FemaleNeedWeight = 0.5;         // 家計困窮(1−満足)が女性の追加就労を押し上げる強さ。賃金を保持できる(retention)時のみ効く＝困窮しても賃金を取られるなら formal 労働に出る誘因がない
    public double FemaleLitFloor = 0.6;           // 賃金保持なし時の女性識字の実効係数（女子が就学を後回しにされる＝人口転換の出生率項。retention=1で1.0＝旧 WomenPropertyLaw?1:0.6 の連続版）
    // ★修正予約7（2026-07-13）の係数 DecoupleWomenSuffrage は**撤去**（2026-08-10・女性法の統合）。
    //   「財産権と参政権を別の法にするか」というスイッチは、財産権→教育権→選挙権を1本の梯子（<see cref="WomenRightsLaw"/>）にした時点で
    //   意味を失った＝分離は**段の並びそのもの**が恒久的に保証する（脱結合=1.0 の挙動が構造として焼き込まれた形）。
    //   史実（1914年に女性参政権を持つ主要国は事実上ゼロ・多くは1918-1920+）との整合＝最上段だけが憲法級＋男性普通選挙を前提、が担う。
    public double AgingYears = 16;               // 子供→生産年齢のコホート送り年数（出生が労働力になるまでの時差＝投資は一世代後に実る）
    // ①年齢コホート（老年）：生産年齢→老年→死。Phase1は OldShare を追跡するのみ（Size/ChildShareは不変＝較正中立）。Phase2の年金法(PensionLaw)が老年を支援。
    public double WorkingYears = 45;             // 生産年齢→老年のコホート送り年数（≈15→60歳の就労期）。長いほど老年比率は低位
    public double OldMortalityWeight = 3.0;      // 老衰：成人の死亡のうち老年に厚く配分する重み（働き盛りより死にやすい）＝OldShareを現実的に有界化。Size総量は不変（既存の死亡の内訳のみ＝較正中立）
    public double OldShareMax = 0.15;            // 老年比率の上限（成長期＝死亡0で老年が貯まりすぎるのを防ぐ安全弁＝19世紀の高齢者比率の現実的天井）。Phase1の近似（物理的な老年死亡＝Size減はPhase3で較正再走）
    public double OldLaborFactor = 0.75;   /* 【史実方向2026-08-08＝0.6は硬性赤（経済−7.5）→0.75測定・旧0.92 */   /* リアリティ群点火2026-07-18＝人口転換(穏やか) */          // ①Phase3：老年の労働参加率（0=完全引退〜1=フル稼働）。（M8点火試験2026-07-13＝0.5でbatch破綻1/30＋exact35に悪化／**再計測2026-07-15＝0.85でbatch破綻0・calib24-24-24堅持だがexact41→39（−2）＝高齢化がexactを単調に削る（1.0→41/0.85→39/0.5→35）。唯一 清覇権を抑制(12→8・仏11勝で競争化)したがexact優先で却下。清抑制を優先するなら0.85が選択肢（要ユーザー裁定）。専用の経済再較正なしにexact41維持と両立不能**）（EconomyStepの労働供給で (1−OldLaborFactor)×OldShare を成人から差し引く）。（M8点火試験2026-07-13＝0.5+FertilityAffectsBirthsOnly=1.0でbatch破綻1/30＋exact38→35/◎22→19悪化＝#17 balance再較正が要る確定＝休眠へ差し戻し・要専用Calibration.Search）。#17の較正再走で <1 に下げ、高齢化→労働力縮小→成長鈍化（人口転換後の扶養比率上昇）を有効化
    // 年金法（①年齢コホート Phase2）：老年人口への給付。デフォルト（年金なし）＝0で較正中立。
    public double PensionCostRate = 0.8;         // 年金「十分」時・老年1単位あたりの月次給付（国庫→老年）。高齢化が進むほど財政負担＝福祉国家のジレンマ
    // ★物理削除2026-08-21【墓標・再点火禁止】：PensionSatBonus（旧0.10→8/17に0）＝年金の満足度フラット加算（Region.PensionWellbeing・読み手ごと削除）。
    //   作者裁定2026-08-17「年金を現金給付へ」＋2026-08-19「満足度は買えたかのみ」＝年金の効果は現金給付（PensionCostRate＝国庫→老年→消費→生活水準）だけが担う。
    public double EduPerChild = 0.2;             // 子供1人あたりの教育の必要量（×子供比率0.3＝従来の人口あたり0.06と一致）
    public bool FertileWomenBirths = true;      // ①Phase3：出生を「出産可能女性プール」比例にする。**true＝有効化済み**（台帳訂正2026-07-12・旧注記「既定false＝dormant」は誤り）。各popの出生量を Size×(1−ChildShare−OldShare)×FemaleShare/InitialFertileShare に律速＝徴兵で男が抜け女性比率が上がっても/老人だらけでも出生が構成に応答（失われた世代の伝播）。net（ロジスティック）は不変＝人口保存
    public double FertilityBase = 1.0;           // 出生率の基礎倍率（無学の社会＝従来の較正値そのまま＝中立）
    public double FertilityLitSlope = 0.55;      // 女性の識字で出生率が**下がる**幅＝人口転換の因果（女子教育→少子化。多産側の加速は医療＝死亡率低下が担当）
    public double FertilityFloor = 0.5;          // 出生率の下限（先進社会でも人口は緩やかに増える）
    public double FertilityLitOnset = 0.1;       // 出生率が下がり始める女性識字の開始点（初等識字は出生率に効かない＝中等教育から。実証準拠）
    public double FertilityIncomeSlope = 0.15;   // 所得/発展（工業化度）で出生率が下がる幅（B-4）＝都市化・所得上昇の少子化。識字とは別の経路で、死亡率低下の後に遅れて効く（工業化は緩やかに育つ＝二段階の人口転換）
    public double CrudeBirthRate = 0.035;        // 粗出生率（年率・19世紀の実証値≈3-4%）。×出生率倍率で子供が補充される（純増とは独立＝構成のみ動かす。子供比率の均衡≈出生率/(出生率+1/16年)≈0.2-0.36）
    // === 人口忠実度ラウンド（2026-08-21）＝「英が増えず（×1.68・帯2.6-4.3）仏が増えすぎる（×2.39・帯1.25-1.7）」の構造修正 ===
    // 実測診断（popprobe s1）：全国とも Q100 で pop/capacity≈1.0 に張り付き＝**成長は100%扶養力天井が決める**。
    // FertilityAffectsBirthsOnly=1.0 点火（2026-07-27）以降 netFertility≡1 ＝出生率倍率（人口転換の全機構・係数5本）は純増に一切効かない
    // （英は Q100 で出生率が下限0.5に達しても帰結ゼロ）。少子化した国が天井より下で止まる経路が存在しない＝仏の早期出生低下が構造的に無力。
    // A/B（selfplay-batch10・同一SOURCE 37f6bfe9…・基線=人口18.6%）：F3単独28.6 / F1単独27.1 / F1+F3=24.3 / F1+F4+F3=24.3
    // ＝**合成が単独に劣後（F1×F3の干渉）**→ F3のみ点火・F1/F2/F4は休眠温存（詳細=docs/202608/20260821_人口の史実度_完了.md）。
    public double FertilityEquilibriumWeight = 0.0;   // 【休眠・単独A/Bは+8.5pt】人口転換の**均衡**結合：ロジスティックの均衡点を capacity から (1−これ×max(0,1−fertility))×capacity へ。
                                                      // 出生率が下がった国は扶養力の天井**より下**で人口が止まる（出生=死亡の均衡＝仏の1.45×の物理。死亡側は不変＝人7の解消を壊さない）。
                                                      // 単独0.5＝仏20→40%（×1.90）と日/西/葡改善・代償=英×1.49/清×0.74。F3(live)との同時点火は実測で劣化（24.3<27.1）＝#17較正再走まで休眠。
                                                      // 0で (1−pop/cap) と厳密同値（1−0×…＝1.0はIEEE754で正確）。fertility≥Floor>0 なので max は非負有界＝NaN経路なし
    public double FertilityLandDivisionSlope = 0.0;   // 【休眠・未点火】分割相続の出生抑制（ナポレオン民法典＝仏の人口転換早発の標準的説明）：土地改革（LandReform法＝小土地所有の創出）が
                                                      // 進んだ国は自作農が土地の細分化を避けて出生を絞る。fertility −= これ×(int)LandReform/2（None=0/Limited=0.5/Full=1）。
                                                      // 既存の較正済み法状態のみを読む（国名分岐なし・年号なし）。⚠実測（popprobe s1）＝**英AIが1808年までに土地改革Fullを通す**（帯期待=None）
                                                      // ＝現行の法挙動では英仏を同率で叩きコントラスト不発→法忠実度の是正後に再評価。0で厳密恒等
    public double DoctorHealthcareSubstitute = 0.5;   // **2026-08-21点火（単独A/B＝人口18.6→28.6%・英×1.73→1.95[0→10%]・日30→80%・西10→30%・破綻0/10・他次元ノイズ内）**
                                                      // 市場医療の代替（英の私的医療経済）：国家医療チャネル healthcare（社会保障×識字で律速＝福祉なき国は識字と医者が居ても0）を、
                                                      // 実医療財の消費 doctorCare（HealthFill＝既に較正済みの実体経済）×これ で**下から**支える＝max(healthcare, これ×doctorCare)。
                                                      // 19世紀の死亡率低下は福祉国家の前に市場の医者・種痘で始まった（英 doctorCare 0.53 vs 仏 0.07＝実測 Q100）。0でゲート不読＝厳密恒等
    public double FertilityIncomeSurvivalGate = 0.0;  // 【休眠・合成でのみ測定＝干渉源】所得少子化の因果順序（人口転換の定説＝「子が生き残るようになってから産み控える」）：FertilityIncomeSlope の項に
                                                      // ×((1−これ)+これ×min(1,healthcare)) を掛ける＝死亡率低下（医療）が実現した国でだけ所得少子化が進む。
                                                      // 既存コメント自身が「死亡率低下の後に遅れて効く」と意図を明記しながら、実装は avgInd（開幕バーストで全国+2.0）を直に読み
                                                      // 全国の出生率を1808年までに床へ叩き落としていた（英は開幕から0.5固定＝ヴィクトリア朝の高出生と正反対）。
                                                      // ⚠F1と同時に立てると fertility を引き上げて F1 の有効成分（仏・日の抑制）まで打ち消す（C=24.3<B=27.1）＝清の保護（0.74→0.93）にだけ効いた。0で乗算1.0＝厳密恒等
    public double FamineMortalityConcentration = 3.0;  // 飢饉死の困窮層集中度。死亡の配分重み＝規模×(1+これ×(1−FoodFill))＝食料不足の層ほど多く死ぬ（地主/資本家は生き延びる）。0＝旧式（規模一律按分・中立）
    public double FamineDeathFillFloor = 0.8;          // 第4段4-5点火（2026-07-27）：飢饉死集中の絶対水準ゲート＝食料充足がこれ以上のpopは飢饉集中の対象外（重み1.0）。旧・連続(1−ff)重みは平均をわずかに下回るだけの州に恒常的な偽陽性の超過死亡を配っていた。1.0で旧恒等。#17較正2026-07-28：0.9→0.8（0.9は限界的な州まで集中対象＝総政変+49の主因・真に飢えた州へ絞る）
    // 局地飢饉（地域別・相対的剥奪）：国の人口トレンド（DemographicStep）はそのまま、**国平均より食料が乏しい州**にだけ超過死亡を上乗せ＝アイルランド型の局地飢饉。
    // 月次超過死亡＝これ×(国平均FoodFill−州FoodFill)×州人口。1州なら州=国平均で不足0＝発火しない＝較正中立。0で無効。
    public double RegionalFamineMortality = 0.025; // 相対的不足1.0あたりの月次超過死亡率（不足0.4で≈1%/月＝数年で深刻な人口減）。複数州ナラティブでのみ発火
    // 作物病虫害（年次・専用RNG＝主系列を乱さない）：病害に弱い作物（ジャガイモ/葡萄/小麦/米/トウモロコシ）に稀に胴枯れ。
    // その作物の産出が数年落ち、栽培州で局地飢饉（アイルランドのジャガイモ胴枯病1845型・葡萄フィロキセラ）。天候(緯度)の悪いロールと積算＝重なれば産出ほぼ0。
    // 病害は good id 別（作物固有）＝栽培地から空間相関が創発（地域独立ロールでない）。較正の合成食料(id 0)は非対象＝中立。
    public double CropDiseaseChance = 0.02;        // 病害に弱い作物1つあたりの年次の胴枯れ発生確率（健全時のみ）。5作物で年≈10%＝稀に大不作
    public double CropDiseaseSeverity = 0.3;       // 胴枯れ時の作物産出倍率の基準（×0.5〜1.5の揺らぎ＝0.15〜0.45へ激減）
    public double CropDiseaseRecovery = 0.4;       // 病害からの年次回復速度（CropHealth→1.0へ。0.4で胴枯れは約4年で癒える＝多年飢饉）
    // 緯度帯（気候帯）の天候（②集計粒度・国跨ぎ）：同じ緯度帯の国は一緒に不作（欧州一帯の干ばつ/冷夏）。MultiNationSim が年次ロール（専用RNG）。
    // 各国の HarvestFactor（自前の局地天候）と積算＝帯と国の悪い目が重なれば大不作。さらに作物病虫害(CropHealth)と三重に積算しうる。単一国（較正）は MultiNationSim 非走行で WeatherBandFactor=1.0＝中立。
    public double WeatherBandVariation = 0.12;     // 緯度帯天候の振幅（±12%＝帯全体の豊凶）。HarvestVariation（国の局地天候）に上乗せ
    public double WeatherBandSize = 15.0;          // 緯度帯の幅（度）。15度ごとに同じ気候帯＝近い緯度の国が一緒に不作
    // 疫病（B-4・コレラ等）：過密×不衛生の地域で確率的に発生し人口を削る（死亡スパイク）。専用RNG系列で主系列（豊凶・鉱山・pop意思決定）を乱さない＝較正/Stage3は疫病の死亡効果のみで変わる。
    public double EpidemicChance = 0.18;         // 疫病の年次発生確率の基礎（×脆弱度）。脆弱度＝過密(都市化)を工業化の衛生整備で割り引いた残り
    public double EpidemicSanitationHalf = 1.5;  // 衛生整備の飽和スケール：工業化度がこれで疫病脆弱度が半減（sanit=工業化/(工業化+これ)）。完全には消えない＝発展国でも疫病は稀に起きる
    public double EpidemicSeverity = 0.06;       // 流行時に地域人口が失う割合の基礎（揺らぎで0.5〜1.5倍）。衛生・医療の価値を高める
    // === テーマC（疫病の完成）===
    public double EpidemicSanitationWeight = 0.6; // 致死率を工業化proxyから実衛生財(InfraFill+石鹸+電化)へブレンド（epidemic-ignores-built-sanitation）。0で旧proxy厳密一致。>0で上下水道投資がコレラ致死を下げる(スノウ)
    public double EpidemicVulnConcentration = 0.5; // 疫病死を脆弱層へ集中（epidemic-uniform-age-class-mortality）：重み=Size×(1+これ×(ChildShare+OldShare+(1−食料充足)))。0で全階級一律(現行)・総死亡量は保存
    // 疫病の伝播（コレラの世界的流行＝交易路・近接で運ばれる）。発生国は EpidemicContagiousYears 年だけ感染源になり、近接＋交易接触で未感染国へ飛び火。単一国較正は伝播相手なしで無影響。
    public int EpidemicContagiousYears = 3;      // 発生後に感染源であり続ける年数（この間は他国へ伝染しうる）
    public double EpidemicTransmitChance = 0.35; // 完全接触（隣接の感染国）から1年で伝染する基礎確率
    public double EpidemicTransmitRange = 6000;  // 近接伝播が効く首都間距離（kmこれ以内で陸路接触・遠いほど弱い）
    public double EpidemicTradeTransmit = 0.6;   // 交易/港の接触経路の重み（両国の交易開放度の積＝海路のコレラ。陸の近接と最大を取る）
    public double EpidemicWarTransmit = 0.85;    // 戦争＝距離に依らない強制的な濃厚接触（軍営・前線・補給線・復員兵）＝最強の伝播経路（スペイン風邪1918型）。交戦国間で蔓延

    // --- 需要の階層（エンゲルの法則）と固執資材（§C 恐慌の社会的増幅）---
    public double DailyNeedWeight = 0.5;         // 日用品の満足度への重み（生存＝主食1.0が基準。腹が満ちていれば日用品の不足は半分の痛み）
    public double LuxuryNeedWeight = 0.2;        // 贅沢品の重み（買えなくても暴れない。ただし上流の体面には効く＝満足度経由）
    // 留保賃金（賃金の下方硬直の創発源）：賃金は留保賃金（労働者が慣れた賃金）を下限に動く。留保賃金は賃上げに速く（Rise）追従し賃下げに遅く（Fall）追従＝「慣れた賃金より下では働きを引き上げる」非対称が下方硬直を生む（固定倍率0.25を排除）。Fall=0.25/Rise=1.0 は旧 WageStickiness と挙動同値（較正温存）。
    public double ReservationWageFall = 0.25;    // 留保賃金が下方の目標へ追従する速度（小さいほど賃下げに抗う＝下方硬直が強い）
    public double ReservationWageRise = 1.0;     // 留保賃金が上方の目標へ追従する速度（賃上げ＝新しい生活水準へすぐ慣れる）
    public double UnionWageRiseBoost = 0.5;      // 組合の賃金交渉（no-monopsony-wage）：組合厚生(LaborWellbeing代理)1.0あたり留保賃金上昇速度に上乗せ＝賃上げに速く賃下げに抗う。0で賃金水準への組合効果なし（現行恒等）
    public double PriceFlowDailyDiv = 30.0;      // 日次価格形成の速度配分（月次係数÷これ）。30日積分が従来の月次1回にほぼ一致＝較正温存（三層時計の鼓動）
    public double UnemploymentMilitancy = 0.4;   // 倍率排除⑥b-2：失業の**非所得成分（職の無さ自体の怒り＝尊厳/規律の喪失）**のみ。所得成分(失業→消費↓→満足↓)は WantWeight×(1−Satisfaction) が既に拾う＝旧0.8は二重計上。係数を割り引いて再較正
    public double WarWearinessMilitancy = 1.0;   // 厭戦（対外戦争の消耗）→闘争度入力。旧：イデオロギーへ階級分岐で直接加点（Ideology）を撤去し、闘争度経由で既存の mil 項（閉鎖→反動/大衆→左）が自然に拾う。較正は we=0 で不活性＝中立。監査2026-07-11（二3）：Diplomacy側の月次直接加算の一本化に伴い 0.5→1.0（総厭戦圧のおおよその水準補償＝唯一の経路になった分を目標項で持つ）
    public double WarMilitancyViaTarget = 1.0;   // 監査2026-07-11（二3）：1＝厭戦→闘争度を Politics の目標項に一本化（Diplomacy の月次直接加算 WarMilitancyRate/WarExhaustionMilitancy を不発化）。0＝旧の二重経路。クーデタ側の明示乗数（WarExhaustionCoupBoost）は戦争崩壊型の設計レバーとして残置＝再較正時の点検対象

    // --- 転職（昇格・転落）。閾値＝国民平均の1人あたり貯蓄に対する倍率＝経済規模で自動スケール ---
    public double ClergyFloorShare = 0.002;      // 聖職者の下限（地域人口比0.2%）。世俗化で没落しても教会は消えない

    // --- 植民地POP（現地住民の実体）と独立 ---
    public double ColonialPopScale = 500;        // 人口ウェイト→住民数の換算（ベンガル8→4000単位=400万・代表スケール）
    public double ColonialPopGrowth = 0.0008;    // 住民の月次成長
    public double ColonialPayShare = 0.3;        // 採取費のうち現地住民の手に渡る分け前（残りは中抜き＝対外消失。搾取の度合い）
    public double ColonialExploitMortality = 0.002; // B-4：搾取×(0.5+不満)が住民の死亡を高める＝搾取が成長を上回ると人口減（ベンガル飢饉型の負ループ。人口減→産出減→…）
    // 植民地の過伸展（最終調整2026-06-29・ユーザー指示「覇権が現れづらい仕組み」）：行政・駐留・制海の限界で、保持能力（基礎＋軍事力×係数）を超える植民地は AI が新規に獲得しない＝
    // 最多保有国（覇権）の植民地獲得だけが頭打ちになり、植民地スコアの独占が緩む（少数しか持たない挑戦者は無傷＝恐慌脱植民地化のような逆効果がない）。帝国過伸展(Kennedy)の実体化。既定0で無制限＝旧挙動。
    // ※植民地の過伸展キャップも逆効果（挑戦者＝植民地保有国の唯一の武器を奪い覇権が経済力で勝つ）＝既定0で無効化（撤回）。覇権抑制はキャッチアップ＋資本破壊＋過熱で行う。
    public double ColonialSpendRate = 0.08;      // 住民の蓄えが本国財の購入（捕囚市場）に向かう月次率＝財布の実体
    public double ColonialLiteracyGrowth = 0.0006; // 開発（産出率）との接触で識字が上がる速さ＝教育された植民地ほど独立を求める
    public double ColonialMilitancyGrowth = 0.0023; // 不満の成長（×搾取×(0.3+識字)）。0.01→0.003→0.0023＋独立閾値0.85。
    // 閾値超えは「崖」（0.0022で0回／0.0025で30回）。0.0023で125年＝独立11回（5シード安定）＝19世紀は概ね帝国の時代、終盤に発達した大植民地のみ少数が離反。
    public double ColonialMilitancyDecay = 0.0005; // 不満の自然減
    public double ColonialUnrestSupplyHit = 0.5;   // 不満1.0で植民地の産出が半減（怠業・反乱）
    public double ColonialHoldScale = 1500;        // 本国の抑え＝軍×即応度×これ。圧力（人口×不満）がこれを超えた大植民地は独立（米独立戦争の構図）。※巨大植民地では人口×不満が抑えを大きく超え非拘束＝独立回数の制御は不満成長率で行う
    public double ColonialIndependenceMilitancy = 0.85;   // 独立の最低不満（これ未満では圧力があっても離反しない）。0.7→0.85＝離反のハードルを上げ脱植民地化を抑制
    // --- 植民地の州昇格（2026-08-09・作者裁定2026-08-08「植民地州昇格＝実装」。設計原典＝docs/202607/20260731_植民地のラベル化_部分完了.md §3-3d）---
    // 昇格の決め手は「誰が住んでいるか」＝入植者の多数（作者裁定2026-07-31＝閾値0.5・降格なし・自動）。経済価値では決めない（インドは最も価値ある植民地で最後まで昇格しなかった）。
    // 入植の物理＝本国の大衆（農民・労働者）が渡航費（距離減衰）とマラリア（キニーネ鎮静率）に律速されて移住＝カナダ/豪は入植者が多数になり昇格・ベンガルは原理的に昇格しない。
    // ★★植民地の州昇格（2026-08-26・作者裁定「植民地を本物の場所にする」）＝(1)の本体。
    //   ⚠発見＝植民地は Region ではなく Power.ColonyList の帳簿行で、市場も生産者も住民の買い物も持たない。
    //     砂糖・茶は「植民地から来る」のではなく**持ち主の首都州で作られている**（Region.ColonialResources）。
    //     だから植民地は交易に参加できず、BilateralMarket は IsColonial 財を丸ごと除外している（TradeColonialGoods=0）。
    //     地図の空白を埋めるべき102地点のうち**61地点が植民地の中**＝州として存在しない土地である。
    //   ★機構は新設しない＝入植者が過半になったら州へ昇格する既存の経路（Simulation.PromoteColonyToRegion・
    //     ColonyPromotionTests で検証済み）を、**開始時点で全植民地へ適用する**だけ。人口・蓄え・資源賦存・気候ゲート・
    //     保存の記帳は既に書かれている。格は Colonial のまま（議会代表なし・維持費あり）＝Integrated への自動昇格は従来どおり残る。
    //   ⚠0＝1件も昇格しない＝厳密恒等。
    //   ★点火2026-08-26：実測（batch5）＝破綻0/デッドロック0/異常0/**ハーネス不合格0**・exact49%/near81%（基線と同等）・州209→245。
    //     ⚠TradeColonialGoods と**対で**点火する（植民地財の交易解禁の前提が「植民地が自分で産む」こと）。差し戻しは両方を0へ。
    public double ColoniesAreRegions = 1.0;
    public double ColonySettlerRate = 0.00015;       // 入植の月次流量係数（本国の自由な大衆の総数×これ×距離減衰×マラリア鎮静率が各植民地へ移住）。0＝入植なし＝昇格も発火しない＝厳密恒等（休眠マスター）。0.00015＝英の対植民地移住が年5〜6万人規模（史実の19世紀英移民10〜20万/年の下側）＝点火測定値2026-08-09
    public double ColonyPromotionCoreShare = 0.5;    // 昇格に要る入植者比率（過半数・作者裁定2026-07-31）。米準州/シベリア/自治領＝入植者多数が一般則（アルジェリア型＝欧州系1割での統合は選挙権差別が前提の特例＝再現しない）
    public double ColonyPromotionMinPop = 60;        // 昇格に要る総人口（1単位=1000人）＝北西部条例1787「自由人口6万人で州昇格を申請できる」の一次データ
    // 恐慌の脱植民地化（最終調整2026-06-29・ユーザー選択「破産で植民地喪失」）：本国が深い恐慌（GdpDrawdown 閾値超）に陥ると、財政・軍が崩れ遠方植民地への grip(hold) が失われ、
    // 植民地不満も煽られて離反しやすくなる＝スペイン帝国がナポレオン危機で米州を失った史実型。覇権の構造的優位（植民地）を大恐慌が削る経路。既定0で恒等＝較正中立。
    // ※恐慌の脱植民地化は逆効果（恐慌は経済の脆弱な挑戦者の植民地をより奪い覇権の相対優位を拡大）＝既定0で無効化（撤回）。覇権の植民地独占は過伸展(下記)で抑える。
    // --- 商人（流通・貿易の仲立ち）---
    public double MerchantMargin = 0.04;         // 小売・問屋の取り分（消費者の購入に上乗せ→商人の収入）。商業の規模＝商人の富
    public double MerchantTradeMargin = 0.05;    // 国際交易の仲介料率＝取扱高（輸入額＋輸出額）に掛かる手数料。商人の貿易収入は黒字の固定割合でなく「捌いた量」に比例（純流入を上限にクランプ）
    // === テーマJ（関税戦争・公害）===
    public double TariffRetaliation = 0.5;       // 報復関税（tariff-no-strategic-retaliation）：相手の対自国関税の超過分に比例して自国関税目標を上げ/友好低関税国に下げる偏倚。0で偏倚なし（現行恒等）。多国かつ>0でのみ発火
    public double TariffReactionMax = 0.25;      // 報復/相互低減で偏倚させ得る上限(±)。TariffRetaliation=0なら無効
    public double PollutionCapacityWeight = 0.15; // 工業化の環境外部性（no-environmental-pollution-externality）：capacityに −これ×都市化×avgInd×(1−衛生) を加算＝工業都市の公害超過死亡。上下水道で緩和。0で従来完全一致

    // --- 税制の拡張（行政力でアンロック・実効性もスケール）---
    public double PollTaxRate = 0.15;            // 人頭税スライダー1.0時の1人あたり月額（労働者の月収2〜3に対し約5〜7%＝重い）
    public double LandTaxAdminGate = 0.1;        // 土地税のアンロックに要る行政力（粗い検地台帳＝近世国家の主財源・年貢/タイユ）。低い＝確立した国家は序盤から課税できる
    public double IncomeTaxAdminGate = 0.75;     // 所得税のアンロックに要る行政力（所得査定機構＝19世紀の発明）。実効性もこの比でスケール
    public double AdminNeedPerPop = 0.04;        // 人口1単位あたりの行政の必要量。官僚・予算が足りないと AdminFill<1＝汚職
    // --- 社会移動（昇格・転落）：閾値は地域の1人あたり平均貯蓄に対する倍率＝経済規模で自動スケール ---
    public double CapitalRiseThreshold = 8.0;    // 中流→資本家の昇格閾値（平均の8倍の資金）。転落閾値と離す＝発振防止
    public double CapitalRiseRate = 0.01;        // 中流→資本家の四半期移動率
    public double UpperFallThreshold = 0.8;      // 上流（貴族・資本家・聖職者）→中流の転落閾値（平均的市民より貧しい上流＝没落。高くしすぎると身分ごと溶ける）
    public double UpperFallRate = 0.02;          // 上流→中流の四半期転落率（恐慌で貯蓄が溶けると大量転落）
    public double MiddleFallThreshold = 0.4;     // 中流→下層の転落閾値（平均の4割を切る＝職が無い専門職）
    public double MiddleFallRate = 0.03;         // 中流→下層の四半期転落率
    // 破産（貯蓄が枯渇し信用で延命されている＝慢性赤字）の所有者は速やかに転落させる。緩やかな通常転落(2-3%)では
    // 信用の底打ち（毎月0に戻す）に負けて破産プールが滞留し LossFinanced が膨らむため、破産者だけ高い率で抜く。
    public double InsolventThreshold = 0.10;     // 貯蓄/人 が 平均×これ 未満＝事実上の破産（信用延命中）とみなす
    public double BankruptcyFallRate = 0.15;     // 破産した所有者（資本家・職人）の四半期転落率（緩やか転落より速く抜ける＝ゾンビ延命を断つ。0.25は江戸を常勝化させた疑い→0.15へ緩和）
    // === POPの個人債務（設計＝docs/202608/20260802_POPの個人債務_部分完了.md・2026-08-02）===
    // ★器は1つ（Pop.Debt）、入口は2つ（損失の記憶／消費者信用）、出口は1つ（返済規律）。
    //   これでフィッシャーの負債デフレ（損失→債務→強制的なデレバレッジ→数年の投資抑制）と
    //   19世紀の労働者家計の質屋サイクル（月曜に質入れ・土曜に請け出す）が同じ器から出る。
    // ⚠貨幣は Bank.HouseholdLoans（Bank.Loans とは別ストック）。Pop.Debt は「誰の分か」の記録で貨幣ではない。
    //   別ストックにする理由＝Credit.Step は目標追従の制御器で、Bank.Loans に載せると返済が**半減期1.16年で
    //   機械的に貸し直され**、しかも再創造分は首都州の投資家POPへ渡る＝負債デフレが原理的に起きない。
    public double PopDebtDriven;                 // 主フラグ（0＝休眠＝誰も読み書きしない厳密恒等）
    public double PopDebtLossShare;              // 入口A：backstop で消えた赤字のうち**個人が背負う割合**（有限責任の度合い）。
                                                 // 1.0＝全額＝無限責任（1856年英有限責任法**以前**の既定）。0＝現行（社会化）
    public double DebtRepayFrac;                 // 出口：黒字のうち毎月返済に回す割合。★質屋の週次サイクルは実質100%返済／
                                                 // 露の買戻金は1861→1907の49年賦＝階級で違うが第一段は一律（目安 0.3〜1.0）
    public double DebtRuinRatio;                 // 返済不能：債務が年所得のこの倍数を超えると階級転落の判定へ算入（目安 2.0〜3.0＝
                                                 // 1875年デカン暴動の ryot は年収の数倍の債務を負っていた）。0＝転落に算入しない
    public double HouseholdCreditMonths;         // 入口B：借入枠＝月次所得のこの倍数（目安 1.0〜2.0＝19世紀ロンドンの労働者家計の
                                                 // 家財＝質屋の担保が概ね数週間〜2ヶ月分の所得）。0＝借りない
    public double HouseholdCreditStapleOnly = 1.0;  // 入口B：主食のtierでのみ借りる（1＝主食限定）。質屋は食い扶持のための信用であって奢侈のためではない
    // ⚠利息の係数は立てない（設計§2-5）。LoanSpread のB4が一度失敗している（教育アンカーが耐えなかった）ので同じ轍を踏まない。
    //   利息なしでも「返済が将来の予算を食う」ので採用条件①は満たされる。

    public double ClergyAttractThreshold = 2.5;  // 聖職者の魅力閾値（平均比の豊かさ）。これ超で識字の高い下層が教会へ
    public double ClergyJoinRate = 0.004;        // 下層→聖職者の四半期移動率（宗教学校の社会のみ）
    public double ClergyExitRate = 0.004;        // ★点火2026-08-31（ラウンドB）＝聖職者の退出（世俗化・AI審査3-5）：非宗教学校の社会で聖職の実入りが平均を割ると教師/都市労働者へ（入口ClergyJoinRate=0.004の対称・同率）。0で退出なし
    // --- 国家間移民（豊かさの引力で大衆が移る・ゼロサム。ゲーム外からの流入＝WorldMigrationPoolFrac とは別）---
    public double EmigrationRate = 0.004;        // 機会差1.0あたりの四半期流出率
    public double EmigrationMaxFrac = 0.003;     // 四半期の流出上限（人口割合）＝大量流出の暴走防止
    // 移民の自己制限（07_再設計 §12-1・A4裁定・2026-07-31）：人が減るほど賃金と機会が上がり縁故が細る＝流出は自然に止まる。
    // ★国の消滅処理（ゾンビ清掃）は廃案＝「空になる」ことを後始末で対症せず、上流のフィードバックで防ぐ。
    public double EmigrationFloorSize = 50.0;    // 送出popの下限（千人）。これに近づくほど流出が絞られ、下回れば止まる
    public double EmigrationFloorSpan = 2.0;     // 絞りが効き始める幅（下限の何倍から効くか＝下限の3倍で満額流出）
    public double DistanceMarginScale = 1.0;     // 貿易重心からの距離1万kmあたり輸送マージンが何倍嵩むか（日本≈9千km＝マージン約2倍＝遠さの障壁）
    // 相対/地域距離：単一重心からの距離を「近隣相手への重力重み付き平均距離」へブレンド＝隣国が安く繋がる地域貿易ブロック。
    // ⚠撤去2026-08-12（棄却確定（コメントに明記））: RegionalDistanceWeight  第3波の単離再点火（2026-07-28）＝**棄却確定**：相対距離が日本の実効距離を縮め「距離の遠い国は交易が細い」契約を反転（ServiceEconomyTests赤＝帯でなく硬性ゲート）。過去却下near−5の帰属疑義は解消＝本体の効果だった。休眠温存。  // 0=重心距離（現行・既定）。1=相対距離（近い大相手が居れば実効距離が縮む＝地域ブロック）。**2026-06-29検証：現7カ国は欧州単一クラスタゆえ相対≒重心で効果ほぼ無し（pricedist不変）＝複数の地理クラスタ（アジア圏等）を足した時に効く土台として温存**。多国のみ走行＝較正不発
    public double RegionalDistanceHalf = 4000.0; // 表示専用（地図の交易重力円）・力学には効かない。力学読み手 RegionalDistanceWeight は2026-08-12撤去済み
    // funding修正（2026-06-18）：公共サービス予算を**国庫ストックでなく税収フロー(FiscalCapacity)から支弁**＝国庫が基礎義務に食われ常時0でも機能する。各係数は「歳入のうちその用途に充てる最大シェア（スライダー×これ）」。
    // 旧は ×Treasury（≈0で全餓死）だったので値も歳入基準に再較正。支出は国庫から引く（不足は赤字→国債→緊縮の既存フィードバック）。
    public double FiscalCapacitySmoothing = 0.15; // 裁量余剰(FiscalCapacity)EMAの平滑速度（豊作/恐慌の振れをならす）
    public double AdminPowerSmoothing = 0.05;     // 行政力(AdminPowerSmoothed)EMAの平滑速度（旧 Fiscal直書き0.05を係数化＝sweep対象）
    public double GdpTrendSmoothing = 0.18;       // トレンドGDP(GdpTrend)EMAの平滑速度（旧 World直書き0.18。GdpDrawdown/恐慌予兆の基準）
    public double InflationExpectationSmoothing = 0.34; // 期待インフレ(ExpectedInflation)EMAの平滑速度（旧 World直書き0.34）
    public double AdminBudgetFrac = 0.5;          // 行政＝歳入シェア（行政費スライダー×これ×歳入）。行政が薄いと汚職で歳入が漏れるので自己投資的
    // ★S3a（2026-07-31）：軍需予算を**宣言どおり「上限」にする**。下のコメントは「軍需調達の**上限**」と書いているが、
    // 実装 MilitaryBudget = 軍事費×シェア×歳入 は**常にその額を割り当てる固定額**で、必要額を下回れば不足・上回れば余る＝上限ではない。
    // 実測（1833年断面）＝アメリカは兵7に対し予算1708（afford 92倍）＝使われない過大予算が滞留する一方、
    // オスマンは兵2755・必要128510に対し予算1303（afford 0.010）。**同じ軍事支出の中で給与だけが既に min() 形**
    // （Simulation.cs:1313 SoldierPayBudget = min(Treasury, 兵数×民間賃金×倍率)）で、装備だけが取り残されていた。
    // min(上限, 実際の必要額) にすれば宣言と実装が一致し、余剰は福祉・インフラへ回る（Fiscal 側の請求額も同時に揃える）。
    // ⚠これ単独では**大軍側は変わらない**（上限が binding のまま）＝S3b/S3c と組で意味を持つ。0で厳密恒等。
    // ★是正2026-07-31：必要額は**全4段**（基本・上位・tier3・空軍＝EconomyStep.MilitaryProcurementNeed）。旧実装は基本段だけを必要額にしており、
    // 上限がそこで binding すると `remaining = MilitaryBudget − estCost×afford` が**厳密に0**＝機関銃/装甲艦/戦車/弩級戦艦/空軍が**全世界で調達不能**になっていた（死蔵財を増やす向き）。
    // 全段なら afford=1 のとき残余＝上位3段の必要額ちょうど＝**調達需要はビット恒等**で、変わるのは「使われない軍事費が福祉/インフラへ回る」財政側だけ。
    public double MilitaryBudgetNeedCapped = 1.0;   // **再点火2026-07-31（S3a・是正版＝必要額を全4段に直した後）**：基準線 39dc21f8（全緑）に対する単独バッチで測る
    public double MilitaryRevenueShare = 0.25;    // 軍需＝歳入シェア（軍需調達の上限。大軍ほど MilitaryScale↑で平時も消耗＝高維持費）。45%は鋼を奪い私的工業化をクラウドアウトし過ぎた→0.25
    public double WelfareRevenueShare = 0.8;      // 福祉＝歳入シェア（社会保障スライダー×これ×歳入が給付の上限）
    public double NobleAdminFactor = 15.0;       // 貴族による行政の素地：貴族の人口比×これ＝国庫不要の行政効率（近世国家は貴族が行政を担う＝序盤の財政難を緩和）
    public double NobleAdminCap = 0.5;           // 貴族由来の行政効率の上限（貴族だけでは満額にならない＝近代化で官僚が要る）
    public double CorruptionMax = 0.25;          // 行政が全く無い時に税収が漏れる最大割合（漏れは官僚の懐へ＝移転で保存）
    public double CorruptionPoorOfficialWeight = 0.0; // ★暮らせない官僚は汚職に手を染めやすい（作者要望2026-08-17・休眠）。実効汚職＝(1−行政)×(1−監視)×(1+これ×max(0,1−World.OfficialWelfareFill))。**物差しは俸給でなく満足度**（作者裁定＝「嗜好品を購入できているか」）＝官僚popの前月満足度の規模加重平均。俸給比を採らない理由＝(a)**全員が貧しい国では 官僚所得÷平均所得 が1.0（適正）になるのに官僚は飢えている**＝絶対的な窮乏を取り逃す (b)満足度は[0,1]に有界＝**比でないので分母の下限が要らない**（『比のガードは絶対値で書かない』の罠を構造的に踏まない） (c)闘争度・犯罪率と同じ物差しに合流＝**汚職はエリート版の同じ不満**＝式を2つ作らない。史実＝清の**養廉銀**（官位にふさわしい暮らしを保たせて汚職を減らす＝俸給の額でなく生活の充足の制度）／英の**ノースコート＝トレヴェリアン改革**。⚠**前月**の満足度を読む（Pop.LastSatisfaction）＝汚職の分け前→貯蓄→消費→満足度→汚職 の環を**同一ティックで閉じない**（設計側 20260817_開発速度の根本修正 §1）。0＝World.EffectiveCorruption が否定形ガードで即return＝旧式そのもの（ビット恒等・経路を作らない）。⚠設計側への申し送り＝汚職を予算の余りへ畳む改修が入ったら、この項は「余り×(1−監視)」の**分配率**へ移す（同じ導出量を読み替えるだけ）。点火は単独A/B
    // ★撤去2026-08-16（掃除キューC2-C5・棚卸C群）：汚職根絶レバー（2026-07-06）の係数8本＝AntiCorruptionSpeed/CostRate/DebtLock/DebtFree/GraftLock/Floor/SpanPopWeight/SpanRegionWeight を物理削除。
    //   汚職V2（CorruptionCoreV2＝(1−行政)×(1−監視noisy-or)）恒久ONの裁定済み＝読者は Fiscal の清廉度更新・根絶費請求のみで、いずれも同日撤去＝読者ゼロを確認。
    public double IndirectTaxInBudgetBase = 1.0;  // 監査2026-07-11（接2）：関税（四半期実収/3）＋消費税（当月実収）を予算基数（行政・軍装備・裁量余剰の請求権とLastRevenue）へ算入する重み。**1.0＝有効（ユーザー裁定2026-07-12「史実どおりの物理で良い・間違っているのはテスト」）**＝19世紀の関税国家（米・露型）の行政・軍拡が実歳入で立つ。回帰番人「教育で技術が分かれる」は前改革期（300Q）判定へ変更済み（露の1870年代型の遅い近代化は史実として許容）。0で旧（所得系のみ）
    public double TitheRate = 0.05;              // 十分の一税（教会税）：大衆（非特権・非兵士）の所得のこの割合を聖職者が受け取る（pop→聖職者の移転＝保存）。全員が満額払う訳でない想定で実効5%（要望）
    public double HealthFillCapacityBonus = 0.05; // 医療（医者の役務）の消費が人口扶養力に与える上乗せ（小さく・創発の味付け）
    public double WelfareCostRate = 0.6;         // 社会保障1.0・大衆1単位あたりの月次給付（国庫→大衆）。高い＝福祉は財政を圧迫＝レッセフェールとの選択
    // 倍率排除⑥：WelfareMilitancyRelief / LaborUnionMilitancyRelief（福祉・組合の闘争度直接減算）を撤去。
    // ★満足度（＝生活水準）は NeedMet/NeedTotal（＝買えたか）だけで決まる（作者裁定2026-08-19）。労働保護の効果は出力減としてのみ残る。
    //   満足度への直接バフ4件（ShorterHours/Elec・Welfare/Pension）は物理削除2026-08-21（各所に墓標）。残る器は UnionSatBonus（休眠）のみ。
    // ★物理削除2026-08-21【墓標・再点火禁止】：ShorterHoursSatBonus（旧0.10→8/19に0・作者裁定「時短は落とす」）＝思想⑨違反＝**法を通しただけで満足度が上がり、財を1つも買っていない**。
    //   Simulation の whWell 項ごと削除。★時短の効果は出力減（whOut＝LaborFatigueExp）としてのみ残る。
    //   【教訓】8/17の「支出から直接バフを排除する」の洗い出しは「支出→バフ」を探したので、この「法/州の状態→バフ」の形が素通りしていた（網の穴）。
    // 労働時間の連続化（倍率排除②）：実労働時間 WorkHoursValue ∈[8,14] を単一ソースに、出力/厚生/扶養力を連続関数で導く（3つの外科テーブルを廃止）。
    public double LaborFatigueExp = 0.37;         // 労働時間→工場出力の疲労逓減指数：whOut=(hours/14)^exp。h=14で1.0、短いほど産出↓だが逓減（8h=0.81・10h=0.88・12h=0.94＝旧テーブルとほぼ一致）
    public double LaborFatiguePenalty = 0.03;     // トレードオフ化2026-07-06:12h超の過労で産出が頭打ち〜微減（whOut×(1−これ×max(0,hours−12))）。0.03で14h=×0.94＝実効産出0.940<12hの0.944＝**12hが産出最適・無制限は好況でも損**（賞金消失）。0で旧（14h最大＝単調）＝要較正再走
    public double OverworkHealthSlope = 0.015;    // 労働時間→扶養力：12時間（過重労働の基準）より短い1時間ごとに健康改善で扶養力↑（8h=+0.06・10h=+0.03・12h以上=±0＝旧テーブルと一致）
    public double WorkHoursFollowSpeed = 0.15;    // 実労働時間が法定上限へ収束する月次速度（法は離散だが現場の労働時間は連続で追従＝移行期に中間値）
    public double UnionSatBonus = 0.00;           // ⚠休眠2026-08-19（作者裁定「労働組合は団体交渉権などに使うので休眠」）：同じく思想⑨違反（法→満足度の直接加算）。
                                                  // ★撤去ではなく休眠＝**団体交渉権として再利用する予定**（賃金交渉＝財の分配へ回せば思想⑨に触れない）。旧0.09
    // ★物理削除2026-08-21【墓標・再点火禁止】：WelfareSatBonus（旧0.10→8/17に0）＝社会保障の満足度フラット加算（Region.WelfareSatComponent・困窮targeting読み手ごと削除）。
    //   作者裁定2026-08-17「福祉を現金給付へ」＋2026-08-19「満足度は買えたかのみ」＝福祉の効果は現金給付（WelfareCostRate＝国庫→大衆→消費→生活水準）だけが担う。
    public double UnionMobilization = 0.15;        // B-5：容認組合の政治動員＝組織労働が改革派(reformist)を押し上げる（一方的な安定化でなく体制への改革圧力。1889ドック・スト型）。革命radicalは闘争度緩和で下げつつ改革圧力は上げる＝両義

    // --- メリトクラシー・昇格（教育2段階の社会的上昇）---
    public double MeritGroupWeight = 0.8;        // 近代的利益団体の勢力割合がメリトクラシー値に効く重み
    public double PromotionSpeed = 0.04;         // 教育済みPOPが上の階級へ昇る速さ（M×識字×これ）
    public double ReligiousProfessionShare = 0.05; // 宗教教育下の技師・教師・医者への昇格係数（神学校は技師をほぼ再生産できない＝世俗水路。官僚は例外）
    public double PromotionPremium = 1.5;        // 転職に要る給与倍率（機会費用＋資格取得の壁＝現状維持バイアス。雇用枠は廃止＝職の需給は給与が表現する）
    public double ArtisanDeclineRate = 0.01;     // ★【点火0.01・2026-08-16】手工業の没落（**四半期率**＝QuarterEndのみ実行）：工場に所得で負けた職人→都市労働者。駆動は昇格①と同じ所得差の言語。値は手織工アンカー帯0.008-0.012の中央（24万→4.3万/36年＝年率−4.7%）。⚠入口PettyEntryRateと対で点火（出口単独は職人が単調消滅＝Japan実測でsize=0）。S級梯子r6+9＝35/70/56・合成で帯中立
    public double JobSearchRate = 0.025;         // ★【点火0.025・2026-08-15】失業プール（作者指示）：失業者が四半期に階級のプール（上流/中流/下流）経由で職を探す割合（①''）。同階級のもっともマシな職へ資格（識字×高等教育）の按分で転職し、駄目なら1段下の最良職へ降格。>0で没落④⑤⑥・手工業の没落①'の行き先も同経路（無条件「→労働者」の廃止）。0.05は硬性赤（seed10リヴォルノ満足度0.12＝微小国が過流量で崩れる）→0.025×T0.15で硬性緑・near70/法57/貿易1.58%（exact−1は記録済み・修正方針20260801）。Search候補
    public double JobPoolTemperature = 0.15;     // ★【点火0.15・2026-08-15】①''の着地温度（リアリティ監査rank2）：>0で着地を最良職総取りから「所得×資格×空き(1−受け皿失業率)の低温softmax按分」へ軟化（PopDecision MigrationTemperatureと同じ言語・£単位）。0＝総取りウォーターフォールに厳密一致（総取りはA/B実測で near−4＝差し戻し済み。softmaxで exact+2 を実測）。値はMigrationTemperature同値
    // --- 社会移動リアリティ監査 2026-08-15（docs/202608/20260815_社会移動リアリティ監査_部分完了.md・点火状況は各行参照・点火は1本1バッチのA/B）---
    public double MerchantArtisanCapitalRise = 1.0;  // 【点火1.0・2026-08-16＝S級梯子r1単独37/71/58・合成で帯中立】rank1：商業・手工業資本→産業資本（③の対象を商人・職人へ一般化＝Crouzet「第一世代工場主の過半が商人・職人出自」）。閾値/率は既存CapitalRiseThreshold/CapitalRiseRateを共用（これは率の乗数・1で専門職と同率）。>0で商人の転落（⑤同型）も解凍＝凍結を両方向解く。職人のSmoothedMarginゲート（儲かる工房だけ工場化）は初版見送り＝貯蓄閾値8×avgが好況を既に選別（§10記録）
    public double PettyEntryRate = 0.02;             // 【点火0.02・2026-08-16＝出口ArtisanDeclineRateと対】rank6：小営業（職人・商人）への参入階段＝徒弟→親方・行商→店舗。労働者から所得差駆動（①'と対称・識字ゲート不要＝腕と元手の職）×元手ゲート（1人あたり貯蓄≥地域平均avgPerCap＝新自由度なし）。>0でプールJobGate(職人)にも同じ元手ゲート＝「無一文の失業者が工房主」の非一貫を閉鎖。⚠ArtisanDeclineRate（出口）と同時A/Bが条件
    public double RuralPromotionRate = 0.0;          // 【差し戻し2026-08-16＝単独でexact−7（29/68/58）＝教師の過剰供給が識字→政治の梯子を早回し。休眠温存】rank16：農村識字の直行便＝村の秀才→師範（教師）/聖職（識字先行国＝北欧・明治日本型で都市化天井が①の二段経路を塞ぐのを迂回する小水路）。ゲートは①と同一（m×識字×高等教育×世俗・本人就学PromotionGateOwnSchooling込み）
    public double SerfMobilityGate = 1.0;            // 【点火1.0・2026-08-16＝S級梯子r3単独37/70/58】rank3：農奴の移動不能＝都市化フロー（PopDecision 農村→都市方向のみ）に (1−これ)+これ×serfFree を乗算（serfFree=農奴解放 None:0/Limited:0.5/Full:1＝Colonial.cs入植と同じ梯子）。都市→農村は自由＝非対称。露普の都市化が解放後に始まる順序が法から出る。地域間移民(Territory系)への配線は次段（§10記録）
    public double ServiceUnemployment = 1.0;         // 【点火1.0・2026-08-16＝S級梯子r11単独37/72/55】rank11：役務専任popの失業＝教育→教師/医療→医者/行政→官僚/家事奉仕→使用人にも売れ残り率でUnemploymentRateを立てる（式は労働3財と同一・これは強度乗数）。使用人の袋小路（U恒0＝プール対象外・出口ゼロ）の解消。U→闘争度/福祉targetingにも効く＝較正非中立・A/B必須
    public double JobSearchLiteracyWeight = 0.5;     // 【点火0.5・2026-08-16＝S級梯子r10a単独35/72/56】rank10a：職探し効率の識字連動＝実効率=JobSearchRate×(1−これ×(1−識字))。1783年の教区縁故社会と1911年の職業紹介所社会の探索効率差＝識字（新聞求人・文書応募）が代理。固定年号ゲート不要
    public double JobSearchUsesEma = 0.02;           // 【点火0.02・2026-08-16＝S級梯子r10b単独35/71/61】rank10b：>0＝月次EMA率（例0.02≈4年記憶）。プール流入の駆動を瞬間UでなくU多年EMAへ＝循環失業は滞留して闘争度になり（Politics既存）、慢性失業だけが職業転換を駆動（手織工の遅さと恐慌の怒りが同じ係数から分岐）。Pop.UnemploymentEmaを月次更新（0では読み書きなし＝恒等）
    public double MinorityPenaltyModernBlend = 0.5;  // 【点火0.5・2026-08-16＝S級梯子r17単独37/73/61=単独帯最良（Search手掛かり）】rank17：ガラスの天井の時代ブレンド＝実効ペナルティ=MinorityPromotionPenalty×(1−これ×M)（M=メリトクラシー値）。開かれた社会ほど法的障壁が畳まれ慣行が残る（ユダヤ人解放の年代差が政体・社会構成から出る＝国名条件なし）。①とプールJobGateの物差しも統一（プール側にminorityF追加）
    // --- 作者裁定2026-08-16（同監査 rank7/8/12・点火状況は各行参照・実装は Meritocracy.cs・点火は1本1バッチのA/B）---
    public double FallAnchorReform = 0.3;            // 【点火0.3・2026-08-16】A/B＝1.0はexact39.7/法57.3だが小国満足度で硬性赤／0.5はバッチ緑(exact38.0・法58.1)だが**TaxTestsが赤＝英の行政成熟が止まる**（所得税の実効上限が238四半期で0.085→0.100・要求+0.1）＝中流（官僚）が転落で痩せる。カナリア二分探索で崖は0.4と0.5の間＝**崖の直下を避けて0.3**（テスト緑側の余裕）。rank7：転落物差し改革の束（3点を1本で・0=旧とビット恒等）。(a)③④⑤⑥の判定資産を(Savings+IlliquidWealth)/Sizeへ・分母の地域平均も同定義（⚠IWはSavingsの内数タグ（Model.cs）＝これは結晶資産を流動の2倍に重む加重＝土地・地金は没落判定で「恐慌に溶けない重い資産」）。(b)アンカーを他人の平均→**自分の平滑所得×年数**へブレンド（0=地域平均・1=年所得＝debtRuined判定の p.Earned×MonthsPerYear と同じ言語・平滑=max(当月,前月)=結晶化アンカー（EconomyStep）と同じ取り方）＝⚠>0では閾値係数（UpperFallThreshold=0.8等）の単位が「平均の何割」→「**年所得の何倍**」へ切替わる。(c)転落率を深さ連続化 rate×((1−f)+f×clamp((閾値−資産)/閾値,0,1))＝浅い割れはゆっくり・深い割れ（恐慌）は速い・debtRuinedは素通し。avgPerCap相対の「格差が没落を製造する因果の逆転」とClark比7-10倍速のエリート融解の是正
    public double CohortGateK = 0.0;                 // rank8：世代ゲート＝非ショックの大流量移動（①昇格・①*小営業参入・①'手工業没落・①''失業プール）に flow×=min(1, K×四半期新成人率)。新成人率=ChildShare×3/(AgingYears×12)＝Simulationのコホート送りagedと同じ物差し（新しい量を作らない）。④⑤⑥の転落・戦争・破産（BankruptcyFallRate経路）は素通し＝「破産は速い」が史実。移動の大半は入職時（Long&Ferrie）＝均衡は不変で時定数だけ世代スケールへ。0=乗算ごとスキップ（厳密恒等）。新成人率≈0.5%/四半期なのでK≈数十〜百が実効目盛り
    public double ProfessionGenderGate = 1.0;        // 【点火1.0・2026-08-16＝A/B単独で exact36.2→37.2・near/法ほぼ中立・硬性緑】rank12：職業の性別運搬＝Moveの移動コホート FemaleShare=src×access(行き先)（識字選抜PromotionLiteracySelectionと同型＝残留側で質量保存）。access=専門職（技師/官僚/医者）のみ「女性の権利」の梯子((int)WomenRights/3＝FactionSnapshotと同じ物差し)×WomenWageRetention（財産権の社会的確立の連続量）から導出・教師/使用人/その他=1.0＝**新しい法は作らない**（作者裁定）。女性教育権→教職の女性化と専門職の男性閉鎖（marriage bar）が同じ1本の法から出る。0=従来の按分混合とビット恒等

    // --- 信用・銀行（§2.5.1／§9-G・段4）---
    public double CreditMultiplier = 3.0;     // 信用乗数（1/準備率）。広義マネー上限 ＝ 金×これ
    // R12（2026-07-13点火）：信用乗数の発展度スケール化。全国全時代一律3.0＝1789の露清オスマンに英規模の近代銀行＋125年の金融深化がない不整合を是正。
    public double CreditMultiplierDevWeight = 1.0;  // 【点火1.0】0=一律CreditMultiplier（厳密恒等）／>0で発展度(工業化)スケール（1で完全発展度依存）。maxLoans×=1+(target-1)×これ
    public double CreditMultiplierDevFloor = 0.35;  // 最未発展国（工業化0）の乗数深度＝(CreditMultiplier-1)×これ。前工業でも手形/両替商の最低限の与信はある（実効乗数≒1+2×0.35=1.7）
    public double CreditDevScale = 0.4;             // MeanIndustrialization がこの値で満額の近代信用創造（devFactor=1・実効乗数3.0）。工業化が進んだ英独は満額・露清は floor 近辺
    public double CreditAdjustSpeed = 0.05;   // 与信が目標へ寄る速さ（緩やか＝循環を滑らかに＝過剰変動の抑制）
    public double InterestRateEffect = 1.5;   // 金利が貸出意欲を抑える強さ＝貸出 ×clamp(1−これ×金利)。金融政策の効き
    // 政策金利（バンクレート）の配線：旧来は貸出意欲のみ。19世紀金融政策の核「バンクレート引上げで正貨を呼び戻す・為替を守る」を表現。
    // すべて InterestRate に線形（較正は InterestRate=0＝中立／為替・資本流入は較正で非走行）。
    public double PolicyRateBondWeight = 0.02;   // 政策金利→国債金利の上乗せ（高金利＝政府の借入も高くつく）
    public double PolicyRateCapitalDraw = 1.0;   // 政策金利→外資の引き付け（高金利が資本を呼ぶ＝carry/正貨還流。uniform分は ret−worldRate で相殺＝相対金利差が効く）
    public double PolicyRateFxWeight = 0.2;      // 政策金利→自国通貨高（高金利でペッグ防衛・減価を抑える）
    public double ConfidenceSpeed = 0.02;     // 信頼が育つ速さ（月次・遅い＝過信は平穏の**年月**が育てる。ミンスキー）
    public double PanicSpeed = 0.20;          // 信頼が崩れる速さ（速い＝取り付けは一夜。非対称が恐慌の形を作る）
    public double PanicSensitivity = 5.0;     // 平穏線を割った充足の不足幅→信頼目標の下げ感応度（0.1割れば目標0.5・0.2割れば0）
    public double DrawdownPanic = 3.0;        // 景気後退（トレンドGDPのピーク比収縮）→信頼目標の下げ感応度（収縮10%＝目標−0.3）。4.0は大恐慌77%と過多→3.0で適度。※十分の一税後の恐慌増は不作主導でこの信用ノブでは下がらない（HarvestVariation/税率が効く）
    // シティ型恐慌（A・最終調整2026-06-29・ユーザー指示「恐慌で覇権を揺るがす」）：与信過熱(Heat)そのものが信頼を脆くする＝最も金融化した経済（深い与信＝高Heat）ほど
    // 好況の絶頂でミンスキー暴落する。満足度が高くても過剰レバレッジなら崩れる＝覇権国（ロンドンのシティ）が自らの与信バブルで定期的に恐慌入りする経路。
    // 既定0で恒等（較正中立）＝#17較正再走で有効化。Heat>閾値の超過分にのみ効く（健全なレバレッジは無傷）。
    public double OverheatFragility = 1.1;        // 過熱(Heat)が閾値を超えた分×これ を信頼目標から減じる（0で無効＝較正中立）。Heat1.0超でミンスキー着火→既存DrawdownPanicが暴落へ増幅。※深め過ぎは逆効果（恐慌は脆弱な挑戦者をより壊す）＝中庸1.1が最適
    public double OverheatFragilityThreshold = 1.0; // この与信使用率を超えると過熱が信頼を蝕む（1.0＝枠いっぱい超＝バブル領域。Heat は 0..1.5）
    public double ConfidencePivot = 0.65;     // 平穏線：これ以上の充足が続くと信頼が満枠へ漸増（割るとパニック側）
    // --- B-3 金融危機：銀行取り付け・最後の貸し手・民間負債デフレ伝播。すべて Confidence/maxLoans 経由＝実Loans変化は既存の保存安全コードを通る ---
    public double BankRunSensitivity = 2.0;   // 預金者パニック：充足が平穏線を割った不足幅→実効準備(maxLoans)の縮み（正貨逃避）。取り付けは信頼(貸し手意欲)と別チャネル
    public double BankRunMax = 0.5;           // 取り付けによる実効準備の最大縮小率（0.5＝半分まで）
    public double LolrHeatTrigger = 0.9;      // 最後の貸し手の発動：与信過熱度(Heat)がこれ超で危機と判定
    public double LolrDrawdownTrigger = 0.10; // 同：景気後退(GdpDrawdown)がこれ超で危機と判定
    public double GdpPeakDecay = 0.02;        // GDPピークの忘却係数（四半期）。トレンドがピークを下回る間ピークをゆっくり再基準化＝構造的に縮小した国が「新しい長期水準」へ。0＝旧バグ（単調増加で永久恐慌）
    public double LolrMinFunding = 0.6;       // 最後の貸し手を担える財政健全度（FiscalFundingRatio）の下限＝破綻寸前の国は救えない（Bagehot：solventにのみ貸す）
    public double LolrStrength = 0.7;         // 危機時に取り付け(run)を打ち消す割合＝流動性供給で恐慌を和らげる（高利＝根治はせず底打ちのみ）
    // ★恐慌AIの座標化（2026-08-22・二段構え較正＝作者裁定「まず裸の資本主義の帯・次にAIの対策で史実へ」）。旧 SelfPlay の private const を昇格＝既定値不変＝ビット恒等。
    //   裸の測定腕＝POB_COEF "LolrStrength=0;LolrReserveBoost=0;PreTightenHeatFrac=1.0;CrisisAusterityRelief=1.0"（測定専用・恒久ONの裁定2026-07-25は不変）。
    public double AiCrisisBorrow = 0.0;           // ★恐慌の谷での前倒し起債（2026-08-22・恐慌対策＝賢いAI・プレイヤー同条件）：不況かつ債権者緊縮前かつ枠ありなら国庫が財政バッファを割った時点で借りる＝逼迫反射の連鎖を立たせない。0＝恒等
    public double PreTightenHeatFrac = 0.75;      // 予防的引締めの発動＝過熱閾値のこの割合から（1.0＝予防なし＝素の過熱閾値のみ）
    public double CrisisAusterityRelief = 0.5;    // 恐慌の谷での緊縮反射の緩和（1.0＝緩和なし＝1930年代の緊縮の罠を素通し）
    // === テーマD 貨幣金融（価格・バランスシート層）===
    public double LolrReserveBoost = 0.5;   /* リアリティ群点火2026-07-18＝最後の貸し手(バジョット) */     // 最後の貸し手の準備拡張（no-lolr-balance-sheet）：危機×財政健全時にmaxLoansを(1+これ)倍＝バジョット「平時の準備を危機に貸す」。信用創造はBaseMoney中立ゆえInvariants変更不要。0で恒等
    // 金利doc B4（2026-07-30・点火）：与信の着地先（投資家）と利息の着地先（預金者＝全pop・預金額比例）が**別の階級**になる＝
    // 「利下げも利上げも同じ財布に着地する」（診断③）が壊れ、金利が**分配のレバー**になる。値は年率＝ loanRate = 0.02 + 0.16×InterestRate。
    // ⚠ 点火の前提＝B3（年率を日次へ落とす除数が /30 で12倍だったバグ）の是正。順序を守ること。
    // ⚠⚠ **doc の値（0.02 / 0.16＝年率2〜10%）は実測で差し戻した**：`MobilityTests.教育市場は…`（英・単一国・240Q）の教育月産が
    //   190.3 →（1/8）23.7 →（満額）5.6 の**構造的崩壊**（seed60=4.6・seed61=4.6＝軌道ノイズでない）。bisect で 1/16 が緑の上限。
    //   診断＝利息は `bank.Loans`（**残高ストック**）に課され、支払いは `Min(利息, 借り手の Savings)` で**現金ストック**から取る。
    //   与信を受けた投資家はその現金を投資に回して手元に残さないので、残高に対し現金が薄く**クランプが恒常的に binding** する
    //   （利息は本来フロー＝当期の利潤から払うもの）。#17較正ラウンドで機構ごと見直す＝そこで初めて doc の水準へ上げられる。
    //   1/16（0.00125/0.01＝年0.125〜0.625%）は単体では緑だったが、**同クラスの他テストと同一プロセスで走ると 22.4 まで落ちて赤**
    //   （＝この教育アンカーは共有キャッシュ経由の相互汚染に対して余白がなく、B4を載せると耐えられない）。
    // ★**結論＝この回は休眠へ差し戻す（0/0）。** 機構を作り直してから #17 較正ラウンドで点火する。B3（除数の是正）は恒等なので残す。
    public double LoanSpread = 0.0;           // 民間貸出金利の**年率**スプレッド（no-loan-interest-cashflow）：借り手(投資家)→預金者の利息移転 bank.Loans×(これ+政策金利項)。pop→pop純移転で保存。0で利息なし
    public double PolicyRateLoanWeight = 0.0; // 政策金利（無次元0..1）→年率への換算重み（引締めが借り手の利払いを増やす）。0で無効
    public double BondLossConfWeight = 0.5;   // 国債二次流通(no-bond-secondary-market)：BondPrice下落(利回り上昇)の評価損が銀行信頼targetConfを下げる×(国内債/GDP)。0で恒等。BondPriceは既存診断値を配線
    public double DebtDeflationWeight = 4.0;  // フィッシャー民間負債デフレ：デフレ率×レバレッジ(Heat)→信頼目標の下げ（実質債務増→債務者破産→さらにデフレの渦）。MonetaryEnabled時のみ

    // --- 国庫・財政（§9-F／§6.2・段4b）---
    // BaseCoercion 自体が兵数×即応度×CoercionPerSoldier から出るので、これは軍と別立ての費用ではない。
    public double CoercionUpkeepRate = 0.05;  // 圧政（警察・内政）の維持費 ＝ これ × BaseCoercion × 人口/基準人口（毎月・人口比例＝大人口の統制ほど高コスト）。0.12は国庫を枯渇させ procurement を止めた（国庫×割合で賄うため・軍需/行政の死蔵）→0.05（下流0）。高圧政国は依然高コスト（専制の代償）。税収が下回ると funding ratio↓
    public double WarCoercionDrain = 0.15;    // 圧政と軍事のリンク(A)：軍は内外を兼ねる一つの武力＝戦時は前線に取られ国内の鎮圧力が下がる。実効圧政 ×(1−これ×厭戦)。長期戦ほど本国で革命機会（1917型）。較正は無戦争＝不変
    public double CoercionPerSoldier = 5.0;   // 圧政＝**兵数×即応度×これ**（圧政=軍の一本化 2026-06-23）。装備された軍だけが鎮圧力を持つ＝武器を買えぬ軍は即応度0→圧政0→革命。軍隊規模(兵数)＝軍事費スライダーが駆動。CoercionMax で頭打ち（CoercionFollowsForce=true 時）
    public double CoercionMax = 2000;   // 【点火2000・2026-08-16 点火梯子＝★2026-08-16に4000→2000（漸近化と同時）＝挑戦力の理論最大（BaseCoercion換算≈1250）の3.2倍だった壁を等号点の1.6倍へ。旧4000は「不満100%でも革命が代数的に不能」を作っていた。合成comp4（12本＋海0.5）で exact41.6/near77.4/法63.2/貿易0.66・硬性緑】         // 圧政の上限（旧 Reactionary の最大鎮圧力＝史実の最大動員）。装備された大軍でも2000で漸近（CoercionSoftCap）

    // --- 領土・地域間移民（§5.2／§A-8・段4c）---
    public double FrontierDevelopmentRate = 0.01;   // locked 地域のインフラ開発速度（毎月）
    public double FrontierUnlockThreshold = 1.0;    // インフラがこれを超えたら active 化
    public double RegionMobility = 0.03;            // 地域間移民の緩和速度
    public double MigrationSecondDestShare = 0.3;   // 監査2026-07-05（D2）：州間移民の第2目的地への分岐率。0=最大機会の単一州へ一極吸引（現行と厳密一致）・0.3程度で第2機会の州にも分散（現実の移民は複数都市へ散る）。#17で有効化検討
    public double TransportFriction = 0.15;         // 距離/輸送の摩擦（引力から差し引く）
    // 民族統一度（倍率排除⑧で POP属性化＝各popの CoreEthnicShare 加重平均から創発。EthnicEnabled の国のみ・較正＝無効）。国際移民で希釈→同化で回復、低統一度は移民を引き低教育は排斥で阻む。
    public double UnityMilitancyRelief = 0.5;       // 高統一度は不満の【上昇】を鈍らせる（上昇分 ×(1−これ×統一度)。下降は妨げない＝「上昇率を下げる」）
    public double UnitySecessionMilitancy = 0.2;    // 〔分離圧力〕低統一度は不満の目標に +これ×(1−統一度)＝多民族帝国の不安定化（分離戦・独立）
    // 倍率排除⑧：旧 EthnicDilution（国際移民で統一度を明示的に下げる外科係数）は撤去。希釈は移民が core=0 で混ざる帰結として創発する。
    public double EthnicDraw = 0.7;                 // 低統一度は移民を引く：流入の引力 ×(1+これ×(1−統一度))＝坩堝。放置すると暴走するので同化が歯止め
    // 同化：毎四半期 統一度 += (これ＋教育加点)×(1−統一度)。**世紀単位に弱めた（2026-06-18）**：旧0.008/0.02 は速すぎ1850までに全国が均質化＝多様性が中盤で消えた。
    // 弱めて多民族帝国（墺洪/オスマン）が多様なまま不安定に推移し、同化しきれず**やがて分裂**（史実1918）＝多様性が持続的レバーになる。
    public double EthnicAssimilation = 0.0025;      // 同化の基礎（移民希釈との均衡点を下げる＝多様性が残る）
    public double AssimilationEducationBonus = 0.007;// 公教育/義務教育の同化加速（「学校が農民をフランス人にする」＝近代国民国家のみ速い）
    public double DiscriminationLiteracy = 0.45;    // 平均識字がこれ未満だと差別で移民を阻む：流入 ×clamp(平均識字/これ)＝低教育＝排斥
    public double UnityMilitaryQuality = 0.2;       // 〔軍の結束〕Power.Military ×(1+これ×(統一度−0.5))＝同質な軍は強い・多民族軍は脆い
    public double ConquestForeignWeight = 1.0;      // 倍率排除⑧/item4：征服で抱える植民地人口(col.PopSize・1000人単位)を自国人口単位へ換算する係数。希釈=homePop/(homePop+これ×植民地人口)＝相対規模から創発（旧 一律 ConquestUnityDrop=0.06 を置換）
    public double UnityAdminBonus = 0.12;           // 〔近代化〕行政効率 ×(1+これ×(統一度−0.5))＝国民国家は中央の指令が届く
    // #14 少数民族の経済的実体：少数派（CoreEthnicShare<1）の階級は昇格に摩擦・不満が高い＝同化までの過渡で「別挙動」を持つ（均質pop=core1で効果0＝較正中立）。EthnicEnabledでgate。
    public double MinorityPromotionPenalty = 0.5;   // 昇格率 ×(1−これ×(1−core))＝完全少数派(core=0)で昇格半減＝ガラスの天井（移民/被征服層が下層に滞留）。0で無効
    public double MinorityMilitancy = 0.2;          // 不満の上乗せ ＝これ×(1−core)＝差別・排斥が不満を生み分離独立/ナショナリズムへ（被征服のCededColonyMilitancyと別＝恒常的な地位の不満）。0で無効

    // 貨幣・物価水準（段4-貨幣 第1段。MonetaryEnabled の国のみ。較正＝P≡1で不変）。物価＝名目のヴェール（金は保存）。
    public double MonetaryPriceSensitivity = 0.25;  // 物価水準の感応度：P を「広義マネー/実質産出 のトレンド比」へ寄せる速度。高いほど物価がキビキビ動く
    public double MonetaryTrendSpeed = 0.02;        // M/Y トレンドの追従速度（遅い＝secular な産出成長を吸収。小さいほど長期デフレが残り、大きいほど純粋に循環のみ）
    // 鋳造（金鉱→正貨）：金鉱産出の一部を造幣局が新鋳貨で買い取る＝基礎貨幣が増える（金産出国の通貨的優位・ゴールドラッシュ→マネー膨張→インフレ/好況）。
    // 鋳造分は金の商品市場から引き取られる＝宝飾と造幣が金を奪い合う（金価格↑）。0=無効（較正中立）。保存：CumulativeGoldMinted 台帳で基礎貨幣増を追跡。
    public double GoldMintFraction = 0.2;           // 金鉱の月次産出のうち鋳造（貨幣化）に回る割合。0=中立。0.2起動（キュー3・金発見移民 2026-07-10）＝金鉱州の産金→新鋳貨が鉱山所有者へ＝金鉱国の購買力/賃金↑→移民機会↑（ゴールドラッシュの貨幣面）。旧保存テストは CumulativeGoldMinted 込みの式へ更新済み
    public double PriceLevelFloor = 0.4;            // 物価水準の下限（深いデフレの底＝暴走防止）
    public double PriceLevelCeil = 4.0;             // 物価水準の上限（高インフレの天井＝暴走防止）
    // 地域別の貨幣的物価水準（②集計粒度）：各州の物価水準＝国家物価×地域乗数。乗数＝(州の1人あたり貯蓄/国の1人あたり貯蓄)^Weight をクランプ。
    // 現金の厚い金融中心州は物価/名目賃金が高く、現金の乏しい辺境州は低い（19世紀の地域物価・賃金格差・辺境デフレ）。1州なら乗数1＝較正中立。0で無効。
    public double RegionalPriceLevelWeight = 0.3;   // 地域の現金の厚みの差→物価格差への感応度（0=地域差なし=従来一律）。緩め＝極端な州だけ大きく振れる
    public double RegionalPriceLevelMin = 0.7;      // 地域物価乗数の下限（辺境デフレの底）
    public double RegionalPriceLevelMax = 1.45;     // 地域物価乗数の上限（金融中心の物価高の天井）
    // 金本位制（信用ゲート＋黄金の足枷）。加入＝資格（コストでない）、加入中＝規律。
    public double GoldStandardMaxDebt = 0.0416666666666666667;   // 加入の信用要件：債務/**年**GDP がこれ以下。財7単位フリップ2026-07-26＝旧0.5（月次GDP比）÷12＝代数恒等。**年GDP比4.2%＝史実（英1815=250%）に対し極端に厳しい＝#17で史実レンジへ再較正する主対象**。〔②検討〕旧単位での緩和(1.5)は急進化＋techテスト破綻で据置だった（②は慢性赤字の解決が先）
    public double GoldCoverMin = 0.25;              // 兌換維持に要る正貨準備カバー率（convertibility-not-reserve-backed＋fx-peg防衛）＝BaseMoney/BroadMoney。これ未満で兌換停止クライシス(金流出で守れない)。
                                                    // 有効化2026-07-10（キュー1）：実測（goldprobe 5seeds×500Q・加入国10.9万サンプル）＝健全帯 中央0.52/p25 0.48/p1 0.43・危機の谷は0.21以下〜負値へ突き抜ける。
                                                    // 0.25＝健全帯の床(p1=0.43)より下・危機の谷より上＝下回りは加入四半期の約0.1%＝「実在するが常態でない」兌換停止（1797英/1893米型）。0.5だと36.6%が下回り常時発火＝不採用
    public double GoldStandardMinFunding = 0.85;    // 加入の信用要件：連合維持を払えている（funding ratio がこれ以上）。危機でこれを割ると強制離脱（兌換停止）
    public double GoldStandardSuspendDebt = 0.075;  // 加入中でも債務/**年**GDP がこれを超えると兌換維持不能→強制離脱（信用暴落）。財7単位フリップ2026-07-26＝旧0.9（月次GDP比）÷12＝代数恒等（#17再較正の主対象）
    public double GoldStandardRateDiscount = 0.6;   // 完全兌換時の国債金利の倍率（信用＝低金利。0.6＝4割引）。Convertibilityでlerp＝部分兌換は中間
    // 兌換可能性 Convertibility∈[0,1]（倍率排除②）：金本位/不換の bool 分岐を連続化。1=完全兌換(金)・0=不換。OnGoldStandard(資格)を非対称速度で滑らかに追従＝部分兌換の移行を表現。
    public double ConvertibilityRiseSpeed = 0.05;   // 加入後に兌換が確立する速さ（準備・信認の積み上げ＝遅い）
    public double ConvertibilityDropSpeed = 0.34;   // 危機で兌換が崩れる速さ（兌換停止は一夜＝速い・非対称）
    public double ConvertibilityCoverageBand = 1.0; // 金利doc B5（2026-07-30・点火）：兌換目標を bool でなく**正貨カバー率の連続関数**へ（バンドは既存係数から導出＝lo=GoldCoverMin×GoldRejoinCoverMargin=0.325／hi=lo×(1+GoldCoverCreditRestraint)=0.4875）。加入していても準備が薄れれば兌換が目減りする＝金本位期でも物価/為替/国債金利のチャネルが死なない。0で旧bool（加入=1.0）へ縮退＝厳密恒等
    // 貨幣と国債の紐づけ（#2 Fisher・#3 印刷インフレ）。#1（名目GDPで債務負担を測る＝負債デフレ）は World.NominalGdp で実装。
    public double FisherInflationWeight = 0.5;       // 名目国債金利＝実質＋これ×期待インフレ（高インフレ→高名目金利／デフレ→低名目金利だが実質債務は重い）
    public double FiatInflationWeight = 0.6;         // 通貨切下げ（紙幣増発）が物価を押し上げる強さ：P ×= 1+これ×(切下げ額/広義マネー)＝印刷→インフレ→実質債務減
    // 為替レート（第3a段・不換国のみ変動。金本位は1.0固定）。レートは「決定」のみに効き決済額には掛からない＝保存不変。
    public double ExchangeRateSpeed = 0.2;           // レートが目標へ寄る速度（四半期）
    public double ExchangeTradeAdjust = 3.0;         // 貿易収支によるオーバーシュート強度（赤字→余分に減価＝輸出競争力／黒字→増価）
    // ==== 通貨改革（2026-08-13・作者採用）====
    // 史実＝レンテンマルク（独1923）／ポワンカレ・フラン（仏1926）／英1925の旧平価復帰（失敗例）。
    // 過去の減価の記憶を、**現に残っている預金を焼却する**代価で帳消しにし、実力に合った新平価で建て直す。
    // 既定 0.0＝発動しない＝厳密恒等（Fiscal の新ブロックが1命令も走らない）。
    // ★2026-08-13（作者裁定「行政費は汚職などで抜け落ちるが、それ以外は価格相応の働きをするように」）：
    //   行政（と行政費で買う上下水道）の調達に**買い控えのゲート**を掛けるか。1=旧挙動（掛ける）／0=掛けない＝裁定側。
    //   予算の制約（afford＝金で買える量）はどちらでも残る＝それ自体が「価格相応」。ここで外すのはその上に重ねた
    //   「参照価格より高いから買わない」という追加の拒否で、金を持っていても行政が働かなくなる原因だった。
    //   ★点火2026-08-13＝0（実測10シード・硬性ゲート全緑）：合計+18.8pt。**列強再現率 22.5→30.0**（本調査の対象軸）・
    //   人口 17.1→21.4・領土本国 79.2→82.5・領土植民地 40.0→44.2・政体exact 35.3→37.6。経済規模だけ −3.7。
    public double AdminProcurePriceGate = 0.0;
    //   ★点火2026-08-13（実測10シード・硬性ゲート全緑）：合計+10.0pt。経済規模 32.5→41.2・列強再現率 17.5→22.5・人口 11.4→17.1。
    //   発動は131年55カ国で4回＝稀で重い事件（1797仏・1854西・1869モロッコ・1914マラータ）。スペインだけが実力の平価0.86を選んだ。
    public double CurrencyReformEnabled = 1.0;
    public double CurrencyReformForgiveShare = 1.0;   // 帳消しにする累積切下げの割合（1=全消し）
    public double CurrencyReformBurnShare = 0.5;      // 記憶の代価＝累積切下げのこの割合を貯蓄から焼却
    public double CurrencyReformBurnCap = 0.5;        // 焼却の上限＝総貯蓄のこの割合（1度で全財産は焼かない）
    public double CurrencyReformLegitimacyHit = 0.35; // 正統性の代価＝帳消し比に比例（大きな罪を許すほど高い）
    public int CurrencyReformCalmMonths = 24;         // 発動に要る「切下げゼロ」の連続月数＝財政の同時再建（1923年11月だけ成功した差）
    public int CurrencyReformCooldownMonths = 120;    // 濫用防止
    public double ExchangeRateFloor = 0.3;           // レート下限（極端な減価の底＝暴走防止）
    public double ExchangeRateCeil = 3.0;            // レート上限
    // 国際金融（第3b段・民間外資＝A案）。資本は収益率（工業化伸びしろ×信用）の高い国へ流れ、工業化を支え、配当を送り、信用崩壊で逃避・伝染。
    public double CapitalIndTarget = 4.0;            // 投資収益率の素地＝(これ−工業化度)。伸びしろの大きい後発国ほど高収益＝外資を呼ぶ。※衰退実験(3.5)は逆効果（覇権はレンティア配当で富裕なまま首位維持）＝既定4.0に復帰
    public double OffGoldCapitalPenalty = 0.5;       // 不換国の対外信用の倍率（金本位＝1.0。不換は外資が付きにくく逃げやすい）
    public double CapitalDemandScale = 0.02;         // 流入需要＝(収益率−世界平均)×名目GDP×これ（吸収力＝経済規模）
    public double CapitalExportFrac = 0.10;          // 資本余剰国が対外投資に回す投資家貯蓄の割合。※衰退実験(0.28)は逆効果（覇権がレンティア化し配当で首位維持）＝既定0.10に復帰
    public double CapitalDividendRate = 0.02;        // 外資への四半期配当率（ForeignCapitalIn に対し・本国へ送金＝外資のコスト）
    public double CapitalFlightRate = 0.15;          // 資本逃避：毎四半期 ForeignCapitalIn×これ×(1−信用) が本国送還（信用崩壊で急増）
    public double CapitalContagion = 0.6;            // 伝染：危機国の割合×これだけ世界の資本意欲が縮む（サドンストップ）
    public double CapitalCreditFloor = 0.5;          // 信用の床：収益率＝伸びしろ×(これ+(1−これ)×信用)。信用が低くても高潜在国は資本を呼ぶ（ゲートでなくプレミアム）。代償は高い逃避・配当
    // 関税＝輸入関税（保護＋歳入）。19世紀国家財政の主柱（米：所得税前は歳入の過半）＋産業政策（リスト/ビスマルク/共和党）。
    // ★財ごとの売買方針（2026-08-04・作者仕様(3)「高く買う/安く売る」）。関税ダンピングと同じ保存経路（国庫→商人）に載せる
    // ★条約港（2026-08-04・作者仕様(4)「遠方の国に大勝しても属国化は不自然（日本の属国になったオスマン）＝多額の賠償金＋条約港へ」）
    public double TreatyPortWinnerDistanceKm = 6000;  // 勝者と敗者がこれ以上離れていたら属国化しない（遠隔地の属国は統治できない）。0で従来どおり距離を見ない
    public double TreatyPortTariffLoss = 0.25;        // 条約港1つあたり自国の実効関税が失われる割合（4港で関税ゼロ＝関税自主権の完全喪失）。0で恒等
    // ★条約港の自然失効（案A・作者裁定2026-08-16「戦争で解除という例外を作らない。もっとシンプルに」）＝
    //   不平等条約は「力の差が続く間だけ有効」。動詞・ボタン・交渉・戦争例外なし＝脱出路は「強くなる」だけ
    //   （日本の条約改正1899/1911＝近代化を背景に条約が風化した、が創発）。AI対称は構造（同じ検査が全国に走る）。
    public double TreatyPortLapseRatio = 0.5;         // 【点火0.5・2026-08-16＝A/B: 単独35/69/51・港配線との合成36/73/51=near+5優加法。法−5は記録・監視】ゲート兼閾値：国力（軍事+生産＝NationalScore既存成分）÷最強列強 がこれ以上なら条約港が風化。0＝1命令も走らない厳密恒等（片道ラチェット）
    public double TreatyPortLapseYears = 4.0;         // 失効の刻み（年）＝この年数ごとの全国一斉検査で1港ずつ（無状態＝month剰余判定・クールダウン用フィールドを作らない）。Ratio=0では不読
    public double TreatyPortReparationMult = 2.5;     // 条約港の講和での賠償倍率（「多額の賠償金」＝属国化の代わりに金と通商特権を取る）
    public double TradeBiasStrength = 0.25;   // 敷居を動かす幅（世界価格比）。高く買う＝輸入の敷居を25%下げる／安く売る＝輸出の敷居を25%上げる。0で厳密恒等
    public double TariffProtect = 1.0;               // 輸入の敷居を上げる強さ：輸入閾値＝世界価格×(1+輸送費+関税率×これ)。高関税＝輸入減→国内価格高止まり→国内産業を保護（輸入代替）
    public double TariffExportDrag = 0.3;            // トレードオフ化2026-07-06:保護の代償。正の関税率×これ を輸出閾値から引く＝高関税で自国の輸出競争力が落ちる（報復/交易縮小）。0で旧挙動（保護がほぼ無料）。関税0の国・非交易較正には無影響
    public double TariffRevenueRate = 1.0;           // 関税収入＝輸入額（世界価格建て）×関税率×これ→国庫（popが負担＝保護下でも消費する分の関税）。慢性赤字の主財源
    public double TariffFloor = -0.25;               // 関税の下限＝負の関税（ダンピング／輸出補助金）。負の関税は輸出閾値を|関税|ぶん引き上げ→輸出増（世界市場へ安売り）、国庫→商人の補助金。AI（産業スタンスのダンピング）とプレイヤーの双方が負値を使う。条約は負値を物差しにしない
    // 土地（耕地）＝固定生産要素。農村人口が耕地賦存量(Region.ArableLand)を超えると土地作物RGOが収穫逓減し、食料/人↓→所得↓→移民が自然に止まる（room/容量番兵を撤去した本体）。
    public double LandDiminishExponent = 0.7;       // landFactor=min(1,(耕地/農村人口)^これ)。農村が耕地の2倍で産出0.76倍・4倍で0.57倍。0＝逓減なし

    // --- 国際・世界市場（§5.1・段4d）---
    public double TradeSpeed = 0.05;        // 交易量の速さ（価格差→輸出入量）。⚠2026-08-30 S4点火後は**既定経路で不読**（旧経路＝TradeArbitrageClearing=0時と単一国Trade.csのみ）＝掃除はS6/#17再較正と同席
    // ★裁定流量の価格差感応化（2026-08-17・休眠＝docs/202608/20260817_裁定流量の価格差感応化_完了.md）：
    //   売り手が動かせる量は アクセス×TradeSpeed×規模 だけで**価格差を見ない**（＝定数蓋・鋼市場診断β／8/15「残る律速は速度」と同一犯）。
    //   これ>0 で 裁定margin x=世界平均/自州価格−1 に応じ 流量に x/(1+x/これ) を上乗せ＝**自己有界**（x→∞で(1+これ)倍へ漸近）。
    //   値の読み方＝「最大何倍まで速く出せるか−1」（1.0で最大2倍・4.0で最大5倍）。x が小さい領域では f≈x＝線形で平時を歪めない。
    //   買い手側の q は既に価格差比例なので触らない（同じ x を両側に掛けると価格差が二乗＝二重計上）。0で分岐ごとスキップ＝ビット恒等。
    //   ★点火4.0（2026-08-29・batch30 A/B＝鉄道低下0.25の上）＝貿易0.12→0.15%・政体47.5→48.0・列強31.7→32.5・人口29.0→31.0・
    //     法57.0→57.9・スペイン常勝25→20/30／植民地30.0→26.1・経済−0.9。硬性全緑。差し戻しは0へ。
    public double TradeArbitrageMax = 4.0;
    // ★植民地財の交易解禁（2026-08-21・反実仮想レバー／既定0＝BilateralMarket:245 の判定が旧と厳密同値＝ビット恒等）。
    //   検証する主張＝「実在する定義の穴は植民地財が二国間交易にも貿易統計にも一切入らないことだけ（規模は数%）」。
    //   >0 で IsColonial 財（生ゴム/金鶏樹皮/パーム油/象牙/サトウキビ/カカオ/茶葉/コーヒー豆/香辛料/アヘン/グアノ）を
    //   通常財と同じ二国間交易へ載せる＝賦存州（world.json の provinces.resources に該当idを持つ24州）が輸出できるようになる。
    //   ⚠旧注記「これは穴を塞いだ世界の反実仮想であって仕様提案ではない（抽象植民地機構からの流入と二重計上になる）」は
    //     **2026-08-26の植民地の州昇格（ColoniesAreRegions）で失効した**。植民地が州になると、砂糖も茶も
    //     **その州が自分で産んで自分で売る**（首都州の ColonialResources は空＝抽象機構からの流入が無い）＝二重計上の相手がいない。
    //   ★これで1783〜1914年の長距離交易の主役（砂糖・茶・コーヒー・香辛料・生ゴム・パーム油・象牙…）が世界市場に載る。
    //   ⚠0＝BilateralMarket:258 の判定が旧と厳密同値＝ビット恒等。ColoniesAreRegions と**対で**点火する。
    //   ★点火2026-08-26：貿易/GDP 0.08%→0.13%（+63%）。⚠水準は依然ほぼゼロ＝縛っているのは「何を交易してよいか」ではなく
    //     **運びたい量と運賃**（輸送容量は潜在量の10倍余り・内陸州は片脚4,788km相当）。次の本丸は陸路の直行と運賃。
    public double TradeColonialGoods = 1.0;
    // ★賦存の反実仮想レバー（2026-08-21・診断専用／既定1.0＝×1.0はIEEE754で厳密恒等＝ビット恒等）。
    //   「非賦存州も0.4で自給するから比較優位が価格差に翻訳されない」という主張をA/Bで検証/反証するために置く。
    //   ResourceScarcityScale＝非賦存RGOの産出倍率(ResourceScarcity=0.4)に掛ける（0.1で0.04＝賦存比100倍・0で非産地は厳密0）。
    //   ResourceEndowmentScale＝賦存州の産出倍率(4.0/3.5)に掛ける（賦存側から差を広げる対照）。
    //   ⚠既定値は動かさない＝掃引の物差し専用。POB_COEF で切り替えて測る。
    public double ResourceScarcityScale = 1.0;
    public double ResourceEndowmentScale = 1.0;
    // ★器の反実仮想レバー（2026-08-21・診断専用／既定1.0＝分岐を1命令も通らない＝ビット恒等）。
    //   「第2の栓＝買い手の注文式の器 scaleT が実質GDP比で縮んだこと」という主張を、**売り手側の蓋と分離して**A/Bするために置く。
    //   TradeBuyerScaleMult＝買い手の q（注文量）だけを倍する／TradeSellerFlowMult＝売り手の flowS（出せる量）だけを倍する。
    //   TradeSpeed を上げると両側が同時に動く＝どちらが律速かを切り分けられない、という測定上の穴を塞ぐ物差し。
    //   ⚠既定値は動かさない＝掃引の物差し専用。POB_COEF で切り替えて測る。
    public double TradeBuyerScaleMult = 1.0;
    public double TradeSellerFlowMult = 1.0;
    public double TransportMargin = 0.18;   // 世界価格との輸送マージン（この帯の中は裁定しない＝広いほど地域価格が割れる）。前鉄道の道路/河川は高コスト
    // ⚠撤去2026-08-12（旧世界市場の撤去で読み手消滅）: WorldPriceSpeed  国際市場（多国）の世界価格が需給差で動く速さ（§5.1 多国版）
    // === テーマI（国際貿易・植民地）===
    public double RestOfWorldElasticity = 0.2;   // ⚠読み手ゼロ（唯一の機構＝世界価格の費用アンカーは2026-08-12の旧世界市場の撤去で読み手消滅。旧説明＝extra=これ×(RefPrice/_price-1)）。番人は PriceOfBread.Tests/TradeThemeTests.cs の既定値ピンのみ（Tests側の削除は別ファイル担当）
    // 独占markup（B-2）：世界生産が少数国に集中する財ほど世界価格に上乗せ＝価格支配（スタンダード石油・独カルテル）。
    // 集中度＝各国生産シェアのHHI（1/N..1）。床を超えた分に比例。**抜け道**＝高価格で他国の採算が立ち参入→生産シェア分散→HHI低下→markup自壊（追加コード不要・自己是正）。
    public double DomesticMarkupMax = 0.0;  // 国内寡占（no-market-power-monopoly）：財別有効生産者数EffFirmsから μ=1+これ×(1/EffFirms) の自己有界マークアップを国内clearingに乗せる。0で現行。**EffFirms再定義(CompetitiveFirmsBase)は成功＝素点火0.5の崩壊(ハーネス23/30・exact7%)を0.5でハーネス0/30・exact37へ解消。だが点火は帯劣化＝独占が伝統帝国(清)を富ませ固定化(0.5で清20常勝/0.2でも固着+3)＝独占が国に純コストでなく富の集中。タスクC完成には#4(政治腐敗＋大衆resentment＝独占の純コスト化)が必須。EffFirms再定義コードは休眠温存**
    public double CompetitiveFirmsBase = 50.0;  // 【M6/タスクC EffFirms再定義】非独占財の既定有効生産者数＝競争的（高いのでμ=1+DomesticMarkupMax/50≈1で実質マークアップなし）。生産者popは多数の実企業の集約なので既定を高く取り、法的独占(塩gabelle/茶東インド)だけEffFirms=1の例外にする＝素点火の「全財が偽独占」崩壊を回避。DomesticMarkupMax=0では未使用
    public double LegalMonopolyDissolveInd = 0.3;  // 【M6/タスクC】法的独占が解体する工業化度。Industrialization<これの伝統経済で塩(6)/茶(74)がEffFirms=1（独占価格）・近代化で潜在競争者数(CompetitiveFirmsBase)へ移行しμ→1で価格下落＝営業の自由/専売廃止の創発的代理。DomesticMarkupMax=0では未使用
    // タスクC（市場の権利構造・独占レント方式）：EffFirms/マークアップの崩壊を避け、既存の安定した「上乗せ→保有pop」経路（消費税/流通マージンと同型）で表現。伝統的独占の超過利潤を消費者→保有エリートへ移転し、近代化で解体＝「市場の自由化」体験。
    public double MonopolyRentPremium = 0.15;   /* リアリティ群点火2026-07-18＝塩gabelle/茶の専売(resentment無し・工業化で自然消滅) */   // 伝統的独占(塩の王室専売gabelle・茶の東インド会社)の買い手価格上乗せ率。**タスクC/#4試験2026-07-15＝0.3+resentment0.05でbatch◎24・清entrench解消の好結果だが、テストゲートで5失敗（茶ルーティングのIndexクラッシュ[修正済]＋resentment闘争度が政治を自律撹乱＝幕府→共和/NullAgentでも参政権変化の4政治テスト破壊）。清を直す強さと政治を壊す強さが同一＝resentment方式は両立不能で差し戻し。機構は休眠温存**。**タスクC点火試験2026-07-15＝0.5でleakhunt清潔・機構は妥当だが帯劣化（exact39→35・清11→17常勝・首位交代61.7→43.4・固着+4）＝エリートへのレント集中が伝統帝国(清)を entrench＋「解体=工業化連動」が"工業化しなければレント保持"の倒錯誘因を生む＝保留。政体連動の解体＋別効果経路なら要再設計**。機構(徴収→保有pop・保存清潔・休眠恒等)は温存。0=独占なし＝現行と厳密一致。>0で塩(id6)/茶(id74)の買い手価格に上乗せ→塩は国庫(王室)・茶は資本家(会社)へ移転（消費者→保有者で保存）＝大衆が高値で苦しみエリートが儲ける。専売廃止(下記フェード)で価格下落・生活水準↑
    public double MonopolyDissolveInd = 0.3;   // 独占が完全解体する工業化度。実効率＝MonopolyRentPremium×max(0,1−Industrialization/これ)＝近代化(=営業の自由・専売廃止の創発的代理)で独占が消える。MonopolyRentPremium=0では未使用
    public double MonopolyResentmentMilitancy = 0.0;  // タスクC/#4＝差し戻し（0.05で政治を自律撹乱＝上記MonopolyRentPremium参照）。政治腐敗＝独占の純コスト化：独占価格を払う大衆popの月次闘争度上昇＝これ×monRent（買い手ループ）。0で不発。>0で独占が伝統帝国を富ませてentrenchするのを、大衆の不満→不安定で相殺し「独占は悪・解体で生活改善＋安定」を創発（独占レント素点火の清entrench問題への対処）

    // --- 資本・建設（§2.4 拡張：地域集約の「工業化度」。投資＝機械・セメントを消費して積む）---
    public double IndDepreciation = 0.003;        // 工業資本の減価（D1腕＝IndDepreciation0.0045/IndCapitalCost0.45は2026-08-09に一度採用→州23件還流後のアブレーションで符号反転（経済21.3vs30.0・総合−7.8）＝同日差し戻し。原本=rs_D1/wavef_full/wavef_noD1）
    // 開発度の記憶＝「ある程度は硬い列強」（ユーザー要望2026-07-27）。旧＝無記憶の指数減衰のみで床が無く、投資が止まると約50年で工業化がほぼ0へ。
    // 実測（列強軸の初計測2026-07-27・batch30）＝1914年に史実の列強8カ国が列強である率は**22%**（理論上限88%）、平均順位は仏9位・墺23位・米26位・日27位・英29位・普33位・伊38位・露49位＝
    // 史実の列強はどの国も安定して上位7に入れていない。seed1では英が工業化0.00・49位（1788年に仏へ敗れ属国化）。
    // ピーク（DevelopmentPeak）から離れるほど物理減価を緩めて0へ漸近させる＝資本を注入せず「体化された技術・熟練・制度は失われない」を表現（独日の戦後復興）。
    // 1.0でピーク比0のとき減価0＝完全な漸近床／0.5で半減。0＝旧挙動（式・掛順とも不変＝厳密恒等）。
    // **2026-07-27＝0.7で点火試験→差し戻し（休眠へ復帰）**。batch30実測＝列強一致 22→25%（+3）・◎7割帯 17→22（+5）・△境界 10→4（−6）＝分布は締まったが、
    // exact 38→36 / near 70→67（−3＝ノイズ幅超）の帯コストを払う。かつ**動機だった英が29→30位で改善せず**（英の凋落は工業化の減衰でなく
    // 1788年の敗戦→属国化→人口崩壊が主因＝この機構では届かない）。仏9→7位・日27→17位・墺23→17位は改善したが、米26→33・普33→36・伊38→42は悪化＝正味+3のみ。
    // 機構は史実的に正しく（体化された技術は失われない）分布も改善するので、**0.4への二分探索を#17較正ラウンドの候補として温存**する。
    public double DevelopmentMemory = 0.0;
    // 恐慌の資本破壊（最終調整2026-06-29・ユーザー指示「恐慌が資本を破壊」）：深い景気後退（GdpDrawdown が閾値超）では工場閉鎖・資本廃棄で工業化度が退行する＝
    // 恐慌が『ストック』を削る＝覇権の構造的先行（工業化）を大恐慌が巻き戻す。閾値超のドローダウンにのみ効く。
    public double DepressionScrapRate = 0.06;       // 閾値超ドローダウン1あたりの月次・追加工業化減価（0で無効）。大恐慌(DD50%・閾値0.2→超過0.3)で月1.8%の資本廃棄。※深め過ぎは逆効果（挑戦者をより壊す）＝中庸0.06が最適
    public double DepressionScrapThreshold = 0.20;  // これ未満のドローダウンでは資本廃棄なし（通常の景気循環では工場は壊さない・大恐慌のみ）
    // ヴィンテージ資本有効化2026-07-10（キュー5＝2026-07-08承認の工程(1)）：技術先行国の旧資本が後年に足枷となり後発が新鋭資本で競り勝つ（実力ベース首位交代の本命）。
    // 配線＝新旧合計(TotalIndustrialization)を従来読者へ・座礁控除(ProductiveIndustrialization)は生産性チャネルのみ＝座礁だけが現行との差分（較正中立の分割・Model.cs Region参照）。
    public double VintageMigrateRate = 0.005;     // ヴィンテージ資本（no-vintage-capital-depreciation）：現世代→旧世代の月次経年率。0.005＝半減期約11.6年（19世紀設備の世代交代）。0で二層化せずOldVintageCapital=0（現行恒等）
    public double VintageObsolescence = 0.5;      // 旧世代の生産性寄与を技術差で割り引く座礁の強さ（座礁分＝これ×techGap・techGap=2で全損）。トリアージ/承認工程に推奨値なし＝配線テスト値0.5を採用（保守側はここから半減）。0で割引なし＝Industrialization単一スカラーの現行に恒等
    public double RevolutionLandReform = 1.0;      // ★2026-08-04（列強再現率）：革命が土地権力を壊す＝共和革命で土地改革（限定的）・プロレタリア独裁で全面を floor-raise。史実＝封建地代の廃止1789年8月4日。旧＝政変後も貴族の地代＝政治力が無傷で反動ピンポンに130年浪費（仏の技術0.28）。0で厳密恒等
    public double BlockedLawGrievance = 0.002;       // ★2026-08-04（革命の点火信頼性）：阻止された法要求の不満＝MandateGateが止めるたび賛成ブロックの闘争度+これ×賛成×|純支持|／四半期。PushGrievance（押し切り遺恨・一発）の鏡像＝止められた側の怒り。仏が絶対王政のまま1914を迎える試合が10中9（政体exact10%）の是正＝1789の実体は封鎖された改革要求。0で厳密恒等
    public double OpulenceTaxRelief = 1.0;         // ★2026-08-04（P4）：国庫が月次義務の8四半期分を超えたら超過に比例してAIの税目標を縮める（床0.25）。旧＝スタンスの税目標が固定率で、黒字国が経済から貨幣を吸い上げ続けデフレ螺旋（プロイセン国庫1.3M/GDP17k・米38M）。0で厳密恒等
    public double LandedPowerCapitalization = 8000;   // ★2026-08-04（統一根の作り直し）：旧支配層の政治力の基盤に**土地**を算入＝Blocs の富に Closed 階級の地代（LandRent・月次フロー）×これを資本化して足す。⚠最初の実装（ClosedWealthMultiple=25＝流動資産を25倍）は**政治力と消費力を混同**し、貴族の消費予算が小国の物価を吊り上げて満足最小国が崩壊（ハーネス4/10赤）・教育市場崩壊等テスト4赤＝撤回。土地は政治力ではあるが流動的な購買力ではない。0で厳密恒等
    public double PrivateAbsorptionBlend = 1.0;   // ★2026-08-04：私的建設の desiredGrowth に吸収能力（AbsorptionOf＝技術/外資と同じ写像・床は CapitalCreditFloor 共有）を掛ける適用率。速度を絞る＝天井なし＝デッドロックなし（敵対審査の推奨形）。0で厳密恒等
    // ⚠撤去2026-08-12（再点火禁止・読み手ごと削除）: MilitarizeSpendThreatSpan  【墓標2026-08-08＝「形が先・金が後」（SpendFromNeedWeight）が代替済み・再点火禁止】★2026-08-04：Militarize の軍事費0.7を脅威で連続化＝0.7−これ×(1−脅威)。**0.4はA/B実測で棄却＝休眠確定**（政体exact−4.3・法−3.8・列強−3.8・経済−2.5＝軍縮した列強の軍事項が痩せて順位が崩れる。多様性は土地の政治力による教義の是正が既に担う）。0で旧＝0.7固定（厳密恒等）
    public double ClosedWealthMultiple = 1.0;     // ★2026-08-04（統一根）：貴族・聖職の初期資産の倍率＝**土地**。旧＝3000/人で資本家3200/人とほぼ同額＝旧支配層の政治力が英3%（blocprobe実測）＝法の門番が全員素通り＝全国1783年に近代法＝工業化の全球収束。1.0で旧と厳密恒等
    public double IndInvestFromIncome = 0.0;      // ★**0で確定＝休眠**（2026-08-04）。器と診断は残すが点火しない。      // ★2026-08-04（作者指摘「工業化なくしてコストをかけられる方が根本問題」）：私的投資の原資を**貯蓄ストックでなく所得フロー**にする。投資家の四半期所得のこの割合まで投資へ。【診断は正しい／基準の入れ替えだけでは直らない】投資家の**所得**はGDPの約20%＝妥当だが、**貯蓄ストック**は所得の700〜1200倍＝175〜300年分（英2127万・清8724万）。旧式 0.05×貯蓄 は英で106万/四半期＝投資家の四半期所得の62倍＝**予算が制約として一切効かず**、律速は材料だけ（輸入で埋まる）＝「工業化なくして金をかけられる」の実体。★しかし 0.4×所得 で点火すると旧式の約1/150になり、資本の更新が追いつかず**世界が崩壊した**（実測：英GDP 290,733→2）。釣り合わせるには係数を150倍＝「四半期所得の60倍を投資」という無意味な式になる＝**資本コストの較正があの巨大な貯蓄ストックを前提に組まれている**。直すなら建設コスト・減価率・貯蓄ストックを同じラウンドで一緒に動かす必要がある。0で旧式＝厳密恒等
    public double IndInvestmentFrac = 0.05;       // 投資家（資本家）が貯蓄からこの割合まで投資に回せる（affordability 上限）
    public double IndInvestmentSpeed = 0.012;     // 投資の速さ（純収益→建設需要への換算）
    public double IndPerConstruction = 0.01;      // 建設1単位が工業化度を上げる量（要較正）
    public double StateBuildCost = 40_000;        // 手動工場建設1回の国庫予約額。資本家と同じ建設の束（鋼/機械/セメント/製材）を国庫負担で買い工業化度に変換
    public double RgoCapitalShare = 0.5;   // ★2026-08-04（作者指示「投資家もプランテーションや鉱山に投資するように」）：資本家の建設が生む工業化度のうち、最も採算の良いRGO（農園/鉱山/牧場）の作付面積（BuiltScale＝Scaleの下限）へも回る比。旧＝資本家の建設は工業化度にしか変わらず、RGOは採算によるScaleの伸縮だけで**面積を増やす資本がどこからも来なかった**（工場はBuiltScaleが下限を押し上げるのにRGOには無い）。史実の農園・鉱山は資本を吸って規模を広げる（囲い込み・カリブの砂糖・南アの金）。同じ建設束・同じ予算から出す＝新しい資源も市場も作らない。0で厳密恒等（休眠）／StateShareCounterOnly=1.0 点火（2026-08-30）により既定ではこの枝は不走行＝rgoprobe 対照実験用に残置
    public double FactoryBuildScale = 0.5;        // 離散工場1棟の建設で増える生産者のScale下限（工場容量＝Vic2型）
    public double FactoryMaterialFrac = 0.6;      // プレイヤーの工場建設費のうち材料（鋼・機械・セメント・製材）に充てる割合。残り(0.4)は工賃（StepConstructionで工員へ）。材料は建設期間で徐々に消費
    public double ConstructionLaborWageFrac = 0.67; // 投資家/国家の建設：材料費×これを工賃として工員へ（材料6:工賃4の比＝投資にも工賃が乗る）
    // プレイヤー工場建設の材料費は「素材の市場価格に依存」（鋼が高い時期は割高＝上限なしの真の価格依存）。
    // 素材高騰では建設を**崖でなく連続に絞る**（採算の連続判断＝期待利潤に対し建設費が嵩むほど建設率が滑らかに減衰）。
    // 鋼で鋼工場を建てる自己フィードバックは、建設率減→需要減→価格低下で自然に律速（停止→再開のオン/オフ振動を排除）。
    public double FactoryBuildPriceCeil = 2.5;   // 建設率の半減点：素材束価格/参照 がこの倍率で建設可能率=0.5（崖でなく中心）
    public double StateProcurePriceGate = 1.0;   // ★2026-08-03（作者指示「全ての政府支出で、価格を無視しないよう修正。これは全て同じ計算式でよい」）：国家調達の価格感応の適用率。旧＝どの政府支出も予算の制約だけで、参照価格との比を見ずに**何倍の高値でも買い切る**買い手が市場に居座り品薄財の価格を押し上げていた。式は私的な工場建設と同一（FactoryBuildAfford＝現在価格/参照価格の連続減衰）＝新しい定数を置かない。適用先＝行政/上下水道/電化インフラ/兵力/軍需4層/艦隊修理/国家建設/巨大建造物/植民地維持費。1=満額適用・0=旧恒等（休眠）
    public double FactoryBuildAffordSteep = 4;   // ★点火2026-08-31＝16→4（清レポ＝16は「逓減の衣を着た崖」。4で束比3倍でも進捗が細く残る＝壁でなく逓減。ラウンドA実測でハーネス末端財の死蔵も解消）
    public double FactoryStartAffordFloor = 0.15; // ★点火2026-08-31＝0.5→0.15（清レポ4-1「建設の壁」＝後発国の束比3〜5倍で着工が離散的に不可能だった崖の是正。進捗側が同じ採算率で連続に絞るので床は低くて良い。旧World定数の係数化と同時）
    // ★休止（mothball・AI審査2-6・2026-08-31）：建てた工場（倒産免除）の慢性赤字を止める欠けていた第4の動詞（施設は残る/倒産する/★休止する/国有化される）。
    public double FactoryMothballRate = 0.05;    // ★点火2026-08-31（ラウンドB）＝月次の休止/再開の速度（床割合/月）。建てた工場（倒産免除）の慢性赤字の垂れ流しを止める第4の動詞（施設は残る/倒産/★休止/国有化）。0で休止なし
    public double FactoryMothballMarginIn = 0.15; // 休止に入る慢性赤字の深さ（SmoothedMargin<−これ）。再開は採算回復（>0）＝閾値を増やさない
    public double FactoryMothballCap = 0.9;      // 休止できる床の上限割合（×民営持分。国営持分は休止しない＝国庫が支える既存設計の維持）
    // ★塊1 飢饉の深さ（AI審査2-1/2-2・docs/20260830/20260830_塊1）。段0と段1bは**別々に測る**（符号の是正と参加者追加は別の帯）。
    public double StapleElasticityZero = 1.0;        // ★点火2026-08-31（ラウンドB）＝段0：主食の自己価格弾力を0に＝必要量は生理的に決まり、買えるかは予算制約が決める（符号の是正＝正しい挙動枠）。主食どうしの乗り換え（CrossElasticity）は残る。実測＝経済+3.8/領土+3.3/貿易+5.6/英常勝6→4勝・◎−3は記録コスト。0で旧データ弾力
    public double FoodIncludesAnimalProtein = 0.0;   // 段1b：動物性タンパク（加工肉63/干物64・Nutrition=1）を食料に数え、交差弾力の食卓に参加させ、主食の必要量を AnimalNutritionNeedRatio で譲る（総食料需要は中立）。ギッフェン＝肉高騰→需要がパン/芋へ流れる、が既存の交差弾力から創発。0＝厳密恒等

    /// <summary>工場建設の採算連続判断：素材束の現在費用/参照費用 の比に対し建設可能率∈(0,1] を滑らかに返す（崖でなく漸減）。
    /// 比=FactoryBuildPriceCeil で 0.5、未満ではほぼ1、超えると Steep で急減。期待利潤に対し建設費が嵩むほど妙味が連続的に減衰。</summary>
    public double FactoryBuildAfford(double cpuNow, double cpuRef)
    {
        if (!(cpuRef > 1e-9) || !(FactoryBuildPriceCeil > 1e-9)) return 1.0;
        double ratio = cpuNow / cpuRef;
        if (!(ratio >= 0)) return 1.0;
        return 1.0 / (1.0 + System.Math.Pow(ratio / FactoryBuildPriceCeil, FactoryBuildAffordSteep));
    }
    public double SoeSaleYears = 5.0;             // 国営工場の民間売却価格＝年間利益×これ（資本家の貯蓄が足りないと売れない＝レッセフェール移行のゲート）
    // 工業化由来の生産性＝1 + Gain×工業化度/(1+工業化度/Scale)。固定上限を持たず Scale で逓減（飽和）し頭打ち。
    public double IndProductivityGain = 1.2;      // 低工業化度での生産性の伸び（飽和カーブの初期傾き）
    public double IndProductivityScale = 2.5;     // 生産性の逓減スケール（工業化度がこれを超えると伸びが鈍る）
    // 規模の経済（B-2）：工場財の生産性が操業規模で上がる＝大工場ほど単位コスト安→輸出規模を持つ国に産業が集中（rich-get-richer）。
    // 規模＝産出/自国市場需要(u)。u/(u+Half)で飽和（発散しない）。自給規模(u≈1)では控えめ、輸出で規模を伸ばすほどボーナス。RGO・役務・労働は対象外。
    public double ScaleEconomyGain = 0.3;         // 規模ボーナスの最大上乗せ（飽和値。0で無効＝従来）
    public double ScaleEconomyHalf = 1.5;         // 規模ボーナスが半分に達する u（産出/自国需要）。大きいほど大規模でないと効かない
    // 冷蔵の時代動学（B-2）：工業化が進むと生鮮（肉・魚・乳・果実）の腐敗が下がる＝1870s冷凍肉貿易革命。工業化でゲート（TechLevelよりスケールが既知）。
    public double RefrigerationEffect = 0.7;      // 完全な冷蔵で生鮮の腐敗が下がる最大割合（0で無効）
    public double RefrigerationIndOnset = 1.0;    // 冷蔵が立ち上がる工業化度（これ未満＝冷蔵なし＝従来の腐敗）
    public double RefrigerationIndSpan = 1.5;     // 冷蔵が完全に効くまでの工業化度の幅（onset+spanで満額）
    // 収益駆動の投資：限界収益(逓減)×(1+Leverage×技術) − CapitalCost > 0 の間だけ投資＝固定上限なしで均衡が創発。
    public double IndCapitalCost = 0.7;           // 投資の資本コスト（D1腕=0.45の顛末は IndDepreciation の注記を参照）
    public double IndTechLeverage = 2.4;          // 技術が工業化の収益を高める強さ（高技術国ほど高工業化＝国ごとの差を生む）
    public double BaseUrbanCap = 0.20;            // 前工業の都市化上限（1789≈20%）
    public double UrbanCapFollowSpeed = 0.02;   // 【点火0.02・2026-08-16＝S級梯子r4単独37/71/56】都市化天井の工業化追従に建設時間（時定数≈4年）＝天井ジャンプ時の史実比8-10倍速い都市化を律速。      // 監査2026-07-05（D3）：都市化天井の工業化追従速度（月次）。1=即時追従（現行と厳密一致）・0.02程度で住宅/インフラの建設時間＝天井が数年遅れて追いつく。#17で有効化検討
    public double UrbanPerInd = 0.08;             // 工業化度1あたり都市化上限の上乗せ（史実：1890で都市≈37%）
    // 工場建設が食う束（鋼＋機械＋セメント＋製材）＝これらの死蔵を解消する消費先（最も不足する成分が律速）
    // 機械は少数の専門職が担う資本財段で常に最も薄い→建設での必要量を下げ「機械は希少でも工業化の壁にはしない」
    // （機械は発電機・電化製品など他用途で価値を保つ）。建設の主体は構造材（鋼・セメント・製材）。
    public double StateBuildUnitsPerMonth = 0;    // 国家建設の月次単位数の物理上限＝建設の工期（バランス調査2026-07-27・dormant温存）。0=無制限＝現行恒等。
    // 実測2026-07-27：現行は開幕に「AI国庫×初期市場在庫200」で全AI国が1四半期に工業化+2.0のバースト（地図の開発度表示で可視化された）。
    // 2.0/月に絞ると10年で序列が史実化（英0.83>普0.73>日0.56>伊0.42>仏0.31・民間投資が主役に復権）が、**忠実度がexact38→28/near70→57へ大幅劣化**
    // （逸脱過多13→23カ国＝アジア後発国の経済→政変→戦争の全連鎖が開幕バーストの上に較正されている）＝バーストは忠実度較正の暗黙の土台。
    // 点火は再較正ラウンド（Search再走で他係数と同時調整）でのみ＝単発点火は機構飽和の教訓どおり劣化する。
    public double ConsSteel = 1.0;
    public double ConsMachine = 0.15;
    public double ConsCement = 0.4;
    public double ConsLumber = 0.5;
    public int SteelGoodId = 32;                  // Catalog の id
    public int MachineGoodId = 53;
    public int CementGoodId = 35;
    public int LumberGoodId = 39;
    // 工場建設費の素材階層+α（2026-08-09・ユーザー裁定「基本は固定・上位材+α」）：出力財の連鎖深さ（Catalog.Complexity＝レシピDAG最長深さ0〜9・手置きテーブルなし）で建設費を差別化。
    // 建設1単位あたり 機械（MachineGoodId）を これ×max(0, 深さ−1) 束だけ**追加**購入（深さ0のRGOと深さ1は式から自然に+α=0＝特例コードなし）。
    // ⚠costPerUnitRef には**意図的に加えない**＝加えると建設単位 u が縮んで「+α」でなく既存4材の「置換」になる（基本束は不変・+αは Cost の外の追加支出＝裁定の実装形）。
    // ⚠着工ゲート（World.ConstructionAfford）と進捗ゲート（StepConstruction）にも**意図的に加えない**＝機械高騰で着工・進捗が止まらない fail-open（サプライを考える負担を作らない裁定）。
    // 書き手＝なし（純係数）。読み手＝EconomyStep の工場建設ブロック限定2箇所（需要計上:614付近・決済:1500付近）のみ＝Cons*系の他経路（国家建設・巨大建造物・私的工業化・保守）へ波及しない。
    // 番人＝FactoryTierTests（点火ピン0.05・Complexity階層ピン・ON経路の式・保存）。★点火済み（2026-08-09 ign_tier）＝0に戻せばガード>1e-12を踏まず1命令も実行しない＝既存フルスイート全緑がビット恒等の番人。点火設計値0.05目安。
    public double FactoryTierMachinePerDepth = 0.05;
    // 工業化に伴うインフラ敷設（鉄道）＝建設に比例して消費。資本財段（機関車→蒸気機関→機械部品）へ需要が波及し死蔵を解消。
    public int RailGoodId = 56;                   // 線路
    public int LocoGoodId = 88;                   // 機関車
    public double ConsRail = 0.25;
    public double ConsLoco = 0.12;
    // 敷設済みインフラの保守需要＝工業化度×これ。成長（建設）が止まってもセメント/線路/機関車を毎期消費＝定常でも消費先が持続（死蔵解消）。
    public double InfraMaintRate = 0.4;

    // --- 輸送・物流（§5.1拡張：港・鉄道・船。世界市場は港州のみ、内陸は鉄道で港経由。容量不足→購入量限界縮小→価格上昇）---
    public bool TransportEnabled = true;            // 輸送ゲートの有効化
    public double InlandPortDistanceDecay = 1.0;    // 内陸州のrailToPort容量を最寄り港までの海路距離で減衰（trade-capacity-even-share-not-network）＝遠い内陸ほど鉄道を食い港集約が創発。減衰=1/(1+これ×NearestPortDistanceKm/10000)。0で均等割りそのまま（恒等）
    public double TransportDecay = 0.02;            // 鉄道/船容量の月次減耗（維持に投資が要る＝持続需要）
    public double TransportTargetPerPop = 0.08;     // 目標容量＝人口×これ（必要数を増やし鉄道供給網の構築を要求）
    public double TransportCapPerUnit = 30.0;       // 鉄道/船 1単位の購入が積む容量
    public double TransportBuildRate = 0.15;        // 容量ギャップを毎月詰める速さ（投資の上限割合）
    // T1（輸送doc §3-3・2026-07-31）：輸送財の**需要の計上**を買い手の支払い能力で頭打ちにする係数（1単位あたり＝手持ち貯蓄で買える単位数の倍率）。
    // ⚠旧＝目標との差から出る希望量をそのまま LastDemand に載せていた＝**買えない国（人口だけ大きい国）の需要が世界市場に載り、
    // 買える国（英・蘭）の線路・機関車・帆船・汽船の調達費を押し上げる**。★在庫0でも需要を立てる意図（鶏卵回避）は貯蓄がある限り保たれる。
    // 0（既定）＝上限なし＝分岐に入らず厳密恒等。1.0＝「今月の手持ちで買える量まで」。
    public double TransportDemandAffordCap = 0.0;
    public double TransportBaseline = 50.0;         // 前鉄道の基礎輸送（道路/河川＝低容量で高コスト）。鉄道前は州が世界市場と細々としか繋がらず地域価格が割れる→鉄道（容量≈人口×0.08）で統合され収束
    public double RailTechOnset = 0.35;             // 鉄道（内陸輸送）の技術解禁。工業化判定閾値(IndustrializedTechThreshold0.25)の一段上＝工業化に入った国から鉄道を積める。旧1.0は採用上限(AdoptionCeiling0.5)/後追い天井(×CatchupFraction0.7)と不整合で後発国・単一国が永久に解禁できなかった（Wave1-B監査）。船(帆船)は古来あり据え置き
    public double RailTechWidth = 0.5;             // 解禁の幅：onset(0.35)〜onset+width(0.85)で鉄道容量上限が0→満額へ。先端国は満額・工業化途上国も部分的に鉄道を持てる（普及の漸進）
    public int[] ShipGoodIds = [84, 85];            // 帆船(tier1)・汽船(tier2)
    public int ShipTier2GoodId = 85;                // 汽船＝tier2輸送船（蒸気船）。蒸気機関を要する＝供給チェーンで自然に技術ゲート
    public double ShipTier2CapMult = 2.5;           // tier2輸送船は1単位あたり容量が大（蒸気船は帆船より高速・大容量＝海運の革命）

    // --- 国際移民（§A-3拡張：ゲーム外＝未モデルの世界全体から、機会の高い国へ大衆が流入。非ゼロサム＝他国を奪わない。史実：米は欧州各地・アジアから移民吸収）---
    public double MigrationStayHome = 0.55;         /* 移民史実化2026-07-08：0.7→0.55 */ // この機会水準以下なら移民は来ない。0.7では米が125年不発（対仏比13.6%のまま・史実は253%へ）＝seed1実測。流入量＝世界プール（WorldMigrationPoolFrac×世界人口）のpull比例配分（02断線走査2026-07-28：旧ImmigrationRate記述を是正）
    // 改修2026-06-28：アメリカ脱工業化の構造修正（移民が農業世界の技術水準一極に吸われず工業州にも流れ、労働者として着地する）。多国移民専用＝単一国較正は内部移民非走行で不変。
    public double IndustrialOpportunityWeight = 0.5; // 工業化度1あたり移民機会の上乗せ（Opportunity ×(1+これ×Ind)）。空世界の技術水準の静的高生産性一極吸引を解く
    public double OpportunityWageWeight = 0.2;       // 州の労働価格プレミアム（1人あたり月次所得の対国平均比＝Region.WagePremium）1あたり移民機会の上乗せ（Opportunity ×(1+これ×(premium−1))）。金鉱州の高賃金→移民殺到＝ゴールドラッシュを賃金経由で創発（キュー3・金発見移民）。0=恒等（較正中立＝単一州はpremium=1）。0.2採用＝実測2026-07-10：(a)wageprobe＝前提「欧州平時bestOpp<0.55」は不成立（全53カ国が常時>0.55＝国際流入は受入上限ImmigrationReceiveCapFracで飽和＝重みは国際流入量を変えず磁石化リスクなし（02断線走査2026-07-28：死んだImmigrationMaxFracの論拠を実係数へ差し替え）・実効は金鉱/ブーム州への誘導＝受入州選択・国内移動）(b)提案帯0.3-0.4は4国回帰番人「工業化の差別化」を壊す（0.3→spread0.15/0.4→0.22＜基準0.5＝賃金スパイク追随が工業州への集積を乱す）→番人合格の上限0.2
    public double ImmigrantWorkerBase = 0.3;         // 移民のうち労働者になる基礎割合（農業州＝Ind0で3割が労働者・7割農民）
    public double ImmigrantWorkerPerInd = 0.2;       // ＋行き先州の工業化度1あたり労働者割合↑（Ind3で〜0.85上限＝工業州は労働者として着地）

    // --- 外交・戦争（§6.1 国際層）---
    // ※旧 MilitaryFromCoercion / GdpPerMilitary（圧政ベースの軍ゲージ）は Part 2 で兵士POPベースに置換し廃止。
    public double InsultChance = 0.35;            // 3ヶ月毎にライバルを侮辱する確率。0.6→0.35＝ライバル間の緊張エスカレートを抑え開戦回数を減らす
    public double InsultTension = 6;              // 侮辱の緊張↑（15→6＝休戦明けの急再燃を防ぐ。再上昇は脅威/イデオロギー主体の緩やかなものに＝同一ペアの時計仕掛け連戦を防ぐ）
    // ★緊張のラチェット解消（2026-07-31・英崩壊の切り分けで判明）：緊張は**100超で減衰が完全に止まり**、
    // 開戦閾値140への一方通行になっていた。講和後の PostWarTension(38)+RevanchismTension(70)=108 も、
    // AI屈服の ConcedeTensionTarget(110) も、どちらも**この「永久に冷めない帯」に着地**しており、
    // 講和も屈服も実質的なデエスカレーションになっていなかった（＝戦争でしか解けない状態が恒久化する）。
    // 既定0で現行の永久凍結＝**厳密恒等**。>0 で高緊張帯にも自然減衰を与える。
    // ※既存の例外（FrozenTensionDecayRate＝開戦経路が塞がれたペア／DefeatShockTensionRelief＝直近の敗戦国の保護）は
    //   より特定的なので優先される。本項はそれらに当たらない一般の高緊張ペアに効く。
    // ★★**再設計2026-08-01（作者指示「固定値は採用したくない・何かしらの値を絡めたい」）＝意味が変わった。**
    // 旧＝月あたりの減衰量そのもの（0.2 を試して差し戻し：near62→58・◎21→19・SOURCE-HASH c1a6d710fd3d3acd）。
    // 新＝**「遺恨がゼロのとき、平時の何倍の速さで冷めるか」**の倍率。実際の減衰量は
    //     TensionDecay(0.42) × これ × (1 − 遺恨) で、遺恨は講和で1に立ち**失地と同じ半減期**（LostLandHalflifeQuarters=80四半期＝20年＝アルザス）で薄れる。
    // ★狙い＝実測で判明した「同一ペアの再戦：平均 最多7.2回・3回以上戦うペア67組・最悪 清×ボルネオ9回」の構造的原因を潰す。
    //   原因＝講和後の PostWarTension(38)+RevanchismTension(70)=108 が**100超＝永久凍結帯**に着地し、開戦閾値140への一方通行になる。
    //   奪われた側は世代を跨いで冷めない（アルザス）が、**何も失っていないペアは平時と同じ速さで冷める**＝繰り返し開戦が止まる。
    // 0 で分岐に入らず厳密恒等（遺恨も書かれない）。1.0＝「遺恨ゼロなら平時と同じ速さ」＝新しい水準を1つも発明しない。
    public double HighTensionDecayRate = 1.0;   /* **点火2026-08-01＝遺恨ゼロなら平時と同じ速さ** */
    public double TensionDecay = 0.42;            // 平時の緊張の自然減（月）。0.18→0.42＝冷却を速め全体の緊張水準を下げ開戦回数を抑える（100年で〜10回狙い）。小さい＝周期的列強戦争が増える
    public double FriendlyTensionMax = 20;        // これ未満＝友好（同盟の条件）
    public double RivalTensionThreshold = 40;     // これ超＝ライバル（共通の敵）
    public int WarTriggerMonths = 6;              // 緊張100以上がこれだけ続くと開戦（攻守区別なし）。戦争過多を抑えるため3→6（長い緊張の末に開戦）
    public double AllyJoinTension = 40;           // 同盟国が参戦する敵への緊張（参加義務なし＝利害一致時のみ）
    public int MaxAlliances = 2;                  // 1国の同盟数の上限（全員同盟を防ぐ）
    // 対覇権合従（B-1・弱者連合 against the hegemon）：突出した覇権国が現れた時のみ、覇権でない国どうしが緊張低くても手を結び・参戦しやすくなる（三国協商型）。
    public double HegemonThreatMin = 0.3;         // 覇権と見なす最低脅威超過（GDP×0.6＋植民地×0.4 の平均超過分）。これ未満＝明白な覇権なし＝通常の同盟のみ
    public double AntiHegemonAllianceChance = 0.7;// 覇権が共通の敵のときの同盟成立確率（通常0.4より高い＝合従が組まれやすい）
    public int AntiHegemonExtraAlliances = 1;     // 覇権に対抗する時だけ同盟上限を+これ（三国協商＝三極以上の合従を許す）
    public double AntiHegemonJoinFactor = 0.6;    // 敵が覇権のとき同盟国の参戦閾値をこの倍率に下げる（皆で覇権に雪崩れ込む）
    // 反覇権の経済封じ込め（最終調整2026-06-29・ユーザー指示「覇権はスコアでなく外交の失敗による包囲網で揺るがす」）：
    // 明白な覇権国は、合従側の市場から締め出され**交易アクセスを追加で失う**（大陸封鎖・対英経済戦型）。覇権度（脅威超過）に比例し、
    // 覇権が縮めば封じ込めも緩む＝自己抑制的（暴走しない）。多国限定（Powers不在の単一国較正では Hegemon=null で非発火＝較正中立）・戦争を起こさず経済だけで締める。
    public double HegemonContainmentTrade = 0.40; // 封じ込めで覇権国が失う交易アクセス＝これ×脅威超過（0で無効）。海軍で侵攻不能な島国覇権を経済で律する主レバー。バランス2026-07-07：0.30→0.40（上海16/30勝＝53%の寡占を抑え目標「最大勝率≤50%」へ）
    public double HegemonContainmentMax = 0.55;   // その上限（交易アクセス floor 0.1 まで落とさず・最大でも交易の約半分まで）
    // ★診断のみ（2026-08-12・既定0＝1行も書かない＝厳密恒等）。1で、決定的な講和のたびに戦勝点を
    //   「押し合いの累積」と「運の累積」へ分解した行を年表へ出す。warprobe が立てる。力学は読まない。
    // ★2026-08-12（作者裁定①）：崩壊講和（厭戦100%）の取り分を「その戦線で実際に押していた量のシェア」で割り引く。
    //   0＝現行＝崩壊した国が抱える全戦争へ一律±1.5（＝ラオスもモロッコもイギリスに完勝できる）＝厳密恒等。
    //   1＝届いていない戦線では取り分ゼロ＝白紙講和。中身は既存の較正済み量だけ（兵の絶対数×補給距離×制海権×戦費充足×技術の質）。
    //   ★点火2026-08-13（実測10シード・硬性ゲート全緑）：8軸のうち6軸が改善し合計+23.1pt
    //   （政体exact 28.5→36.7・法 48.1→52.0＝初の50%ゲート突破・人口 10.0→15.7・領土本国 79.2→85.0・経済 23.8→27.5）。
    //   分離独立の建国も131→103回＝帝国が崩壊代入で解体されなくなった。
    public double CollapseImposeFromFront = 1.0;
    // ★2026-08-12（作者裁定②）：昇格の高等教育ゲートを「エリートに届いた余剰教育(higherEdu)」から
    //   「志望者本人が積んだ就学(EducationFill／EMA)」でも代替できるようにする**重み**（形は max＝下げる方向には働かない）。0=現行と厳密恒等（休眠）。
    //   >0 で「教育が不足している社会では教師を一人も育てられない」自己閉鎖が解け、人口が増えれば教師も時間とともに増える。
    //   価格→教師の所得→attract>1→昇格 の負帰還は既に配線済みで、閂（乗算で必ず0になる項）を外すだけ。
    //   自己制動あり＝教師が増える→供給増→価格低下→attract≤1 で止まる。学校が1つも無い社会では ownEdu も secular も 0＝無からは湧かない。
    //   ★点火2026-08-13＝0.5（実測10シード・硬性ゲート全緑）：合計+17.0pt
    //   （人口 10.0→17.1・列強再現率 17.5→21.3・領土本国 79.2→82.5・領土植民地 40.0→43.3）。法だけ-1.6。
    //   ★0.5→**0.15**（2026-08-13）：0.2以上でイギリスが所得税を解禁できなくなる（TaxTests が赤）。
    //     原因は希釈でなく**供給側**＝教師/技師/医者へ人を引き抜くと都市労働者が薄くなり行政の産出が落ちる。
    //     これ自体は実在のトレードオフ（学校に人を置けば役所に人が足りない）だが、当のテストは行政予算を0.8に固定して
    //     いるため「行政力が落ちたら行政費を上げる」応答が働かない。0.5 は根拠なく選んだ値だったので、
    //     既存の挙動アンカーを壊さない範囲（崖は0.18〜0.2）から余裕をとって 0.15 を採る。
    //     ⚠本当の欠落は「行政費が AdminFill に応答しない」こと＝教師の件と同型（不足に供給が応答しない）。別項目。
    public double PromotionGateOwnSchooling = 0.15;
    // ★2026-08-12（作者裁定③）：移民の受入上限に受入能力（食料充足×住居充足×土地逓減）を指数 e で掛ける。
    //   0=現行と厳密恒等（休眠）。cap は「率」なので現行は人口が増えれば上限も同率で増える正帰還＝有限の定常点が無い。
    //   耕地は移民で増えない既存ストックなので、e が十分大きいと1人あたり流入が人口の減少関数になり水準で止まる。
    //   探索帯の目安 1.5〜3.0（初手 2.0）。止まる位置は新しい数でなく既に較正済みの耕地・住宅・食料が決める。
    //   ★点火2026-08-13＝2.0（実測10シード・硬性ゲート全緑・テスト283緑）：戦争+教師の合成に上積みで**さらに+13pt**
    //     （法 55.2→59.2・経済規模 28.7→32.5・領土本国 80.8→83.3・人口 5.7→11.4＝移民の暴走が正された分）。
    //     3機構の合計は基線比 **+36.6pt**。
    public double ImmigrationAbsorbExponent = 2.0;
    public double WarScoreDecomposition = 0.0;
    // ★塹壕（2026-08-13・doc 20260812_塹壕と戦車）：守る側の機関銃（陸分の上位軍需）が押し合いを削り、
    //   攻める側の戦車（陸分のtier3）がその壁を無効化する。0＝壁なし＝厳密恒等（分岐に入らない）。
    //   1で「守る側が機関銃を満たし攻める側が戦車ゼロ」のとき押しが0＝完全な膠着。
    //   ⚠接触強度（戦死・戦災）には掛けない＝戦線は動かないが人は死ぬ（WWIの実相・厭戦→革命の狙い）。
    // ★残余カスケードの廃止（2026-08-13）：軍需の4段（基本・上位・tier3・空軍）を同時に立て、不足は一律比例で削る。
    //   0＝旧の入れ子（残余が上から下へ流れる）＝厳密恒等。1＝一律按分。
    //   旧の害＝予算が基本段に届かない国は上位以上が**厳密にゼロ**（装備が二値になる）／
    //   開戦で消費9倍・予算3.8倍なので**戦争中は上位段もtier3も0**（塹壕と戦車が戦場で消える）。
    //   ★実測2026-08-13で**差し戻し（休眠のまま）**：硬性ゲート赤（破綻1/10・ハーネス不合格1/10）。
    //   帯も 経済規模 37.5→19.4・政体exact 36.4→28.3。理由＝一律按分は**優先順位の廃止**で、貧しい国が
    //   基本装備（小銃・弾薬＝全コストの63%）を揃える前に戦車と弩級戦艦を買い始め、軍が機能不全になって経済ごと壊れる。
    //   カスケードは「まず銃、余ったら機関銃」という優先順位そのもの。docの前提（大軍国が基本段で使い切る）は
    //   S3a（予算を需要でキャップ）の点火で既に消えており、docの記述が現物より古い。
    //   ★残る本当の穴＝**開戦で消費9倍・予算3.8倍のため戦時に上位段が消える**。優先順位を保ったまま直すには
    //   WartimeBudgetFollowsNeed（予算が需要に追随する度合い）の側を扱う。別項目。
    // ★耐久装備のストック（段2a・2026-08-13）：上位段とtier3を**ストック**にする。0＝現行のフロー＝厳密恒等。
    //   戦時の9倍は需要でなく**摩耗**へ回す＝機関銃は9倍壊れないが、9倍激しく使えば早く壊れる。
    //   発注は不足分 (目標−在庫)⁺ だけ＝予算を9倍にしなくても戦場に装備が残る。
    //   ★点火2026-08-13＝**塹壕と対で**（TrenchDefenseWeight とセット）。実測10シード：
    //   ストック単独＝硬性ゲート赤（損失financing 68.5%＝人口12万のジブラルタル共和国で分母が痩せた）・帯−21.7pt。
    //   ストック＋塹壕＝**硬性ゲート緑**・帯−5.4pt・◎7割帯 16→19。
    //   理由＝耐久装備を在庫にすると軍事力が恒久的に嵩上げされ（質乗数が下がらない）単独では戦争が一方的になる。
    //   塹壕は「守る側の機関銃が押しを削る」ので、その嵩上げを**防御側の利益として回収**する。**2つは対**。
    // ★財の地理ゲート（2026-08-13・裁定⑥）：希少鉱物6財（硫黄・金・銀・クロム・錫鉱・硝石）を**産地でしか採れない**財にする。
    //   非産地は厳密に0・産地の賦存は**世界総産出が不変になるよう逆算**（産地数は world.json から数える＝手で書かない）。
    //   0で厳密恒等。★硬性ゲートが割れる可能性が本ラウンド随一なので**硫黄1財だけ単独で測る**こと（裁定⑥）。
    //   ★実測2026-08-13で**差し戻し（休眠のまま）**：硫黄1財だけでも硬性ゲート赤（ハーネス不合格3/10）。
    //   内訳＝**下流の無い財＝肥料109・ダイナマイト128・化学兵器133**が世界のどこでも作られなくなった。
    //   帯も 人口 18.6→4.3・列強再現率 22.5→8.7。
    //   ★docの「世界の総供給は変わらない＝§3の破局を回避」は**必要条件であって十分条件ではなかった**。
    //   総量が同じでも産地が1州（パレルモ）に集中すると、そこから**輸送で届かない国**では下流が丸ごと消える。
    //   ★先に要るのは「産地を増やす」か「下流が代替レシピを持つ」か。地理ゲートはその後。
    public double ScarceMineralGate = 0.0;
    public double ScarceMineralOnlySulfur = 1.0;   // 測定用（裁定⑥）：1で硫黄5のみを対象にする。0で6財すべて。
    public double ArmsStockEnabled = 1.0;
    public double ArmsWearRate = 0.02;            // 平時の月次摩耗率（定常で 目標×これ ＝ 現行の平時フローに一致するよう逆算）
    public double ArmsWarWearScale = 1.0;         // 戦闘消耗＝摩耗に (warMult−1)×これ を上乗せ（1.0＝9倍戦時は摩耗9倍）
    public double MilitaryProcureProRata = 0.0;   // 一律比例按分。2026-08-13 実測で差し戻し（破綻1/10）＝0で休眠
    // 直下 TrenchDefenseWeight の注記：
    //   ★点火2026-08-13＝0.5（ArmsStockEnabled と**対**。装備が戦場に残る世界でのみ意味を持つ）。
    //   ★装備がフローだった頃に単独で測ると −17.8〜−26.4pt だった＝前提（戦場に装備がある）が偽だったため。
    public double TrenchDefenseWeight = 0.5;
    public double WarPushSpeed = 0.10;            // 戦争スコアの押し合い速度（月）
    public double WarLuck = 0.12;                 // 戦況の運（決定的会戦・補給・士気）＝毎月の戦勝点に±これの乱数を加算。勝敗と終結時期を読みづらくし逆転を生む（軍事力は依然効くが絶対でない）
    // ★★上陸ゲート（2026-08-01・作者裁定）：「開戦で負けない限り、**陸続きでない限り陸戦は起こさない**。少なくとも海軍力で勝たないとブリテン島には乗れない」
    // ＋精密化「厳密には、**海戦で閾値に勝たない限り上陸はできない**＝陸戦は起きるが、**その被害は民間には出ない**」。
    // ⚠旧＝Projection に SeaControl（連続値）が乗るだけで、**海軍が劣勢でも1隻も持たなくても海越えの押し合いに参加できた**
    //（大陸の勝者が海を越えて本国州を削れる＝英が開幕16年で本国5州のうち4州を失い151年間回復しない実測の直接の経路と見ている）。
    // ★機構＝制海権がこの値未満／海軍ゼロの側は、海越え戦線で陸の押し（Push）が0になる。**戦争は続く**（海戦・通商破壊・厭戦・封鎖はそのまま）。
    // ★★「民間に被害が出ない」は自動的に従う：戦災と民間人死は contact＝min(自分の押し, 相手の押し) を分母に持つため、
    //   上陸できない側の押しが0になると contact も0になり、**戦災（農業/畜産/工業/送電/港/鉄道/商船）も民間人死も一切発生しない**（Diplomacy の戦災ブロック）。
    // ★値の根拠（史実のアンカー）：1805年のイギリス戦列艦シェアは約0.61で、**ナポレオンは海峡を渡れなかった**＝仏側0.39では当然として、
    //   **0.61でも上陸を許さない**＝閾値は0.61より上。一方 1854年クリミアは連合の制海が圧倒的（露黒海艦隊は自沈）で**上陸は成功**＝閾値は0.9より下。
    //   したがって区間(0.61, 0.9)。**0.65＝およそ2:1の明確な優勢**を採る（対抗上陸には数の互角では足りない、が本義）。⚠この1本が本機構の唯一の較正点。
    // 0 で常に1.0＝厳密恒等。陸続きの戦線には一切触れない。
    public double SeaInvasionControlMin = 0.65;
    public double WarDeclareTension = 140.0;      // **2026-07-25採用（C-高6の次段＝下げ戻し）**：exact38/near71/◎20・人口一致30%（ともに梯子最高）。屈服経路（AISubmitMilRatio=3.0）の開通で一方的な組合せは戦わずに折れる＝旧140へ戻し互角の対立だけが戦争へ（160は屈服なし時代の戦争過多対策だった）。緊張上限200
    // 1934拡張 #106（外交・戦争UI）。全てプレイヤー経路のみ＝自己対戦/較正に無影響（Mobilized/PendingWarは非プレイヤーで常にfalse/null）
    public double MobilizationConscriptFrac = 0.22;   // 総動員ONでの戦時徴兵の深さ（levée en masse＝大衆の22%まで兵士化・平時上限0.04/通常戦時0.12を超える）。既存のDrawFromPoolで非兵士POPを兵士へ変換＝代償は自然（労働喪失で経済悪化・兵増で戦死増・国民意識ゲートで低NC国は届かない）
    public double ConcedeTensionTarget = 110.0;   // 最後通牒で「要求を受け入れる」＝緊張をこの値へ下げて開戦を回避（WarDeclareTension=140未満）
    public double TensionPopupThreshold = 70.0;   // 緊張ポップアップを出す内部緊張の閾値（同ランク列強と）＝**宣戦閾値の半分**（WarDeclareTension=140）。プレイヤーUIのみ＝自己対戦/較正に無影響
    // ★2026-08-02に 100→70（作者指摘「もっと早く通知してもよい」）。100は表示のクランプ上限と同値だったので
    //   通知は必ず「100%」と出て**数字が情報を持たなかった**（GameViewModel.TensionPct を見よ）。
    //   半分に置けば、宣戦までの折り返し地点で一度だけ知らせる＝まだ増減の操作が効く時点で選べる。
    //   ⚠一度出した相手は TensionRepromptDrop ぶん下がるまで再通知しない＝頻繁には出ない。
    public double WarCostPerMilitary = 400.0;     // 軍ゲージ1あたりの月次戦費（とにかく金食い虫）
    public double WarExhaustionRate = 0.03;       // 戦争疲弊（厭戦%）の蓄積：戦争の持続（月あたり基礎）
    public double WarExhaustionEcon = 0.10;       // ＋経済悪化（GdpDrawdown）に比例して厭戦が増す（月）
    public double WarExhaustionBlockade = 0.07;   // ＋通商破壊（海上封鎖）の度合い(1−CommerceRaidFactor)に比例して厭戦が増す（月）。改修2026-06-28：封鎖の即時の痛みを厭戦へ直結（兵糧攻め＝海軍劣勢国の士気を削る）
    public double WarExhaustionCasualty = 0.6;    // ＋戦死（兵士に対する戦死率）に比例して厭戦が増す
    public double WarExhaustionMilitancy = 0.04;  // 厭戦→闘争度：厭戦%に比例して交戦国の大衆の闘争度が上がる（長期戦・敗色→革命）。⚠WarMilitancyViaTarget>0.5（既定）では不読＝旧経路
    public double WarFeverMilitancy = 0.6;     // 闘争度→戦争熱：大衆の闘争度が戦争熱を押し上げる（外征で内憂をそらす）
    public double WarFeverMilitancyGate = 0.5; // その出口は**好戦世論の公共圏に比例して**開く加点（将校貴族 trad と合算しClampで上限1）。★2026-08-18＝旧「親軍法ONで満額」の段差を撤去
    public double WarWearyThreshold = 0.5;        // 疲弊がこれ超なら新たな戦争に入らない（数年の休戦）
    public double WarPeaceExhaustion = 0.9;       // 双方がこれ超なら早期講和（疲れ果てて手打ち）。#17 0.8→0.9（#8多正面集約の修正後に再有効化）：早期白紙講和を遅らせ戦争が一方の崩壊(厭戦≥1.0=決定的)まで続く＝決定的決着→割譲→#15復讐心の発火を可能に
    public int WarMaxMonths = 60;                 // これを超えた膠着は白紙講和
    public double PostWarTension = 38;            // 講和後（休戦中の凍結値）の緊張。休戦明けに緊張がゆっくり100へ再上昇＝中後期戦争を生むが時計仕掛けにはしない
    public int TruceYearsPerFullVictory = 10;     // 講和後の休戦：戦勝点(0-100)10点につき1年＝完全勝利で10年。期限内は再戦せず＝戦争過多の抑制
    public int MinTruceYears = 4;                 // どの戦争（白紙講和含む）にも最低この年数の休戦。戦争の運で決着が曖昧→即再戦、の連戦を断ち開戦回数を抑える
    public double ReparationGdpFraction = 0.2;    // 賠償金＝敗者GDP×戦勝点×これ。完全勝利(戦勝点1)で GDP の20%（普仏戦争の50億フラン≒仏GDP25%規模に近づける＝大国も戦争で痩せる。0.1→0.2）
    public double SpoilsWorthThreshold = 10_000;  // 抽象勢力（清）への開戦に要する最低限の戦果＝植民地が無く国庫もこれ未満なら攻める意味なし（賠償0の無意味な連戦を防ぐ）

    // --- 戦争熱／膨張意欲（案Y・植民地獲得を許容する国内世論。段B＝計算と累積のみ／消費は段Cで配線。値は暫定でsweep対象） ---
    public double WarFeverMilitarism = 0.4;   // ×好戦世論の公共圏（報道自由度×識字×都市化×対外屈辱∈[0,1]）。★2026-08-18＝旧「親軍法ONで満額」の段差を撤去（1914年の熱狂は都市の教育ある中産層／黄色新聞の米1898）
    public double WarFeverMilSpend   = 0.5;   // ×軍事費(0..1)
    public double WarFeverNoble      = 0.3;   // ×伝統支配層の力（将校貴族＝旧支配層ブロック）
    public double WarFeverSoldier    = 4.0;   // ×兵士人口比
    public double WarFeverThreat     = 0.3;   // ×外的脅威(MaxTension/100)＝脅威下では軍が発言力を得る
    public double WarFeverThreshold  = 0.5;   // これを超えた分だけ膨張意欲が貯まる（中立＝0.5前後）
    public double ExpansionWillGrowth   = 0.5;   // 四半期あたりの累積率 ×(戦争熱-閾値)
    public double ExpansionWillCap      = 10.0;  // 膨張意欲の貯蓄上限（連続侵略の原資上限）

    // --- 能動侵略の要件（段C・案Y。値は暫定でsweep対象） ---
    // 経緯：2026-06-28ユーザー指示で「戦争は緊張から創発すべき」として能動侵略の動詞を廃止（false）→
    // **2026-07-08ユーザー指示（AI対等化Phase2）＝プレイヤーが持つ侵略/宣戦の動詞をAIにも使わせる**で再有効化（true）。
    // 発火はプレイヤーと同じゲート（CanInvade＋戦争熱0.85＋膨張意欲6.0）＝頻度は batch30 で監視・調整。
    public double WarFeverBourgeois    = 0.5;   // 標的が不足資源を産むときの近代エリート（商業ブルジョワ）加点 ×近代ブロックの力
    public double InvadeScarcePriceFactor = 1.3;   // 標的資源の市場価格が参照のこの倍超なら「不足資源」＝ブルジョワが戦争熱に加わる
    // ★InvadeWillBase / InvadeWillPerMilitary / InvadeWarFeverMin / EnableActiveInvasion は撤去（作者裁定2026-08-23の1本化）。
    //   要求余剰戦力は国力比の単一式（Diplomacy.ColonizeWillCost＝上限÷(1+割引×実効戦力/屈服線)）へ移り、固定費も戦争熱の別閾値も持たない。
    public double InvadeShipsBase         = 60.0;  // 遠征に要る船（帆船+汽船）の基礎在庫
    public double InvadeShipDistanceScale = 1.0;   // ×距離1万kmあたりの船の追加要求（遠方ほど大船団＝近接有利）
    public double InvadeMilitaryFactor    = 1.2;   // 自軍の実効戦力が標的軍事力×これ以上で挑める
    // マラリア（熱帯の疫病・偽ブレーキの実コスト化）：硬直キニーネゲートを廃し、損耗は「物理的曝露 × 既存の致死率」から創発させる（マラリア専用の致死倍率は置かない）。
    //  ・遠征の防護に要るキニーネ＝養う遠征軍と同規模＝缶詰要求量(InvadeCannedReq)を流用＝曝露は物理。未防護の兵が EpidemicSeverity（既存の疫病致死率）で死ぬ。
    //  ・植民地の風土病＝ColonialExploitMortality（既存の植民地月次死亡率）で、キニーネ未供給の分だけ蝕む。
    public double MalariaQuininePerColony = 6.0;   // マラリア植民地が風土病鎮静に毎月要するキニーネ（本国市場から購入＝供給がコスト。石炭/糧食と同型の物理的補給率）
    public double InvadeCannedBase        = 20.0;  // 遠征軍の携行糧食（缶詰）の基礎在庫＝全侵略で必須（兵站。缶詰は元来軍隊向けの発明）。アフリカ限定のキニーネと別建て
    public double InvadeCannedPerMilitary = 20.0;  // ＋標的の軍事力に比例（大遠征ほど多く食う＝糧食産業を太らせる動機）
    // 近接緊張（グレートゲーム）：侵略した標的が、ある列強の本国/植民地（＝勢力圏）に近いほど、その列強との緊張が上がる
    public double ProximityTensionRange   = 3000.0; // この距離(km)内の列強が反応（隣接で最大、距離に比例して減衰）
    public double ProximityTensionMax     = 35.0;   // 隣接(距離0)時の緊張上乗せ
    // 海峡・運河（チョークポイント）：運河開通で輸送が短絡、支配国との戦争で封鎖→迂回（輸送費↑＝サプライチェーン崩壊）。distF への加算
    // 運河は資本家（投資家pop）が建設＝累計投資が総額に達すると開通（年でなく投資で開く。富裕な工業国ほど速い）。投資家→自国popで保存
    // 巨大建造物§4-1（2026-07-28）：SuezBuildCost/PanamaBuildCost/SuezTechGate/PanamaTechGate の4本は**個体別の値**なので world.json（chokepoints[].buildCost/.techGate）へ移設し削除した。
    // 係数表に残すと「値はあるが誰も読まない」＝一次資料が嘘になるため。個体に依らない**率**は下記のとおり係数側に残す。
    // === 巨大建造物（設計docは2026-07-28「巨大建造物」・パスは事後の棚卸リネームで陳腐化するため書かない）===
    // **休眠＝0 で機構ごと非実行＝厳密恒等**（較正中立も同じガードで担保）。>0 で点火。
    public double MegaprojectEnabled = 1.0;   // **点火2026-07-28（巨大建造物 段3/段4）**      // 巨大建造物の総ゲート。0=個体を生成せず国庫も積まず効果も適用しない＝現行と厳密一致
    public double MegaprojectStateFrac = 0.02;   // 着工中の建造物へ毎四半期投じる国庫の割合（国家プロジェクト＝国庫が出し手。個体に依らない率なので係数側）
    public double MegaprojectStateCap = 0.5;     // 国庫からの拠出の上限比（1国あたり総額。Treasury×これ を超えて積まない＝国庫を一度に吸わない有界化）
    // 段6 威信（2026-07-28 裁定＝**正統性にのみ載せる。威信スカラーは新設しない**）。理由＝マルコフ性（過去に何を建てたかの履歴を抱える状態を作らない）。
    // ★この裁定の下では威信は列強スコアに一切届かない（NationalScore は Legitimacy を読まない）＝「列強一致13%への回答」という副産物は放棄。
    // ★国民意識(NationalConsciousness)には載せない＝蓄積が headroom で天井を持つのに最終クランプが[0,1]しかなく、天井の外から加算すると
    //   「公教育×識字で買う」というP9の購入モデルが無効化されるため。加算は Politics の再計算の外で clamp 込み（Formations の統一の威信と同型）。
    public double MegaprojectPrestige = 0.05;   // **点火2026-07-28（段6）**：Formations の統一の威信0.1の半分＝建国より軽い一回加算     // 建造物の完成が正統性へ与える一回加算。0=無効＝厳密恒等
    // 段7 反景気循環（ニューディール）。発動条件は「恐慌 かつ **起債可能**」＝Fiscal.cs:162 と同一の3条件。
    // ⚠「財政に余裕」を条件にすると不況時に発動しない（設計書§4-6 の自己矛盾）。起債可能を条件にすると
    //   デフォルト直後は BorrowCooldown=24四半期で6年間発動せず「破産した国はニューディールを打てない」が自動で出る。
    public double MegaprojectCounterCyclical = 1.0;   // **点火2026-07-28（段7）**：恐慌かつ起債可能なら拠出2倍   // 恐慌時に建造物への国庫拠出を何倍にするか（0=無効＝厳密恒等・1.0で「恐慌時は倍」相当の加算率）
    public double MegaprojectCrisisDrawdown = 0.08;   // 恐慌とみなす GdpDrawdown の閾値（トレンドGDPのピーク比収縮）
    // 段5 外資パートナー（2026-07-28）。**単一パートナー**＝相手は決定論のargmaxで1カ国だけ・持分は係数で固定（交渉しない）。
    // トレードオフ＝自前は遅く財政を圧迫するが果実は全部自国／外資は速いが完成後も収益の一部が恒久的に外へ流れる。
    public double MegaprojectForeignShare = 0.5;   // **点火2026-07-28（段5）**：持分50%＝外資を入れると建設は約2倍速く、完成後は元本の利回りが恒久的に外へ流れる      // 外資の持分。0=外資機構ごと無効＝厳密恒等。>0 で「その比率ぶん建設が速くなり、完成後の効果の同比率が外へ流れる」
    public double MegaprojectForeignMinRank = 1.0;    // 1=列強のみが外資になれる（0で全国）。史実の資本輸出国＝列強という制約
    public double MegaprojectForeignDrawFrac = 0.05;  // 1件の建造物が外資国の国庫から1四半期に引ける上限比＝資本の希少性（1国が全世界の事業を賄えない）
    public double MegaprojectForeignYield = 0.004;    // 完成後に元本へ毎四半期つく利回り（保有国庫→外資国庫。これが「果実が恒久的に外へ流れる」の実体）
    // B4 利息の支払い方（2026-07-31 裁定＝案A+案Bの合成）。旧実装は min(利息, 借り手のSavings) で不足分を**捨てて**いた＝
    // 「儲からなければ借金がタダ」。与信を工場に変えた借り手は手元現金が薄いのでクランプが恒常的に binding していた。
    // 案A＝当期の利潤（フロー）から払う／案B＝払えない分は消えず残高へ繰り入れる。★繰入は bank.Loans を増やすだけで
    // MoneyConservation の恒等式（BaseMoney = baseline + TradeFlow + GoldMinted + FiatIssued）に Loans は入らない＝貨幣を作らない。
    // 雪だるまは既存機構が止める＝FactoryBankruptcyEnabled（点火済み）と、Loans 増→銀行信頼低下→与信収縮（ミンスキー）の自己制限。
    // ③ 阿片の輸出法のAI規則（2026-07-31 裁定）＝外圧駆動。新しいスカラーは作らず既存の緊張・TradeWeight・相手の保有法だけで書く。
    public double OpiumExportPressureTension = 40.0;    // 「緊張が高い」とみなす閾値（Tension は 100 で宣戦水準）
    public double OpiumExportPressureThreshold = 1.2;   // 外圧の合計がこれを超えたら輸出を禁じる（TradeWeight の和＝交易上の重み）
    public double InterestCapitalization = 0.0;   // 未払い利息を残高へ繰り入れる比率。0=案Aのみ（安全側・今より正しいが漏れる）／1=A+B（正しい機構・破綻率を別バッチで測る）
    public double CanalInvestFrac = 0.03;      // 運河へ毎四半期投じる投資家貯蓄の割合（全経済国が拠出＝集合投資。スエズは欧州全体の利益）
    // 倍率排除：旧 SuezDetourPenalty（交易の一律迂回加算）は撤去。迂回距離は Geo.SeaDistanceKm（喜望峰/スエズ/パナマ経由）が距離そのものとして表現する。
    // === 港湾容量（国家プロジェクト＋資本家参入・改修2026-06-28）。運河(StepCanals)を雛形に、港州の取扱容量を投資で積む。港0なら従来挙動＝較正中立。多国シム専用（StepPorts）===
    public double PortInvestFrac = 0.04;       // 資本家が毎四半期 港へ投じる州投資家貯蓄の割合（混雑時のみ＝採算ゲート）
    public double PortStateFrac = 0.5;         // 国家が港建設に投じる割合＝行政費予算の一部（国家プロジェクト＝資本家より大きな出し手）
    public double PortBuildCostPerUnit = 40.0; // 港容量1単位の建設費（資本/国庫→自州popへ還流＝保存）
    public double PortDecay = 0.008;           // 港湾の四半期減耗（維持に再投資が要る＝持続需要）
    public double PortTechOnset = 0.2;         // 近代港湾（蒸気埠頭・浚渫）の技術ゲート（帆船港は古来ありなので低め）
    public double PortCapToThroughput = 1.0;   // 港容量1あたり、その港州の実効海運への加法的上乗せ（港の大きさ＝交易の口の太さ）
    public double PortFeeRate = 0.01;          // 港湾料率＝取扱高×これを港所有者(地元投資家)へ移転（関税と同型の国内移転＝保存無影響。商人仲介料とは別＝施設使用料）
    public double PortCongestionTarget = 0.9;  // この律速率(LastTradeThrottle)未満＝港/船腹が交易を絞っている＝拡張の採算が立つ（混雑ゲート）
    // === 海上保険（ロイズ型・改修2026-06-28・金融改革③）。商人pop＝引受手(基金)。平時に保険料(荷主→商人)、封鎖損失時に保険金(商人→荷主・基金の範囲で部分払い)。すべてpop移転で保存・多国限定で較正中立 ===
    public double MarinePremiumRate = 0.0015;  // 保険料率＝海上取扱高×これを毎四半期 荷主(全pop)→引受の商人へ（平時の underwriting 収入）
    public double InsurancePayoutFrac = 0.5;   // 保険金＝封鎖損失(取扱高×(1−raid))×これを 商人基金→荷主へ（基金が尽きれば部分払い＝ロイズの破綻）。海運リスクの分散

    public double ColoniesForFullColonial = 3.0;  // 植民地素材を満たすのに要る植民地数（少ないと入手率↓・封鎖で更に↓）
    public double ColonialExtractionFraction = 0.25;  // 植民地輸入の支払いのうち国外へ出る割合（採取費）。残りは交易益として本国に還流＝帝国は富ませる
    public double WhitePeaceScore = 0.25;         // 戦勝点がこれ未満の講和は白紙（得るものなし）
    // 植民地の奪取：戦勝点(0〜100点＝sa×100)＝奪取予算。コスト＝基本30点 ＋ 資源 ＋ 開発の重み（加算）。
    // ＝未開発でも30点要る（初期に大量簒奪できない）、開発・資源を生む植民地ほど高くつく。完全勝利(100点)でも上限3つ。
    public double ColonyCaptureBudget = 100;       // 完全勝利(戦勝点1)の奪取予算＝100点（budget ＝ 戦勝点 × これ）
    public double ColonyCaptureCostBase = 30;      // 植民地1つの基本奪取コスト（未開発・無資源でも30点）
    public double ColonyCaptureResourceCost = 10;  // 固有資源1つあたりの追加奪取コスト（資源を生む植民地ほど奪いにくい）
    public double ColonyDevCostWeight = 10;        // 敗者の開発度1あたりの追加奪取コスト（開発された帝国ほど植民地が堅い）
    public double ColonyCapturePopCost = 2;        // 人口規模1あたりの追加奪取コスト（人口の多い植民地＝印度ほど奪いにくい＝大勝が必要）
    public double ColonyCaptureReachGate = 1.0;    // ★2026-08-02：講和奪取の射程ゲート。投射圏（CessionMaxDistanceKm=4000）の外の植民地は、上陸侵攻と同じ原始条件（NavalPower>0 かつ 敗者との SeaControl≧SeaInvasionControlMin）を満たさなければ受け取れない＝賠償のみ。州割譲の硬い上限と対（植民地版はコスト増だけで上限が無く、実測でヴェネツィア→ボスポラス／アシャンティ→内陸ベンガル／露→ジブラルタルが起きていた）。0で旧挙動＝厳密恒等
    public int ColonyCaptureMax = 3;               // 1戦争で奪える植民地の上限（完全勝利でも3つほど）
    public double ColonyCaptureDistanceWeight = 1.0;   // 戦勝奪取の距離実力ゲート（2026-07-09・上海集中対策）：奪取コスト×(1＋これ×海路距離万km×(1−制海権))＝海軍なき国は遠方植民地を奪えず、海軍国は距離を制海権で相殺（州割譲のCessionMaxDistanceKmと対をなす植民地側＝地理無視の戦利品循環〔清がカラカス/ペルー・ソコトがペルー保有〕の是正）。0で旧挙動（休眠可）
    public double ExpansionWillBourgeois = 0.4;        // 商業帝国チャネル（裁定2・2026-07-10）：ブルジョワ・ブロック力×これ/四半期の膨張意志＝東インド会社の実体化（英Modern≈0.4で+0.16/四半期→willCost8.4を約13年で充足）。従来は戦争熱>0.5超過分のみ＝自由主義的な英仏が構造的に植民地化不能だった。0で旧挙動
    public double ColonizeWillSuperiorityDiscount = 1.0;   // 国力比の重み（作者裁定2026-08-23）：要求余剰戦力＝上限÷(1＋これ×実効戦力/屈服線)。1.0＝**ちょうど屈服させられる相手で上限の50%**（弱小へは半分で行ける）。大きいほど優位が安くつく・0で常に満タン要求
    // 宗主の地理（2026-07-12・宗主一致exact40%の是正＝「従属するが宗主が史実と違う」の主因への3レバー）
    public double ExpeditionTechLevel = 0.8;   // 遠征技術ゲート：**海越えの植民地化**の実効戦力×Clamp(floor+(1−floor)×Tech/これ, floor, 1)＝蒸気補給・兵站・医療（TechMilLowFloorの遠征版）。低技術の大陸国（清）は隣接にしか届かず、海洋帝国は技術とともに世界へ届く。明治日本の朝鮮到達も技術上昇で自然に開通。陸続き・戦争の押し合いは不変。0で恒等。1.2初版は欧州の到達も遅らせ黒船圧が細り幕府8/30（帯2-5超）・日本exact63へ副作用→0.8で欧州は1810-30年代に全開・清は世紀後半まで抑制（batch実測2026-07-12）
    public double ExpeditionTechFloor = 0.15;  // 遠征技術ゲートの床（技術0でも沿岸砲艦の最低限＝完全遮断はしない）
    public double ColonizeValueGdpPer100k = 1.0;   // AI標的の魅力に経済規模項＝GDP10万あたり+1（植民地化の目的＝市場・税基盤。旧＝植民地数のみで実国のインド諸邦より近場の抽象小勢力が常に勝った）。0で旧
    public double VassalTransferOnCrush = 1.0;     // 宗主権の引き継ぎ：圧勝（VassalizeWinScore以上）の勝者が敗者の属国の宗主権を1件引き継ぐ（下関1895＝日本が清の朝鮮宗主権を剥奪・朝貢体制崩壊の物理）。chronicle実測＝清の従属化は全て講和経路＝この時代交代の経路がないと欧州・日本が清の従属圏を引き剥がせない。0で旧（宗主権は戦争で動かない）
    public double AiColonizeChance = 0.12;             // AI列強の植民地化試行率/四半期（裁定2：衛星国用SatelliteFormChance=0.06の借用から分離）。0.06で旧挙動＝英は突出自制の床0.25で1回/16.5年→0.12で1回/8年
    // 主要国戦争の領土帰結＋レジームチェンジ（doc改善#3・全て多国限定＝較正中立）。
    public double TerritoryCessionScore = 1.2;     // |未クランプ戦勝点| がこれを超える圧勝（崩壊1.5寄り）で敗者の非首都州を1つ割譲（アルザス・ロレーヌ規模＝稀に・レジームチェンジ閾値1.0より厳しい）
    // ★海を渡る州の割譲（2026-07-31・英崩壊の切り分けで判明）：03地理で作った陸塊テーブル（landmass.json）は
    // PathGraph/SeaGraph には入ったが**州の割譲経路（CedeTerritory）には適用されていなかった**。結果、大陸の勝者が
    // **海軍を1隻も持たずに海の向こうの本国州を講和で取れた**（パリ→ロンドン336km・ベルリン→929km・マドリード→1265km＝全て4000km圏内）。
    // 植民地の奪取は ColonyCaptureDistanceWeight で 海路距離×(1−制海権) のゲートを既に持つ＝**本国州だけが無防備**という非対称だった。
    // 日本が領土を保っているのは防御されているからでなく パリ→東京9709km＝圏外という偶然。英だけが構造的に露出していた。
    // 同型の是正＝海を渡る必要がある州は制海権で実効距離を割り増す。制海権1.0（完全制海）なら等倍＝上陸できる（1066年・ナポレオンの英本土上陸計画）。
    // 0で割り増しなし＝**厳密恒等**（休眠）。
    public double CessionSeaCrossingWeight = 1.0;   /* ★点火2026-08-01（上陸ゲートと同時）：渡海の摩擦。★閾値の判定そのものは SeaInvasionControlMin が担い、本項は「閾値を超えた側にも残る距離の割り増し」＝1.0で制海権0.65のとき実効距離×1.35 */
    // ★投射圏を技術でゲートする（2026-07-31・ユーザー指摘「4000kmという単位に根拠はない」）。
    // 固定4000kmは「帆船と伝令の1783年」と「蒸気船・鉄道・電信の1913年」を同じ投射圏で扱っていた＝時代が出ない。
    // 実効投射圏 = CessionMaxDistanceKm + CessionRangeTechKm × TechLevel（内生・実測アンカー＝英1806年 t1.00／1858年 t1.80／1913年 t2.92）。
    // 0で従来の固定値＝**厳密恒等**（休眠）。点火時は基礎を下げて技術項を上げる（例：基礎1500＋技術1200×t → 1783年1500km・1913年約5000km）。
    public double CessionRangeTechKm = 0.0;
    public double CessionMaxDistanceKm = 4000;     // 監査2026-07-05：割譲の投射圏＝**勝者の首都**から割譲候補州までの大圏距離の上限。圏外は割譲不可＝賠償のみ（実走で清がボストン/リガ獲得＝地理無制約の是正。全拠点アンカーは連鎖征服で無効化されたため首都のみ）。0以下=無制約（旧挙動）。首都座標未登録のテスト小世界は自動的に無制約
    public double WarDefeatMilitancySpike = 0.15;  // 決定的敗北で全popの闘争度に上乗せ（敗戦→革命の火種）
    public double DefeatShockDecay = 0.85;         // 敗戦ショックの四半期減衰（1.0から数年で消える）
    public double DefeatShockLegitWeight = 0.075;  // 敗戦ショック→正統性の低下幅（leg −= これ×DefeatShock）。**ストック意味論＝ショックは減衰0.85で毎期加算され累積Σ0.85^t≈6.67倍→旧0.5（フロー一回分）÷6.67≈0.075**＝敗戦一発の総打撃を旧水準に保つ
    public double CededColonyMilitancy = 0.3;      // 移転州（被征服地）の pop に上乗せする不満（征服への反発＝高すぎると即分離）
    public double RevanchismTension = 70.0;        // #15 復讐心：領土を奪われた国が勝者へ抱く恒久的遺恨（緊張上乗せ・ライバル閾値40超＝休戦明けに失地回復戦を駆動。仏アルザス・ロレーヌ1871→1914型）
    // #21 会議外交（Concert of Europe・賠償抑制アームのみ）：講和時、傍観する非交戦の列強が多く・勝者が覇権的なほど「会議度」が高まり、勝者の**賠償**戦果を削る
    // （サンステファノ→ベルリン1878でロシアの過大な戦果が列強会議で削られた型）。覇権的勝者ほど傍観列強に戦果を削られ、覇権が縮めば抑制も緩む自己抑制形＝ロンドン一強の抑制候補。
    // **植民地/割譲アームは不採用**（ベルリン会議1884-85はアフリカ分割を「加速」＝史実逆行、かつ植民地→ThreatScore→開戦網への非局所波及）。賠償のみ＝Treasury移転で保存則内に閉じる。
    public double ConcertReparationRestraint = 0.04;  // 第7段第1波⑤点火（2026-07-28）：会議外交＝ウィーン体制（傍観する非交戦列強が勝者の賠償を削る＝サンステファノ→ベルリン1878）。旧0.10は2026-07-15却下（賠償削減が富移転を減らし清entrench）→副作用警告に従い0.04へ減量して点火。0でビット恒等。
    public double ConcertRestraintMax = 0.5;         // 抑制の上限（会議度が高くても賠償の半分まで）。非0だが主レバー0が積を先にゼロ化＝恒等不破。
    public double ThreatTensionRate = 0.10;       // 経済/植民地の大国であること自体が周囲の緊張を高める（覇権防止）。0.25は軍事0で空振りしていたが、GDP+植民地基準に修正(2026-06-23)したら戦争過多(76回)になったため0.10へ＝覇権国を「時々」包囲（常時でなく）
    public double RouteDependenceTensionRate = 0.0;   // ★13l地政学（休眠・作者裁定2026-08-14）：閉鎖海盆の出口を扼する相手への緊張（月・依存度1あたり）。露⇔土（黒海×ボスポラス）・普/瑞⇔丁（バルト×エーレスンド）の受け皿＝経済の内積からは出ない対立（観測4回で≈0・99_実装ログ§4-6）。設計目安はThreatTensionRate同桁（依存1.0の国は覇権国並みに扼者を警戒）。0＝RouteTensionが1命令も走らない厳密恒等。点火はS2測定キュー（露土戦争の創発が判定指標）
    public double IdeologyTensionRate = 0.22;     // 異なる政体間の緊張（イデオロギー距離1あたり・月）。陣営化の駆動。0.35→0.22＝開戦回数の抑制（覇権の脅威緊張ThreatTensionRateは温存）
    public double IdeologyAffinityRelief = 0.30;  // 同じ政体間の緊張低下（月）。同イデオロギーの親近
    // 緊張の差分化（民族/宗教/法の隔たり＝陣営化の駆動。EnableCivilizationTension で gate＝較正は単一国合成世界で外交を回さず非波及）。時代適合の重み：民族≳法＞宗教
    public bool EnableCivilizationTension = true; // 民族/宗教/法の差分緊張の有効化（false で従来＝政体/脅威のみ）
    public double EthnicTensionRate = 0.06;       // 異民族グループ間の緊張（汎スラヴ/汎ゲルマン＝同グループは親近・異グループは反目）。月。政体緊張0.22より十分小＝war-spam回避
    public double EthnicAffinityRelief = 0.12;    // 同民族グループ間の緊張低下（月・同一民族はさらに強い）
    public double LawTensionRate = 0.05;          // 法のリベラル度(World.Freedom 0..1)の差による緊張（自由主義 vs 反動＝1848型）。月。政体距離と相関するため控えめ
    public double ReligionTensionRate = 0.03;     // 宗教の隔たりによる緊張（1789-1880は宗教戦争後＝小重み）。ファミリー座標距離＋同族異端ボーナス。月
    public double ReligionHeresyBonus = 0.22;     // 同ファミリー異宗派（スンナ⇔シーア・カトリック⇔プロテスタント）の摩擦加算＝「異端は異教より揉める（小さな差異のナルシシズム）」。多くの異ファミリー距離を上回る
    public double ReligionAffinityRelief = 0.06;  // 同一宗教間の緊張低下（月）
    // P11 東方問題パック「同宗教保護」（原典2026-07-17・実装2026-08-09・点火済み）：自国と同宗教の州を異宗教の国が支配している→保護利害（緊張チャネル＋介入口実）。
    // 宣言は保存しない＝宗教ラベルの構造から毎期導出（新規状態ゼロ）。書き手＝なし（純係数）。読み手＝Diplomacy.ProtectorTension（緊張）・Diplomacy.InterventionMotive（介入口実）。
    // 番人＝ProtectorTests（既定ピン＋ON経路の式検証）。
    // 再現＝露のバルカン正教保護・聖地管理権争い（クリミアの引き金）・汎イスラム主義（スルタン=カリフ＝オスマン側の同式運用）。台本なし＝州宗教ラベルから創発。
    public double ProtectorTensionRate = 0.02;  // 【点火2026-08-09 ign_p11＝硬性緑Δ+8.2】// 同宗教保護の緊張（月）＝これ×grievance（相手国内の自宗教州人口比0..1・完全一致のみ＝同族異端はReligionHeresyBonusの領分で重複計上しない）。休眠側の設計値0.02目安＝EthnicTensionRate 0.06/ReligionTensionRate 0.03 の弟分。0=不走行（厳密恒等）
    public double ProtectorInterventionWeight = 0.5;  // 【点火2026-08-09 同上】// 列強介入の動機×(1+これ×grievance)＝介入口実（InterventionMotive の1箇所のみ・新しい介入経路は作らない）。休眠側の設計値0.5目安。0=乗算自体を踏まない（PeaceInterventionEnabled=1.0 live下でも厳密恒等）
    // 従属関係（属国/衛星国/傀儡）。EnableDependency で gate。
    public bool EnableDependency = true;          // 属国/衛星国/傀儡の有効化
    public double VassalTributeRate = 0.015;      // 属国/傀儡の貢納＝従属GDP×これを毎四半期 宗主国庫へ（運河通行料の両建てを流用・保存）。搾取だが過大にしない
    public double DependencyAlignmentRelief = 1.2; // 従属-宗主間の緊張を毎月これだけ下げる＝整列（従属は宗主に開戦しない）。衛星=外交整列・属国/傀儡も従属下で反目しない
    public double VassalHoldScale = 0.5;          // 属国の抑え＝宗主の陸軍力×投射(距離減衰)×これ。属国の軍がこれを超え反目が高いと離反（過伸展した帝国は遠方の強い属国を失う）。改修2026-06-28の次元修正で実効化
    public double VassalDefectionMilitancy = 0.6;  // 離反の意志ゲート＝属国民の平均闘争度がこれを超え、かつ軍事条件（VassalHoldScale）を満たすと従属を脱する。監査2026-07-11死1：旧・緊張条件は整列緩和が流入を恒常的に上回り到達不能＝死蔵だった離反を実在量（pop闘争度）駆動へ交代。0.35初版はseed1で離反107回/125年＝従属の史実固着（SubjugatedOk33カ国）が崩れ忠実度exact73→61へ悪化＝0.6（強い不満の属国だけが離反）へ再調整（2026-07-12 batch実測）
    public int VassalDefectionGraceYears = 8;      // 従属成立からこの年数は離反不能＝敗戦直後（軍壊滅・武装解除・高闘争度が必然）の即時離反の振動を防ぐ。ナポレオン衛星国の離反も数年後（1813型）
    // 講和での従属化＝戦果のエスカレーション。戦勝点は[-1.5,1.5]クランプ＝割譲1.2＜属国化1.4の2段（属国一本化2026-06-28＝傀儡/レジームチェンジと衛星国化は機構ごと撤去済み。
    // 監査2026-07-12 死17/死18：撤去済み機構の残骸係数 PuppetWinScore・Satellite系4本を削除＝sweepで振っても無反応な「現役の顔をした死蔵」の掃除）。
    public double VassalizeWinScore = 1.4;        // この戦勝点(未クランプ)以上の壊滅的勝利なら、領土割譲(1.2)の代わりに敗者を属国化＝国ごと従属(金銭貢納)。割譲より重い
    public double DependentThreatWeight = 0.3;    // 宗主の覇権脅威評価に従属国のGDP/植民地をこの率で合算（属国の帝国は大きく見える＝反覇権連合を呼ぶ）。過大だと戦争が増幅し経済が均質化＝0.3に抑制
    public int MaxDependents = 8;                 // 1宗主が抱えられる従属の上限（帝国の過剰拡張＝過伸を防ぐ）。4→8（宗主の地理2026-07-12：史実の英は印度諸邦6＋ビルマ＋アデン等で4では史実の勢力圏が物理的に組めなかった。過伸の実費は植民地維持費・貢納の不満・離反が担う）
    public double GovCostVassalThreshold = 0.4;   // 講和の圧勝後：敗者の統治コスト（民族距離0.5＋宗教距離0.5）がこれ以上＝異民族/異教で直接統治が高コスト→属国化（間接統治）／未満＝同族で安く併呑→追加割譲
    public double AllianceBreakTension = 50;      // 同盟国間の緊張がこれを超えると同盟が崩れる（強国は孤立へ）
    public double WarMilitancyRate = 0.004;       // 自国の交戦が pop の闘争度を上げる（戦争疲弊の内政コスト）。⚠WarMilitancyViaTarget>0.5（既定）では不読＝旧経路
    public double WarCasualtyRate = 8.0;          // 戦死＝交戦兵力(Military)×これ/月。改修2026-06-28：24→8（15%/月上限と相まって年率80%超は桁外れ＝WWI動員の10〜20%/年の一桁過大）。総力戦でも史実水準へ
    public double WarCasualtyMonthlyCap = 0.04;   // 戦死の月次上限＝兵士の これ（改修2026-06-28：0.15→0.04＝総力戦で年〜40%。膠着戦は WarCasualtyRate×Military で更に低消耗）
    public double OfficerCasualtyShare = 0.06;    // B-1：戦死の一部が士官＝伝統支配層(貴族)にも及ぶ割合＝WarFeverを煽る貴族も血を流す（士官は少数なので小・上限は貴族の5%/月）

    // === 改修2026-06-28：国家ランク・通商破壊・技術優位・外交アクション（ユーザー指示） ===
    // 国家ランク（列強/中堅/弱小）＝NationalScore の相対閾値で四半期ごとに動的分類（数に限りなし・ランク変化でも同盟/戦争は継続）。
    // 実国家を首位スコア比で3層に分け、抽象勢力(Nation==null＝被植民地の弱小勢力)は常に弱小。
    public double GreatPowerScoreFraction = 0.35;  // 首位比率式のランク判定。53カ国世界（実国>12）では人数制に置換済みだが、**実国12以下の世界（テスト・較正）では現役**（Diplomacy.cs の if (real.Count > 12) の else 側＝台帳訂正2026-07-12・旧注記「廃止・残置」は不正確）
    public double MinorPowerScoreFraction = 0.22;  // 実国12以下の世界（テスト・較正）では現役（GreatPowerScoreFractionと同じ if (real.Count > 12) の else 側）
    // P7 制度疲労（2026-07-17）：InstitutionalDecay の読み3チャネル＋脱出動学の係数。主フラグ＝3チャネル重み（全0で完全休眠・状態更新も走らない）
    public double DecayReformResistWeight = 0.75;   // ①改革への抵抗＝旧支配層の政治力×(1+k×decay)（配線1本＝InterestGroups.PoliticalWeight Closed分岐）。live 0.75（清decay0.8で×1.6）
    public double DecayTechAdoptWeight = 0.75;      // ②技術採用の遅延＝キャッチアップ採用速度×(1−k×decay)。live 0.75（清decay0.8で×0.4＝科挙官僚制の遅い近代化）
    public double DecayMilitaryWeight = 0.75;       // ③軍改革の失敗＝軍質×(1−k×decay×正規化技術差)＝1840年代にアヘン戦争型敗北が可能に。live 0.75
    public double DecayShockRelief = 0.20;         // ショック（決定的敗戦/内戦勃発/国家破産）1回の部分減衰（仕様帯−0.15〜0.25）
    public int DecayShockCooldownQuarters = 20;    // ショック減衰のクールダウン（連発防止＝5年）
    public double DecayReactionRegrowth = 0.01;    // 反動の再成長率/四半期（旧支配層優位×検閲が続く限り天井へ漸近＝「負ければ近代化」の逆説を防ぐ）
    // ★撤去2026-08-16（C2-C5）：DecayLockinCleanGov（清廉度ロックイン閾値）を物理削除＝汚職V2恒久ONで清廉度ストックごと撤去・唯一の読者（Politics.cs lockin枝）は常に偽の死骸だった。
    public double DecayLockinIndustrialization = 1.0;  // ロックイン＝平均工業化がこの閾値以上で再成長停止
    public double RankUpdateIntervalQuarters = 4;  // P14（2026-07-17点火）：ランク再分類の間隔（四半期）。4=年次ソート＝閾値チャタリング（列強動詞の点滅）抑制・威信の残光。1=毎四半期（旧挙動）。判定タイミングの間引きのみ＝RNGなし決定論中立
    public int GreatPowerCount = 7;                // 列強の定員（スコア上位N・2026-07-04人数制：同ランクの外交相手が常時5〜8カ国）
    // ★4段階化（作者指示2026-08-11）＝列強／準列強／中堅／弱小。旧「中堅12」を 準列強5＋中堅7 に割った。
    //   ⚠**和を12のまま保つ**のが要点＝弱小の集合が動かない（植民地化の標的・列強の顔ぶれとも不変）。
    //   変わるのは「同ランク」の束だけ＝緊張の上下と防衛同盟の相手が、旧・中堅12の中で2つに分かれる。
    /* ★二国間交易（作者裁定2026-08-11）＝世界市場と「世界の交易重心」を廃止し、州と州の実経路で取引する。
       0（既定）＝旧経路（各州が1つの池に対して売買・距離は重心まで）＝**厳密恒等**。1＝置換後。
       置換後の要点：①相手は「その州まで運んで最も安く着く売り手」②価格は次善の相手の価格が決める（競争）
       ③世界価格は平均価格へ降格（表示と数量の正規化だけに使い、清算には使わない）。
       ⚠現行の較正は全て「重心つきの池」に対して合わせてある＝点火すると帯は大きく動く前提。 */
    // ⚠撤去2026-08-12（読み手ゼロ）: BilateralTrade
    /* ★冬季の港の凍結（作者裁定2026-08-11「一部の港を冬に使用不可にする。これでグレートゲームが創発できる」）。
       バルト海・白海・オホーツク海・セントローレンス湾の港が真冬の四半期だけ閉じる（Climate.PortFrozen＝実在の海域の表）。
       0で通年開港＝厳密恒等。⚠二国間交易（BilateralMarket・唯一の経路）で効く。 */
    public double WinterPortFreeze = 1.0;
    public int SecondPowerCount = 5;               // 準列強の定員（列強の次のN）
    // 外交の「同ランク」束をどう数えるか。1＝準列強を中堅と同じ束に置く（＝4段階化の前と同じ相手・既定）／
    // 0＝ラベルどおり4束に割る。★実測（2026-08-11）＝割ると8軸合計 319.4→305.2（硬性は緑）。
    // ラベルの粒度と、外交の相手の粒度は別物として持つ＝呼び名を細かくしただけで世界が動かないようにする。
    public double RankBracketsMerged = 1.0;
    public int MiddlePowerCount = 7;               // 中堅の定員（準列強の次のN。残りの実国家と抽象勢力は弱小）
    public const int GreatPowerCountForFidelity = 7;   // 列強軸（忠実度・2026-07-27）の判定に使う定員。**物差しは較正で動かさない**ため GreatPowerCount とは別の定数に固定する（人口軸が Q524 断面固定なのと同じ思想）
    // 通商破壊（戦争中の海上交易阻害）：交戦国は敵の制海権に応じて海運(交易船)を失う＝海軍劣勢ほど深い（私掠・巡洋艦戦）。
    // embargo(交易比重喪失・双務)とは別系統で、交戦国の**海運容量を直接絞る**（海上輸送に効く＝内陸の鉄道交易は無傷）。保存＝交易量の縮小のみ（金の創出/消滅なし）。
    // 技術優位（外科的・19世紀の欧州優位を技術で表す）：技術水準が軍の質と国力評価を押し上げ、人口規模だけでは上位に立てないようにする。
    // 軍の質＝**低技術の大軍を割り引く**（監査案3）：素兵数×(LowFloor〜1.0)＝前近代の大軍は訓練/兵器で無力化（アヘン戦争・下関）、先端は満額。
    public double TechMilLowFloor = 0.4;           // 技術0の軍の実効戦力（素兵数の40%＝前近代）。Power.Military ×(LowFloor + (1−LowFloor)×min(Tech/FullLevel,1))
    public double TechMilFullLevel = 2.5;          // この技術水準で軍の質が満額(1.0)。欧州先端は満額・巨大人口の追従国(清/印)は割引＝技術が軍の質の差を生む
    public double ScoreTechWeight = 12.0;          // NationalScore：技術水準1あたりの加点（1人あたりの発展＝非規模。工業化と並ぶ近代国力の柱）
    // 外交アクション（プレイヤー/AI 共通・同ランク間が原則）：緊張の上げ下げ・防衛同盟・植民地化。
    // ★戦闘のラウンド記録（2026-08-04・作者仕様(1)「戦争をラウンド化する。1ヵ月1ラウンド」）。戦争の解決は元から月次＝ラウンドの実体はあり、欠けていたのは「その月に何が起きたか」の可視化だった
    public double BattleLogEnabled = 1.0;          // 1で毎月の戦闘結果を年表へ書く。0で1行も書かない（挙動には一切影響しない純記帳）
    public double BattleDecisiveMargin = 0.06;     // 今月の戦勝点の動き÷崩壊点 がこれ以上なら「圧勝」
    public double BattleClearMargin = 0.02;        // 同上・これ以上なら「快勝」（未満は「辛勝」）
    public double ActionTensionStep = 25.0;        // 「挑発する/緊張を緩和する」1回の緊張増減量（合計。TensionActionRampMonthsかけて徐々に反映）
    public int TensionActionRampMonths = 6;        // 緊張操作の反映期間（月）＝即時でなく毎月 Step/Ramp ずつ動く（2026-07-04）
    public int TensionActionCooldownMonths = 18;   // 緊張操作のクールダウン（月・対相手ごと）＝連打防止の長い待ち
    // 外交アクションの政治的帰結（2026-07-27ユーザー設計）：能動的な挑発/宥和を国内のイデオロギー構成が評価する（作用先＝正統性・AI/プレイヤー対称の4サイト）。
    public double TensionPoliticsScale = 0.03;     // 挑発＝タカ派(反動/ナショ/帝国/ファシ)の喝采−ハト派(自由/共和)の反発、宥和＝逆。正統性への一発インパルス×シェア差（参政権voice加重＝Ideologies.National）。0で厳密恒等
    public double WarFeverWeakness = 1.5;          // 格下への宥和の「弱腰」増幅＝タカ派の失望×(1+これ×好戦世論)。格上への宥和は自衛＝増幅なし（AI屈服の屈辱AISubmitLegitCostの連続版）
    public double WarStartPoliticsScale = 0.0;     // ★休眠（2026-08-10 作者FB③）：開戦そのものの政治的帰結＝挑発と同じ向き（タカ派の喝采−ハト派の反発）を**開戦を選んだ側**の正統性へ。0で1命令も実行しない厳密恒等（点火はバッチ測定で）。防衛側には掛けない＝被攻撃国は分裂でなく結束（別機構）
    public double ProvokeProximitySpread = 0.3;    // 挑発の近隣波及＝標的の近隣諸国(ProximityTensionRange内)も挑発者への緊張を＋step×これ。軍需の押し上げは既存経路（脅威→大軍許容→軍事費→軍需財）から創発＝直接ブーストは二重計上のため置かない（2026-07-27ユーザー裁定）
    public double ColonizeSubmitRatio = 3.0;       // 侵略：実効戦力が屈服線（＝標的の軍事ゲージ×これ）以上なら標的は屈服→属国化/併合、未満なら拒否→戦争
    public double ColonizeSubmitFloorMilitary = 0.05;   // 屈服線の床＝無防備な標的にも最小限の遠征が要る（0で床なし＝軍を持たない国が無料で無血併合される）。★2026-08-23：要求余剰戦力の分母と屈服判定の分母が別の床を使っていた二重定義を、この1つへ統合
    public double ColonizeRivalTension = 22.0;     // 植民地化が**他の列強**との緊張を高める量（グレートゲーム＝勢力圏争い・他列強の警戒）
    // AIの生存・自制（改修2026-06-28）：弱小/劣勢国の自衛と、突出国の自制（覇権snowball抑制）。
    public double SurvivalThreatRatio = 1.5;       // 最強他国の軍が自軍のこれ倍超＝存亡の脅威（生存軍拡が立つ閾値）
    public double SurvivalMilitaryWeight = 1.5;    // ×(脅威比−閾値)＝生存のための軍備効用（弱小が脅威下で軍拡）
    // ★★②生存効用の飽和の是正（2026-08-26・記録 docs/202608/20260826_軍縮と理想の軍隊_部分完了.md §7 の②）。⚠0で厳密恒等。
    //   ⚠実測（armstrace ⑥）＝脅威比 ratio の中央値は 20（1788）〜257（1933）で、閾値1.5に対して桁が違う。
    //     つまり clamp(ratio−1.5, 0, 3) は**開幕から最終まで上限3に張り付き**、生存効用は「脅威に応じた軍拡」でなく
    //     **常時ONの定数4.5**として働いていた。項を0にすると36/60カ国が軍備スタンスから降りる＝軍縮0件の主因。
    //   ★ratio そのものは異常ではない。ポルトガルが自分の数十倍の相手に睨まれるのは史実的にありうる。
    //     異常なのは**応答が単調で、絶望的な差でも軍拡を最大化すること**である。史実の小国は勝てない相手に軍拡で応じない
    //     ——同盟を買うか、従属を受け入れるか、ただ諦める。⇒**見込みの薄さで割り引く**（山形の応答）。
    //   ★新しい定数を置かない＝尺度は既存の閾値 SurvivalThreatRatio を流用する。
    //     survival ×= 1 − k×(1 − clamp(閾値/比, 0, 1))　… k=0で恒等・k=1で「比が閾値の桁違いに大きいとほぼ0」。
    //     k=1 のとき比が閾値の3倍あたりで最大＝「拮抗する相手には軍拡し、桁違いの相手には軍拡しない」。
    //   ★★点火2026-08-26（実測が主目的と帯の両方で明確に良い）：
    //     **軍縮エピソードが 0件 → 2件**（1890年代スペイン 0.575→0.319 / 0.451→0.273）＝このプロジェクトで初めて軍縮が創発した。
    //     軍備スタンス **61/61 → 21/61**・平均軍事費 0.641→0.682 が 0.394→0.515 へ・生存効用 3.96 → 0.27（飽和が解けた）。
    //     ⑤「その項を0にしたら軍備から降りる国」は 生存36→**2**・緊張項8→**11**＝脅威への応答が定数から本当の応答へ変わった。
    //     帯（batch30・①点火後との比較）＝人口 15.4→**19.3**・本国 83.3→**85.8**・法 60.4→**61.6**・列強再現 19.6→**20.8**／
    //     政体exact 47.9→46.2・経済 35.0→33.8。**硬性ゲート全緑**（破綻0/デッドロック0/異常0/ハーネス0/要注意0）。
    //   ⚠差し戻しはこの1本を0にするだけで完全に旧挙動（分岐に入らない＝厳密恒等）。
    public double SurvivalHopelessScale = 1.0;

    public double StanceRevoltWelfare = 2.0;       // 第5段5-2点火（2026-07-27）：体制AIの目①譲歩＝革命の接近(大衆闘争×正統性欠乏)が福祉効用を押す（ビスマルク社会保険の反射）。旧AIはLegitimacy/Militancy不読＝革命が見えなかった。0で旧恒等
    public double StanceRevoltCoercion = 1.0;      // 第5段5-2点火（2026-07-27）：体制AIの目②引き締め＝同入力が軍備（武力→圧政）効用を押す。譲歩との綱引きは教義バイアスと不足の大小が決める（政体ラベル分岐なし）。0で旧恒等
    public double StanceDrawdownFiscal = 1.5;      // 第5段5-2点火（2026-07-27）：体制AIの目③恐慌＝GDPドローダウンが緊縮効用を押す（19世紀正統財政の反射・国庫逼迫より早い先行指標）。0で旧恒等
    public double MiddleLayerMilitancy = 0.08;     // 第5段5-4点火（2026-07-28）：危険な中間＝(識字−min(意識,識字))層の闘争度加算（トクヴィルのパラドクス＝識字化が意識に先行する近代化中盤が最も不安定）。[PORT:P1]。0で旧恒等。#17較正2026-07-28：0.15→0.08（識字先行国＝普/日/蘭が逸脱過多化・総政変+26の主因）
    public double RevolutionConsciousness = 0.25;  // 第5段5-6点火（2026-07-28）：暴力革命の成立→国民意識へ NC+=これ×(1−NC)（ナポレオンの鎖①＝臣民が国民になる・学校天井をバイパス＝直接回路化）。受け皿＝Military徴兵深度の国民意識ゲート（既配線）。0で旧恒等
    public double IrreversibleLaws = 1.0;          // 第6段6-7点火（2026-07-28）：支持層を作る法の不可逆＝参政権/女性の権利（★2026-08-10 統合＝梯子の全段）/社会保障制度は平時に後退不能・労働時間/児童労働は戦時のみ緩和可（英1915軍需品法）。報道/国教は可逆。水準スライダーは常に自由（制度と水準で割れる史実）。0で旧恒等（農奴解放のみ既存不可逆）
    public double RuptureWindowQuartersOnCrush = 8;   // 第6段6-8点火（2026-07-28）：断裂の窓の長さ＝革命鎮圧・内戦制圧・弾圧の直後この四半期数だけ6-7を解除（反動の後退はこの窓のみ＝仏1850・ストルイピン1907）。0で窓なし
    public double LawEnforcementAdminGate = 0.5;   // 第6段6-8点火（2026-07-28）：執行の飢餓＝先進方向の法浸透（労働時間短縮・児童労働禁止・女性賃金保持）の追従速度×min(1, 行政力/これ)。法は残して監督官を切る反動（1802徒弟法の空文化）。緩和方向は即時（規制撤廃に監督官は不要）。0で旧恒等
    public double FactionCompensation = 1.0;       // 第6段6-6点火（2026-07-28）：危機の三行目「別の軸で埋め合わせる」＝本丸（top-1軸）は拒み副次要求を与える（ビスマルク社会保険）。AI/プレイヤー対称の第4択。0で旧3択
    public double CompensationMilitancyRelief = 0.75;   // 第6段6-6：埋め合わせの闘争度緩和（受諾ReformMilitancyRelief=0.5より弱い＝本丸は満たされていない）
    public double CompensationCohesionRetain = 0.5;     // 第6段6-6：埋め合わせ後に残る結束（穏健派が剥がれ組織は痩せるが核は残る＝分断・再来）
    public double FactionOpportunism = 1.0;        // 第6段6-5点火（2026-07-28）：結束の予算化＝運動は閾値越えでも体制健在なら待つ（静かな蓄積→一斉投入＝1848/1917）。弱み（下2つ・交戦）か圧倒（下のOverwhelm）で打つ。0で旧＝閾値即発火
    public double FactionStrikeLegitimacy = 0.5;   // 第6段6-5：体制の弱み判定＝正統性がこれ未満なら好機
    public double FactionStrikeDrawdown = 0.1;     // 第6段6-5：体制の弱み判定＝GDPドローダウンがこれ超（恐慌）なら好機
    public double FactionOverwhelmFactor = 1.5;    // 第6段6-5：圧倒判定＝勢力強度が保持力のこれ倍超なら好機を待たず打つ（雪崩は止まらない）
    public double FactionTargetsWeakAxis = 1.0;    // 第6段6-5②点火（2026-07-28）：要求スコア÷(1+これ×OpposingPower)＝体制の守りが薄い軸を優先（状況依存の要求）。0で旧＝ブロック選好×可動域のみ
    public double PoliticalBudgetGate = 0.5;       // 第6段6-1点火（2026-07-28）：政治予算制約＝開いた戦線（目標≠現在の政治軸）数Nで押す力を正規化（速度・余白×(1/N)^これ）。0で全軸に全力＝厳密恒等・1で完全正規化。「全部を同時には押せない」
    public double ArmyPoliticalWeight = 5.0;       // 第6段6-4点火（2026-07-28）：統帥権＝軍を第4の勢力へ。力＝これ×兵士人口シェア×(1−議会統制)＝文民統制の確立が軍を政治から退場させる。選好＝軍事軸（武力＝軍事費/圧政・徴兵法）のみ＝軍国度の2因子。0で旧3勢力＝恒等
    public double ArmyPcPressure = 0.02;           // 第6段6-2点火（2026-07-28）：4主体の欠けた腕＝軍。王権寄りの軍（lean>0）が文民統制の確立を毎期押し戻す（プロイセン統帥権・憲法紛争1862）。×lean×軍政治力。0で恒等
    // ★PolityLeverRanges は2026-08-19に**物理削除**（作者裁定「政体ごとの上限は全て廃止」）。旧＝参政権/報道/組合の上限＋軍事費の床（MilitaryFloorScaleも同時撤去）。
    //   ⚠再点火禁止（墓標）＝実測で7次元が改善し、政体exact は動かなかった＝この上限は忠実度を支えていなかった。読み手ゼロ（Government.cs/NationConfig.cs にコメント残置のみ）
    public double DefeatNationalism = 1.0;         // 機能7-1点火（2026-07-28）：敗戦ショック→r[4]ナショナリズム（刺され伝説＝1871仏/1918独）。時代ゲート・ファシズム式の前に加算＝r[9]の燃料として自動で効く。裁定（未決1）＝Ideologyコアへ直接加算（P1は闘争度ポート＝置き場が意味を壊す）。0で恒等
    public double LostLandNationalism = 0.1;       // 機能7-2点火（2026-07-28）：失地ストック×これ→r[4]の長期項。裁定（機能7-6）＝案A役割分担：RevanchismTension=特定の相手への対外敵意（緊張・ワンショット）／本項=国内イデオロギー分布（持続）＝出力先が異なり二重計上でない（[PORT:P1]台帳へ記録）。0で恒等
    public double LostLandHalflifeQuarters = 80;   // 機能7-2：失地ストックの半減期（20年＝アルザスの遺恨は世代を跨ぐ）
    public double WarRallyCoercion = 0.3;          // 機能6-1点火（2026-07-28）：戦時の結束（rally around the flag）＝保持力×(1+これ×max(0,1−厭戦/減衰点))。厭戦で減衰させないと二月革命型が構造的に消える＝恒常抑制にしない。0で旧＝ドレインのみ恒等
    public double WarRallyDecayPoint = 0.4;        // 機能6-1：結束が消える厭戦水準（開戦時+30%→WE0.4でゼロ→以後はドレインが上回る）
    public double RevolutionSurrenderWeight = 0.4; // 機能6-2点火（2026-07-28）：講和意欲の閾値×(1−これ×革命圧力)＝内戦の懸念がある国は余力を残して降伏（独1918/露1917型）。厭戦崩壊(WE≥1)の決着は不変。0で旧固定閾値恒等
    public double SubmitCountsAllies = 1.0;        // 機能5-①-2点火（2026-07-28）：屈服判定を単独軍→陣営戦力（参戦見込みの同盟込み＝JoinAlliesと同一述語）へ＝三国協商の一員は独より弱くても屈服しない。0で旧恒等
    // ★参戦を見送る「国難」の線（2026-08-01）。⚠いずれも**既にある状態量**を読むだけで、新しい機構は作らない。
    // 根拠＝どれも「政府が対外戦争に人と金を割ける状態にない」ことの現物。値は既存の較正済みの帯から取る：
    //   食料0.7＝主食が3割欠ける（飢饉の入口・FamineDeathFillFloor=0.8 より深い）／財政0.6＝歳出の4割が賄えない
    //   ／正統性0.4＝内乱が起きる帯
    public double AllyJoinFoodMin = 0.7;
    public double AllyJoinFundingMin = 0.6;
    public double AllyJoinLegitimacyMin = 0.4;
    public double AllyRefusalTension = 60;         // 機能5-③点火（2026-07-28）：参戦要請の見送り/拒否＝要請元との緊張＋これ（同盟破棄閾値50を一撃で超える＝伊1914型の離反。信頼度スカラーは作らない）。AI/プレイヤー同一式。0で旧＝見送り無帰結恒等
    public double WarChainMaxDepth = 2;            // 機能5-④点火（2026-07-28）：同盟参戦の連鎖段数（WW1型）。0で1段のみ＝旧恒等。防壁＝段数減衰+到達可能性+訪問済み共有
    public double WarChainDepthPenalty = 1.5;      // 機能5-④-2：2段目以降の参戦閾値×これ^depth（連鎖は段ごとに渋る＝全世界戦争の防壁）。1.0で減衰なし
    public double VictoryNationalism = 0.5;        // 機能8-②点火（2026-07-28）：戦勝ショック→r[4]（戦勝→主戦論＝日清・日露後の日本型。敗戦のr[4]+r[1]に対する対称）。0で恒等
    public double VictoryImperialism = 0.3;        // 機能8-②：戦勝ショック→r[8]（植民地熱。時代ゲートeraImpが早期を抑える）。0で恒等
    public double VictoryShockDecay = 0.85;        // 機能8-②d：戦勝ショックの四半期減衰（DefeatShockDecayと同水準＝噴出は数年で消える＝連勝暴走の防壁。厭戦・反覇権合従が他の防壁）
    public double DepressionSocialism = 0.3;       // 機能8-③点火（2026-07-28）：恐慌（GdpDrawdown）→r[5]社会主義。恐慌は平均60.8回/試合＝小さく。0で恒等
    public double DepressionCommunism = 0.15;      // 機能8-③：恐慌→r[6]共産（時代ゲートeraCommが早期を抑える）。0で恒等
    public double DepressionReaction = 0.2;        // 機能8-③：恐慌→r[1]反動（両極化＝ワイマール型）。0で恒等
    public double FamineRepublicanism = 0.3;       // 機能8-④点火（2026-07-28）：飢えの記憶→r[3]共和（1789＝「パンの値段」の題名に最も近い機構）。0で恒等
    public double FamineSocialism = 0.3;           // 機能8-④：飢えの記憶→r[5]社会。0で恒等
    public double FamineMemoryDecay = 0.95;        // 機能8-④：飢えの記憶の四半期残存率（半減期≈3.4年＝飢饉は忘れられるが世代内は残る）
    public double ExternalPressureNationalism = 0.3;   // 機能8-⑤点火（2026-07-28）：外圧→r[4]（攘夷→富国強兵・清の反帝国主義）。ExternalPressureDerived=1と同時点火＝外圧が実体（技術格差×海の接触）を持つ。0で恒等
    public double DefeatShockTensionRelief = 2.0;  // 機能9-1点火（2026-07-28）：ハイエナ抑制＝敗戦ショックが高い相手への緊張は100超でも減衰（普仏戦争後の仏が連続で食われない）。月次×max(両者shock)。0で恒等
    public double DefeatShockProtectMin = 0.3;     // 機能9-1：保護が効く敗戦ショックの下限（数年で切れる＝DefeatShockDecayが窓）
    public double ParliamentBudgetScope = 1.0;     // 機能2-1点火（2026-07-28）：予算協賛の対象を所得税のみ→全税軸（人頭/土地/累進/消費）へ＝議会の同意なしに歳入構成は動かない（憲法紛争の一般化）。0で旧＝所得税のみ
    public double ElectionEventEnabled = 1.0;   // 【点火1.0・2026-08-17】A/B＝def4(38.2/74.3/61.5/0.63)→eD(**exact40.2**/73.1/61.3/0.66)・硬性緑・372緑。AI等価物と確定形（レバー＝裁量余剰の%・効き＝A/(A+半減点)・代価＝投入額）が揃ってから点火。★E2（選挙doc §7）：総選挙の公示イベント＝「どの思想に加担するか」の択（§3-0/3-2）。0＝公示もポップアップも押し込みもAIの判断も1命令も走らない厳密恒等。★E4のAI等価物（2026-08-17・docs/202608/20260817_選挙イベントのAI等価物_完了.md）でこの1本がプレイヤーとAIの**共通ゲート**になった＝点火すると全国に公示が立ち、プレイヤー国はモーダル・AI国は UtilityAgent.DecideElection が同じ四半期に同じ動詞（World.ResolveElection）で答える（別フラグを作らない＝片方だけ点火して非対称を再生産できない）。点火は単独で測る
    // ★E3''（確定形2026-08-17・作者裁定 docs/202608/20260817_選挙の押し込みの凸性_部分完了.md §3）：**代価は曲げない・効きを曲げる**。
    //   レバー＝裁量余剰(FiscalCapacity)の何%を注ぐか／投入額＝裁量余剰×レバー／金の代価＝投入額そのもの（国庫→pop）／
    //   効き＝投入額の逓減 A/(1+A/half)（半減点 half で無次元化＝A/(A+half)∈[0,1)）。
    //   ⚠旧 ElectionPushCostConvex（代価を強さ^(1+k) へ凸化）は**撤去**＝作者裁定で却下（§1「代価を歪める形はこのプロジェクトに一つもない」・
    //   §2「看板ごとに逓増すると3つを1/3ずつ押すほうが代価1/3＝設計意図と逆」・§7d「効き側の逓減と二重にしない」）。
    public double ElectionPushHalfPerVoter = 0.04; // ★E3''：逓減の**半減点**＝有権者1人あたりの単価。half ＝ これ × 有権者数 × (名目GDP÷人口)＝「有権者1人につき月あたり平均所得の4%を配れば効きが半分」。⚠国の大きさに比例させる錨が要る（未決7aの解決）＝絶対額に置くと大国は常に漸近線（＝振り切りが最適に戻る）・小国は永久に押せない。形は既存の adminNeed=AdminNeedPerPop×人口（§3-③が名指し）と同型で、票を買う相手は人口でなく**有権者**なので分母の錨を有権者数（ComputeVotes と同じ 規模×FranchiseVoice）に置く。単価が名目GDP/人口＝物価にも所得成長にも自動追従（固定額だと後年に買収が無料化する）。既定0.04＝実測（1785-1898の選挙政体で 裁量余剰÷有権者÷一人あたりGDP＝0.013〜0.35・中央値≈0.04）から「典型的な選挙政体が裁量余剰を全額注ぐと効きが半分」に置いた目盛り。⚠主ゲート ElectionEventEnabled は**2026-08-17に点火（=1）**＝この係数は live（旧注記「主ゲート0＝読まれない」は点火で陳腐化）
    public double ElectionBribePovertyWeight = 0.0; // ★買収しやすさの富加重（作者要望2026-08-17「金のないPOPほど買収しやすい」・休眠）。半減点の単価を「全国一律の一人あたり名目所得」から「その有権者pop自身の豊かさ」へブレンドする率∈[0,1]：half＝係数×Σ_pop[声_p×((1−これ)×規模_p＋これ×前月所得_p÷全国の一人あたり所得)]×一人あたり名目GDP。0＝Σが全国一律へ畳まれ現行とビット恒等（World.ElectionPushHalfPoint が否定形ガードで即 return＝経路を作らない）／1＝完全にpop別＝票の値段はその有権者の稼ぎで決まる。★豊かさに**所得**（Pop.LastEarned）を採った理由＝①全国側の単価がフロー（名目GDP÷人口）なので次元が揃う ②史実の買収は「何日分の稼ぎか」で値が付いた ③資産(Savings)は選挙資金の還流先そのものだから自己参照になる。★狙う創発＝貧しい選挙民の国は安く買える（腐敗選挙区）／有権者が豊かになるほど買収が割に合わない（参政権の広さに**所得の次元**が加わる）。⚠主ゲート ElectionEventEnabled は**2026-08-17に点火（=1）**＝この係数を0から上げれば即座に効く（休眠は自分の0のみが担保）。点火は単独A/B
    // ★マニフェスト（作者指示2026-08-24）＝選挙で加担した議題を公約として持ち、在任中に果たせば支持が伸びる。
    public double ManifestoFulfillMove = 0.1;      // 達成と認める最小の移動量（軸の可動域に対する割合＝0.1で「1割進んだ」。段のある法は1段でおおむね超える）
    public double ManifestoFulfillCredit = 0.5;    // 達成した瞬間に加担した思想へ乗る支持（Ideology の r[] と同じ物差し＝他の出来事項と横並び）
    public double ManifestoCreditDecay = 0.05;     // その支持の四半期あたりの減衰（半減期≈14四半期＝3.5年＝任期1回ぶん）。0で減衰なし
    public double ElectionPushScale = 0.3;         // ★E3：加担の押し込み＝選んだ思想の得票を(1+効き×これ)倍（開票1回のみ・×1.0はIEEEでビット恒等）。主レバーElectionEventEnabled=0が先にゼロ化＝恒等不破。設計目安＝効き1.0で+30%（世論を作る長期経路＝教育/検閲より常に劣る短期ブースト）
    public double EarlyElectionEnabled = 1.0;      // 機能2-5点火（2026-07-28）：不信任＝与党の民意（VoteShares）が閾値割れで繰り上げ総選挙。0で旧＝固定周期のみ恒等
    public double NoConfidenceThreshold = 0.2;     // 機能2-5：与党族の得票率がこれ未満＝内閣が倒れる（第三共和政＝平均8ヶ月内閣の史実側）
    public double EarlyElectionMinQuarters = 4;    // 機能2-5：繰り上げ選挙の最短間隔（1年＝選挙の乱発防止）
    public double ForeignBondCounterparty = 1.0;   // 02断線走査点火（2026-07-28）：外債の利子を債権国投資家へ配当（債権ストック=ForeignBondClaims按分・世界で金が閉じる）＝レンティア帝国（シティ/パリ）の成立。旧＝利子が世界から消える片側記帳。0で旧恒等
    public double TreatyRatificationWeight = 0.5;  // **点火2026-07-31（07_再設計 第1弾1c）**：議会統制力0.5以上の議会国は講和の従属条項を批准しない。機能2-6配線（2026-07-28・帯リスク高＝戦争終結ループ直撃）：議会統制力がこれ以上の議会国（立憲/共和）は講和の従属条項を拒否（属国化→追加割譲へ振替＝講和は成立）。0で不読＝厳密恒等
    public double AppeaseMilitaryRatio = 2.5;      // 相手の軍が自軍のこれ倍超＝勝てない相手＝挑発せず宥和（緊張を下げる）
    public double HegemonRestraintFloor = 0.25;    // 突出自制の下限＝覇権国でも植民地化意欲はこの割合までしか落ちない（完全停止はしない）
    // リアリティ補強（改修2026-06-28・第4弾）。
    public double PrizeMoneyRate = 0.004;          // A2拿捕賞金＝敵GDP×これ×制海優位を毎月 制海国の国庫へ（両建て保存）。海軍を持つ交易上の意味
    public double PrizeCargoShare = 1.0;           // 拿捕賞金原資をGDP比例から『敵が通商破壊で失った海上取扱高(LastPortThroughput×(1-CommerceRaidFactor))』比例へ移すブレンド（prize-money-gdp-based-no-cargo）。1=完全に積荷連動（内陸大国を封鎖しても賞金0）/0=現行のGDP比例（恒等）
    public double ColonizeAnnexMilitancy = 0.3;    // A5無血植民地化の被支配不満（接収植民地のMilitancy/属国pop闘争度の初期値＝抵抗の実体化）
    public double DefendProjectionMin = 0.2;       // A6宗主防衛参戦の最低投射力（これ未満＝届かない属国を見殺し＝離反へ）
    // ★★列強の介入と和平提案（docs/202607/20260731_列強の介入と和平提案_部分完了.md【一部】.md・器2026-08-01）：
    // 「列強が交戦中の2国に和平を提案する。応じれば白紙で終わり、拒否すれば提案国が拒否側に参戦する」＝**戦争の終わり方を増やす**（帯直撃）。
    // ⚠新しい述語を1つも書かない——応諾・意志コスト・緊張・投射・厭戦はすべて**植民地化の要求と同じ関数**を引数違いで呼ぶ。
    // ★点火2026-08-01。Probe実測（seeds1-10・SOURCE-HASH e0f…）＝**撃てる局面が1試合あたり41.8回**＝空振りしない。
    // 同時に測った「同一ペアの再戦 最多8回・3回以上戦ったペア65.5組（最悪＝清×琉球9回）」が、この機構が要る理由そのもの
    // ＝大国が小国を何度も殴り続ける世界は史実ではない。列強は均衡が壊れる戦争へ口を出して止めた。
    // ★宣戦に到達可能性を要求する（点火2026-08-01）。0＝旧（届かない相手にも宣戦できた）／1＝どちらも投射が届かないペアは開戦しない。
    // 実測の動機＝再戦の最悪ペアが「内陸インドの藩王国×ベンガル湾の向こうのマレー・9回」だった。
    // ⚠★閾値（DefendProjectionMin=0.2）は**動かさない**（ユーザー裁定②・2026-08-01）。理由は Diplomacy.WorthFighting の
    //   ⓐ〜ⓕ に全文を置いた。要点＝SeaControl の和が1に拘束されるため 0.25〜0.5 の狭い区間で「何も止めない」から
    //   「海の戦争を全部止める」へ反転する**ナイフエッジ**であり、較正で選べる形をしていない。本命は DistanceWarDecay の時代関数化。
    public double WarNeedsReach = 1.0;
    public double PeaceInterventionEnabled = 1.0;
    public double PeaceInterventionProbe = 1.0;   // ★2026-08-01：診断を常時ON（世界に一切書かない純観測＝厳密恒等）。撃てる局面の延べ数をバッチ末尾に出す      // 診断のみ。0でゼロコスト。>0で「撃てる局面」を数えるだけ（世界に一切書かない）
    public double InterventionMotiveRatio = 1.0;     // 勝勢側の陣営戦力 ÷ 介入国の陣営戦力 がこれ以上なら「止めたい」＝動機
    // 応諾の敷居（無次元）。★較正の読み方＝**対等な調停者（lean=0.5）は、膠着した戦争なら止められるが、
    // 誰かが勝っている戦争は止められない**。0.5 なら：勝敗なし＋やや疲弊(0.4)＝0.9>0.5で応諾／
    // 決定的に勝っている側(0.9)は lean+weary>1.4 が要る＝圧倒的な調停者か、勝者自身の消耗が要る。
    public double InterventionSubmitBar = 0.5;
    public double InterventionRivalTension = 22.0;   // 提案が他の列強との緊張を上げる量（ColonizeRivalTension=22.0 と同型・同値）
    public double InterventionWarMinMonths = 12.0;   // 開戦からこの月数未満の戦争には口を出さない（始まったばかりの戦争に列強は動かない）
    public double InterventionCooldownYears = 10.0;  // 同一交戦ペアへの再介入の間隔（年）
    public double InterventionRefusalSymmetric = 1.0;   // ★点火2026-08-14（Wave D同一ソースA/B：列強再現率+8.8→30.0・領土本国+5.9・◎+3／法−4.0・経済−5.0＝軟性規準通過）。両者とも調停を拒んだとき、旧式は war.A だけを拒否者にしていた（登録順という実装の都合）
    public double InterventionRefusalWar = 1.0;      // ★点火2026-08-14（上と対＝調停の拒否は面子の問題では済まない）。拒否＝提案国が拒否側に参戦。0で「止めるだけ」（点火2で1へ）
    public double ColonialUnrestHomeWeight = 0.006; // C1植民地不満→本国大衆の闘争度（反帝世論）の月次係数（植民地人口加重平均不満×帝国規模）

    // --- 人口動態（ロジスティック＝扶養力へ収束。人口転換。§A-3 拡張）。出生−死亡の純を扶養力との差で表す＝頑健（暴走/崩壊しない）---
    public double PopGrowthRate = 0.006;          // 扶養力へ収束する速さ（月次）。戦死からの回復もこれ
    public double HealthcareCapacityBonus = 1.2;  // 医療（社会保障×識字でgate）が扶養力↑（乳児死亡の低下＝人口増の主因）
    public double HealthcareEducationGate = 0.6;  // 医療は識字がこれで満額（医者=教育済みPOPが要る）＝教育が人口動態に効く
    public double UrbanCapacityPenalty = 0.12;    // 都市化で扶養力低下（近代家族＝少子化＝人口転換の後半）。neutralは概ね安定に
    public double IndustryCapacityBonus = 0.12;   // 工業化が扶養力↑（雇用・食料生産性＝産業革命の人口増・移民の定着先）。工業化度の平均に比例（強すぎると人口爆発で経済破綻）
    public double FoodCapacityWeight = 0.5;       // **実食料の扶養力連結（マルサスの積極的抑制）**：FoodFill=主食充足(消費ベース∈[0,1])。capacity に +これ×(FoodFill−1) ＝凶作/過密/高騰で主食が買えねば扶養力↓→飢饉死。平常 FoodFill≈1 で中立（較正温存）。下方向のみ（消費は需要で頭打ち＝余剰成長は既存機構）。翌年の収穫回復＋capacity下限0.3で再生可能
    public double LandRoomFertilityWeight = 0.3;   // 【現行0.3＝有効】U3で役割分離（旧名LandRoomCapacityWeight・2026-07-13）：空き土地(max(0,Σ耕地/Σ農村−1))×これ＝**世界の技術水準出生率ブースト**（FertilityBase以上へ・米西部の高出生）。旧はcapacity乗数でLandAnchorと二重リフトだった→出生側へ移管。ArableLand未設定（較正）は集計除外＝厳密恒等。0で休眠
    // B-高1（史実検証2026-07-22）：扶養力の食料アンカーの分子へ主食の**純輸入**を算入する比率。0=旧挙動＝自国産出のみ＝厳密恒等。
    // 旧実装は消費ベースが met=sub+min(qty,need−sub) で foodMet≤foodNeed を構造的に保証し、生産ベースも自国産出だけだったため、
    // **輸入で人口を養う国が構造的に人口爆発できない**（英は1846年穀物法撤廃後1900年頃に小麦消費の約8割を輸入して人口を養い1783→1911で×3.4）。
    // 人口軸（B-中7）の実測が歪みを確認＝英×1.22（史実×3.4の36%）・清×1.01（史実×1.45）。Simulation.cs:1346 のコメント自身が「将来課題」と自認していた欠落。
    // 輸出国は純輸入が負＝送り出した分だけ自国の天井が下がる＝保存的。
    public double FoodAnchorNetImport = 1.0;   // **2026-07-23点火**
    // A-高2（史実検証2026-07-22）：運賃革命＝交易マージンの**従量成分**（TransportWeightMarginScale項）を技術で連続的に縮める。
    // 旧実装はマージンが1783-1934を通じて時代不変＝麦の輸出入価格楔≈7.7倍が151年固定・石炭は輸出閾値cap張り付きで国際交易が不能
    // （1913年に7000万トンを輸出した英国最大の輸出品が構造的に存在できない）。TransportMargin の行のコメント自身が時代依存を意図していた内部矛盾。
    // 史実＝Liverpool-Chicago小麦ギャップ 1870年57.6%→1913年15.6%（約3.6倍縮小）。Max=0で乗算1.0＝厳密恒等。
    // 時計＝**世界前線技術**（海運技術は世界財＝運賃低下は全国に均霑）。onset1.7≈1850年前後・span1.2＝1913(前線2.9)で満了。点火0.7＝楔が30%まで縮む。
    public double TransportRevolutionMax = 0.5;   // **2026-07-23点火・同日0.7→0.5へ縮小**（楔の縮小を半分に＝交易構造の変化を緩やかに）   // **2026-07-23点火**＝楔が30%まで縮む（史実3.6倍縮小）
    public double TransportRevolutionOnset = 1.7;
    public double TransportRevolutionSpan = 1.2;
    // B-高5（史実検証2026-07-22）：飢饉プッシュの上限緩和を**送出州の FoodFill** で判定するブレンド率。0=旧挙動＝国平均のみ＝厳密恒等。
    // 飢饉クラスタの他機構（超過死亡・地方蜂起・Factions危機）は州単位へ移行済みで、MoveMigrants の上限緩和だけが国平均の取り残し＝
    // 英5州構成では州FoodFill0.4でも国平均0.91までしか下がらず、アイルランド型の集中的大量脱出が構造的に発火しない。
    public double FaminePushRegionBlend = 1.0;   // ⚠台帳矛盾の確定（第2段2-7・2026-07-27）：コメントは「2026-07-23点火→同日休眠へ戻し」だが**実リテラルは1.0＝戻し忘れで稼働中**。以後の全基線（fidelity exact38/near70等）はこの1.0込みで測定されている＝**現状の正は1.0（基線側）**。0への差し戻しは挙動変更＝1項目1バッチで別途裁定（旧・戻し根拠＝州化で飢饉検知が敏感化→欧州の流出加速→英×0.99へ人口逆行、Boost=2.0と同系）
    // B-高6（史実検証2026-07-22）：受入capのクリップ余剰を、cap未達の国へ pull 比で再配分する（総量はプール側 poolSize が律する＝洪水なし）。
    // 0=旧挙動＝余剰は捨てられ実効流入が名目を下回る＝厳密恒等。旧実装は cap 係数=プール係数(0.004)が同一のため「pullシェアが人口シェアを超える国は必ずcap張り付き」
    // が算術的に保証され、**流入量が pull（アメリカが豊かなこと）でなく自国人口に比例する**因果の逆転が起きていた。
    public double MigrationRedistributeClipped = 1.0;   // ⚠台帳矛盾の確定（FaminePushRegionBlendと同型の戻し忘れ）：コメントは「2026-07-23点火→同日休眠へ戻し」だが実リテラルは1.0＝稼働中。以後の全基線はこの1.0込みで測定されている＝現状の正は1.0（基線側）。0へ戻すかは別途1項目1バッチで裁定
    // B-高4（史実検証2026-07-22）：外部移民の識字を定数(0.15)から「流出圧が正の国の人口加重識字」の運搬へ移行する比率。0=定数＝厳密恒等。
    // 0.15は1897年ロシア農村級の下限で、史実の大西洋移民は識字0.73（Dillingham委員会）＝3-5倍の過小。identity経路（自然増・越境・国内・昇格）が
    // 全て識字を運搬する中で外部移民だけが運ばず、**移民磁石だけが技術ペナルティを負う**非対称だった（米国成人識字は大量移民期に80%→92.3%と上昇）。
    public double ImmigrantLiteracyCarry = 1.0;   // **2026-07-23点火・同日1.0→0.5**（満額運搬は受入国の識字を動かしすぎ＝時代加重の実測0.4-0.6帯の中央へ）
    // C-高4（史実検証2026-07-22）：身分制免税＝旧体制（絶対王政/専制/幕府）における閉鎖階級（貴族・聖職）の課税ベース割引率。
    // 0=割引なし（×1.0＝厳密恒等）。点火0.6＝貴族は所得税・土地税を4割しか払わない（taille réelle・ユンカーのGrundsteuer免除。
    // vingtième/capitation は貴族にも課されており実態は「免除」でなく「過少査定」＝完全免除1.0は取らない）。
    // 立憲/共和/軍政では消える（特権の廃止）。累進課税が Closed を狙い撃つ既存設計はそのまま＝議会統制獲得後の特権課税ラチェットの受け皿。
    public double TaxConsentWeight = 0.35;   // ★2026-08-04（作者指摘「政治がゲームに与える影響が小さすぎる」）：課税への同意。発言権(FranchiseVoice)のないpopからは所得税/累進を取りきれない＝tax×(1−これ×(1−voice))。人頭税と土地税は対象外＝源泉で力ずくで取る税（専制の税源）。土地税も掛けると農業専制国（ビルマ/エチオピア等）の歳入が消えて忠実度が崩れる（2026-08-04実測）。実測で民主化が純粋なコストだった（参政権拡大＝正統性−52%/歳入−13.7%/国力+1.4%・政体を共和へ＝国力−4.3%）のを、史実の財政国家（英は仏の約2倍を徴収）へ寄せる。0で厳密恒等（休眠）
    public double PrivilegeTaxDiscount = 0.3;   // **2026-07-23点火・同日0.6→0.3へ縮小**（0.6は旧体制44カ国の歳入を削りすぎ＝プロイセン/スペインが逸脱過多へ・batch実測）
    // C-高9（史実検証2026-07-22）：公教育（Public法）の国庫財源率。0=旧挙動＝Public は財政コスト厳密0（国が無料で供給を得る因果の逆向き）。
    // 史実の公教育は無償でなく「共同体が教師俸給を払い親も一部払う混合」（プロイセン無償化1888・仏1881・英1891）＝定義的特徴は歳出項目化。
    // 点火0.4＝義務教育（EducationSpending満額）の4割相当を国庫が負担。
    public double PublicEduFundingShare = 0.2;   // **2026-07-23点火・同日0.4→0.2へ縮小**（C-高4と重なり旧体制の国庫を細らせすぎた）
    // C-高1（史実検証2026-07-22）：欽定憲法（上からの改革）の到達経路。旧実装は正統性ストック平衡が完全閉鎖でも0.895・恒常内戦でも0.445で
    // 閾値0.4を割らず、発火窓がデフォルト/敗戦/失脚の直後2-3年のみ＝「上からの改革」が事実上のno-op。
    // (1) anticipation＝大衆動員圧(challenge/coerce)＋外圧が高いほど窓が開く（自由民権運動1874-84・ハイドパーク暴動1866＝革命の予感が王を動かす）。0=旧閾値のみ＝恒等。
    public double ReformAnticipationWeight = 0.2;   // **2026-07-23点火・同日0.4→0.2へ縮小**（外圧定数の除去とセット＝最大閾値0.6・正統性平衡0.895では発火せず侵食時のみ窓が開く）
    // (2) 下賜PCの連続化＝床0.3に動員圧比例の幅を加算（強い議会圧力ほど厚い譲歩＝予算協賛権つきの欽定憲法）。幅0.15で最大0.45＝立憲床に到達
    //（HistoricalReference は日本・プロイセン・オーストリアの3国で exact=CM を要求＝設計意図「0.3<0.45なら専制のまま」と忠実度基準の正面矛盾を解消する一般則）。
    // >0 は PolityGraphRetired の早期returnもバイパス（改革派主導の平和的遷移で下賜に到達できない点火口の死を解消）。0=旧挙動＝厳密恒等。
    public double ReformGrantPcWidth = 0.15;   // **2026-07-23点火**＝動員圧満杯で0.3+0.15=0.45（立憲床）
    // ===== 第3群（史実検証2026-07-22・帯が揺れる群＝段階点火）＝2026-07-23配線 =====
    // C-高6：AI同士の屈服経路（第1段＝資産移転なし）。旧＝高緊張は戦争でしか下がらず、プレイヤーだけ屈服UIがある＝プレイヤー/AI対等の違反。
    // 軍事が劣勢の側は開戦寸前に屈服＝緊張をConcedeTensionTargetへ・正統性に小さな傷・同ペアに再屈服クールダウン（ファショダ1898・三国干渉＝力の差が見えた対立は戦わずに引く）。
    // MilRatio=0で不読＝旧挙動（即開戦）＝厳密恒等。初版1.8→採用3.0（2.5倍=植民地化の無血屈服より手前の帯）。
    public double AISubmitMilRatio = 3.0;   // **2026-07-25採用（第3群C-高6）**：軍事3倍差で弱い側が屈服（緊張解消＋正統性コスト＝戦わずに折れる外交）＝exact37/near70。WarDeclareTension下げ戻しは次段バッチで実施
    public double SubmitProbabilistic = 0.0;   // ★屈服の確率化（AI審査3-1・2026-08-31休眠）：3.0倍の決定論的な崖（2.9倍で戦争・3.1倍で無血屈服）を逓減へ。屈服確率=clamp((陣営比−1)/(AISubmitMilRatio−1),0,1)＝互角0%・崖の線で100%（新しい数は作らない＝既存の線が確実点になる）。ファショダで引いた英仏と引かなかった日露が同じ機構から出る。専用RNG系列（SubmitRng）＝0では未消費＝厳密恒等
    public double CapturedColoniesAreRegions = 1.0;   // ★実装2026-08-31・点火2026-08-31（V1V2腕＝ハーネス0/10・植民地+2.5）★従属の一般化・第一切片（docs/202608/20260828_従属の一般化_部分完了.md §0）：講和奪取/無血併合で得た Colony をその場で植民地格の州（RegionTier.Colonial）へ実体化＝「開始時の植民地は州・プレイ中の獲得は Colony」という格差ある二重管理の解消。変換は既存の PromoteColonyToRegion（保存記帳込み）・保存検査は PromotedColonies へ計上。同名州ガードで不可なら旧経路（ColonyList）へフォールバック。0＝旧経路＝厳密恒等
    public double ColonialRegionCession = 1.0;        // ★実装2026-08-31・点火2026-08-31（V1V2腕＝植民地+10.9・列強+3.8・首位確定Q109→Q200/交代1.6→3.0＝ラウンドBの記録コストを戦争の意味の回復で相殺）★従属の一般化V2（講和量差の是正）：講和で敗者の**植民地格の州**を複数割譲できる器＝旧・植民地奪取（ColonyCaptureMax/Budget/コスト式）を州側へ移植。V1で戦利品の器がColony→州へ移ると州割譲は1戦争1州＝「七年戦争でカナダとインドを同時に」が消えるための対。reach条件＝colonialReachと同じ（海軍あり＋制海権≧SeaInvasionControlMin）・コストの人口はSumPopulation/ColonialPopScale＝Colony.Populationと同じ物差し。0＝不発＝厳密恒等
    // ==== 研究＝解禁の唯一の形（docs/202608/20260827・段1〜3実装2026-08-31）====
    public double DiscoveryInstitutions = 1.0;    // ★点火2026-08-31（段2腕＝◎+1/法+2.2/植民地+3.3・列強−6.3はノイズ帯縁=#17答え合わせ対象）★段2ゲート：Institutions の bool 閾値（特許/株式会社）を Discovery.Unlock の傾斜へ置換。暫定時計=TechLevel×適性（特許=EliteCore・株式=最大工業化度）。boolは表示のみ（ramp≥0.5）へ。0＝旧bool閾値＝厳密恒等
    public double PatentDiscoveryOnset = 0.35;    // 特許の傾斜開始＝EliteCoreのランプ（段2＝旧閾値0.4と同じ量・同じ中点のまま**崖だけ**連続化）。⚠幅0.2の広いランプは後発へ部分ボーナスを早配りし列強再現−7.5（実測2形で再現）＝**細いランプ（span0.1）で除去は不連続のみに限定**。広げ直しは段4（分野時計）で測定とセット。時期感は較正の目標＝年は書かない
    public double PatentDiscoverySpan = 0.1;      // 特許の普及幅（旧閾値0.4を中点に±0.05＝形式は連続・分布は旧とほぼ同一）
    public double JointStockDiscoveryOnset = 0.25; // 株式会社の傾斜開始＝maxIndのランプ（旧閾値0.3が中点・span0.1＝細いランプ）。時期感1850〜1870
    public double JointStockDiscoverySpan = 0.1;  // 株式会社の普及幅（細いランプ＝除去は不連続のみ）
    public double DiscoveryFieldSplit = 0.0;      // ★段4ゲート（休眠）：分野時計の按分を後援者の勢力へ開く（0=産業100%＝現状の単一時計と同値＝厳密恒等）。段5以降で軍事/思想の読者を配線
    public double DiffusionWeight = 0.0;         // ★発見・段7（思想の伝播・休眠）：到達(A→B)=貿易量(A,B)/買い手GDP×メディアA×メディアB×前四半期の到達A。メディア=NewsFill×識字+RadioFill（全て既存量＝「思想は商人と本と留学生を通じて広がった」＝貿易路がそのまま伝播路・原典§5-4）。0＝ペア記帳（PairFlowQ）も伝播も1命令も走らない＝厳密恒等。読者（思想eraゲートの置換）は段8＝絶対に混ぜない
    public double IsolationExportWeight = 1.0;   // ★点火2026-08-31（T2腕＝欧州内50.3%/英世界工場復帰）   // ★鎖国の対称化（2026-08-31・pairprobe実測「関税100%の朝鮮が世界一の輸出国」＝輸入関税だけで鎖国を表現する構造穴）：売り側access×=(1−これ×関税²)。二乗＝新しい数を作らず**高関税レジームだけ**を閉じる（0.25→×0.94・0.8→×0.36・1.0→×0＝真の鎖国）。関税が政治で下がれば輸出も開く＝開国が貿易の両面を開く。0＝旧＝厳密恒等
    public double TariffExportOppositionWeight = 3.0;   // ★点火2026-08-31（T2腕＝英の自由貿易転換が政治から創発・純支持−0.41）   // ★関税の全員暴走の対（2026-08-31・pairprobe実測＝仏99%英高率で欧州相互貿易が絞殺）：近代エリートの関税選好へ**輸出利害の反対**を加える＝−これ×輸出/GDPシェア（マンチェスター学派＝輸出で食う資本は自由貿易を推す。反リカード側の保護利害 TariffInterestPref と対）。IsolationExportWeight とセット＝「高関税は輸出も殺す」物理ができて初めて政治の負帰還が史実の向きになる。0＝厳密恒等
    public double AiTariffRelaxation = 0.1;             // ★点火2026-08-31（T2腕＝AI目標が5-10%帯へ・保護と自由化の波の対称化）             // ★案A（作者裁定2026-08-31）＝AI保護関税ラチェットの対動詞：急増の無い平時に目標を毎四半期 TariffReactionMax×これ だけ漸減（保護の波→自由化の波の対称化。ReactProtectiveTariff の「下げはしない」の是正）。0＝厳密恒等（点火候補0.1＝約−10%/年）
    public double TradeTreatyEnabled = 1.0;             // ★点火2026-08-31（T2腕・プレイヤーUI=外交タブ「通商条約」同日実装）             // ★案B（作者裁定2026-08-31）＝通商条約：平時×両国の産業利害が自由貿易側（州関税利害の国平均<0）の実国家ペアが、互いの関税目標を**低い方へ収束**（コブデン=シュヴァリエ1860＋最恵国の連鎖＝条約網が関税を下げ広げる対ラチェット）。新しい数はゼロ（低い方へ寄せるだけ）。⚠この収束はAI同士のみ（プレイヤーは同日実装の外交タブUIから提案する側＝AIはプレイヤーへ自動提案しない非対称が残る）。0＝厳密恒等
    public double RentProtectionWeightCoef = 1.0;       // ★点火2026-08-31＝1.5→1.0（案D・T2腕）       // ★案D（作者裁定2026-08-31）＝旧支配層の保護利害の重み（旧・PolicyPreferences のハードコード定数1.5を係数化＝既定同値で厳密恒等）。関税・穀物法の選好が読む。全員関税100%漂流の主動力＝#17調整対象
    public double AbsorptionAdminWeight = 0.5;          // ★点火2026-08-31（T2腕＝アジア世界工場の椅子取りを制度の質で判別）          // ★穴③（アジア準先端技術・2026-08-31）：吸収能力に**行政**の脚を追加＝×(1−これ×(1−行政効率))。08方針§6の原器（洋務運動＝武器は買えても識字・**行政**が伴わない）の行政側。既存の識字（Elite）・所得（IncomeAbsorption）は輸出成功の循環で満たされてしまう（カンボジア技術2.33実測）＝制度の質だけが循環の外にある判別子。IncomeAbsorptionと同形。0＝厳密恒等
    public double AISubmitLegitCost = 0.05;        // 屈服の正統性コスト（下関・三国干渉の屈辱＝国内の怒り）
    public double AISubmitCooldownYears = 10.0;    // 同ペアの再屈服クールダウン（連打で戦争が消えるのを防ぐ）
    // B-高3：同化への識字抵抗＝assim_eff = assim × max(0, 1 − これ×識字)。0で×1.0＝厳密恒等。
    // 旧＝同化が無条件・単調で墺 EthnicUnity 0.35→0.83（1914）＝多民族帝国が均質化し、Unity系6機構が最も効くべき1848-1918に最弱化。
    // 史実＝1910年国勢調査で墺独語話者23.9%は一世紀横這い・ボヘミアのチェコ人は識字95%超で同化拒否（バデーニ暴動1897）。点火0.6＝遅くなるが止まらない（1.0にしない＝ハンガリーのマジャール化の反例）。
    public double AssimilationLiteracyResist = 0.6;   // **2026-07-25点火試験（第3群B-高3）**：識字した少数派は同化に抗う（遅くなるが止まらない＝0.5-0.7帯の中央）。ボヘミア1900年識字95%の同化拒否
    // ⑭-B（B-高3の前提）：CoreEthnicShare の初期化を州の Culture ラベルで分化（主流文化州=高・少数文化州=低＝地理的局在）。0=国一律u0＝厳密恒等。
    // 旧＝墺の全11州が一律0.35＝分離圧力の強度が戻っても「どの州が離れるか」の地理が生まれない。点火1.0＝一致州1.0/不一致州0.0（加重平均が州構成から創発）。
    public double CoreInitByRegionCulture = 1.0;   // **2026-07-25点火試験（第3群B-高3の前提⑭-B）**：一致州1.0/不一致州0.0＝分離の地理的局在が州構成から創発
    // C-高7：制度疲労の天井の共通床。旧＝天井=初期値のため decay を持たない50カ国は構造的に硬直しえない（3カ国だけの特権）。
    // 0=旧挙動＝厳密恒等。点火0.3＝低い値からの段階点火（0.8級を一律に与えると約40カ国の改革抵抗が跳ね1914断面の6法軸が保守側へ倒れる）。
    public double DecayCeilingUniversal = 0.3;   // **2026-07-25点火試験（第3群C-高7）**：低い共通床から段階点火（decayを持たない50カ国も硬直しうる）
    // C-高5：保守綱領の福祉上限を大衆闘争度で緩める＝ビスマルク型「アメとムチ」（社会主義者鎮圧法1878と同じ手が疾病保険1883を作った）。
    // 旧＝非民主体制は福祉意図が毎期 ConservativeWelfareCap(0.1) に上書きされ法段0＝非民主の社会保険が構造的に不能。0で加算0＝厳密恒等。
    // 点火0.3＝闘争度0.5で上限0.1+0.15=0.25（第1段=労災 相当が通る）。
    public double ConservativeWelfareMilitancyRelief = 0.0;   // **2026-07-25点火試験＝差し戻し（第3群C-高5）**：0.3単独batch＝破綻0・清6勝だが exact35/near67（−2/−5）＝
    // 福祉が不満を宥めて政変が減る「歴史がおとなしくなる」型。半減0.15の再試行は#17較正ラウンド枠。0=cap据置＝厳密恒等
    // ===== 2026-07-24設計群（7doc）＝点火状況は各行参照 =====
    // 産業政策の代償（設計doc 2026-07-24「産業政策の代償設計」）
    // レバー1【本命】軟予算制約（コルナイ）：補助金/国営赤字で操業する工場は「補助依存ストック」（Producer.SubsidyDependence 0..1）が漸増し、
    // 実効生産性 ×(1−これ×依存)。恒久補助＝実質コスト逓増＝「時限補助→黒字化 or 払い下げ(SoeSale)」だけが割に合う（明治の払い下げが最適解として創発）。
    public double SubsidySoftBudgetDecay = 0.4;        // **2026-07-24点火試験**（レバー1＝恒久依存で最大4割の非効率）。0で乗算×1.0＝厳密恒等
    public double SubsidyDependenceRate = 0.007;       // 依存ストックの月次増分（+0.02/四半期相当）。補助が外れ黒字なら同率で漸減
    // レバー2 財政規律：補助金の国庫負担へ SpendingCapFactor（借入スタックの支出上限）を適用＝借金漬けの国は補助を維持できない（1880年代の払い下げ）。
    // 国営持分の赤字（外せない計画経済の代償）は対象外のまま。0で不読＝厳密恒等。
    public double SubsidyRespectsSpendingCap = 1.0;    // **2026-07-24点火試験**（レバー2＝借金漬けの国は補助を維持できない）
    // レバー3 AI対称化：Industrialist教義の開発国家プレイ（平時の民生上流Intermediate/Producer赤字工場へ補助・黒字N期で解除）。
    // ⚠順序不可逆＝レバー1・2の点火より先に入れない（コストなしの補助金ファームを44カ国へ配ることになる）。
    public double AiDevelopmentalSubsidy = 0.0;
    // 政体フレーバー（設計doc 2026-07-24「政体フレーバー設計」）
    // レバー2 勅令は速い：非選挙政体（絶対/専制/幕府/軍政）のスライダー歩幅 ×(1+これ)（議会審議を経ない＝農奴解放勅令・太政官布告）。
    // 代償は新設不要＝押し切り遺恨 PushedLawGrievance が既に「速いが恨まれる」を価格付け。0で×1.0＝厳密恒等。
    public double AutocraticPolicyAgility = 0.5;       // **2026-07-25点火試験**（非選挙政体のスライダー歩幅×1.5＝勅令は速い）
    // レバー3 議会の信認割引：選挙のある政体（立憲/共和）の国債金利に連続割引＝予算統制→債権者の信認（英コンソルが安かった理由）。
    // convDiscount と同形の乗数。C〜H中6（英仏が同一条件で価格付けされる問題）の一般則。0で×1.0＝厳密恒等。
    public double BondRateRepresentationDiscount = 0.1;   // 【0.2→0.1へ減衰2026-08-08作者裁定＝連立とセットの攪乱源】議会統制力の連続量へ改修して再点火（旧・政体ラベル二値0.2は2026-07-25差し戻し＝DebtGdp年換算フリップで再挑戦解禁の記録どおり）。
    // 政体フレーバーdocの留意どおり DebtGdpAnnualized=0 のままでは歪みだけ出る＝**財7（債務/GDP年率化・第4群）とセットでのみ再挑戦**。0=×1.0恒等
    // ⚠撤去2026-08-22: ExportDemandWeight(0.25)・ExportDemandSmoothing・Market.ExportSmoothed（貿易特化レバー1＝輸出EMAの別建て加算）＝準レント配分では価格に輸出需要が載る（次元の合った1本）ので不要。墓標は準レント注記。
    // 革命の輸出（設計doc 2026-07-24「革命の輸出設計」）機構A＝革命の波（C-高3の解）。
    // 暴力的な政体転換が起きた四半期に全国へ放送（2相方式＝四半期末に収集し翌四半期に適用＝処理順非依存）。受信＝距離減衰×文化親和×旧体制同型重み。
    // 消費は大衆闘争度targetへの加算1本のみ（意識には効かせない＝17年の遅い変数に数週間の興奮を混ぜない）。[PORT:P1]
    public double RevolutionExportRate = 0.3;          // **点火2026-07-31（07_再設計 第1弾1b＝革命の波）**：受信強度。隣国(距離減衰0.5)×同文化×同型体制で1件あたり波+0.15＝闘争度target +0.02。0で放送・受信・減衰の全経路不走行＝厳密恒等
    public double RevolutionWaveDistanceKm = 1500.0;   // 距離減衰スケール（1/(1+km/これ)）
    public double RevolutionWaveHalflifeQuarters = 8.0;   // 波の半減期（約2年＝1848→1849反動の時間スケール）
    public double RevolutionWaveMilitancy = 0.15;      // 波→大衆闘争度targetへの寄与（wave満杯時）
    // 金本位の振動抑制＋正貨準備の動学（2026-07-25 #125・ユーザー裁定）。実測＝強制離脱381回/30試合（うちカバー率割れ316回）＝
    // 離脱(coverage<GoldCoverMin)と再加入(coverage>=GoldCoverMin)が同一閾値・クールダウンなしのチャタリング。
    public double GoldRejoinCooldownYears = 5.0;    // **2026-07-25点火試験**：強制離脱後の再加入禁止（年）。0=現行恒等（1797英停止→1821再開・1914各国→1925英＝兌換の信認は年単位でしか戻らない）
    public double GoldRejoinCoverMargin = 1.3;      // **2026-07-25点火試験**：再加入に要するカバー率の余白（GoldCoverMin×これ）。1.0=現行恒等（シュミットトリガー＝境界チャタリング防止）
    public double GoldCoverCreditRestraint = 0.5;   // **2026-07-25点火試験**：金本位国のカバー率防衛＝coverageが床(GoldCoverMin×(1+これ))未満で与信上限を比例縮小（1890年代バンクレート防衛の与信面＝兌換を守るため信用を絞る・与信↓→BroadMoney↓→coverage回復の負帰還）。0=不読＝恒等
    // 戦争・内戦の経済ダメージ（2026-07-25 #136・ユーザー指摘「低すぎる可能性」）。棚卸し＝現行の内戦は軍需消費2倍・正統性ドレイン・選挙停止**のみ**
    //（生産・資本・民間人が無傷＝太平天国の長江壊滅・米内戦の南部資本半減が表現不能。軍需2倍はむしろ軍需景気）。対外戦争は戦費・資材競合・
    // 兵士/士官の戦死・封鎖・厭戦のみ＝**国土は無傷**（北仏1914-18型の戦場破壊なし）。以下3本で物理ダメージを追加（点火試験値・値は各行参照）。
    public double CivilWarEconomyDisruption = 0.2;  // **2026-07-25点火試験**：内戦中の実効生産性×(1−これ)（流通麻痺・徴発・戦場化・労働の逃散）。0=不読＝恒等
    public double CivilWarCivilianToll = 0.005;     // **2026-07-25点火試験**：内戦中の民間超過死亡（四半期・非兵士pop比。飢餓・虐殺・流民＝太平天国の主死因は戦闘でない。3年内戦で約6%減）。0=恒等
    public double WarCivilianToll = 0.002;          // 第7段第1波②点火（2026-07-28）：対外戦争の民間人死＝劣勢度×接触強度×これ（月次・非兵士pop比）。戦争が本当に恐ろしくなる（厭戦→革命の実体＝餓死）。CivilWarCivilianTollと同じ保存作法。0で恒等
    public double WarZoneCapitalDamage = 0.01;      // **2026-07-25点火試験**：対外戦争＝劣勢側の領土が戦場になる：敗色×接触強度に応じ工業化資本・港湾が月次摩耗。0=恒等
    // 機構B 矯正講和（革命輸出doc §3・2026-07-25実装）：壊滅級勝利×政体イデオロギー距離≥閾値＝勝者が敗者の政体を自陣営へ矯正（講和条項＝新しい宣戦動詞は作らない）。
    // 対称な一般則＝革命共和国の勝利→衛星共和国（バタヴィア1795/ヘルヴェティア1798）・君主同盟の勝利→反動介入（西1823/ハンガリー1849）。国名も方向も書かない。
    public double ImposeRegimeEnabled = 1.0;        // 第7段第1波④点火（2026-07-28・#17較正後の再点火＝過去差し戻しは帯のみが理由）：矯正講和＝衛星共和国と反動介入が1本の一般則で両方出る（神聖同盟が革命を潰す/仏が姉妹共和国を作る＝ナポレオンの機構B・国名も方向も書かない）。0=不発＝厳密恒等
    public double ImposeRegimeIdeologyGap = 0.4;    // 発動に要する政体イデオロギー距離（Ideology()スカラー差＝絶対0.0⇔共和0.60や立憲0.45⇔絶対が入り、立憲⇔共和0.15は入らない）
    public double ImposedRegimeLegitimacy = 0.3;    // 押し付け政体の正統性上限（低く始まる＝復古の芽。実績ストックが失望を蓄積→宗主が弱れば揺り戻し＝ウィーン体制を書かずに復古が出る）
    // NonElected狭い版（2026-07-25・B群）：非選挙政体は保守綱領のうち**福祉上限・累進ゼロの強制のみ**免除（関税・穀物法は維持）＝
    // ビスマルク型社会保険の裁量だけを君主に与える。全面版NonElectedSkipsPlatform=1は帯−3/人口崩れで差し戻し済み（貿易・食料が一斉に動いた）＝
    // 狭い版は帯リスクを福祉軸に限定。C-高5（闘争度での上限緩和）とは別解＝こちらは上限そのものの免除。0=恒等。
    public double NonElectedSkipsWelfareCap = 1.0;   // **2026-07-25採用（NonElected狭い版）**：exact38/near71/◎19/逸脱11（基線37/69/◎18/13）＝全指標基線以上・破綻0。全面版で失敗した機構の福祉軸限定再設計が成立。清43%/首位Q485は監視
    // === 全域監査2026-07-11の配線系13本（2026-07-25一括配線・2026-07-27に全点火・第1〜3群）===
    public double TransportCongestionWeight = 1.0;   // **点火2026-07-27（機能優先ラウンド第1群）**   // 接3：輸送容量目標×(1+これ×活動州の(1−律速率)平均)＝混雑シグナルを目標へ接続（交易集約国が増強・非交易国は誤配分しない）。0=不読
    public double BondInterestSavingsWeighted = 1.0;   // **点火2026-07-27（機能優先ラウンド第1群）** // 接5：国債利払いの国内分配を頭数比例(0)→Max(0,Savings)比例(1)へブレンド＝債券所得（レンティア動学）。経10預金利息と同じ規範。0=現行
    public double MintWageShare = 0.5;   // **点火2026-07-27（機能優先ラウンド第1群）**               // 接6：鋳造代金のうち労働pop（掘り子）へ渡す割合＝ゴールドラッシュの高賃金を創発（総額不変＝保存非接触）。0=全額所有者（現行）
    public double TariffInterestPrefWeight = 0.3;   // **点火2026-07-27（機能優先ラウンド第2群）**    // 接8a：州関税利害（競争力）の国平均を近代エリートの関税選好へ加算＝後発工業国の保護主義（米国システム/独1879）。0=不読
    public double TariffStateRevenueWeight = 0.08;   // **点火2026-07-27（機能優先ラウンド第3群）**    // 接8b：国家の歳入要求を関税軸へ（消費税と同型＝19世紀最大の歳入源）。0=不読
    public double InvadeShipSeaDistance = 1.0;   // **点火2026-07-27（機能優先ラウンド第1群）**       // 接9：侵略の船要求距離を大圏直線(0)→海路距離(1・喜望峰/スエズ/パナマ経由)へ統一（他の海運コストは統一済み）。0=現行
    public double EpidemicOnsetSanitationWeight = 0.4;   // **点火2026-07-27（機能優先ラウンド第2群）** // 接12：疫病の発生率×(1−これ×最過密州の衛生整備度)＝衛生インフラが流行の発生自体を止める（従来は死亡率側のみ）。0=不読
    public double HealthcareRealGate = 0.5;   // **点火2026-07-27（機能優先ラウンド第3群）**          // 接13：扶養力の主医療チャネルを実医療財消費(HealthFill)で min ゲート（1=医者なし→医療ボーナス0・中間=部分ゲート）。0=第3項なし（現行）
    public double CrimePushWeight = 6.0;   // **点火2026-07-27（機能優先ラウンド第2群）→ 同日 0.3→6.0 へ再点火**：crimeRate の上限は CrimeBase 0.01×(1+CrimeUrbanWeight 0.6)=0.016 しかなく、
                                           // 0.3 では押し出し上限 0.0048＝同式の PushUnrestWeight(上限0.5) の約1/100＝ノイズ級で機構が事実上死んでいた。6.0 で上限 0.096＝不満項の約2割＝副次要因として意味を持つ水準。             // 接16：州別犯罪率を移民の押し出し（pushPenalty）へ加重＝治安悪化からの逃避。0=不読
    public double SteamTransportOnset = 1.0;   // **点火2026-07-27（機能優先ラウンド第1群）**         // リ5：1で汽船(85)onset0.5・機関車(88)onset0.6を既定レシピへ＝フルトン以前の汽船流通を止める（起動時パス・CrucibleSteelと同型）。0=無ゲート（現行）
    public double DisasterAgeMortalityExcess = 0.4;   // **点火2026-07-27（機能優先ラウンド第2群）**  // リ10：災害死（疫病・局地飢饉）の子供/老年の超過死亡倍率＝ChildShare/OldShareへ運搬しコホートの穴を残す。0=均等死＝比率不変（現行）
    public double MigrantDowryWorldBase = 1.0;   // **点火2026-07-27（機能優先ラウンド第1群）**       // リ11：外部移民の持参金基準を受入地1人当たり貯蓄(0)→世界平均(1)へブレンド＝富裕国ほど外生マネーが湧く自己強化を解消。0=現行
    public double StateSpendTreasuryClamp = 1.0;   // **点火2026-07-27（機能優先ラウンド第1群）**     // 他12：軍需/行政の予算を「いま国庫にある現金」で比例縮小＝StateSpent精算の無利子当座借越（財政規律の迂回）を封じる。0=現行
    public double ConscriptExcludeOldMales = 1.0;   // **点火2026-07-27（機能優先ラウンド第3群）**    // 他13：徴兵上限を働き盛り男性（成人−老年）へ＝総動員時の老年男性二重計上（OldShare水増し）を解消。0=現行
    public double ExternalPressureDerived = 1.0;   // **点火2026-07-27（機能優先ラウンド第2群）**     // 接7：外圧を創建時定数0.3から「世界の技術水準格差×海の接触」の四半期導出へ（1で有効）。0=定数据え置き（現行）
    public double ExternalPressureGapScale = 1.5;    // 接7：外圧が満額になる技術格差（世界の技術水準−自国がこれで外圧1.0）。ExternalPressureDerived=0では不読
    public double ExternalPressureInlandFactor = 0.5; // 接7：内陸国（活動州に港なし）の外圧係数＝黒船は海から来る（陸伝いの外圧は弱い）。ExternalPressureDerived=0では不読
    // A-高1：鋼のベッセマー不連続。坩堝鋼（TechOnset=0・高価＝鉄2.2+コークス1.2・Productivity0.9）と錬鉄レール（TechOnset=0・鉄1.3）を
    // 並存レシピで追加し、デフォルト（ベッセマー転炉＝鉄1.0+コークス0.4）を DefaultRecipeOnset(32)=0.55（≈1858・クロムなめし0.55/原油0.6のアンカーと整合）でゲート。
    // 0=追加もゲートもしない＝厳密恒等。点火1.0＝「深い連鎖ほど高い」が鋼で立つ（機械部品の実効原価+77%＝帯は必ず揺れる＝バッチ必須）。
    // ★石油ケロシン（灯油doc・2026-08-13）：灯油の第2レシピ。原油の「1859年から40年の買い手ゼロ」を埋める。
    //   鋼（坩堝→ベッセマー）と極性が逆＝**新レシピの方が安い**ので、onset後にコストで自動的に鯨油を駆逐する（捕鯨船団735隻→39隻）。
    public double KeroseneFromOilEnabled = 1.0;   // ★点火2026-08-14（n22実測：列強再現率+6.2・領土植民地+5.8／人口−5.7・政体exact−2.1・◎20vs21＝混合。原油の40年の買い手ゼロは実在の穴＝正しい挙動＞バランスで採用・#17で見直す）
    public double KeroseneOilInput = 0.5;         // 灯油1単位あたりの原油。1870年代の精製収率45〜60%（残りは廃棄・ナフサ）
    public double KeroseneOilProductivity = 1.6;  // 連続精製の生産性（既定＝鯨油レシピの相対。史実の価格差5〜10倍はこれと投入係数の合成で出す）
    public double CrucibleSteelEnabled = 1.0;   // 第7段第1波③点火（2026-07-28・#17較正後の再点火＝過去差し戻しは帯のみが理由）：坩堝鋼/ベッセマー不連続＝1783年から安価な鋼が在る現状を直し製鋼転換が時代を刻む（鋼原価+77%が機械〜工業財連鎖へ波及）。0で恒等
    public double LandRoomFertilityCap = 0.6;      // B-高2（史実検証2026-07-22・**2026-07-23点火**）：landRoom の上限＝世界の技術水準出生倍率−1。旧1e9＝実質無上限で、米は西部解錠後 landRoom≈3.7＝出生倍率4.7倍→年6.4%成長（史実3.09%・人類最大の観測値フッター派約4.0%）＝生物学的に不可能だった。0.6＝倍率1.6（米CBR約55/1000÷基準35/1000）
    public double LandAnchorCapacityWeight = 1.0;   // 人2c 土地アンカー（2026-07-11・#17級）：capacityBaselineへ＋これ×max(0, Σ耕地/(1−都市化)−capacityBaseline)＝土地が養える人口を天井に（米25×の構造解・下方向なし・センチネル除外で較正厳密恒等）。0で休眠
    public double SanitationCapacityWeight = 0.4; // **衛生の扶養力連結（近代公衆衛生→死亡率低下）**：sanitation=上下水道(InfraFill)+石鹸(SoapFill)+電化(ElecInfraFill)の人口加重∈[0,1]。capacity に +これ×都市化×(sanitation−1) ＝不衛生な都市で疫病死↑→扶養力↓。**都市化で按分**＝疫病は過密の問題（既存の疫病圧 (都市人口/人口)×(1−衛生) と一貫・農村は影響小）。施設/石鹸の無い世界は sanitation=1.0 で中立（較正温存）。19世紀の死亡率低下の主因は医療より衛生＝直接チャネル
    public double FoodFillSmoothing = 0.2;        // FoodFill の移動平均速度（備蓄＝穀倉が月次の振れをならす。餓死は単月でなく数ヶ月の持続的欠乏で起きる＝時定数≒5ヶ月）
    public int MedicalGoodId = 77;                // 医薬品の good.Id（社会保障＝公共医療が消費する資材）
    public double InsuranceCoverageMax = 0.6;     // 健康保険(#3)：国家が医薬品の購入費をこの割合まで肩代わり（実効負担＝社会保障×充足×これ）。popの実効価格↓→医療消費↑→HealthFill↑＋満足↑。費用は福祉と同じ裁量余剰から（保存：国庫→生産者）
    public int SoapGoodId = 72;                   // 石鹸の good.Id（消費充足が衛生＝公衆衛生を上げる）
    public double MedicalWelfareBoost = 2.0;      // 医薬品需要 ＝ 基礎 ×(1＋社会保障×これ)。高福祉ほど医薬品を大量消費（資材）
    // 過密/スラムの疫病：都市化が衛生(工業化由来)を上回ると疫病圧が立ち、医療(医者の役務)の需要が跳ねる。満たせねば HealthFill↓→扶養力↓(死亡)＋不満。
    // ＝公衆衛生をスライダーでなく「医療の市場需要」として表す（供給は医者＋医薬品の連鎖が応える）。容量という上限を使わず emergent に都市を律速する。
    public double HealthCrowdingBoost = 2.0;      // 疫病圧(都市化×(1−衛生))が医療需要を最大この倍率上乗せ（満額で×3）。過密×低衛生の都市が医療を大量に要求
    // 都市住宅・家賃（housing-urban-rent-absent・最小初手・住宅HIGH）：19世紀労働者の最大固定費=家賃の欠落を埋める土台。HousingId=125財＋都市化度ゲート＋移民摩擦。
    public double HousingNeedPerUrban = 0.03;   /* リアリティ群点火2026-07-18＝都市pop1あたり住居必要量（家賃＝家計固定費）。HousingUrbanThreshold超で立つ */      // 都市pop1単位あたりの住居の必要量。0=家賃が家計に乗らない（現行恒等）。goods.json再生成(dumpgoods)で住居財追加が前提・未追加ならHousingId<ngガードで安全に不発
    public double HousingUrbanThreshold = 0.25;  // ★点火2026-08-31＝0.45→0.25（AI審査2-7＝45%は前工業都市化上限0.20+追従では算術的に到達不能＝家賃と過密が全国・全期間で不在だった。⚠なお閾値のオン形は残る＝連続化は別途）   // 住居需要が立つ都市率の下限ゲート（低都市率の合成較正AgrarianToUrbanで不発）
    public double HousingMigrationFriction = 0.5; /* B6点火2026-07-19＝鉄筋コンクリート（住居の晩期レシピ）とセット：過密都市は流入が鈍り、鉄筋コンクリが収容力を解放する */ // 移民引力に住居充足(HousingFill)を負の摩擦として乗じる強さ。0で無上限吸引（旧）
    public double SoapSanitationWeight = 0.3;     // 石鹸消費が衛生に与える上乗せ（衛生＝Clamp(InfraFill + これ×SoapFill, 0,1)）。上下水道(InfraFill)の部分代替＝清潔で疫病↓。医療品ほどではない（控えめ）
    // 上下水道（#4 施設化）：衛生＝上下水道財の充足率（旧「工業化proxy」を実財に置換）。都市人口に比例した必要量を国家が行政費で調達。
    public double InfraNeedPerUrban = 0.04;       // 都市人口1あたりの上下水道の必要量（衛生インフラ）。満たすほど疫病圧が下がる
    public double InfraBudgetScale = 0.15;        // 上下水道＝歳入シェア（行政費スライダー×これ×歳入×人口比）。funding修正で税収フロー基準。0.3はセメント/鋼を奪い私的工業化をクラウドアウト→0.15
    // 上位インフラ（電化インフラ＝近代都市インフラ）：上下水道と同型の国家調達。電灯/ガス灯式の並存レシピ。便益＝満足度＋衛生追加＋送電容量↑
    public double ElecInfraNeedPerUrban = 0.03;   // 都市人口1あたりの電化インフラの必要量（上下水道より少なめ＝上位財）
    public double ElecInfraBudgetScale = 0.15;    // 電化インフラ＝歳入シェア（上下水道より控えめ＝先進国の余力で電化）。funding修正で税収フロー基準。電化製品/送電網が高い序盤は買えず自然に終盤の能力
    public double ElecInfraSanitationWeight = 0.2; // 電化インフラ充足が衛生に与える上乗せ（電動ポンプ/上水処理＝上下水道に次ぐ）。衛生＝Clamp(InfraFill + 石鹸×SoapW + ElecInfra×これ)
    // ★物理削除2026-08-21【墓標・再点火禁止】：ElecInfraSatBonus（旧0.08→8/19に0）＝満足度への直接加算（読み手＝EconomyStep の1行ごと削除）。
    //   作者裁定2026-08-19「満足度という値を捨ててください。純粋に『生活水準』でよい」＝電気インフラ財は既に買われ NeedMet に入っており**二重計上**。しかも「上がれば無条件に上がり下がらない」＝慣れが無い（作者指摘）。
    public double ElecInfraGridBoost = 0.5;       // 電化インフラ充足が送電容量(GridCapacity)を底上げする割合（夜間操業の工場電化を後押し＝既存の電化ブーストを増幅）
    public double ChildLaborLiteracyPenalty = 0.6; // 児童労働を禁止すると識字成長 ×(1＋これ)（子供が工場でなく学校へ）＝出力と教育のトレードオフ。0.35→0.6＝働く児童は学校へ行けず教育が明確に犠牲（教育悪影響を体感できる強さ）

    // --- POP動詞3種（2026-07-19ユーザー裁定・設計doc「POP動詞設計」）。全て中立恒等＝動詞を使わない限り不走行 ---
    // ①階級への優遇と弾圧（World.ClassStance＝中立0/優遇1/弾圧2）
    // POP動詞①（階級優遇/弾圧）の係数5本（ClassFavorCostPerPop/ClassFavorVoiceRelief/ClassRepressCostPerPop/ClassRepressDamp/ClassRepressGrievanceRate）は
    // 2026-07-20の機構廃止後も恒等読みで残置されていたが、第3段3-1（2026-07-27）で読み手ごと完全削除。
    // 国内危機イベント（2026-07-20・戦争ポップアップ#106と同型）：組織運動が蜂起寸前になると「要求受諾／武力で対処」の2択（Politics.CheckFactionRevolt→ResolveFactionCrisis）。武力鎮圧に常設ボタンはなくこのイベントが唯一の入口。
    // 鎮圧は闘争度に触れず、その回の蜂起を打ち消して余剰戦力を消費するだけ＝経済・政治の便益経路に漏れない＝非決定的（連発は余剰戦力上限で律速）。AIも同じ択を自動で選ぶ（非議会系＋余剰戦力→鎮圧・体制内要求→受諾・止められない革命→蜂起）。
    public double SuppressFactionWillCost = 2.0;       // 1回の鎮圧で消費する余剰戦力（上限ExpansionWillCap=10＝満タンで約5回）＝連続鎮圧の律速。⚠FactionSuppressionOmit>0（既定）では不読
    public double SuppressFactionLegitCost = 0.04;     // 第4段4-7点火（2026-07-27）：鎮圧の政治的代償＝正統性−これ×(0.5+ハト派シェア)。旧・余剰戦力のみでは実質無料の支配戦略だった。AI/プレイヤー対称。0で旧恒等。⚠FactionSuppressionOmit>0（既定）では不読
    // ⚠撤去2026-08-12（機構は2026-07-27に削除済み（World.cs:423））: TrainingCostPerConvert  転換1人口あたりコスト（国庫→教師pop＝訓練の担い手）
    // ⚠撤去2026-08-12（機構は2026-07-27に削除済み（World.cs:423））: ScholarshipCostPerConvert  同コスト（国庫→教師pop）
    public double ConscriptGrievanceRate = 0.05;      // 戦時の強制徴兵（徴兵制/総動員）で徴兵された階級の闘争度加算×徴兵率＝E5徴兵法の一般効果（志願制でも**総動員中は発火**＝wartimeConscript。平時・非動員の志願募兵のみ不発＝番人テストあり）。供給源の選別=POP動詞③は2026-07-21撤去済み・この遺恨のみ残置（清の内戦/対外戦の不満が抜けると覇権化するため対称機構として維持）

    // --- 軍需調達（国家が軍需財を消費＝死蔵解消。財源は国庫→生産者で保存。戦時増＝武器需要ブーム）---
    public int[] MilitaryGoods = [82, 83, 81, 86, 85, Catalog.HorseId, 132];   // 02断線走査（2026-07-28）：裸の127をHorseIdへ＋自動車132を輜重へ（馬と併存＝WWIも馬匹依存だが自動車が食い込む。DemandOnset1.50到達後の晩期のみ実需）        // 小銃・弾薬・火砲・軍艦・汽船・馬・自動車
    public double[] MilitaryRates = [1.0, 0.8, 0.4, 0.15, 0.2, 0.1, 0.02]; // 各軍需財の消費比率。馬=0.1（初期0.25は畜産＝食料源と競合しNYの産出財が18まで痩せた＝多国200Qテストで実測・戦時9倍の馬匹徴発は自動で付く）。自動車=0.02（輜重の機械化＝小さく併存）
    // ★★①基本段の耐久品ストック（2026-08-26・記録 docs/202608/20260826_軍縮と理想の軍隊_部分完了.md §7）
    //   ⚠発見＝装備充足 MilitaryEquipFill は「その月に首都市場で買えた比率」というフローで、在庫の概念が無い。
    //     即応度に平滑も床も無いので（Military.cs:216）**1ヶ月の調達失敗が全軍を消す**（実測＝1850年断面の英が
    //     海0.01/陸0.01、1914年断面の米が海0.00/陸0.00）。Military が0へ潰れると生存効用の脅威比
    //     maxReach / Math.Max(1e-9, Military) が天文学的な値へ飛び（実測 1.4×10¹⁰）、clamp の上限に恒久的に張り付いて
    //     **全61カ国が131年間 Militarize から降りられない**＝軍縮エピソード0件の根。
    //   ★機構は新設しない＝上位段と tier3 が既に持つ耐久品ストック（ArmsStockEnabled）を、取り残されていた
    //     基本段の**耐久品だけ**へ広げる。消耗品（弾薬・馬）はフローのまま1ビットも変えない。
    //   ★★**発注も見積も1ビットも変えない**（2026-08-26 の設計是正）。変えるのは**充足の測り方だけ**＝
    //     納入を在庫へ積み、充足を「在庫÷目標」で測る。定常では従来の充足と厳密に同じ値へ収束し、違いは時定数だけ。
    //   ⚠⚠ 旧設計（不足分を発注見積にする）は差し戻した：在庫が目標を割ると estCost が34倍に膨らんで afford を潰し、
    //     **同じ afford を共有する消耗品（弾薬）まで巻き添えで34分の1に絞られる**。装備↓→不足↑→afford↓→装備↓の
    //     正のフィードバックで小国が崩壊した（実測 seed5 ハノーファー：産出8300→400・損失financing 115%＝硬性ゲート赤）。
    //   ⚠0＝以下の配列を1度も読まない＝**厳密恒等**（差し戻しはこの1本を0にするだけ）。
    //   ★★点火2026-08-26。決め手は「基線の充足率が**測定として壊れていた**」ことの実測：
    //     イギリスの装備充足（seed1・単月）は 0.196→1.000→0.002→0.947→1.000→0.028→0.000→0.000→0.000→0.593 と毎月跳ね、
    //     軍事力ゲージは 0.011 と 4.741 の間を振動していた（1903/1905/1907年は3回続けて厳密に0）。
    //     在庫版は同区間で 0.19〜0.53 に安定し、小銃在庫は目標の約20%＝**イギリスの軍需調達は慢性的に必要量の2割**という
    //     一貫した読みを与える。旧の「1914年に1.35」は振動系列のたまたま高い1標本にすぎなかった。
    //     ⇒ 全61カ国の Military が毎月コイン投げで0近傍へ落ちていたことが、生存効用の脅威比が1.4×10¹⁰へ飛んだ直接の原因でもある。
    //   ★点火時の実測（selfplay-batch 30）＝**硬性ゲート全緑**（破綻0/デッドロック0/異常0/ハーネス0/要注意0）・テスト405緑。
    //     帯は 政体exact 49.9→47.9・法 59.6→60.4・人口 23.5→15.4・列強再現 20.8→19.6・経済 33.8→35.0・本国 85.0→83.3・植民地 43.9→44.2。
    //     ⚠帯の増減は**ノイズを信号へ置き換えた結果**であり、差し戻さない（方針：破綻しない＞正しい挙動＞バランス）。
    //   ⚠**これは軍縮を創発させない**（軍縮エピソードは0件のまま）。①は「1ヶ月の事故」を消しただけで、
    //     「何年も買えない国」は消していない（アメリカの軍事力0が残る＝軍需産業の不在と貿易の消滅が原因）。次の根はそちら。
    public double BaseArmsStockEnabled = 1.0;
    // 月次摩耗率（MilitaryGoods と同じ並び＝小銃・弾薬・火砲・軍艦・汽船・馬・自動車）。
    // ★1.0＝消耗品＝従来のフロー経路。1未満＝耐久品＝在庫を持つ（上位段の ArmsWearRate と同じ0.02）。
    // ⚠**新しい分類表を作らない**＝「耐久か消耗か」は摩耗の速さという物理そのもので表す（1.0で従来経路に退化する）。
    public double[] MilitaryWearRates = [0.02, 1.0, 0.02, 0.02, 0.02, 1.0, 0.02];
    public double MilitaryUpkeepScale = 0.18;                 // 軍隊+圧政1あたりの平時軍需消費スケール（0.12→0.18＝戦争が減っても常備軍の調達で火薬/鉛/帆船の連鎖を維持＝死蔵防止）
    // ★初期軍需の整合（2026-08-22・作者報告「初期軍隊と実際の生産が噛み合ってない（火器0%・軍艦1083%）＝初期値を調整」）。
    //   詳細と実測は docs/202608/20260822_初期軍需の整合_部分完了.md。播種の対象財は Simulation.InitialArmsIndustryGoods。
    //   ⚠**どちらも 0 で「触らない」＝旧初期値と厳密恒等**（＝合成後アブレーションの腕をソース編集なしで測るための対）。
    // ⚠**0＝休眠（2026-08-22の実測で棄却）**。1.0 なら1783年の軍需連鎖（工廠・火薬廠・造船所）を職人工房と同じ操業規模で始める形。
    //   棄却の理由＝**目的変数に貢献しない**（milstart long・全61カ国の分布）：作者が報告した Q1 断面で
    //   小銃fill 中央値 備蓄のみ5.0 / 両方6.0・fill<5%の国 27 vs 28＝**ほぼ同じ**、
    //   **小銃の国内生産量は両腕とも中央値0.0・生産~0の国 46 vs 44＝同一**
    //   （＝Scale を上げても demand が価格ゲートで閉じているので prodW=需要×Scale が立たず**生産は始まらない**＝律速は capacity でなく demand）。
    //   一方で帯は4次元とも悪化させる（列強 +2.0→±0.0・人口 −4.3→−10.6・領土本国 −0.8→−5.0・政体exact +2.1→+2.0）。
    //   ＝「fill を改善しないのに帯だけ動かす因子は落として単純化」（例外のつぎ足し禁止）。
    //   ★機構は残置＝再点火が意味を持つのは**需要側（StateProcurePriceGate の崖）を直した後**。
    public double InitialArmsIndustryScale = 0.0;
    // ★採用（2026-08-22）。首都市場に置く軍需最終財の初期在庫＝平時消費（MilitaryUpkeepScale×初期兵×レート）の月数。0＝休眠（旧＝全財一律200＝清の小銃で6日分）。
    //   効く経路＝**在庫→価格が参照帯に留まる→StateProcurePriceGate が開く→国家が実際に買う**（ration は元から1.0・生産は0.0＝どちらも経路ではない）。
    public double InitialArsenalMonths = 12.0;
    public double MilitaryWarMult = 9.0;                      // 交戦中の軍需消費の倍率（武器需要ブーム）。元3.0の3倍＝9.0（5倍は軍が溶けすぎたため3倍に決定）
    public double WarMobilizationDepth = 0.5;                 // 戦時動員の段階性（wartime-economy-field-dead）：対外戦の軍需倍率＝MilitaryWarMult×(1+これ×WarExhaustion)。長期戦ほど総動員(WWI型)。0で旧の固定倍率（恒等）
    // 監査2026-07-12 死19：MilitaryBudgetFrac（国庫比の軍需上限）は歳入フロー基準（MilitaryRevenueShare）への置換後の残骸＝参照ゼロにつき削除。軍需上限を調整する係数は MilitaryRevenueShare
    // 上位軍需（機関銃・装甲艦）：基本装備を整えた残余予算で調達＝戦力の質的乗数。富裕/軍国国ほど届く（高価だが強い）。値は暫定でsweep対象
    public int[] MilitaryQualityGoods = [104, 105];          // 機関銃・装甲艦
    public double[] MilitaryQualityRates = [0.5, 0.1];       // 各上位軍需の消費比率（基本より少量＝高価な少数精鋭）
    public double MilitaryQualityBonus = 0.6;                // 上位軍需を満たした時の Power.Military 乗数の最大上乗せ（+60%）
    // --- 軍需輸出の法（禁制品doc C5・2026-07-30）：「許可／禁止」の1本の法＋緊張の閾値で、売らない相手を**法が選ぶ**（50カ国の手動管理を作らない）---
    public int[] MilitaryExportGoods = [82, 83, 81, 86];      // 輸出禁止の客体＝小銃・弾薬・火砲・軍艦。★MilitaryGoods 全部にはしない＝汽船(85)・馬(127)・自動車(132)は民生用途が主（doc未決4bをこの形で決着）
    public double MilitaryExportTensionThreshold = 60.0;      // この緊張以上の相手へは軍需財を輸出しない（尺度0..200・ライバル40とポップアップ100の間）。実分布を見て調整する
    public double MilitaryExportPrefScale = 10.0;             // 軍需財の生産額シェア→資本（近代エリート）の反対強度（シェア0.1で−1.0＝他軸と同水準）。武器商人が禁止に反対する唯一の回路
    public double MilitaryExportAccessFloor = 0.1;            // 禁止しても残る輸出口（Diplomacy.TradeAccess と同じ床＝全遮断はしない＝密輸・第三国再輸出の抽象）
    // --- 密輸の一般機構（禁制品doc C2・2026-07-30）：障壁（禁令）× 取り締まる力（行政充足率）。価格差は呼び出し側の式に既にある（Contraband.cs 参照）---
    // --- 戦時備蓄（07_再設計 §5(a)＝B3自己成就期待の第1形・A5裁定・2026-07-31）---
    // 「戦争の匂いでパンが高くなる」＝緊張が閾値を超えた国は在庫目標を引き上げ、需要スパイクが価格を押し上げ、隣国も備蓄する（緊張は相互＝自己成就）。
    // 在庫が満ちれば需要は消える＝自己有界。既存 TargetStock 機構に乗るだけで新しいストックを作らない。
    public double StockpilePanicWeight = 0.5;                 // 満点の恐慌時に在庫目標を何割増しにするか（主食・軍需＝満額）
    public double StockpileTensionThreshold = 40.0;           // 備蓄が始まる緊張（黒船と同水準）
    public double StockpileTensionSpan = 60.0;                // 満点に達するまでの幅（40→100＝開戦ポップアップ水準で満点）
    public double StockpileOtherFrac = 0.33;                  // A5裁定＝主食/軍需以外も「控えめに」＝優先財の1/3
    public double SmugglingMax = 0.5;                         // 行政が完全に無力(AdminFill=0)なとき禁令をすり抜ける割合。0.5＝消費税の徴収漏れ（0.5+0.5×AdminFill）と同型。0で漏れゼロ＝旧「禁令＝完全遮断」
    // --- 阿片の法（禁制品doc C3・2026-07-30）：旧 bool の行政禁令 OpiumBan を議会を通る法2本へ。賛否は保有から創発させる ---
    public double OpiumBanPrefScale = 4.0;                    // 全国中毒度→大衆の禁令要求の上乗せ（中毒0.2で+0.8＝他軸と同水準の強い要求）。害が広まってから禁令圧が立つ＝清の1729/1796/1800が条件から創発
    public double OpiumTradePrefScale = 10.0;                 // 阿片の生産額シェア→売る側の資本の反対強度（軍需輸出と同スケール）。産地を持たない国では0＝反対が立たない
    // --- プランテーション（プランテーションdoc D6・2026-07-30）：地代取り分を州別・財別へ ---
    public double PlantationRentShare = 0.6;                  // 賦存財のRGO（＝その州の輸出向け一次産品＝大農園/鉱山）の地代取り分の下限。所有も地主階級へ。0で旧＝国家スカラー max(0.3, farmLordShare) のまま＝厳密恒等
    // #16 tier3 軍需（戦車・弩級戦艦）：tier2(quality)を圧倒する最上位の質的乗数。基本＋上位を整えた更なる残余予算で調達＝深い連鎖の高コストで富裕/軍国/晩期のみ届く（外科ゲートなし＝連鎖深とコストで自然律速）。
    public int[] MilitaryTier3Goods = [122, 123];            // 戦車（陸tier3）・弩級戦艦（海tier3）
    public double[] MilitaryTier3Rates = [0.04, 0.015];      // 各tier3の消費比率（上位より更に少量＝極少数の決戦兵器）
    public double MilitaryTier3Bonus = 1.2;                  // tier3を満たした時の Power.Military 乗数の最大上乗せ（+120%＝tier2の+60%を圧倒）
    // --- 1934拡張E2（2026-07-19）：空軍装備＝tier3の更なる残余予算で調達する第4tier。財の解禁(onset1.0=1910s)前は生産ゼロ→Fill0＝空の概念ごと不走行＝厳密恒等 ---
    public int[] MilitaryAirGoods = [130, 131, 133];         // 飛行機（偵察/輸送）・戦闘機・化学兵器
    public double[] MilitaryAirRates = [0.03, 0.02, 0.02];   // 各空軍財の消費比率（tier3級の少量＝最晩期の高価な装備）
    public double AirControlPushWeight = 0.3;                // 制空の押し合い補正＝aPush×(1−これ/2＋これ×AirControl)。制空満点で+15%・劣勢で−15%（偵察・着弾観測）
    public double AirCasualtyWeight = 0.3;                   // 制空劣勢側の戦死増幅＝cas×(1＋これ×(2×(1−AirControl)−1)クランプ正)。優勢側は増えない
    public double WarExhaustionAirRaid = 0.03;               // 空襲の厭戦（封鎖と同型）＝これ×(1−AirControl)×敵AirPower実在ゲート。都市爆撃1917〜
    public double ChemExhaustionWeight = 0.04;               // 化学兵器の泥沼＝相互保有 min(自Fill,敵Fill)×これ を双方の厭戦へ（イーペルの相互報復）

    // --- B-1 海軍力・制海権・距離（§B 軍事リアリティ）。海軍は新スライダーを足さず Power.Military（陸海合算）から地理で創発分離 ---
    // ★陸海の維持費と熟練度（2026-08-04・作者仕様(5)）
    public double NavalShareFromUpkeep = 1.0;      // 1で海軍シェア＝払った金の比（作者仕様「割り振りは廃止」）。0で旧＝地理から創発（厳密恒等）
    public double SkillUpkeepThreshold = 0.5;      // 平時にこの維持費を超えると熟練度が育ち、下回ると錆びる（作者仕様「50%以上で増加、以下で減衰」）
    public double SkillGainRate = 0.02;            // 熟練度の四半期あたり獲得率（閾値超過分×これ）
    public double SkillWarGain = 0.05;             // 戦争中（内戦含む）の四半期あたり獲得率＝実戦は訓練に勝る
    public double SkillDecayPerQuarter = 0.0115;   // 平時に閾値を下回るときの減衰率／四半期。約2世代（60年=240四半期）でほぼ完全に失われる（0.9885^240≈0.06）
    public double SkillCombatMax = 0.5;            // ★熟練度1.0での戦力倍率の上乗せ＝**最大1.5倍**（2026-08-04・作者の問い「最大2倍は史実的に適切か」への判断）。
                                                  //   ── なぜ2倍でなく1.5倍か ──────────────────────────────────────────
                                                  //   ①**訓練・経験だけ**の効果を定量化した研究はデュピュイの戦闘効率指数が最も引用されるが、
                                                  //     独軍の対英米が1.2〜1.5倍・対ソ連の緒戦でようやく2倍前後で、しかも後者は**装備と教義**を含む。
                                                  //     兵数と装備を揃えた上での練度だけの差は1.3〜1.5倍が実証の中心。
                                                  //   ②このエンジンには**技術による軍質の倍率が既にある**（TechMilLowFloor 0.4→1.0＝2.5倍の幅）。
                                                  //     そこへ練度で2倍を重ねると合計5倍の幅になり、**同じ「精鋭軍」を二重に数える**ことになる。
                                                  //     オムドゥルマンやアヘン戦争の一方的な結果は練度でなく技術の差であり、既に技術側が担っている。
                                                  //   ③作者指示は「最大でも2倍程度に留める」＝**上限の指定**なので、1.5倍はその範囲内。
                                                  //   ⚠0で乗算恒等（休眠）。
    public double SkillMobilizationRelief = 0.5;   // 熟練度1.0で総動員のペナルティがこの割合だけ軽くなる
    public double WartimeUpkeepFloor = 0.8;        // 戦時の維持費の下限＝現在値のこの割合を下回れない（戦争中に軍を解散できない）。0で下限なし＝厳密恒等
    public double SkillTensionWeight = 0.5;        // 熟練度が生む緊張＝軍隊規模に**乗算**する形（作者指示）。0で恒等
    public double NavalShareBase = 0.10;          // 海軍シェアの基礎（Military のうち海軍が占める割合。陸軍力=Military×(1−NavalShare)）
    public double NavalShareOceanBonus = 0.10;    // 外洋海盆（大西洋・太平洋）に開く国の海軍シェア加点（内陸寄りは低い）
    public double NavalShareColonyWeight = 0.05;  // 海外植民地1つあたりの海軍シェア加点（帝国は海軍を要する＝英が高く露/普が低い。植民地数が主信号）
    public double NavalShareMin = 0.05;           // 海軍シェア下限
    public double NavalShareMax = 0.60;           // 海軍シェア上限（陸軍を完全には捨てない）
    // ★旧 NavalEmphasisWeight（海軍シェアへの政策傾斜＝これ×(NavalEmphasis−0.5)）は撤去（2026-08-10 作者裁定
    //   「陸軍と海軍の注力レバーは廃止し、海軍維持費と陸軍維持費で表現する」）＝海軍シェアの入力は**払った金の比だけ**（NavalShareFromUpkeep=1）。
    //   上の地理式は AI が維持費をどう割るかの指針にだけ残る＝政策スタンスは1つも読まない（GeoNavalShare の引数に World が無い＝構造的に読めない）。
    public double NavalBuildRate = 0.3;           // **点火2026-07-31（07_再設計 第3弾3a）**：海軍シェアの目標値への月次EMA収束率。1.0=即時(旧挙動)。0.3＝建艦の時間遅れ（90%到達に約7ヶ月）＝軍拡競争の蓄積とティルピッツ計画型の追い上げが出る
    // 艦隊摩耗＋修理需要（07_再設計 §6-1・A6裁定・2026-07-31点火）：交戦中に敵と接触した艦隊が沈み、建艦でしか戻らない＝トラファルガー後の制海権固定。
    public double NavalAttritionRate = 0.05;      // 月次の摩耗率＝これ×(自分の展開海盆での敵支配度)×現NavalShare。NavalShareMin が床
    public double NavalRepairPerLoss = 1.0;       // 沈没ぶんを軍艦財の追加需要へ変換する係数（A6案i＝スクラップ戻しでなく修理需要。財を無から生まない）
    // ★★艦隊ストック（2026-08-01・作者裁定「陸軍は兵士ありき、海軍は戦艦ありき。海軍の強さが海兵の数から決まるのはナンセンス」）。
    // ⚠実測（1914断面・上陸ゲート点火後）の海軍力順位＝1位 福州王国／2位 長沙王国／3位 清／…／**イギリスは8位圏外**。
    //   原因＝NavalPower = Military × NavalShare で Military が兵数駆動＝**人口の多い国が艦を1隻も持たずに海軍大国になる**。
    // ★機構＝購入した戦闘艦を積み、耐久財の劣化率（Catalog.SpoilageOf＝月0.5%）で減らす。**重みは RefPrice（建造費）**＝
    //   弩級戦艦とスループの差は既にデータにあるので、**新しい定数を1本も置かない**。
    // 段A（現在）＝読み手ゼロ＝挙動は1ビットも変わらない（計器だけ）。段B＝FleetPowerWeight>0 で NavalPower をここから立てる。
    // ★★★理想の軍隊の形（2026-08-01・段0＝全計算を休眠で実装・読み手ゼロ）。設計書＝docs/202607/20260801_理想の軍隊の形_部分完了.md【一部】.md
    // ⚠段0では ArmyShapeEnabled=1 でも**力学は1ビットも変わらない**（Power の診断フィールドに書くだけ）。段1のプローブで分布を見てから接続する。
    public double ArmyShapeEnabled = 1.0;   // ⚠コメント是正2026-08-08：**1.0がlive前提**＝NavalProcurementFromShape=1.0（軍需の陸海再配分）が ShapeNavalShare を読む＝0へ戻すと軍需陸海比が変わる（非恒等）。旧注記「既定0を厳守」は読み手ゼロ時代の陳腐化＝コメント側の消し忘れと確定（設計審査wf_e6c0be63）
    public double AttentionHostilityFloor = 0.15;  // 平時（緊張0）でも残る敵意＝「無政府状態では武力は武力」。⚠段1の分布を見て較正する
    public double AttentionTensionHalf = 40.0;     // 敵意が半分に達する緊張。★**既存の RivalTensionThreshold(40)＝「これ超＝ライバル」と同値**＝新しい水準を発明しない
    public double AllyAttentionDiscount = 0.7;     // 同盟・従属への注意の割引（3割しか向けない）＝日英同盟型の軍拡緩和。⚠較正で決める
    public double InternalGarrisonPerPop = 0.002;  // 不穏度1.0のとき国内秩序に要する兵÷人口。★清の八旗・緑営は約80万／人口3.8億＝約0.2%（1783〜1850の常備の内地守備）
    public double SeaEscortPerTradeValue = 0.0;    // 守るべき海上価値1あたりの護衛艦隊（ゲージ）。⚠**この1本が「英の海軍が世界最大になるか」を決める唯一の較正点**＝段1の分布で同定する
    public double NavalCrewPerGauge = 0.5;         // 同じ戦力ゲージあたりの乗員（海軍は資本集約・陸軍は労働集約）＝英の常備陸軍が人口比で小さいことの本質。⚠較正で決める
    public int[] FleetGoodIds = [86, 105, 123];   // 軍艦・装甲艦・弩級戦艦（＝戦闘艦。汽船85/帆船84は輸送・補助なので艦隊に数えない）
    // ★★段2（2026-08-01）：軍需の**内訳**を理想の軍隊の形の陸海比で再配分する。
    // ⚠現行は MilitaryRates が全国一律＝**海に出られるかを問わず全員が軍艦0.15・汽船0.2 を買う**＝
    //   実測（1914断面）で艦隊ストック4位ネパール・8位アワド（どちらも内陸国）という不条理になっていた。
    // ★形＝**総額を保存したまま比だけ動かす**（新しい水準を発明しない）：
    //     海の係数 ×= 理想の海シェア ÷ 一律レートが含意する海シェア
    //     陸の係数 ×= 理想の陸シェア ÷ 同上
    //   ⇒ 内陸国（理想の海シェア≈0）は軍艦を買わなくなり、その分だけ陸へ回る。海洋国は逆。
    // 0 で再配分しない＝厳密恒等。1 で完全に理想の比へ。⚠ ArmyShapeEnabled>0 が前提（理想が算出されていないと -1 で不発）。
    public double NavalProcurementFromShape = 1.0;
    // ⚠撤去2026-08-12（段B未実装（読み手ゼロ））: FleetPowerWeight  段B のゲート：0=NavalPower は従来（Military×NavalShare）＝厳密恒等／>0 で艦隊ストックから立てる
    // ★軍艦は港でしか造れない（2026-08-01）。0＝旧（内陸州も軍艦を買う）／1＝港州のみ・総額は陸へ回して保存。
    // 実測の動機＝1914年の海軍力1位が**内陸の西安王国**、艦隊ストック2位が広州王国だった（docs/202608/99_実装ログ）。
    public double NavalProcurementNeedsPort = 1.0;
    // ★海軍力を艦隊から出す（作者裁定「海軍は戦艦ありき」）。0＝旧（兵数×海軍シェア）／1＝min(艦隊ゲージ, 乗員ゲージ)。
    // ★点火2026-08-01（裁定③の受入試験を実測してから）。海軍力＝min(艦隊ゲージ, 乗員ゲージ)。
    // ⚠**播種（Diplomacy）と導出分母（EconomyStep.FleetGaugeDenominator）が同じコミットに入っていること**が前提。
    //   播種が無いと Q0 で全世界の艦隊が0になり1783年の英海軍が消える（裁定③(i)）。
    // ★受入試験（裁定③(iii)＝min のどちらも張り付かない・目安30〜70%）の実測：
    //     Q4   艦隊が律速 68% / 乗員 32%   合格
    //     Q200 艦隊が律速 14% / 乗員 86%   ★未達（艦隊が余る時代）
    //     Q350 艦隊が律速 33% / 乗員 67%   合格
    //     Q524 艦隊が律速 38% / 乗員 62%   合格
    //   ⚠Q200（1833年前後）だけ艦隊側がほぼ律速しない。★ただしこれは欠陥とは限らない——ナポレオン戦争後の海軍は
    //     船体より水兵が足りず、艦を予備役（ships in ordinary）で係船していた。乗員律速はその姿である。
    //   ★4断面中3断面が帯に入る。**この1点の受入はユーザー裁定に属する**（撤回は本行を 0.0 に戻すだけ）。
    // ★★差し戻し2026-08-01（終了コード1＝硬性ゲートが赤）。**受入試験と硬性ゲートの両方で不合格**。
    //   実測（SOURCE-HASH 0ef71ca88fc48d3f・seeds1-10）＝**ハーネス不合格 2/10**（満足度・最小国 seed3=0.22・seed9=0.30／目標0.38）。
    //   3値終了コードの規約「rc==1 で止める」に従い 0.0 へ戻す。⚠帯の悪化ではなく**硬性ゲートの赤**なので、
    //   「帯が悪化しただけでは差し戻さない」の例外にはあたらない＝差し戻しが正しい。
    //   受入試験(iii)も Q200 が 14%（目標30〜70%）で既に3/4だった＝2つの独立した理由で不合格。
    // ★次に試すときの筋（記録）：最小国の満足度が落ちるのは、艦隊ゲージが乗員より小さい国で NavalPower が下がり、
    //   制海権→交易→物資という連鎖で小国の消費が細るためと見られる。**海軍が弱くなること自体は正しい挙動**なので、
    //   直すべきは「海軍力が下がると小国の生活水準が壊れる」という経路の急峻さの側である（別ラウンド）。
    public double NavalPowerFromFleet = 1.0;   // ★点火2026-08-02（作者裁定2026-08-01「陸軍は兵士ありき、海軍は戦艦ありき。海軍の強さが海兵の数から決まるのはナンセンス」の実装＝段B）。実測1914の海軍力が1位ハイデラバード（内陸）・2位清・6位英と逆立ちし、講和奪取・上陸・封鎖の海の物理を全部汚していた。min(艦隊, 乗員)＝船を持たない国の海軍は0。播種済み（点火の瞬間は国別ビット恒等）。0で旧式（兵数駆動）
    // ⚠★係数 FleetStockPerNavalGauge は**撤去した**（2026-08-01・裁定③の但し書き）。定数Kは時代で×7.74漂い
    //   （Q200 228029／Q350 54429／Q524 29452）、2倍の許容を大きく超えた。換算分母は現行の調達式から導出する
    //   ＝EconomyStep.FleetGaugeDenominator（SoldiersPerMilitary × MilitaryUpkeepScale × Σ(rate×RefPrice) ÷ Spoilage）。
    public int WarshipGoodId = 86;                // 軍艦（修理需要の宛先）
    public double AbstractNavalShare = 0.10;      // 抽象標的（被植民地勢力）の海軍シェア＝弱小（陸の守りが主）
    public double DistanceWarDecay = 1.0;         // 戦力投射の距離減衰（1あたり1万km）。遠い戦線ほど押し合いが鈍る＝クリミア/ボーア型の兵站難
    // 倍率排除：旧 SuezDetourKm（投射の一律ケープ迂回加算）は撤去。投射距離も Geo.SeaDistanceKm が喜望峰/スエズ/パナマ経由で表現する。
    public double HomeDefenseBonus = 1.25;        // 本土防衛の地の利（抽象標的＝自領で戦う側は投射せず守りに専念）
    public double InvadeSeaControlMin = 0.45;     // 海越え侵略に要る最低制海権（弱海軍の内陸国は海外植民地を取れない＝英の海上覇権が意味を持つ）
    public double LandReachKm = 4000;             // 旧・陸続き判定（同一海盆かつこの距離内）。ContinentalLandReach=0のフォールバック時のみ読む
    public double ContinentalLandReach = 1.0;     // 第4段4-4点火（2026-07-27）→03地理 手順0（2026-07-28）：陸続き＝**陸塊一致**（Landmass.Of＝landmass.json・距離制限なし）。旧・矩形大陸一致は島の概念が無く85.6%の国対が陸続きだった。0=最旧の海盆×LandReachKm判定へ戻す
    public double ColonyUpkeepMilitancyScale = 0.2;  // 植民地維持費の不満項（人口ウェイト×不満×基礎維持費×これ）。高不満の大植民地ほど駐留が高くつく＝インド大反乱型（満額で維持費≒2〜3倍）
    // B-4 移民プッシュ・独立ショック
    public double PushUnrestWeight = 0.5;            // 移民のプッシュ要因：地域の不満（迫害・治安悪化）が土地機会を下げ流出を促す（ポグロム型）。単一地域較正は移民非走行で無影響
    public int IndependenceShockYears = 6;           // 独立植民地の供給がショックから回復するまでの年数（ハイチ1804型＝独立直後は産出崩壊、数年かけて自由な供給者へ）

    // === 開始前の助走（作者裁定2026-08-10「助走をプレイヤーの世界と自己対戦バッチで統一し、延長する」）===
    // ⚠**唯一の入口は MultiNationSim.StartWarmup**（App も SelfPlayMatch もここを通る）。2箇所で別々に助走を組むと
    //   「遊ぶ世界」と「測る世界」の初期条件が再び乖離する（2026-08-10以前がまさにその状態＝App だけ4四半期の助走を通っていた）。
    // 助走は**暦を進めない**（World.WarmupFrozen）＝何四半期回しても開始は1783/Q1。1914断面(Q524)・604四半期・TechOnset の年ゲートは不動。
    public int StartWarmupQuarters = 20;        // 助走の長さ（四半期）。4＝1年（2026-08-10以前の App と同じ長さ）／20＝5年／40＝10年。0で助走なし。★帯はバッチで測って選ぶ
    public int StartWarmupTechIterations = 8;  // 技術の助走の反復回数（旧 GameViewModel のハードコード8）。識字×世俗水路の差を技術差へ実体化（暦も人口も動かさない）

    public const int GameQuarters = 604;                     // ゲーム全期間＝四半期数（1783→1934＝151年・1934拡張2026-07-19ユーザー裁定。「長い19世紀＋戦間期」。selfplay/プローブの正準の長さ）
    public const int FidelityQuarters = 524;                 // 史実忠実度の照合断面＝Q524（1914年12月）。裁定2026-07-19：物差しは1914固定・1914〜1934は自由歴史（参照表を作らない）
    public const int CalibQuarters = 524;                    // 較正セルの正準の長さ（1934延長後も524に凍結＝較正24-24-24の物差し不変）
    public double AdminCostPerPop = 0.03;                     // 行政コスト＝人口1あたりの維持費（広大な領土/人口の大国ほど財政が重い→funding ratio↓→政情不安）。維持費に加算
    public double HarvestVariation = 0.25;                    // 豊作/不作の振れ幅（毎年 1±これ で主食RGO産出と自給を変動。不作→食糧高騰→貧農の飢え→不満。決定論RNG）
    // === テーマB（飢饉・天候）＝点火済み（Skew0.3/ρ0.35/帯ρ0.35・2026-07-07/07-09）。0で旧IID恒等 ===
    public double HarvestSkew = 0.3;                          // 収穫分布の負歪み（symmetric-uniform-harvest）。0=対称一様（現行恒等）。>0 で平均1.0を保ち左裾を重くし10年に一度級の大凶作を稀に生成
    public double HarvestPersistence = 0.35;                   // 収穫の年次自己相関ρ（harvest-iid-no-persistence）。0=純IID（現行）。0.3〜0.5で連続凶作の累積（多年飢饉）。革新係数√(1−ρ²)の分散保存AR(1)
    public double WeatherBandPersistence = 0.35;              // 緯度帯天候の年次自己相関（多国シム限定）。0=旧IID。欧州一帯の多年冷夏。バランス2026-07-07有効化：唯一の乱数（不作）が多年・大陸規模の記憶を持ち、シードごとに勝敗を分ける実体ショックへ（目標2「不作が十分な影響」・単一国較正はWeatherBand非走行＝中立）
    public double BlockadeStapleBias = 0.5;                  // 海上封鎖の主食狙撃（blockade-no-famine-strangulation）∈[0,1]。0で全財一律（現行恒等＝兵糧攻め不成立）。>0 で封鎖severity(1-raid)をStapleの輸入閾値に厚く＝FoodFill低下→既存飢饉機構。交戦なし(raid=1)で不発
    public double FaminePushMaxFracBoost = 1.0;             /* 移民史実化2026-07-08有効化 */ // 飢饉時の移民上限緩和：(1-FoodFill)に比例してEmigrationMaxFracを引き上げ。欠乏30%で上限1.2→1.56%/年・50%で1.8%/年（2.0はハーネス27/30不合格＝過強と実測）。0で旧固定上限
    public double MineralDepletionChance = 0.03;              // 鉱物枯渇イベントの年次発生確率（国ごと）。0.06→0.03＝より稀に（恐慌が増えすぎたため）。発生で1地域の鉱物産出が激減
    public double MineralDepletionFloor = 0.2;                // 枯渇直後の鉱物産出倍率（激減＝平常の20%へ）
    public double MineralRecoveryRate = 0.3;                  // 枯渇からの年次回復速度（緩やか＝0.2から数年かけて1.0へ）
    // 鉱物の発見（枯渇の対・改修2026-06-28）：中盤以降ランダムに1地域の鉱物産出が急増（富鉱＝MineralDepletion>1）。地質ポテンシャル（既知鉱物地帯）で重み付け。
    public double MineralDiscoveryChance = 0.025;            // 鉱物発見イベントの年次発生確率（枯渇0.03の対）。Chance=0 で旧挙動＝較正中立
    public double MineralBonanzaCeil = 2.5;                  // 発見直後の鉱物産出倍率（富鉱＝平常の2.5倍）。MineralDepletion のクランプ上限も兼ねる
    public double MineralBonanzaDecay = 0.15;                // 発見ボーナスが平常(1.0)へ戻る年次減衰（枯渇回復0.3より遅い＝鉱脈は長く続くが有限）
    public int MineralDiscoveryStartYear = 1820;             // 発見が始まる年（地質探査の本格化＝中盤以降）
    // カリフォルニア・ゴールドラッシュ（1848・史実固定トリガ・改修2026-06-28）：西部州に金鉱出現＋移民殺到でアメリカを強化。Year=9999 で無効化＝中立スイッチ
    public int GoldRushYear = 1848;                          // 発火年（サッターズミル金発見）
    public string GoldRushFrontier = "西部";                 // 金鉱が出現する州名（辺境州・この州を持つ国のみ発火＝実質アメリカ）
    public double GoldRushEndowment = 5.0;                   // 出現する金鉱の富鉱倍率（黄金郷＝鉱物4.0を上回る）。MineralDepletion 経路で減衰・保存中立
    // === 兵士POP軍制（Part 2）：軍隊規模＝兵士POP数。軍事費が徴募し給与を払う。圧政（警察）とは別レバー。 ===
    // 兵士POP は IsSoldier フラグで識別（ClassId は貴族0/農民1/労働者2/ブルジョワ3/専門職4/兵士5）。
    public int SoldierRecruitClassA = 1;                     // 徴募/復員プールその1＝農民
    public int SoldierRecruitClassB = 2;                     // 徴募/復員プールその2＝都市労働者
    public double SoldiersPerMilitary = 250.0;              // 戦力ゲージ1.0 ＝ 兵士250単位（×1000人）。ゲージ＝兵士数÷これ×即応度
    // ★富で兵を養う（2026-07-31 裁定・案B）：均衡兵力 desired は **完全に人頭ベース**（軍事費×MaxSoldierFraction×(農民+労働者)）で、
    // 財政力・工業力・技術が一切入らない。結果、巨大な農民人口を持つ清が自動的に世界最大の軍になり、
    // 人口が小さく富裕なネーデルラント・イギリス・プロイセンは最小級になる（史実のプロイセンは人口比で最も軍事化した国）。
    // 実測＝world.json の初期軍÷均衡兵力の比は 蘭45.2 / 普22.5 / 英12.5 / 仏2.0 / 日1.2 / 清0.1（中央値7.2）＝
    // ほぼ全国が開幕直後に大量復員し、**world.json の military 値が数年で意味を失う**。
    // 是正＝人頭ベースと**財政ベース**の大きい方を採る。富裕な小国は少ない人口でも軍を養え、貧しい大国は人口で兵を出す。
    // ⚠旧・max形の係数名 SoldierFiscalWeight は下記の積形への差し替えで撤去済み（この1行にのみ痕跡が残っていた）。
    // ★実装は max(人頭, 財政) から**積の形**へ差し替えた（2026-07-31・作者提案「軍隊量は経済と人口で随時変更してはダメか」）。
    // max は常に片方を捨てるうえ総量が必ず増える（初回0.2603で世界の常備軍を+90%＝軍需調達の急増で経済系テスト3本が落ちた）。
    // 積なら**両方が同時に効き、純粋な再配分になる**＝軍需の総量が変わらないので経済を歪めない。
    // 形＝平時の均衡 = 軍事費 × MaxSoldierFraction × 人的資源 × (自国の1人当たりGDP ÷ **世界平均**)^α
    //   α=0 で現行の人頭のみ（厳密恒等）／α=1 で実質GDP比例（世界総量が保存）。
    // ★基準は固定定数でなく**世界平均**にする＝固定だと世界のGDP成長で全国の軍が際限なく膨張する。
    // ★人口が消える心配は無い＝**戦時の総動員は別経路**（Military.cs の wartimeConscript で ConscriptionFraction(0.12)×人的資源 が下限として効く）。
    //   平時＝財政が律速（英の小さな職業軍）／戦時＝人口が律速（露の大兵力・英1916年の徴兵制）＝史実の構造がそのまま出る。
    // ★単一国較正では Diplomacy==null で倍率1＝**較正中立**。
    // ★軍の恒常性（2026-07-31・作者提案「軍隊は最初から全力を出すのではなく、経済が耐えうる限り出し続ける」）。
    // ⚠これ以前の設計（人頭式・max形・積形）はいずれも**目標を式で決めて上限下限でクランプ**する形だった。
    //   クランプは折れ点を作る。実際 max 形の折れ点がハーネス不合格9/10を招き、その反省で作った積形にも
    //   MultMin/MultMax という新たな折れ点を2つ持ち込んでいた＝**リミットが要る時点で設計が誤っている**（作者指摘）。
    // 新形＝**目標を持たない**。装備と給与の支払能力（必要額に対して払えた比・無クランプ）を見て、
    //   余裕があれば増やし、足りなければ減らす。均衡は式で与えるのでなく**経済との釣り合いから創発する**。
    //   ・豊かな国は多く養える（財政が耐える）／貧しい国は自然に縮む＝国別の特例も倍率も要らない
    //   ・world.json の初期軍は「養える限り維持される」＝開幕直後の見えない大量復員（英1125→150）が消える
    //   ・人口は**戦時の総動員**（ConscriptionFraction×人的資源）が引き続き担う＝平時は財政・戦時は人口
    // ⚠⚠2026-07-31 の発見（S3b に着手する前に読むこと）：**S3a（MilitaryBudgetNeedCapped）と恒常性は、このままでは両立しない。**
    // 恒常性の信号 MilitaryAffordRaw ＝ MilitaryBudget / estCost だが、S3a は MilitaryBudget を min(歳入シェア上限, 必要額) にする。
    // 必要額 ≥ estCost なので **affordRaw ≤ 1 が恒真**になり、「余裕があれば増やす」側が構造的に発火しない＝軍は縮む方向にしか動けない。
    // ★直し方＝信号は**上限（歳入シェア側）**から取り、実支出だけを必要額で切る（2つの量を分けて持つ）。
    //   実装案：Region に「軍需予算の上限」を1つ足し、EconomyStep の affordRaw をそちらから計算する（S3a=0 では上限＝予算＝現行と厳密恒等）。
    // ⚠撤去2026-08-12（読み手ゼロ）: SoldierSustainDriven  【墓標2026-08-08＝積分器＋欠陥信号＋min凍結の三重機序で不合格・「形が先・金が後」（ArmyShapeMenWeight）が代替済み・再点火禁止】**消火2026-07-31（S1）**：0=従来の目標式（厳密恒等）／1=恒常性フィードバック
    // ⚠試行5として点火したが不合格（テスト179/180・ハーネス2/10）。しかも別調査で**信号そのものに欠陥**が判明＝
    // SoldierPayAffordRaw = SoldierPayBudget/(size×Price) で SoldierPayBudget = min(Treasury, size×civWage×SoldierPayMult) のため、
    // 国庫非拘束時は size が完全に約分で消え「民間賃金÷兵力価格」を測っている＝**支払能力を測っていない**。
    // Math.Min がこれを選ぶと desired が兵数を見なくなり制御が凍結する。使うなら分子を兵数非依存の量にする必要がある（S4）。
    // ⚠撤去2026-08-12（読み手ゼロ）: SoldierSustainTarget  支払能力がこれを超えていれば増やし、下回れば減らす（1.0＝ちょうど養えている）
    // ⚠撤去2026-08-12（読み手ゼロ）: SoldierSustainGain  乖離に対する増減の強さ（月次・SoldierMigrationRate と併せて律速）
    // ── 形が先・金が後（因果B「即応0」の本命設計・2026-08-08 敵対審査 原則88/崩壊74点＝wf_e6c0be63）──
    //   兵数の錨を「人口×スライダー」から NeedMen（理想の軍隊の形＝ArmyShape.cs・原因のみで構成）へ移し、
    //   軍事費は「形を養う請求書の支払い側」へ＝金は頭数でなく質（給与・装備→即応）を決める。
    //   清の「大軍・低即応」は首都単一市場の物理律速から自然に残る＝壊さない。分岐ガード（FiscalBufferSoldierPayWeight/WartimeBudgetFollowsNeedは点火済み・値は各行）。
    // ⚠撤去2026-08-12（読み手ゼロ）: ArmyShapeMenWeight  【墓標2026-08-08＝R2a(0.25)で棄却】NeedMenの脅威項が相手の現在兵数を読む＝兵数→脅威→理想兵数の外側ループが開き
    //   順位相関 ρ0.79→0.43 へ崩壊（仏NeedMen 207→800）。**扶養限界方式（ArmySustainWeight＝作者設計2026-08-08）が代替**＝
    //   錨を「ゆっくりしか動かない量」（人口・歳入）に置く。再点火禁止。
    // ⚠R1（SeaEscortPerTradeValue同定）は**保留**（2026-08-08 armyneed実測）＝海上価値の土台が 英110 vs オスマン776・日164 と
    //   歪んでおり（英経済がGDP13位に沈む経済規模問題の写像）、この土台への点火はオスマン海軍を世界最大にする＝経済規模の是正が先。
    //   ρ=0.79（海項なし）で R2 の blocking ゲートは通過済み。英の NeedMen 過小（84 vs 史実相当≈250-400）は k≤0.5 の
    //   部分ブレンドなら人口駆動側が支える＝k=1.0 への到達は海項の再設計とセット。
    // ⚠S4容量信号の分母は市場価格＝供給過剰国で床に張り付き発散（日本21228実測）＝R4で読む前に RefPrice 錨定へ直すこと。
    public double SpendFromNeedWeight = 0.0;       // 【棄却2026-08-08＝0.5で人口−7.1・列強−5.0（旧脅威応答棄却と同型＝物差しの軍事項が支出量を土台）】配線C：請求書駆動（錨=扶養限界目標・RefPrice建て）。物差し再較正とセットで再挑戦
    public double SpendFromNeedMin = 0.10;         // 請求書駆動目標のclamp下限（読み手は SpendFromNeedWeight>0 のみ＝既定で死蔵）
    public double SpendFromNeedMax = 0.85;         // 同・上限（スライダー[0,1]の物理＝ハーネスを壊した種類の折れ点ではない）
    public double SoldierPayRevenueShare = 0.25;   // S4容量信号の分子シェア＝「歳入フローが賃金請求書を担えるか」。段0-2は診断値のみ（旧SoldierPayAffordRawの約分欠陥を持たない）
    public double FiscalBufferSoldierPayWeight = 0.5;  // 【1.0は人口−10/列強−8.7/領土植−9.2＝衝撃過大→0.5測定中2026-08-08・作者裁定「安定するように」】兵士給与を**潤沢判定（OpulenceLineOf）にのみ**算入（緊縮反射FiscalBufferOfは不変＝旧全面算入の緊縮暴発を回避）
    public double WartimeBudgetFollowsNeed = 0.35; // 【1.0は硬性赤（各国独立経済テスト＝戦費が経済を焼き尽くす国）→0.35を測定中2026-08-08】課題5（戦時afford崩落）：戦時は装備必要額がMilitaryWarMult(9.0)倍になるのに
    // 予算milCapは平時のまま＝開戦で afford が9分の1へ崩落していた。1.0で予算も同じ戦時倍率へ追随＝**戦費の赤字財政**
    // （国庫が流出し、尽きれば StateBudgetCashScale の現金クランプが自然に止める＝戦時国債の物理・台本なし）。0=恒等
    // ⚠撤去2026-08-12（任意R5未実装（読み手ゼロ））: MilEquipTreasuryDraw  任意R5：装備予算への国庫超過分ドロー率/月（R2-R4後も afford<0.5 の退蔵国が残る場合のみ。不要なら恒久0）
    // ── 扶養限界方式（作者設計2026-08-08）：軍拡・建艦競争を**扶養限界の比較**で駆動する ──
    //   扶養限界 SustainLimit = min(経済側, 人口側)。経済側＝持続可能な軍事支出（歳入×シェア）÷兵1人あたりコスト
    //   （給与＋装備・**参照価格建て**＝市場価格の循環を避ける・S4欠陥の教訓）。人口側＝徴募可能人口×MaxSoldierFraction。
    //   目標兵数 = SustainLimit × clamp(近隣ライバルの最大SustainLimit ÷ 自国SustainLimit, 下率, 上率)。
    //   ★錨は人口・歳入＝ゆっくりしか動かない量なので「兵数→脅威→目標」の外側ループが**構造的に閉じている**
    //   （NeedMen錨定の失敗＝相手の現在兵数を読んだこと、の是正）。±20%の無理は台本なしで痛みになる＝
    //   限界超過は afford<1（露＝経済の負担）・人口側超過は労働力が抜ける（英＝労働の負担）。
    // ★輸送T4（輸送doc・2026-08-13）：容量目標の錨を人口から**潜在輸送量**へブレンドで寄せる。軍と同じ形（下の ArmySustainWeight の兄弟）。
    public double TransportPotentialWeight = 0.0;   // 0=人口のみ（厳密恒等）／1=潜在量のみ。中間でブレンド（Math.Max で競わせない＝軍の失敗の教訓）
    public double TransportPotentialHeadroom = 1.2; // 潜在量に対して確保する余裕（1.2＝2割の余力。1.0だと常に律速ぎりぎりで貼りつく）
    public double ThreatRailTargetWeight = 1.0;     // ★点火2026-08-30（安保W1腕batch10＝exact+2.0/法+1.3/本国+1.6/開放度8.5→16.7・破綻0）：輸送目標の国防項＝target×(1+これ×脅威比)。脅威比＝SecurityThreat/自国質量（前期値読み＝閉路なし）。戦略鉄道の一般化＝路線を1本も書かない
    public double PreemptiveSeizeWeight = 0.0;      // ★差し戻し2026-08-30（W2腕=1.0で経済−7.9/人口−9.1・W3合成でも同符号＝先制戦争が緩衝地帯経済を壊す）：AIの侵略標的の魅力×(1+これ×max(ライバル列強のProjection(A,標的)))。再挑戦条件＝0.5以下で内戦一元化ラウンド後に単独A/B
    // ★段6（理想の軍隊・2026-08-14実装＝休眠）：Power.Military への艦隊ゲージの合算比。0＝兵数のみ（厳密恒等）／1＝艦隊1ゲージ=兵250と等価。
    //   docs/202607/20260801_理想の軍隊の形_部分完了.md【一部】.md §10-1「要作者裁定」の器＝A/Bで測ってから裁定に出す。
    public double ArmyShapeGauge = 0.0;
    public double ArmySustainWeight = 0.25;        // desired の扶養限界ブレンド比（0=恒等。【0.25採用確定2026-08-08＝k0.5は経済−6.3/領土植民地−6.7で差し戻し】k≥0.5と海側分離は経済順位の是正（退蔵結晶化）後に再測定）
    public double SustainMilShare = 0.175;         // 経済側の持続可能シェア＝歳入のうち軍（給与+装備）へ恒常的に回せる割合（0.25×0.7相当から出発・要較正）
    public double ArmsRaceHigh = 1.2;              // 近隣に上位の扶養限界がいる場合の上限倍率（作者値+20%・要調整）
    public double ArmsRaceLow = 0.8;               // 周辺に脅威がない覇権国の下限倍率（作者値−20%・要調整）
    public double ArmsRaceTensionFloor = 30.0;     // ライバル判定の緊張下限（これ以上の緊張を持つ国の扶養限界と比較。0で全列強/中堅と比較）
    // ── 露普歳入是正（wf_f219b706・2026-08-08 調査確定）：普＝潤沢減税の床0.25に開幕から131年ロック（国庫ストックを支出へ
    //   翻訳する経路が無い）・露＝Militarize固定が教育を一度も目標化せず識字逆行→技術凍結＋農奴制の現金遮断。──
    public double OpulenceSpendRate = 0.6;         // 【梯子測定中2026-08-08＝0.6】支出反射（減税反射の対）：月次予算基数を 歳入 → 歳入＋これ×max(0,国庫−潤沢線)/12 へ（行政・軍需・扶養限界の3箇所）。0=厳密恒等。梯子0.3→0.6→1.2/年
    public double MilitarizeAgrarianTaxes = 1.0;   // 【L3点火測定中2026-08-08】Militarizeスタンスに土地税0.4・関税0.3の目標を追記（軍国が地租と関税で軍を養った史実＝地租改正・Grundsteuer）。0=恒等・1=有効
    public double MilitarizeEducationDrive = 1.0;  // 【L4点火測定中2026-08-08】Militarizeスタンスに公教育＋教育費0.4の目標を追記（義務教育は兵営国家の発明＝プロイセン1763・明治学制）。露のElite封鎖の解錠。0=恒等
    public double InitialLandTaxScale = 0.2;       // 【L3点火測定中2026-08-08＝0.2・台帳と軍国税は対で一つの機構】1783年の地租台帳：全53カ国一律 InitialLandTax=max(world.json値, これ)（Scenario.cs:55「確立国家は台帳を持つ」の履行）。0=恒等
    public double OpulenceInfraChannel = 0.0;      // 支出反射のインフラ拡張（退蔵→鉄道国家の建設）。0.6同時点火で硬性赤（公教育テスト）＝分離休眠2026-08-08。単独再測定用
    // ── 退蔵結晶化（課題7・wf_0c5ad336設計2＝審査82/78・2026-08-08）：貯蓄ストック（所得の700-1200倍）を「消さず」
    //   流動と結晶（IlliquidWealth＝Savingsの内数タグ）に再分類し、流動分だけを所得アンカーへ数十年の双方向緩和で収束させる。
    //   Savings総量は1円も動かさない＝貨幣制度（TotalMoney/BaseMoney/兌換/税/国債/与信）の全読者を凍結。──
    public double HoardCrystallizeRate = 0.0;      // 【Stage1中止2026-08-08＝Y15×床1000×elas基点でも各国独立経済テスト赤＝蓄積退蔵の結晶化が投資予算を痩せさせ床0.4×所得(旧の1/155)では防げない。読者点火は資本コスト群(IndCapitalCost連立4+D+P)の同時Search前提と実測確定】双方向結晶化速度/月（0=厳密恒等）（0=IW恒0=liquid≡Savings=厳密恒等。点火帯0.002-0.004＝超過半減期14-29年＝投資縮小≤5%/年）
    public double WealthAnchorYears = 15.0;        // 【Stage1梯子＝15（安全側）→8→4】流動貯蓄のアンカー（この年数分の所得までは結晶化しない）。段6のSearch次元（2-5）
    public double WealthAnchorFloorPerCapita = 1000.0; // 【400→1000へ2026-08-08＝結晶化の対象を病的退蔵（貴族3000/資本家3200/商人1500）に限定＝大衆播種(200-1000)は全額保護。テスト世界の一律1000/人播種とも整合】所得によらない生存バッファ床/人
    // 【墓標2026-08-29】InvestIncomeFloor/InvestFloorUsesIndustrialRent/InvestReadsLiquid/ConsumeReadsLiquid＝Stage1中止の予算配線4本を撤去
    //   （休眠削除＝厳密恒等。IlliquidWealth 自体は段3の他読者が live なので残る。再挑戦するなら §30 レールごと設計し直すこと）
    public double PanicBuyWeight = 0.0;            // 【休眠2026-08-08＝0.5は閾値0.5/0.75とも小世界の慢性低在庫で常時発動し輸出/税テスト3本の前提を崩す＝在庫閾値では分離不能→危機ゲート（戦争/飢饉文脈）付きの再設計が必要】B3自己成就的期待（2026-08-08作者裁定「入れてみよう」・docs/202607/05§B）：主食の棚が
    // 半分を切ると買い占めが加速（希少→退蔵購入→さらに希少＝バンクランの財版。HoardPanicWeight=資金側は既にlive）。
    // 予算とelasMaxが物理蓋・0=乗算ごとスキップ=厳密恒等。点火0.5
    public double SovietTaxProfile = 1.0;          // ソ連風税制（2026-08-08作者裁定＝完全な計画経済の代替）：プロレタリア独裁は
    // 極端な消費税（取引税＝ソ連最大の歳入源）と大規模な社会保障・累進最大を目標化。価格配分は触らない（保存則非接触・スタンス目標のみ）。0=恒等
    public double NationalismFromConsciousness = 0.0;  // 【休眠2026-08-08＝0.03/0.01ともcanary赤。ただし割れたのは「NY産出財数」＝0.01の微小加算でも割れる軌道ピン＝#17期待値再導出の筆頭対象。B自体の再点火は#17とセット】独統一トリガー解錠B：国民意識→ナショナリズムの平時底上げ（統一運動の燃料）。0=厳密恒等・点火帯0.02-0.05
    public double GarrisonProcurement = 0.0;       // 【棄却2026-08-08＝1.0/0.5とも硬性赤（公教育テスト）＝首都市場の需要構成が較正の暗黙土台】課題6（駐屯州調達・審査88/70）。#17全体再較正の再点火候補・0=首都一極=厳密恒等：装備需要と予算の州配分を
    // 首都一極（Id==0のみ）→兵士の駐屯州比例へブレンド（総量保存）。英ですら首都市場ration0.77＝小軍でも供給bindingの解消。
    // 即応の装備充足も兵士加重の全国平均へ（同係数ゲート）。0=首都一極＝厳密恒等・梯子0.5→1.0
    public double SerfCashShareFloor = 0.15;       // 【L5点火測定中2026-08-08＝0.15】農奴の市場参加床（オブローク＝貨幣代納の物理）：実効地主取り分=min(farmLordShare, 1−これ)＝現金賃金0の遮断を緩める。0=恒等
    // ⚠撤去2026-08-12（読み手ゼロ）: SoldierWealthExponent  【墓標2026-08-08＝NeedMen錨定（ArmyShapeMenWeight）が上位互換・再点火禁止】恒常性形へ移行したため休眠（積形は α=1.0 でハーネス2/10・α=0.5 は測定途中で打ち切り）    // **点火2026-07-31（再較正）**：α=0.5＝人口と経済の幾何平均。
    // α=1.0（実質GDP比例）は硬性ゲートを通らなかった＝ハーネス不合格2/10（点火前0/10）・exact28→21・near75→61・列強15→10%。
    // ただし max 形（折れ点あり）の 9/10 からは激減し 180テストも緑に戻った＝**折れ点が主因**という見立ては裏づけられた。
    // 0.5 なら倍率が平方根で圧縮され、上限 SoldierWealthMultMax に張り付く国（＝そこにも折れ点ができる）もほぼ消える。
    // ⚠撤去2026-08-12（読み手ゼロ）: SoldierWealthMultMin  倍率の下限（極貧国でも軍が消えない）
    // ⚠撤去2026-08-12（読み手ゼロ）: SoldierWealthMultMax  倍率の上限（極小富裕国が暴走しない）
    // ⚠初回は 0.2603（＝世界の**初期軍**13031を保存する値）を採ったが**不合格**＝テスト3本（地域物価・輸送マージン・公教育）が落ち
    // ハーネス不合格9/10・exact28→14%・near75→55%。世界の常備軍を 8069→15330（+90%）とほぼ倍増させ、軍需調達の急増が経済全体を歪めた。
    // 目標設定が誤りだった＝**初期軍13031は一度も維持されたことがない値**で、経済が較正されているのは現在の均衡8069の方。
    // 0.10 は世界総量 8069→9205（**+14%**）に収まる値。普61→115・蘭19→58が持ち上がり、清3845は不変（人頭が勝つ）。
    // ※英は人頭150が財政を上回るためこの水準では不変。英に効き始めるのは k≥0.13（世界総量+26%）＝経済が耐えるかを段階的に測る。
    public double MaxSoldierFraction = 0.04;               // 軍事費1.0で大衆の最大この割合が兵士（平時の上限。人口大国ほど大軍を持てる＝国力）
    public double MilitarismStrengthBonus = 1.3;            // 軍の練度：軍事力（戦力評価）の乗数の**満額**＝実効は 1+(これ−1)×軍の練度（識字×組織×勤務年数。★2026-08-18＝法のON/OFFを撤去）。同じ兵数で軍が強い（訓練・規律・動員）＝労働を奪わないので経済を弱めず軍事に出る
    public double MilitarismClout = 0.5;                   // 旧支配層(将校貴族)が軍から得る政治力＝MilitarismClout×**軍の政治的優位**（軍の圧力×(1−文民制度の弁)∈[0,1]）。★2026-08-18＝法の門を撤去。⚠**給与では買えない**（西1931アサーニャ改革は満額俸給付き退役で最大のクーデタを招いた）＝組織の大きさ・解隊の脅威・人事介入・屈辱が源泉
    public double SoldierPayMult = 1.0;                     // 兵士給与＝民間1人あたり月収×これ（同等待遇を目指す。払えなければ充足↓＝弱兵）
    public double SoldierMigrationRate = 0.08;             // 平時の徴募/離職速度（目標兵数への漸進・月次）
    public double ConscriptionFraction = 0.12;            // 戦時の徴兵上限＝大衆のこの割合まで兵士化（行き過ぎは経済に打撃）
    public double ConscriptionRate = 0.15;               // 戦時の動員速度（平時より速い）

    // --- 軍事／武力解錠（§6.1／§A-8・段4e）---
    public double ForceUnlockRate = 0.10;          // 武力解錠時のインフラ進捗（開発の約10倍速）
    public double ForceUnlockTreasuryCost = 1000;  // 制圧の月あたり国庫出血（軍事調達→pop へ還流）
    public double ForceUnlockMilitancy = 0.03;     // 制圧が pop に与える闘争度（戦争疲弊・§6.1）

    // --- 植民地の整備（§6.1 拡張：固有資源＋人口プール＋収益駆動の開発）---
    public double ColonialOutputHalf = 1.0;          // 産出率の半飽和開発度＝産出率 = 開発度/(開発度+これ)。初期≈0で投資が遅れて実り逓減
    public double ColonialShipPerInfra = 0.3;        // 開発度1あたり消費する輸送船(汽船)
    public double ColonialRailPerInfra = 0.5;        // 開発度1あたり消費する鉄道(線路)
    public double ColonialInfraDepreciation = 0.004; // 植民地開発度の月次減衰（維持しないと衰える）
    public double ColonialInfraPerColony = 1.0;      // 【R13点火2026-07-15＝1.0】植民地開発度の州単位化：0=国家一律の開発度w.ColonialInfraで全植民地の産出（現行と厳密一致）・>0.5で植民地ごとのcol.Infra（所有国水準へ収束するが征服/独立で移動＝奪った開発済み植民地は産出を引き継ぎ・独立後も凍結せず新所有国水準へ調整）。投資決定は国家プールのまま＝影響は移転植民地の産出に局所化
    public double ColonialInfraConverge = 0.01;      // R13：col.Infra が所有国の国家開発度へ収束する月次率（0.01≒半減期6年）。低いほど征服/独立後の開発が長く保持され、高いほど速く新所有国水準へ均される。ColonialInfraPerColony=0では未使用
    public double ColonyUpkeepBase = 150.0;          // 植民地1つの月次維持費（海軍・駐留・行政）の基本額。国庫から払い本国popへ（保存）
    // 帝国の過伸展は距離の金銭倍率でなく**物理消費**から創発：遠方植民地ほど補給線が長く、汽船が石炭(good1)を焚き駐留が缶詰糧食(good65)を食う。
    // 国庫が本国市場から買う＝石炭が産業と競合し価格律速（LastDemand）＝遠方帝国ほど石炭・糧食が逼迫（イギリスの過伸展が物理コストに）。
    public double ColonyUpkeepCoalPerDist = 400.0;   // 植民地1つ・距離1万kmあたり汽船補給線が焚く石炭量（物理消費）。balance：仏英二強の安価な帝国を実コスト化（200→400）＝過伸展が石炭価格・国庫を圧迫
    public double ColonyFuelOilEnergyRatio = 1.5;    // B6重油二択（2026-07-19）：補給線燃料の石炭→石油転換。原油のエネルギー密度＝同熱量の必要量が石炭の1/これ。実効単価が安い方を焚く（原油は1859解禁まで供給ゼロ＝転換は価格から創発）。0で旧（石炭固定）
    public double ColonyUpkeepFoodPerDist = 180.0;   // 植民地1つ・距離1万kmあたり駐留が食う缶詰糧食量（物理消費）。同上（90→180）
    public double ColonyShipOccupyPerDist = 0.12;    // 植民地1つ・距離1万kmあたり海運に課す混雑（ShipCapacity/(1+Σ)＝補給航路が交易船を占有・スケールフリー）。同上（0.06→0.12）＝遠方帝国の交易収入を削る
    public double ColonialReturnScale = 0.01;        // 限界資源価値の換算係数（限界産出×固有資源価値×これ > 投資コスト で私的投資家が投資）
    public double ColonialDevStep = 0.02;            // 採算が合う時に1期で進める開発度の刻み
    public double ColonialInvestFrac = 0.03;         // 私的投資家が貯蓄からこの割合まで植民地開発に充てる（affordability 上限）
    public double ColonialProductionPerColony = 600; // 植民地1つが固有資源を毎期産出する量（×産出率）。需要に関係なく市場へ流入＝過剰なら価格暴落（フラッディング）
    public int[] ColonialMarketGoods = [62, 57, 59, 69, 66];   // 捕囚市場で売る完成財（パン・衣料・家具・煙草・ビール）
    // アヘン（特殊資材・実験）：消費するほど中毒度が上がり、それが需要に上乗せされる＝供給が需要を生む正のフィードバック（暴走する想定）。
    public int OpiumGoodId = 92;                     // アヘンの good.Id
    public double OpiumAddictionGrowth = 0.1;        // P3点火0.1（2026-07-18＝Phase B実現。0.2はハーネス13/30＝依存→満足↓→困窮消費の発散で却下）。0=機構全体オフ（恒等）。点火で困窮ゲート消費・労働/満足ペナルティ・世界プール参加・AI禁令・輸出国緊張が全て連動
    public double OpiumAddictionCap = 0.2;           // 中毒度ストックの生理的上限（州人口の実効障害の飽和＝発散の物理的な蓋）
    public double OpiumAddictionDecay = 0.02;        // 中毒度の自然減（成長>減衰なら発散）

    // === リアリティ監査 2026-07-02 Wave1（致命バグ・保存則・ガード）===
    // すべて既定値が現行挙動を厳密再現する dormant 係数（#17 較正再走で有効化）。純粋なバグ修正は係数を伴わず live 済み。
    public double ReignitionTrickleConserves = 0.0;   /* ★★★**恒久的に0（作者裁定2026-08-01）＝これは不具合ではなく実装である。**
    // 再点火トリクルの「幽霊需要」は、**上位工場を先に建て、その後に必要な下流財を整備する**というプレイのための需要を作っている。
    // ⚠不具合を事実上の実装として使っている状態だが、**これが最もスマートな解決**（作者の言）＝**点火しない**。
    // 実測（2026-07-31・参考）：点火するとテスト180緑・破綻0・デッドロック0・異常0のまま★ハーネス不合格10/10（上位軍需が全滅）・◎7割帯21→6・逸脱過多13→39・
    // 最貧国の満足度0.06。つまり現行の経済はこの需要の上に立っている。⚠**再点火の検討をしないこと。** */
    public double InvestBudgetIncludesAllInputs = 1.0;   /* **点火2026-07-31（S5パッケージA・単独で採用）**：投資家建設の予算律速に鉄道/機関車費・保守要員費を算入＝投資家貯蓄が負に振れる穴を閉じる。
    // ★実測（単独・SOURCE-HASH 8e3…系）＝硬性ゲート全緑（破綻0/デッドロック0/異常0/ハーネス不合格0/フラグ0・テスト180緑）・◎7割帯 21→23・逸脱過多13→13・exact22%据え置き・near62→61。
    // ⚠同じ束の Reignition／CurrentInputFill は単独でも壊すので**一緒に点火しないこと**（Carryover と2本同時は満足度最小国が×＝ハーネス1/10） */   // 経4（予算制約）：投資家建設の予算律速に鉄道/機関車費(ConsRail/ConsLoco)・保守要員費(高度労働0.4+労働0.3)を算入。0=加算0で現行と厳密一致・1で全費目を予算に算入し投資家貯蓄が負に振れるのを防ぐ
    public double InsuranceSubsidyConsistent = 1.0;   // 経13（予算制約）：医療保険補助のベースを基礎価格から税・流通込み総額へ揃える（buyerPriceの(1-insure)と整合）。1でpayがbuyerPriceに一致し予算超過（貯蓄負値化）を解消（2026-07-19バグ監査で有効化）。0=基礎価格ベース。較正harnessはSocialSecurity=0→insure=0で全域中立（この既定変更は較正に不影響）
    public double CurrentInputFillGates = 0.0;   /* ★★★**恒久的に0（作者裁定2026-08-01）＝上と同じ理由で「意図した実装」。**
    // 当期投入が涸れても前期充足率で産出できることが、**上位工場を先に建ててから下流を整備する**プレイの余地を作っている。
    // 実測（2026-07-31・参考）：単独点火でテスト6本失敗（MultiNation/Tax 系）＝産出水準そのものが下がり較正の土台が動く。⚠**再点火の検討をしないこと。** */
    public double ConstructionMaterialCarryover = 1.0;   /* ★**点火2026-08-01（作者裁定＝リアリティ優先・帯とは切り分ける）**：
    // 「無から生成したものを翌月から引く／余った素材を市場に返す」＝買ったのに律速で使い切れなかった非律速資材を翌月の需要から差し引く。
    // ⚠実測（2026-07-31・単独）＝硬性ゲートは全緑だが◎7割帯 21→13・固着4→8・逸脱過多13→17。★**帯の劣化は較正で取り戻す対象であって、機構の可否の判断材料にはしない**（作者裁定）。
    // ⚠既知の限界＝繰越は**1段（翌月まで）で上書き**＝2ヶ月使わなかった資材は廃棄される。完全な物量管理にするなら累積へ（有界性の設計が要る） */
    public double EuphoriaUsesStableReserve = 1.0;   // 金利doc B7（2026-07-30・点火＝0→1）。経8（Heat符号逆転）：株式ユーフォリア項が参照する与信過熱Heatの分母を、取り付けで縮む実効上限(0)か準備縮小前の安定上限maxLoans(1)かでブレンド切替。0で従来の縮小後基準を厳密再現・1で取り付け中の偽の過熱スパイク→投資刺激の符号逆転を防ぐ
    public double CapitalOutflowFromInvestors = 1.0;   // 経9（帰属修正）：配当/逃避の流出原資。1で投資家(近代エリート)貯蓄から徴収し不足分のみ全pop按分・0で全pop按分。★B4裁定2026-07-31で**連続化**（0..1の按分＝0.5超の崖を廃止）
    // 資金逃避（07_再設計 §5(b)・2026-07-31点火）：国債への不信が閾値を超えると自国の資本家も対外資産へ逃げる。保存＝国内pop→CapitalAbroad の移転のみ
    public double CapitalDomesticFlightRate = 0.05;      // 不信1.0あたり四半期に逃げる投資家貯蓄の割合
    public double CapitalFlightDistrustThreshold = 0.02; // 逃避が始まる不信（累積切り下げ／名目GDP）＝切り下げ常習国だけが対象
    public double WelfarePensionClampToTreasury = 1.0;   // 財1（財政規律）：福祉・年金の支出を国庫残高で律速するか。0=現行の無制限（無記録の当座借越を許す・数値中立）／1=Min(cost,Max(0,Treasury))でクランプ。>0.5で発火
    public double FisherDeflationFloor = -0.02;   // 財4：Fisher期待インフレ項の下限。0.0=旧Max(0,·)と同値でデフレ遮断（数値中立）／負値-0.02程度でデフレ側を軽く通し「デフレ→低名目金利」を成立
    public double PrizeLossProrated = 1.0;   // 外4（拿捕賞金の連合按分）：victimの総海運損失(raidLoss)を制海権を握る全交戦raiderの海軍力比で按分。0=按分なし（各raiderが総額基準＝現行の二重取り恒等）/1=完全按分（合計が総損失を超えない）。PrizeCargoShare>0のときのみ作用
    public double FertileShareFloor = 0.05;   // 人6：出産可能女性プール（FertileWomenBirths）の相対基準の下限フロア。**0.05で有効化済み**（台帳訂正2026-07-12・旧注記「既定1e-6＝中立」は誤り）。捕捉時fertile≈0のpopで重みが桁違いに膨張し出生が集中するのを防ぐ（FertileWomenBirths=trueの経路でのみ作用）

    // === リアリティ監査 2026-07-02 Wave2（経済・金融の機構）===
    // 点火状況は各行参照。経18/経12の一部は「直書き定数の係数化」で値同一＝中立。
    public double SubsistenceHarvestFullExposure = 1.0;   // 経2（飢饉の深さ）：自給充足の収穫係数の露出度。0=局地HarvestFactorのみで現行と厳密一致・1で市場向けRGOと同じ三重積算(WeatherBandFactor×CropHealth[主食id]×landFactor)を自給にも乗じ、ジャガイモ胴枯病型の飢饉の核心層(高自給の貧農)に病害・緯度帯天候・土地逓減を届かせる
    public double ConstructionLaborViaMarket = 1.0;   // **点火2026-07-28（巨大建造物§3-1）＝§3-2の律速追加と同一バッチ**   // 経5（労働の二重雇用）：建設工賃を労働力財のinvestDemand(保守要員と同経路)へ回すか。0=現行の直接Savings加算で厳密一致・1で建設労働を市場需要として立てる（需要計上=EconomyStep.cs:329-349・決済=:868-922）
    public double DemandElasticityMaxDaily = 2.5;   // 【R1点火2026-07-13＝2.5】経11（大量消費化）：日用品(Daily)の需要上クランプ。1.4=PriceFactorMaxと同値で現行と厳密一致・>1.4で価格暴落による大量消費化(産業革命の綿布型)を許す。2.5＝安価工業製品を基礎量の2.5倍まで大量消費
    public double DemandElasticityMaxLuxury = 2.0;   // 【R1点火2026-07-13＝2.0】経11：奢侈品(Luxury)の需要上クランプ。1.4=PriceFactorMaxと同値で現行と厳密一致・>1.4で安価工業製品の大量消費化を許す
    // ── 所得翻訳ゲート（設計3・2026-08-08 敵対審査済み）：GDP∝人口＝英14位の根＝「生産性↑が需要へ翻訳されない蓋」を、
    //   貯蓄・投資・価格係留のどれにも触れずこの1点で切る。f = min(1 + k·ln(max(1, r)), Cap)、
    //   r = (LastEarned/Size) ÷ basketRef（basketRef＝Staple∪Daily の BaseNeed×RefPrice＝月収が基礎バスケット何個分か）。
    //   Daily/Luxury かつ非役務の desired にのみ乗算（Staple除外＝FoodMet/マルサス項・満足度台帳は式レベルで不変）。
    //   貧国popは r≤1 で f=1 厳密＝需要不変。
    public double DemandIncomeElasticity = 0.0;    // 【梯子測定済み・差し戻し2026-08-08】k=0.1＝経済規模−1.3pt／k=0.4＝−2.5pt＋政体exact−7.0（貧国エリートの奢侈需要だけ持ち上がり英大衆はr≈1.1で入力なし）。
    // 段5（WageClampMax増）も前提不成立＝WageClampIndScale=1.0 live で英の実効天井は既に約10×rp＝天井は縛っていない（賃金が均衡で天井に届かないのが実態）。
    // **確定測定＝「賃金→予算の翻訳だけでは経済規模軸は閉じない」**＝貯蓄・投資の一括再較正ラウンド（退蔵結晶化=設計2が候補）への入力。計器（incomeprobe）・物差し（IndustrialRent）・本配線は残置。0＝厳密恒等
    public double DemandIncomeFactorMax = 2.0;     // f の上限（世界需要の一斉膨張と商人マージン正帰還の物理蓋）。NaNは否定形ガードで中立1.0へ
    public double ColonialProfitMerchantShare = 0.3;   // 経15（帝国の分配政治）：植民地交易益(colonialProfit)のうち商人pop(MerchantPopIndex)へ傾斜配分する割合。0=全pop人頭按分で現行と厳密一致・>0で商人・特許会社へ集中。残余は全pop按分・受け皿不在時は残余へ還付
    public double ColonialProfitInvestorShare = 0.3;   // 経15：植民地交易益のうち投資家pop(InvestorPopIndex=資本家)へ傾斜配分する割合。0=現行の全pop按分・>0で資本家へ集中
    public double MaintLocoRate = 0.5;   // 経18（係数化・中立）：インフラ保守1単位あたりの機関車(車両更新)消費率。既定0.5=旧直書きと同値
    public double MaintAdvLaborRate = 0.4;   // 経18（係数化・中立）：インフラ保守1単位あたりの高度労働力(機関士・保線技師)消費率。既定0.4=旧直書きと同値
    public double MaintLaborRate = 0.3;   // 経18（係数化・中立）：インフラ保守1単位あたりの労働力(火夫・荷役)消費率。既定0.3=旧直書きと同値
    public double GridReplaceRate = 0.002;   // 経18（係数化・中立）：送電網の置換需要率。既定0.002=旧直書きと同値。※二重計上ではない（第2段2-9訂正3・2026-07-27）＝GridDecayRate と**相殺する対**（決済は減価の前）。ただし2本が (1−x) 関係で結ばれていないため片方だけ動かすと定常が崩れる＝動かす時は必ずセットで
    public double GridDecayRate = 0.998;   // 経18（係数化・中立）：送電網の経年劣化率(毎月GridCapacityに乗算)。既定0.998=旧直書きと同値。GridReplaceRate の対（上の注記参照＝セットでのみ動かす）
    public double ColonialImportLagMonths = 1.0;   // 経19→第7段第1波点火（2026-07-28・綿花ゲートの後＝順序厳守）：植民地輸入の遅延月数(0..1連続近似)。1で今月発注分を1ヶ月遅延＝綿花飢饉型の価格スパイクが立つ。パイプライン配線済み。0=即月充足で旧恒等
    // **点火2026-07-31（07_再設計 第2弾2b・A3裁定「入れるべき（恐慌が大きくなるが正しい）」）**：タンス預金の2段階。
    //   静的＝手元現金は常に1割。動的＝銀行の信用が崩れるほど引き出しが増える（ratio_eff = ratio × (1 + HoardPanicWeight×(1−Confidence))）
    //   ＝退蔵↑→準備↓→与信上限↓→さらに信用収縮の自己強化（B3自己成就期待の銀行版）。★Bank.Gold は導出のまま＝二重ソースにしない（07 §3の再結論）。
    public double CurrencyHoldingRatio = 0.1;   // 経6（流通現金）：家計・企業の手元現金退蔵比率。準備＝BaseMoney×(1−実効比率)。0＝全額準備（流通現金ゼロ・旧）
    public double HoardPanicWeight = 1.0;       // 信用崩壊時の退蔵増幅（Confidence=0で退蔵率が2倍＝準備がさらに1割減る）。0で静的のみ
    // 経20（退蔵の取り崩し no-hoard-drain・R4派生2026-07-14）：消費が需要上限で頭打ちのため所得＞必要消費のpop（世界の技術水準商人id10＝流通/輸入マージン・交易余剰の残余請求者＝マシュー正帰還）が貯蓄を消費ドレインなく単調累積し二極化する。富者が所得を消費・雇用・投資へ回す欠落機構の最小実装＝直近支払いの一定倍を超える退蔵の一部を地域内全popへSize按分で還流（pop→pop純移転＝MoneyConservation不変・GoodsBalance不変）。west=45000（米の対仏2倍成長＝史実）の再有効化の前提。
    public double HoardDishoardRate = 0.0;        // 既定0＝ドレインなし＝現行と厳密一致。**#66再計測2026-07-15＝0.05で却下（現base）＝calib24-24-24堅持だが batch破綻10/30・ハーネス20/30＋leakhunt seed1で人口保存違反(−14)＝退蔵ドレインが経済を不安定化し潜在の人口保存エッジケースを誘発。west25000base では貯蓄暴走が生きた問題でなく（#55結論）ドレインは害のみ**。>0で超過退蔵のその割合を毎月取り崩し還流。**ドレイン機構は休眠温存（点火するなら先に人口保存バグの特定が必要）**。**#55/west45000（America2倍）は保留**＝pop保存バグ(幽霊死/出生抑制/非負Size)修正でleakhunt seed1は完走したがbatch破綻6/30・ハーネス24/30・exact11%（巨大Americaが世界経済を歪め・ドレイン0.05では貯蓄暴走を抑えきれず）＝west25000維持（America101%で十分・BuildFrontier=R4が本命）
    public double HoardConsumptionMultiple = 24.0; // 退蔵とみなす閾値＝直近支払い(p.Paid)の何倍を超える貯蓄か（24≒24ヶ月分の消費を超える貯蓄が「退蔵」）。HoardDishoardRate=0では未使用
    // 経7（与信の州横断配分 CreditSpreadAcrossProvinces）＝2026-07-09裁定で不採用確定（0.25でもテスト赤・過剰な細分化）→2026-07-12裁定で機構ごと廃止（Credit.csのelse枝と係数を削除）。再検討する場合は設計doc「全域監査」2026-07-11 死28 と当時の設計を参照
    public double WageClampMin = 0.3;   // 経12：賃金/役務の床＝WageClampMin×(参照価格×物価水準)。旧MarketFlowの直書き0.3を係数化（値同一＝中立）
    public double WageClampMax = 3.0;   // 経12：賃金/役務の天井＝WageClampMax×(参照価格×物価水準)。旧MarketFlowの直書き3.0を係数化。平坦な帯域拡大(5.0)は首位交代退行で保留＝工業化度連動(WageClampIndScale)が正着
    public double WageClampIndScale = 1.0;  // 【R2点火2026-07-15＝1.0・工業化連動】賃金天井を工業化度でスケール＝effWageMax=WageClampMax×(1+これ×Industrialization)。0=固定3.0（現行と厳密恒等）・>0で工業国のみ天井が上がり実質賃金が伸びる（未工業国は据置＝平坦拡大の"富国青天井で独走固定化"を回避）。産業革命の賃金上昇・英独と亜阿の国際賃金格差拡大の史実
    public double WageClampSoftBand = 1.0;   // 経12（**【現行1.0＝有効＝SoftBand】**）：賃金の床天井をハードクランプ(0)か対数飽和SoftBand(1)かで切替。0=従来のClampで旧挙動・>0.5で財と同じSoftBand（鋭さはSoftBandSharpness流用）に切替え賃金圧縮を緩和。※0.3〜3.0倍の帯域自体は残存（R2）
    public double FiscalQuarterlyGating = 0.0;   // 財3（cadence整合）：四半期注釈の機構（DevaluationCapFrac・InsolvencyQuarters・BorrowCooldown）を月次(0・現行の3倍速)でなく四半期単位(1)で進めるか。0=現行の月次で厳密一致。1で切り下げ上限を月次÷3・カウンタを締め月(World.IsQuarterEndMonth)のみ進める（スカフォールド）
    // **点火2026-07-31（07_再設計 第2弾2a）**：前提（注入＝MultiNationSim・保有国配分＝CapitalMarket の外債レグ）が02断線走査で揃った＝対外国債が完全な閉鎖系になる。
    // シティ/パリの引受能力が世界の借入を規定する＝「貸し手のいない借金はできない」。
    public double ForeignBondFromInvestors = 1.0;   // 財5（対外国債の閉鎖系化）：対外国債プールをモデル外の無限プールでなく他国資本家貯蓄から実引き当てするか。0=現行の無限プール＝厳密一致。1でWorld.ForeignBondInvestorPoolを上限に引き当て
    public double ForeignLendingDebits = 1.0;   // ★点火(保存則の是正)2026-08-30（合成先行300Q＝経済+10.0/列強+7.6/法+3.5/exact+1.5/破綻0。604Q受け入れbatch30で最終確認・記録は20260830doc）       // ★片側記帳の是正（帰還構造の全数調査 §1-4・2026-08-30）：対外国債の元本を貸し手（他国資本家貯蓄）から実際に引き落とす（借り手の+CumulativeTradeFlowと両建て＝世界レベルの貨幣創造を閉じる）。0＝旧・片側記帳＝厳密恒等。点火はE3腕
    public double CapitalOpennessTariffWeight = 1.0;   // 財6（資本開放度の脱・関税連動）：openness=Clamp(1−これ×Tariff,0,1)の関税連動の強さ。1.0=現行の完全連動(1−Tariff)＝厳密一致。0で関税と独立（高関税の米/露も外債発行）＝兌換性/信認ベースへ
    public double DebtGdpAnnualized = 1.0;   // 財7（債務/GDPの単位整合・**2026-07-26点火＝第4群**）：金本位資格/離脱・国債金利プレミアムの分母を年換算GDPへ。点火と同時に4閾値/係数を÷12/×12（下記）＝代数恒等の単位フリップ（FP丸めの軌道再抽選のみ）。以後 dGdp は「債務/年GDP」＝史実（英1815=250%）と直接比較可能＝#17で史実レンジへの再較正と信認割引（BondRateRepresentationDiscount）再挑戦が解禁
    public double CoercionUpkeepToSoldiers = 0.0;   // 財14（抑圧装置の維持費の帰属）：連合維持費（軍・警察・官僚の俸給）を兵士pop・官僚(ClassId8)popへ傾斜させる割合。0=現行の全popへ頭数比例＝厳密一致。1で全額を兵士＋官僚へ・残りを全popへ。受け手不在時は国庫残置
    public double WarFarmOutputDamage = 0.3;      // 05-A（2026-07-29）：戦場強度1.0で主食RGO産出−30%（劣勢側のみ・終戦で即回復）。戦争→飢饉→政変の連鎖
    public double WarLivestockRequisition = 0.03; // ★点火2026-08-31（ラウンドB）＝戦争被害のストック化（AI審査3-11）：戦場強度1.0で家畜RGOの操業規模を3%/月で徴発（軍馬・輓獣・食肉＝flowでなくstock）。回復は既存のRGO供給弾力（年単位）から自然に出る＝回復コードなし（鉱脈在庫と同じ思想）。0で徴発なし
    public double WarLivestockOutputDamage = 0.5; // 05-A：畜産(19)は重め＝役畜・軍馬の徴発が市場価格経由で農業を締める。缶詰→軍需の自己制限も創発
    public double InvestExtrapolationWeight = 0.3; // 05-B2：投資の外挿期待の重み（採算の勢い項）。バブルと深い崩壊を生む増幅側の期待。0で厳密恒等
    public double FreightRatePer10Mm = 0.10;     // 04材化(b)（2026-07-29）：運賃率＝荷価の10%/10,000km（ロンドン→ボンベイ18,000kmで約18%）。荷主（輸入国）が払い実効海運容量シェアで各国へ按分（E2裁定）。0で完全恒等
    // ★貿易復活プログラム（2026-08-15・作者裁定「貿易を先に挟む」・tradewhy分解＝99_実装ログ§4-15）：
    //   1914年の世界貿易/GDP 0.2%（史実の英は輸出だけで約25%）の壁＝①関税wedgeが同国ペアにも掛かる内国関税 ②運賃革命が従量成分にしか効かない。
    public double TariffBorderOnly = 1.0;        // ★点火2026-08-15（ign_trade1・acc_full）：①関税・穀物法wedgeを国境のみに（同国売り手には掛けない・同国取引を輸入統計/関税徴収から除外＝内国関税の撤廃）。0に戻せば旧（全ペアwedge）とビット恒等
    public double FreightRevolutionAdValorem = 1.0;   // ★点火2026-08-15（ign_trade1）：②運賃革命をad valoremマージンにも適用（史実1870-1913＝運賃約8割減は全面的）。0に戻せば×1.0＝ビット恒等
    public double TradeBandWiden = 0.5;          // ★点火2026-08-15（ign_trade1）：③帯の拡張（tradewhy2＝量の分解2026-08-15）：売り手帯=平均×(1+w)・買い手帯=平均/(1+w)。旧＝平均分割は「世界の裾と裾」しか取引できず、穀物大国（露≈平均価格）がロンドン（平均の1.5倍）へ売れない構造遮断＝麦・石炭の貿易死の主因。成立判定（着値vs自州価格）と量式は不変＝ペア黒字の取引を到達可能にするだけ。0＝×1.0/÷1.0＝ビット恒等。設計値0.5。点火はA/B（貿易/GDP＋帯・壁2本との合成も測る）
    public double TradeAccessNormalized = 1.0;   // ★点火2026-08-15（ign_trade1＝主動因・貿易0.23→1.19%・帯全次元改善）：④対外アクセスの正規化：TradeAccessのlostを真のシェア（lost/Σ全相手weight）へ。旧＝TradeWeight（平均0.25・総和≈15）をシェア扱い＝平均4カ国と禁輸/交戦で床0.10＝実測で英仏露普清が全員恒久床。正規化で禁輸4/60≈7%喪失の史実スケールへ。0＝旧式ビット恒等。点火はA/B
    public double RiskLambda = 2.0;              // 03手順7：リスク線積分の強度＝1−exp(−λΣ敵支配度×km/1e4)。完全支配10,000kmで0.86≈旧ChokeBlockadePenalty(0.8)の帯を継承
    // ⚠撤去2026-08-12（旧世界市場の撤去で読み手消滅）: PerStateTradeDistance  03手順4A（2026-07-28）：距離マージンを州単位の3脚（州→港(陸×LandSeaCostRatio)→海→重心）で計算。0=旧・国一律（首都→重心）
    // ★★陸路の直行を運賃に繋ぐ（2026-08-26・作者指摘「陸上の交易は計算されていない？」）＝(1.5)。
    //   ⚠発見＝BilateralMarket は交易のとき州を**最寄り港の座標へ置き換える**（:97-102）。つまり対の距離は必ず
    //     「陸脚A×12 ＋ 海路(港A→港B) ＋ 陸脚B×12」で、**陸路の直行便が存在しない**。
    //     パリとリヨンの取引はル・アーヴル↔マルセイユの**イベリア半島を回る航海**として値付けされていた。
    //     19世紀欧州大陸の交易（ライン川・ドナウ川・街道）が丸ごと海運になっていた＝貿易/GDP 0.09% の主因の1つ。
    //   ★陸グラフ（PathGraph・2026-07-28）は**既に存在して正しく動き地図にも描かれている**が、読み手は
    //     「最寄り港までの脚」と地図描画だけだった（設計doc 03 の「手順2以降で運賃が読む」が来ていなかった）。
    //   ★機構＝対の距離を min(海経由, 陸直行) にするだけ。新しい経路も新しい距離の定義も作らない。
    //     ⇒ (2)の鉄道/人力と(3)の地形は、この陸の辺の属性として乗る。
    //   ⚠0＝陸直行を1度も引かない＝厳密恒等（seaOk==linked・viaSea同式・landNodeは-1埋め＝構成的に旧と同値）。
    //   ★点火2026-08-27：実測（batch5・同一バイナリ）＝破綻0/デッドロック0/異常0/ハーネス0・savetest 0.0E+000・
    //     **貿易/GDP 0.13%→0.25%（ほぼ倍増）**。要注意2件は陸路OFF腕にも出る雑音水準（batch30で確定）。
    public double LandRouteEnabled = 1.0;
    // ★★(3) 地形×手段の係数表（設計doc 20260826_地形と輸送コスト.DONE.md＝タグ7種×手段3列）。添字＝Terrain enum の順
    //   （Plain, WaterMajor, WaterMinor, Hill, Forest, Mountain, Barren）。
    //   ⚠**全1.0＝厳密恒等**（地形タグが付いていても陸路コストは1文字も変わらない）。点火＝docの仮置き
    //   馬  ＝ [1.0, 0.8, 0.9, 1.5, 3.0, 2.5, 8.0]（森は馬を強く阻む・不毛はほぼ通れない）
    //   鉄道＝ [1.0, 1.0, 1.0, 1.5, 1.2, 5.0, 3.0]（森は切り開ける・山はトンネル＝国家事業＝**係数が交差する**）
    //   を入れて単独で測る。馬↔鉄道のブレンドは既存の railGate（Transport.cs＝技術の連続ゲート）＝新しい時計を作らない。
    // ★ゲート TerrainCostEnabled（POB_COEF が配列を受けないためのスカラー栓）。0＝表を1度も読まない＝厳密恒等。
    //   表の値は doc の仮置き（データ）＝ゲートを開けたときだけ効く。
    //   ★点火2026-08-28（batch30 A/B・同一バイナリ）＝硬性全緑・列強35.8→36.7・経済36.7→38.3・植民地46.7→48.3・本国97.8／
    //     政体48.3→46.3・人口26.2→25.2・貿易0.12→0.09（山岳・不毛の陸脚が高くなる分＝正しい向き）。差し戻しはこの1本を0へ。
    public double TerrainCostEnabled = 1.0;
    public double[] TerrainHorseCost = [1.0, 0.8, 0.9, 1.5, 3.0, 2.5, 8.0];
    public double[] TerrainRailCost  = [1.0, 1.0, 1.0, 1.5, 1.2, 5.0, 3.0];
    // 水運の口（doc第3列＝水路州は陸路でなく船の容量を使える）。0＝閉（従来）。>0＝水路州の陸脚コスト係数をこの値へ
    //   置換（大河0.15/支流0.4級を想定）＝内陸なのに港に近い扱い＝ミシシッピ・ライン・黄河が海と繋がる。
    // ★★(4) 輸送容量の配分（設計doc 20260826_輸送容量の配分.DONE.md・作者設計「経済規模に応じて必要であろう輸送力を配る」）。
    //   旧＝州数で均等割り（ロンドンもサハラも同じ）＝州を増やすと1州あたりが薄まる＝**州の細分化が貿易を殺す**。
    //   新＝share = (1−k)×(1/州数) + k×(その州の前期潜在量/国の合計)。材料は既存の純テレメトリ LastTradePotential
    //   （書き込みは容量計算より後＝読めば自動的に前期の値＝同一ティック閉路なし）。分母が痩せたら均等へ倒す。
    //   ⚠設計環境の実測＝**貿易は増えない**（配分は総量を変えない）。目的は州の細分化を可能にすること＝**州の追加と同時に点火**。
    //   ⚠0＝厳密恒等（旧の均等割りそのもの）。
    //   ★点火2026-08-28＝州追加トランシェ1と同時（docの指定どおり）。batch30＝硬性全緑。差し戻しは0へ。
    public double TransportShareByPotential = 1.0;
    public double TerrainWaterMajorCost = 0.15;   // ⚠読み手は TerrainCostEnabled>0 のときだけ（水運は陸運の1/5〜1/10＝docのレンジ）
    public double TerrainWaterMinorCost = 0.4;
    // ★鉄道時代の陸運低下（2026-08-28・輸送コスト是正・作者一任「いい感じに」）：史実＝馬車の陸運は水運の10〜30倍、
    //   鉄道は2〜4倍。旧＝帆船の時代と鉄道の時代が同じ12倍だった。実効比＝LandSeaCostRatio×(1−railGate×(1−これ))＝
    //   railGate（既存の技術連続ゲート＝新しい時計なし）で12→12×これ へ連続に下がる。⚠1.0＝恒等。0.25で満鉄道時代に3倍。
    //   ★点火0.25（2026-08-29・batch30 A/B）＝政体46.3→47.5・列強30.8→31.7・経済34.2→36.7・**人口22.7→29.0**・硬性全緑。
    public double RailCostFraction = 0.25;
    public double LandSeaCostRatio = 12.0;       // 03手順4A：陸の実効距離倍率（§4-2の実測例＝陸単価12。鉄道後の低減は#17で。B3裁定＝新係数はこの1本に集約・地形係数は作らない）
    public double TransitEnabled = 1.0;          // 経路グラフ第1段 Stage C（03 §11-6・裁定A3・2026-08-09）：内陸国（港州ゼロ国）の距離マージンを外国港州トランジット（Region.TransitPort*＝構築時静的の上位2候補・所有だけ四半期解決）の3脚で計算。0＝旧・首都基準フォールバック（厳密恒等）・1で点火。交戦中の港は第2候補→両方不可なら旧フォールバック＝鎖国はしない
    public double TransitTollShare = 0.05;       // Stage C：通行料率＝トランジット利用州の取扱高（LastPortThroughput）比。決済後に利用国国庫→港所有国国庫の移転（運河通行料 MultiNationSim.StepCanals と同型＝Treasury/CumulativeTradeFlow 両建てで保存）。払えない分は国ごとに比例縮小（負債は作らない）。TransitEnabled=0 では読まれない（休眠）
    public double PortRewireEnabled = 1.0;   // 【点火1.0・2026-08-16＝A/B: 単独34/70/53・条約港風化との合成36/73/51=優加法】領土が動いた国の港配線（最寄り港/海盆/通過港）を四半期末に再配線＝割譲・分離独立・州昇格・辺境解錠に配線が追随（旧＝構築時1回の凍結配線）。0で構築時のみ＝旧挙動と厳密一致
    public double TransportWeightMarginScale = 0.3;   // 財9（輸送費の従量化）：交易マージンの従量成分の強度。0で従価一律の現行と厳密一致・>0で margin に TransportWeight(g)/RefPrice(g) 比例の従量部を加算＝石炭/穀物の長距離交易が前鉄道期に立たない
    // ⚠撤去2026-08-12（旧世界市場の撤去で読み手消滅）: ThrottlePrepassUsesRealThreshold  財10（保護バイアス）：輸送スロットルの事前パスの輸入閾値。0で従来の裸マージン＝保護国のthrottleが過小→輸出が巻き添え・1で本パスと同式(tar×TariffProtect+cornPen+blockadeBias)に共通化。>0.5で発火
    public double WorldPriceInitFromRefPrice = 1.0;   // **点火2026-07-27（機能優先ラウンド第1群）**   // 財11（世界価格の初期値）：0で全財1.0初期化（現行）・1でCatalog.RefPricesから初期化＝開始数年の高額財交易の凍結を解消。>0.5で発火。MultiNationSim側でコンストラクタへ渡す配線が要る（既定省略時は0で現行と厳密一致）
    public double SingleNationTradeParity = 1.0;   // **点火2026-07-27（機能優先ラウンド第2群）／⚠batch30では測定不能**：Trade.Step は Trade.cs:13 の !TradeEnabled で即return し、
                                                   // TradeEnabled=true を立てるのは PriceOfBread.Tests の2本だけ（Scenario 既定false・NationConfig.ToScenario も MultiNationSim の分離建国も未設定）。
                                                   // 多国バッチ・較正・GUI はすべて InternationalMarket 経由＝この係数は本番軌道に一切効かない。効くのは単一国モードのみ。   // 財12（単一国/多国の乖離）：単一国モード(Trade.cs)を多国版へ寄せる。0で現行・1で為替換算＋穀物法の主食輸入閾値＋容量シェア(1/activeCount)を配線。>0.5で発火
    public double ExportRevenueToProducers = 0.5;   // 財15（輸出利潤経路）：輸出代金のうち当該財の生産者所有者popへ直接渡す割合∈[0,1]。0で全額を全pop貯蓄按分（現行）＝輸出産業に利潤経路なし・>0で生産者所得とMarket.LastSoldが立ち輸出主導成長が通る。生産者不在の財は全額netFlowへフォールバック

    // === リアリティ監査 2026-07-02 Wave3（人口・社会・労働の機構）===
    // 点火状況は各行参照。1州較正harnessでは加重=非加重・OldShare=0・複数州なしで恒等になるよう設計。
    public double CapacityFromFoodOutput = 0.5;   // 人2（扶養力の食料産出アンカー・大改修スカフォールド）：DemographicStepのcapacity基準を「初期人口baseline」と「実食料産出アンカー(baseline×未クランプfoodMet/foodNeed・下限0.3)」の間でブレンド。0=baselineアンカー(天井約2.5倍)で現行と厳密一致・1で実食料産出から再構成＝19世紀の人口爆発(英4倍/米23倍)とpop>capacityの補償死倒錯を解消。乗数束上限撤去・耕地×技術アンカー・再較正は#17残件
    public double CoupleLimitedBirths = 1.0;   // 人5（徴兵で出生が増える符号逆転）：FertileWomenBirths経路の出産可能プールをFemaleShare比例(0=現行)からカップル律速2×min(女,男)(1)へブレンド。標準構成FemaleShare=0.5で両式が定数倍で一致しt=0正規化が相殺＝較正中立。FertileWomenBirths=true（既定）で有効。falseなら不読
    public double FertilityAffectsBirthsOnly = 1.0;   // 人7（出生率倍率の死亡側混線）：第4段4-6で単独点火（2026-07-27）＝「女子教育を進めた国は同じ食料不足でも飢饉死が半分」の誤因果を解消。旧・M8試験の破綻1/30は OldLaborFactor=0.5 との抱き合わせで、相方はその後0.75で単独点火済み＝前提消滅→単独再測定へ。netFertility=fertility+これ×(1−fertility)。0で旧（死亡側もfertility比例）
    public double FamineAbsoluteThreshold = 0.0;   /* #17保留:balance(London creep) */   // 人9（局地飢饉の絶対水準ゲート）：RegionalFamineStepの飢饉基準famineRef。0=natFood（相対的剥奪だけで発火・現行と厳密一致）・>0でfamineRef=min(natFood,これ)＝十分食える州は国平均以下でも飢えない
    public double NewbornLiteracyDilution = 0.0;   /* #17保留:Stage2/TechInst識字テスト */   // 人11a（新生児の識字の無償相続）：DemographicStepの出生分(識字0の新生児births人)でpopのLiteracyを加重平均希釈。0=希釈なし（現行と厳密一致）・1でLit_new=Lit_old×(Size−births)/Size。識字ラチェットの解消。教育側はTechEducation.cs
    public double OverworkMortalityWeight = 0.015;   /* トレードオフ化2026-07-06:有効化。短時間側 OverworkHealthSlope=0.015 と対称の初期値＝無制限14hで扶養力−0.03（=+19%産出 whOut の対価）。0で旧挙動・要較正再走 */   // 人12（14hの健康被害が12hと同値）：WorkHoursCapacityの長時間側の超過死亡項。扶養力に−これ×max(0,hours−12)を加算。0=現行（Max(0,12−hours)の片側のみ）と厳密一致・>0で12h超に人口動態コスト
    public double EpidemicIntraCountrySpread = 0.5;   /* #17有効化 */   // 人14（疫病の州間伝播）：TriggerEpidemicの感染窓中に最過密州から次過密州へ与える二次スパイクの減衰致死率倍率。0=単一最過密州のみ（現行と厳密一致）・>0で次過密州へdeathFrac×これの二次死亡（1832コレラのパリ→リヨン型）。新規RNG消費なし（決定論不変）。1州世界は不発
    public double IndustrializationPopWeighted = 1.0;   /* #17有効化 */   // 人16（工業化度の人口加重）：DemographicStepの出生率・扶養力に効く工業化度を非加重州平均(avgInd)から人口加重平均(ΣInd×rpop/Σrpop)へ。0=非加重（現行）と厳密一致・1で人口加重。1州世界では両者恒等＝較正中立
    public double MigrationCarriesHumanCapital = 1.0;   /* #17有効化 */   // 人1：移動サイトが識字・闘争度もsize加重で運搬する強さ（0=運ばない＝現行の着地時無償識字獲得を温存／>0で運搬ON）。国家集計は加重平均で中立・per-region分布のみ実勢化。共有係数（PopDecision/Meritocracy/Territory/Military/MultiNationSimが参照）
    public double PromotionLiteracySelection = 0.5;   /* #17有効化 */   // 人1：昇格の識字選抜強度（Meritocracy）。0=選抜なし＝移動コホートの識字＝src平均（現行恒等）／>0で移動者の識字を引き上げ質量保存で残留srcを引き下げ＝昇格ポンプの自己補充を解消。MigrationCarriesHumanCapital>0とセットの時のみ発火
    public double RegionMigrationExcludesClosed = 1.0;   /* #17有効化 */   // 人4：地域間移民（Territory.MoveRegion）が閉鎖階級（貴族・聖職）・兵士を除外する（0=従来どおり全クラスを動かす＝現行維持／>0でPopDecisionのClosed除外・越境の!IsSoldierと対称化）。FrontierDevelopment較正世界は農民pop単体で恒等
    public double LiteracyGenerationalDecay = 0.002;   /* 【R10点火2026-07-13＝0.002】 */   // 人11b：識字の世代減衰（TechEducation・月次）。0=減衰なし＝既得識字は永遠保持（旧ラチェット）／>0でEducationFillを上回る分に微小な世代減衰＝教育投資の維持費（教育崩壊で識字後退）。0.002＝超過分の半減期≈29年（世代規模）＝使わなければ失う
    public double EducationGateUsesEma = 0.0;   // 人13：昇格の高等教育ゲート（Meritocracy）に多年EMAを使う（0=当月EducationFillの瞬間フロー＝現行／1=EducationEmaストックで判定＝一時的な教育の途絶で資格が消えない）
    public double EducationEmaRate = 0.05;   // 人13：EducationEmaの当月Fillへの月次収束率。EducationGateUsesEma=0の既定では未使用＝挙動非依存。値は#17で較正
    public double CrossBorderMigrationByOpportunity = 1.0;   // 人3/外14：国家間移民の送出/受入州を機会で選ぶ（送出=Opportunity×FoodFill最悪州・受入=Opportunity最大州）。0=現行のRegions先頭州固定（恒等）
    public double CrossBorderGapByOpportunity = 1.0;   // キュー7（ユーザー発案2026-07-10）：越境移民の**量ゲート**の州判定化＝gap=受入国最良州機会−送出国最悪州機会(×食料充足)−閾値。旧・国平均満足度は晩期に全国≈0.9へ飽和しgap≈0＝欧州→米の持続流が死ぬ構造の是正。0で旧・満足度ベース（休眠可）
    public double CrossBorderOppGapThreshold = 0.5;    // 州機会gapの発火閾値（機会スケール1〜3に合わせた初期値＝要batch測定。旧EmigrationGapThreshold=満足度スケール0.15は不適合）
    // R3 移民の距離減衰＋渡航コスト財化（2026-07-13・残タスク表 最高インパクト）。移民3関数がGeo/距離を一切読まない＝欧州の農民が米も豪も同確率だった。
    // 大圏距離 Geo.DistanceKm（首都間・海路運河は移民には過剰精緻＝陸海両用の距離近似）。両係数とも既定0で厳密恒等（scale=0→減衰1.0・fare=0→運賃なし）。
    public double MigrationDistanceScale = 10000.0;   // 【点火2026-07-13(2)＝10000km】0=距離無感応（厳密恒等）。>0で越境移民の引力gapに距離減衰 1/(1+DistanceKm/これ) を乗じる＝近い行き先を選ぶ（史実の距離逓減：欧州内・北大西洋が主流で遠距離は運賃/情報で細る）。10000＝欧州→米6000km:0.63/アルゼンチン11000km:0.48/豪16000km:0.38＝機会の大きい米が距離でも勝ち残る緩い減衰。要batch調律
    public double MigrationFarePerkKm = 0.0;   /* 休眠。#54再点火試験2026-07-14＝0.1でmassBirthWeightガード後seed3は完走するが、住民が≈0まで流出した国家がゾンビ残存→多国batchでO(N²)膨張→約12倍低速化。要ゾンビ国家清掃（civilian pop→0の国の消滅機構）。R3距離感応が移民リアリティの核心は提供済み＝運賃は保留 */      // 【休眠に戻した2026-07-13(2)＝要追加調査】0=渡航コストなし（厳密恒等）。>0で移民1人が距離比例の運賃(=これ×DistanceKm/1000)を要する＝貯蓄が運賃に満たない最貧層は動けない（貧困の罠）。運賃分は送出経済に残し保存則を閉じる。**点火0.1で保存則は清潔（leakhunt seed1/25/27緑）だがseed3が破綻＝運賃コード外の下流でSize NaN（診断未発火＝affordFrac自体は有限）＝運賃の軌道摂動が潜在NaNバグを露出。距離減衰は完走。運賃コード（IsFinite安全弁）は残置し、潜在NaN特定後に再点火**
    public double WorldMigrationPoolFrac = 0.004;      // キュー7：国際流入の世界プール化＝総量(世界人口×これ/四半期＝旧cap0.004と同規模＝年1.6%)を各国引力で比例配分。旧「自国人口比例」は小国の米に絶対数が入らない構造だった。0で旧挙動（休眠可）
    public double ImmigrationReceiveCapFrac = 0.012;   // **2026-07-23 B-高6＝台帳一致**（コメントの0.012へ・旧リテラル0.004は台帳の食い違い）   // 世界プールの受入国側の物理上限（/四半期・中間案(b)2026-07-10）＝アイルランド脱出級の絶対フロー年4.8%。無上限は高識字小国への洪水→エリート崩壊を実測。旧cap0.004の3倍＝米国は救い洪水は律する
    // ★移民制限法の効き（2026-08-01）。⚠既定は Open＝1.0 なのでどちらも読まれない＝厳密恒等。
    // 値の根拠＝米1924年移民法は前年比で流入を約8割削った（年約70万→約16万）＝Closed≈0.2。Selective はその中間（紳士協約1907型の部分制限）。
    // 選好の強さ：流入率（前四半期の流入÷人口）1あたりの要求の大きさ。⚠受入上限が年4.8%＝四半期0.012 なので、
    // 上限に張り付いた国で 40×0.012＝0.48＝「強い要求」になる較正。流入ゼロの国では0＝争点にならない。
    // 通貨制度の選好の強さ：年率1%の物価変動あたりの要求の大きさ。★較正＝1873-96の大デフレは年率−1〜−2%で、
    // 20×0.015×(1−資産)≈0.3＝「他の争点と並ぶ強さ」。物価が安定していれば両側とも0＝争点にならない。
    // 国民皆兵が引ける人数＝選抜徴兵の何倍か。★較正＝1870年の普（2400万人から120万人＝5.0%）と
    // 仏の選抜徴兵（3600万人から50万人＝1.4%）の比＝約3.5。動員の上限は別途 manpower が抑えるので 2.5 から入る。
    public double UniversalConscriptionFactor = 2.5;
    public double MonetaryPrefScale = 20.0;
    public double ImmigrationRestrictionPrefScale = 40.0;
    // ★段⑤（2026-08-17）：技術者流出禁止法の選好の物差し。⚠0＝Pref が常に0＝**要求リストに載らない＝厳密恒等**（思想③）。
    //   ★点火時は移民制限法（40.0）よりずっと大きい値になる見込み——抜かれる技師は人口比で桁違いに小さいため。
    public double SpecialistExitBanPrefScale = 0.0;
    public double ImmigrationSelectiveFrac = 0.5;   // 選別：受入上限を半分に
    public double ImmigrationClosedFrac = 0.2;      // 閉鎖：受入上限を2割に（★完全ゼロにしない＝密航・家族呼び寄せ・特例は史実にも残った）
    public double ExternalImmigrantProfile = 1.0;   // 人10：ゲーム外移民に固定プロファイル(低識字・若年成人男性偏重)を加重混合。0=現行の受入popクローン（恒等）
    public double ImmigrantProfileLiteracy = 0.15;   // 人10：外部移民の識字（低・ExternalImmigrantProfile>0でのみ使用。#17で再較正）
    public double ImmigrantProfileFemaleShare = 0.35;   // 人10：外部移民の成人女性比率（若年成人男性偏重＝低め。同上）
    public double ImmigrantProfileChildShare = 0.15;   // 人10：外部移民の子供比率（単身移民＝低め。同上）
    public double TradeWeightDynamic = 1.0;   // 外1（A-中6・**2026-07-23点火＝取扱高駆動へ書き換え**）：TradeWeightを四半期ごと貿易取扱高（輸出+輸入額のEMA）シェアから再計算。0=1789の0.15+0.10×Industrializationを固定維持（恒等）。GDP駆動は開放度を無視して1913年の米・清・露を過大にするため取扱高へ変更
    public double TradeWeightBase = 0.15;   // 外1：動的TradeWeightのベース（TradeWeightDynamic>0でのみ使用。現行式の切片に対応。#17較正）
    public double TradeWeightGdpSlope = 0.10;   // 外1：動的TradeWeightの相対取扱高シェア(世界平均1)への傾き（同上。#17較正）
    public double CanalTollTrafficRate = 0.02;   // 外6：取扱高あたり通行料率（通航トン数課金の実効レート。旧CanalTollRate/CanalTollByTraffic/CanalTollByRouteは02断線走査2026-07-28のルート判定一本化で削除済み＝この係数が唯一の実効レバー。#17較正）
    public double CanalInvestReturns = 0.5;   // 外7：運河建設拠出国へ通行料を持分比で配当する割合(0..1)＋交戦中の拠出停止。0=現行の全額扼者・無条件拠出（恒等）
    public double ConscriptionScalesWithWar = 1.0;   // 外12：戦時徴兵率を戦争規模でスケール。0=現行の一律ConscriptionFraction（恒等）
    public double ConscriptionFloorFraction = 0.02;   // 外12：限定戦争の徴兵下限（depth=0の徴兵率。ConscriptionScalesWithWar>0でのみ使用。#17較正）
    public double ConscriptionExhaustionWeight = 1.0;   // 外12：厭戦(WarExhaustion)→動員深度の重み（同上）
    public double ConscriptionFrontStep = 0.34;   // 外12：追加戦線1本あたりの動員深度増分（単一戦線=0で恒等。同上）
    public double ConscriptionEnemyRatioWeight = 1.0;   // 外12：敵陸軍優勢(比>1)→動員深度の重み（同上）

    // === リアリティ監査 2026-07-02 Wave4（政治・制度・外交の機構）===
    // 点火状況は各行参照（政16 IdeologyGateFromDevelopment は既定0.5で live）。
    // LegitimacyIsStock は第3段3-4/3-5（2026-07-27）で削除＝1.0（2026-07-10点火）をPoliticsへ焼き込み。正統性は常にストック（旧フロー混合＝重み0の死荷重 legFlow/(1−s)×MandateSpent を同時削除）。
    public double LegitimacyRegenRate = 0.1;    // 政1：正統性ストックの四半期再生率。**0.02（時定数12.5年）は過剰安定＝革命が起きず世界が固化（上海97%・首位確定Q152・幕府消滅を実測2026-07-10）→0.1（時定数2.5年）へ**。侵食族は平衡対応（erosion=regen×旧水準）で×5済み＝平衡不変・過渡だけ速い。政治資本の回復は MandateRecoveryRate へ分離（2026-07-26）
    public double ReformFromAboveEnabled = 1.0;   // 政2（**【現行1.0＝有効】**上からの改革の遷移経路）：>0で支配ブロック主導の代議制/近代化への遷移が大衆動員(challenge≤coerce)でも成立（明治1889/プロイセン欽定/露大改革）。0でchallenge≤coerceゲートが無条件＝旧挙動
    public double ReformFromAboveLegitThreshold = 0.4;   // 政2：上からの改革が発火する正統性の上限（Legitimacy<これ＝侵食が進行中の体制のみ自己改革）。ReformFromAboveEnabled=0では未評価
    public double SuffrageRatchetOnLiberalize = 1.0;   // 政3（**【現行1.0＝有効＝立憲化で参政権を狭めるバグ解消済】**）：>0で縮小方向の剥奪を反動系政体への遷移時のみに限定＝自由化はラチェット（立憲化で選挙権を狭めない）。0で旧＝上げも下げも（バグ）
    // ★2026-08-01の調整（0.5→1.0）。圧政項の上限を SecessionThreshold と同じ高さにする＝
    //   **十分な軍を置いた国は、それだけで分離を抑えうる**（清が太平天国を鎮圧し、英がアイルランドを保った形）。
    //   0.5 では上限0.715＝閾値1.43の半分にしかならず、軍をいくら持っても保持力が足りなかった。
    public double SecessionHoldCoercion = 1.0;   // 政5（分離の中央保持力判定がデッドコード）：>0でholdに軍・警察(Coercion)由来の飽和項を加え第2条件を活性化（大軍の帝国ほど分離を抑える）。0で従来のhold式＝現行恒等
    public double SecessionCultureAdditive = 3.0;   // 政14（**【R8点火2026-07-13＝3.0】** 旧0.5は効果≈0.1で分離閾値1.43に届かず実質関税駆動だった＝民族主因の分離が出なかった）：>0で文化/宗教距離×州少数派度×州不満を関税と独立の加算圧力に（民族主因の分離）。参考例（5.0の場合）＝強民族州(文化距離1×少数派0.8×不満0.8)で加算≈0.64＝関税項と合わせ閾値超えが可能に＝バルカン型の民族分離を実数化。0で旧の乗算構造のみ。EthnicEnabledの国のみ
    public double ConsciousnessFromSchoolingStock = 1.0;   /* #17保留:PolicyPolitics/Polityテスト */   // 政15（変換係数が現行の教育法を読む＝世代遅れなし）：混合比∈[0,1]。0=今期の教育法の即時値を全pop一律（現行恒等）／>0でpopの就学履歴ストックと混ぜ世代遅れを作る
    public double SchoolingStockSpeed = 0.02;   // 政15：就学履歴ストックが今期の変換係数へ寄る四半期速度（法改正が変換に効くまで数年）。ConsciousnessFromSchoolingStock=0では未使用
    public double CivilWarRebelSide = 0.5;   // 政13（内戦に反乱側がなく動員が現体制の鎮圧力を強化）：内戦徴集量のうちchallenge側の仮想戦力として累積計上する割合。0=反乱側戦力ゼロ＝challenge不変（現行恒等）／>0で内戦が長引くほど反乱側も増強
    // #16 連立内閣（正式な連立＝少数与党が第二党の経済綱領へ歩み寄る）：既存の CoalitionWeakensPlatform（綱領を弱くしか通せない）に加え、
    // 少数与党（議席<0.5）が第二党（連立相手）の関税/福祉/累進の綱領へ mix する。局所閉じ＝経済スライダー目標のみ（参政権/教育法/政体には非接触）。0=歩み寄り0＝現行ビット恒等。
    public double CoalitionPartnerPlatform = 0.25;  // 【0.5→0.25へ減衰2026-08-08作者裁定＝総政変+103の最大攪乱源・影響小なら減らす】少数与党が第二党綱領へ寄る強さ（実効mix率＝これ×連立相手の相対議席）。連立内閣の歩み寄り＝議会国の綱領が単独過激化しない。0で恒等
    public double IrreversibleEmancipation = 1.0;   // 政4：農奴解放・土地改革の不可逆化。0=現行（自由党綱領が生のLimited代入＝再農奴化バグ温存）／>0で自由党綱領を引き上げのみ(Math.Max)化＋StepEnumで両軸の減少禁止＝一度布告した解放は巻き戻せない
    public double SeatsFrozenBetweenElections = 1.0;   // 政7：選挙間の議席固定。0=PartySeatsを毎期の世論で上書き＝直接民主制的（VoteShares==PartySeats恒等）／>0で得票率はVoteShares(表示)に置きPartySeats(確定議席)は選挙時スナップショットで固定＝レームダック
    public double CoalitionWeakensPlatform = 1.0;   // 政8：連立妥協。0=与党綱領を100%実施（str=1）／>0かつ与党議席<0.5のとき経済綱領(関税・福祉・累進)を議席比で減衰＝過半数なき第一党の妥協
    public double ElectoralDistortion = 0.3;   // 政9：得票→議席の制度歪み。0=純比例代表（恒等）／>0で得票率を凸変換 v^(1+これ) 再正規化＝第一党の議席プレミアム・小党の死票
    public double DecayShockRepeatable = 1.0;      // C-中9（史実検証2026-07-22・**2026-07-23点火**）：制度疲労の改革の窓を(a)破産の回数エッジで2度目以降も開く (b)クールダウン中のショックを保留して窓が開いたら消費する。0=旧挙動（破産は1ゲーム1回・クールダウン中のショックは永久消失）＝厳密恒等
    // A-高3（史実検証2026-07-22）：穀物法の課税客体を GoodDef.GrainChain（麦15・小麦粉47）へ拡張するか。0=旧挙動＝Tier==Staple のみ＝厳密恒等。
    // 旧実装は課税対象が {パン,米,野菜,芋,トウモロコシ} で、史実の客体である麦・小麦粉が素通りしていた。パン(62)の投入は小麦粉のみなので
    // 穀物法Full でも小麦粉を輸入して国内製パンすれば完全に迂回でき、法が自己無効化していた（＝1846年型「地主 vs 産業資本」が経済的に空砲）。
    // 既存 Staple 集合は残し**追加のみ**（帯への差分を最小化）。封鎖狙撃 blockadeBias は窒息が趣旨なので Staple 判定のまま据え置き。
    public double CornLawGrainChainGate = 1.0;   // **2026-07-23点火**
    public double RepudiationCreditPenalty = 1.0;  // C-中1（史実検証2026-07-22・**2026-07-23点火**）：革命的債務否認に借入禁止期間（DefaultCooldownQuarters）を課すか。0=旧挙動（否認しても即座に再起債可＝一過性Anarchyが債務ロンダリング装置）＝厳密恒等
    // ConservativePlatformMilitarism（逆規約1=旧恒等/0=撤去）は第8段8-2（2026-07-28）で焼き込み削除＝撤去は恒久決定（2026-07-23点火）。逆規約の是正1/2
    // **再点火2026-07-31（07_再設計 第1弾1d）**：過去に全面版=1を「帯−3/人口崩れ」で差し戻した履歴があるが、
    // 08の新しい70%計器（6次元）で帯の物差し自体を引き直すため、B5手順（全実装→値レビュー→シミュレート→崩し変数リスト→調整）に従って再投入する。
    public double NonElectedSkipsPlatform = 1.0;   // 政10：非選挙政体への保守党綱領強制。0=全政体でApplyPlatformを適用（専制国家が保護関税/穀物法全面/累進ゼロに固定）／>0で選挙のない政体は綱領適用をスキップ＝経済政策目標をDecideQuarter(AIの経営)に委ねる。
    // **2026-07-24点火試験＝差し戻し**（政体フレーバー レバー1）：=1.0のbatch30で硬性ゲートは緑（破綻0/清8勝）だが帯がexact34/near66（基線37/68から−3/−2）・
    // 人口成長が英清とも×0.85（基線＝英1.02/清1.00）へ劣化＝44カ国の経済目標の一斉変化は帯を壊す。プレイヤーの自由度（doc動機）とのトレードオフ＝ユーザー裁定候補
    //（部分案＝プレイヤーのみ解除は設計思想⑤AI対等に反するため実装しない。再挑戦するなら綱領の一部軸のみスキップ等の狭い版から）
    public double InterestGroupHeadcountWeight = 0.25;   /* 法多様性L1有効化 2026-07-07 */ // 政11：利益集団の力の頭数按分。0=純富シェア（貧しい多数派の力≈0）／>0でbase=(1−これ)×富シェア+これ×人口シェア＝FranchiseVoiceを持つ層に頭数由来の力。実測：0.15で労組27/24/2・0.35で過回転→0.25採用
    public double PensionOldWeight = 2.5;               /* 法多様性L2 2026-07-07・Round2 2026-07-08：5.0→2.5 */ // 年金の受益者項：SocialSecurity Pref にブロックの高齢比率×これを加算＝高齢化した国だけ年金が通る（ビスマルク1889型分岐）。5.0はFull81%と過強（史実1914年時点の年金は独/丁/NZ程度＝少数派のはず）→2.5で「高齢化の進んだ国だけ」に絞る。0で受益者不在＝年金0/53の旧挙動
    public double LaborMilitancyConcession = 4.0;       /* 法多様性L3 2026-07-07 */ // 労働軸（労組容認・時短）への闘争譲歩：資本/旧支配層の反対が大衆闘争度で緩む（参政権SuffrageConcessionと同型）。閾値超過分のみ＝晩期の全国一斉開放を防ぐ
    public double LaborConcessionThreshold = 0.5;       /* 法多様性L3 2026-07-07 */ // 闘争譲歩の発火閾値＝max(0, 大衆平均闘争度−これ)。晩期の全国水準（≈0.38）では発火せず、高闘争国だけが譲歩を引き出す
    public double BourgeoisCoupWeight = 1.5;            /* 法多様性・政体 2026-07-07 */
    // ★2026-08-12（既定1.0＝是正側）：ブルジョア独裁の引き金に、一党支配→独裁化（Politics.cs:499）と**同じ危機ゲート**
    //   （MeanSatisfactionPol < DominanceInstabilitySatisfaction）を課す。0で旧挙動＝素通り。
    //   同じ現象を測る2本のゲートの一方だけが危機を要求していた非対称の解消であって、新しい閾値は増やしていない。
    public double BourgeoisCoupNeedsCrisis = 1.0; // ブルジョア独裁の引力＝ブルジョワ勢力×大衆平均闘争度（Politics:525設計コメントの配線）。議会制の立憲/共和のみ＝較正遮蔽。目標＝ブルジョワ独裁1/30→3/30
    // ★近代化投資（2026-08-04・作者指示「工業化投資を近代化投資に変更…制度疲労・技術力などを改善する効果を持つ」）
    public double ModernizationOldGuardResist = 0.5;  // 旧支配層の政治力シェア1.0あたり近代化投資が止まる割合（免許・検地・認可を握るのが旧支配層）。制度疲労が旧支配層の政治力を膨らませる既存経路と結び「改革を要する国ほど改革できない」が創発。0で乗算恒等
    public double ModernizationCostGdpShare = 1.0;   // frac/(1-frac) に掛かる係数。frac=0.3 で四半期GDPの約0.43倍＝年GDP比11%（発展途上国家の投資率として妥当）・frac=0.8 で4倍・frac→1 で発散。A=2.0 も試したが年GDP比21%は高すぎ、帯も経済規模−6.3で劣った（2026-08-04実測）。**国庫比でなく絶対額**にすることで「100%はほとんどの国で不可能」を成立させる。0で旧式（国庫×frac×0.5）＝厳密恒等
    public double ModernizationDecayCost = 1.5;       // 制度疲労1.0あたりの追加コスト倍率（清decay0.8で×2.2）＝科挙官僚制が鉄道を敷くのに要した余分
    public double ModernizationTechLagCost = 1.0;     // 世界の技術水準からの遅れ1.0あたりの追加コスト倍率＝技術を輸入に頼る国の割高さ
    public double ModernizationDecayRelief = 0.10;    // 実現した工業化度1あたりの制度疲労の低下。**0.02→0.10（2026-08-04）**：0.02では疲労0.8の解消に100年以上かかり、作者指示「近代化投資で疲労が取り除きやすくなるからペナルティを大きくする」の前提（取り除ける）が満たされないまま罰だけが重くなっていた（実測＝疲労を抱える露/墺が列強になれず列強・再現率が−11pt）。0.10で持続的な投資が約20年で疲労を解消＝明治型の速さ。0で恒等
    public double ModernizationTechGain = 0.0;        // ★2026-08-04：**0で確定**（直接の技術チャネルは置かない）。理由＝制度疲労は既に技術採用を律している（DecayTechAdoptWeight＝チャネル②）ので、近代化投資が制度疲労を削れば**技術はその経路で自動的に伸びる**。直接加点を併置すると二重計上になり、実測で「公教育の普(0.32) vs 宗教教育の露(0.31)」＝**教育が技術を分ける**という中核の不変条件が壊れた（テスト赤）。器は残す（残差比例の形）が既定は0
    public double IndustryInvestRegionCap = 5.0;        /* Phase2 2026-07-08 */ // 近代化投資（World.ApplyModernizationInvestment）の州上限＝この工業化度に達した州へは国庫投資を注がない（プレイヤー/AI共通。富国の首都一極への無限投資＝工業化度30超の暴走を防ぐ）
    public double StateRevenueAllTaxes = 1.0;   // 政12：国家の歳入要求の全税軸配線。0=消費税のみStateRevenueを得る（他税は財政逼迫で押せない）／>0で所得税・人頭税・土地税のNetSupportにStateRevenueを独立主体として直接加算＝戦時所得税が可能に
    public double IdeologyGateFromDevelopment = 0.5;   // 政16（load-bearing・**【現行0.5＝有効＝暦年と発展度を50/50ブレンド】**旧コメント「必ずdormant」は誤り）：社会/共産/帝国の暦年ゲートを『世界最先端の工業化度＋都市労働者シェア』由来の発展度ゲートへ置換する割合。0=暦年ゲートを厳密再現／1=発展度ゲート。線形ブレンド era=(1-g)×暦年+g×発展度
    public double IdeologyGateIndScale = 3.0;   // 政16：発展度スカラーの工業化正規化スケール（frontierInd/これ をClamp01）。非0必須（0除算回避）。IdeologyGateFromDevelopment=0では結果に無影響
    public double IdeologyGateIndDynamic = 0.0;   // 【#17イデオロギー暦年ゲートの工業化連動】＝**再計測2026-07-15＝0.3も却下**（calib24-24-24堅持だがexact41→39・清12→16・首位交代55.8→43.5＝0.3は1.0(exact40/首位59.1)より更に悪化＝非単調で好値なし）。旧記録：点火1.0でほぼ中立（exact41→40・首位交代55.8→59.1改善だがexact−1）＝exact優先で保留（機構は休眠温存）。ブレンド比gを固定でなく自国工業化度で動的化＝g=baseG+これ×(1−baseG)×devFactor（工業国ほどg→1＝自国の発展度でイデオロギーが創発・未工業国はbaseG）。0=固定g（現行と厳密恒等）
    public double IdeologyGateUrbanWeight = 0.5;   // 政16：発展度スカラーにおける都市労働者シェアの加重（0=工業化度のみ・1=都市シェアのみ）。IdeologyGateFromDevelopment=0では未使用
    public double IdeologyGateSpan = 0.35;   // 政16：発展度ゲートがonsetから全開(1)まで開く幅。非0必須（0除算回避）。狭いほど閾値付近で急に開く。IdeologyGateFromDevelopment=0では未使用
    public double IdeologyGateSocOnset = 0.20;   // 政16：社会主義が発展度で開き始めるonset（最も早い＝暦年1830相当）。IdeologyGateFromDevelopment=0では未使用
    public double IdeologyGateCommOnset = 0.35;   // 政16：共産主義の発展度onset（社会主義より遅い＝暦年1848相当）。IdeologyGateFromDevelopment=0では未使用
    public double IdeologyGateImpOnset = 0.50;   // 政16：帝国主義の発展度onset（最も遅い＝暦年1860相当）。IdeologyGateFromDevelopment=0では未使用
    public double CasualtiesFromContact = 1.0;   // 外2：戦死の戦力比例項の基準。0=p.Military（品質乗数込み・自軍規模のみ＝現行に厳密一致）／1=各戦線の実接触強度min(aPush,bPush)（遠隔戦は出血せず品質逆転も解消）。#17で再較正
    public double WarWearinessDecays = 1.0;   // 外3：非交戦国の厭戦の扱い。0=Step冒頭で即時0リセット（旧＝開戦抑止がtruceペア限定に縮退）／>0=WarWearinessDecayRateで指数減衰（休戦後も数年は厭戦が残り開戦抑止が効く）。バランス2026-07-07有効化：終戦翌月の再参戦（AI監査の愚行#5）を解消し敗戦国に回復期を与える＝首位交代を促す
    public double WarWearinessDecayRate = 0.97;   // 外3：WarWearinessDecays>0のときの非交戦国厭戦の月次残存率。WarWearinessDecays=0では未参照
    public double AbstractTargetReparations = 0.3;   // 外8：抽象標的(Nation==null=GDP0)への決定的勝利時の賠償原資＝敗者Treasuryのこの割合を移転（対清戦争型）。0=賠償0（現行に厳密一致）
    public double ThreatUsesColonyValue = 1.0;   /* #17有効化 */   // 外10：脅威評価・海軍シェアの植民地規模基準。0=植民地個数（旧式＝インド1個<小島3個）／>0=Σ Colony.Value（資源数＋人口）
    public double FrozenTensionDecays = 1.0;   // 外11：開戦経路が塞がれた（従属）ペアの緊張≥100の扱い。0=永久凍結（旧＝同盟不可/宥和判定を恒久的に歪める）／>0=FrozenTensionDecayRateの微小減衰を許す。バランス2026-07-07有効化：凍結緊張のデッドロック解消
    public double FrozenTensionDecayRate = 0.2;   // 外11：FrozenTensionDecays>0のとき開戦不能ペアの≥100緊張に課す月次減衰。FrozenTensionDecays=0では未参照
    public double FiscalExhaustionWarWeariness = 0.05;   // 外13：財政破綻の厭戦寄与＝(1-payRatio)にこの係数を掛けてWarExhaustionに月次加算（国庫枯渇＝戦費調達限界が講和事由に）。0=無影響（旧＝枯渇しても戦力3割を無期限維持）。バランス2026-07-07有効化：完全破産で約2.3年で厭戦満了＝破産国の無期限戦争（AI監査の愚行#4）を解消
    public double ConquestColonyMilitancy = 1.5;   // 外15＋02断線走査2026-07-28実効化：講和で武力奪取した植民地の初期不満＝これ×ColonizeAnnexMilitancy（旧・>0判定のみで値が式に現れず1.0でも100でも同一だった）。1.5＝武力奪取(0.45)＞無血併合(0.3)の序列＝アルジェリア型の抵抗。1.0で併合と同値・0で据え置き
    public double ColonialHoldDistanceDecay = 0.3;   // 外5・植民地保持の距離減衰（1あたり1万km・属国離反と同型）。>0で本国首都→植民地の海路距離でholdを割り引く＝地球の裏側は隣接島より保ちにくい。0で距離項なし＝現行と厳密一致
    public double ColonialHoldSharedArmy = 0.5;   // 外5・同時多発独立の兵力按分。>0で不穏植民地数に全軍を割り10植民地同時不穏なら各々への抑えが薄まる（戦争が戦線数で戦力を割るのと同型）。分母=1+これ×(不穏数−1)。0で分母1＝現行と厳密一致

    // === スカフォールド完成 2026-07-03（点火済み）===
    public double FoodOutputAnchorProduction = 1.0;   // 人2（扶養力の食料産出アンカーの生産ベース化）：DemographicStepのfoodAnchorの食料比を消費ベースfoodMet/foodNeed（クランプ∈[0,1]・0=現行と厳密一致）から生産ベースstapleOutput/foodNeed（全active州の主食実産出Σ÷主食必要量Σ・未クランプ）へブレンド。1で実食料産出(耕地×農業技術×豊凶を内包したLastProduced)から扶養人口を再構成＝農業増産がcapacity天井を押し上げる経路。CapacityFromFoodOutput=0でさらにdormant。上限撤去・再較正は#17

    // === 政治資本（マンデート余白）2026-07-09（会社PC）===
    // 法/スライダーの硬い「純支持>0」ゲートを「純支持>−θ」へ一般化：θ=MandateWeight×(Legitimacy−0.5)。
    // 高正統性＝反対を押し切って法を通せる（明治維新型）が、押し切った分だけ正統性を燃やす（MandateSpent→Politics が減算）＝自己制限的。
    // 低正統性＝符号が反転し人気のある法さえ滞る（旧体制の罠）。負側は MandateNegativeScale で半減＝死のスパイラル感を避ける非対称。
    public double StagePrereq = 1.0;   // ★2026-08-04（作者指示「参政権含めいくつかの法は1段階ずつしか進まないように（1つ前の段階を前提条件にする）」）：多段の法で1つ前の段を前提にする＝段の飛び越し禁止。StepEnumは元々1段ずつなので施行の速さは変わらず、変わるのは**遠い段を目標に置けない**こと＝プレイヤーもAIも各段を別々の決断として払う。0で従来と厳密一致（休眠）
    public double ConstitutionalMandateScale = 0.0;   // ★2026-08-04（作者指示「少なくとも参政権は固く」）：憲法級の法（参政権/秘密投票/★女性の権利は**選挙権の段だけ**＝2026-08-10 の段単位判定）に効くマンデート余白の倍率。0＝強権では押し切れない＝実際の支持が正でなければ通らない。誰が票を持つかは統治の土台であって政権の政治資本で動かせる政策ではない（1832/1867/1884の拡大はいずれも力の均衡が実際に動いた結果）。負側の余白（信を失った政権の滞り）は非適用＝非対称は維持。1で従来と厳密一致（休眠）
    public double MandateWeight = 0.3;          // マンデート余白の傾き：θ=これ×(Legitimacy−0.5)。Legitimacy=1.0で余白0.15。0で従来の硬い純支持>0ゲート＝現行と厳密一致（休眠可）。実測2026-07-09：参政権の梯子外しの純支持は闘争譲歩で−0.25近傍に漸近＝0.5(θ0.25)/0.4(θ0.2)は梯子を破る（仏+Modernizerで普通選挙が通る）→0.3で梯子保持を確認。これがフロア側の制約＝上げるなら梯子テストと要対measure
    public double MandateNegativeScale = 0.5;   // 正統性<0.5の負側θの減衰：全力(1.0)だと低正統性国が人気改革すら全停止＝死のスパイラル感が強すぎるため半減＝「滞るが不能ではない」。MandateWeight=0では未評価
    public double MandateSpendRate = 0.5;       // 余白でのみ通った一歩（純支持<0）の政治資本消費＝|純支持|×これを MandateSpent へ累積。正統性↓＝実効圧政(BaseCoercion×Legitimacy×funding)も連動して弱まる＝押し切る統治は鎮圧力も削る（意図した結合）
    public double MandateRecoveryRate = 0.035;   // 強権（MandateSpent）の四半期回復率（2026-07-26ユーザー裁定：旧LegitimacyRegenRate=0.1共用→専用係数へ分離。上限1.0クランプも同時廃止＝青天井に積めるが正統性減算の実コストは残る）。★2026-08-04：0.07→0.035（作者指摘「強権のたまりが早く、あまりに早期に近代的な法律を取り入れすぎる」）。時定数≈3.5年→≈7年＝押し切った代償が一世代近く残る。押し切りの連発ができなくなる
    public double PushedLawGrievance = 0.05;      // 1934拡張E4（2026-07-19・ユーザー「無理な法変更後は強権入手力が減少・政治的不安定から創発」）：純支持<0の法を余白で押し切ると反対ブロックpopの闘争度+これ×|純支持|×反対強度→急進派↑→正統性侵食↑→余白↓の創発ループ（強権の直接減算なし＝ユーザーの「直接的でない」指示）。
                                                 // **0.05点火（2026-07-19）**：点火時にseed7の不安定化が分離独立を誘発しMultiNationTestが世界保存破れ→調査の結果、分離独立(SecessionSpawnsNation)は正しく保存(ランタイムper-nation不変量プローブがクリーン)で、破れたのはテストの集計式がspawnの子baselineを勘定しない非対応だった（#107・テスト側を頑健化）。実リークなし＝点火維持

    // === 王権議会P0＝内部状態化 2026-07-10（出典＝設計doc「王権議会_史実精査」§3新規1-6/§4結論/§4-b協力度2次元/§5判断③・「設計メモ」§2段階(i)）===
    // ⚠嘘コメント是正（作業リスト2第2段2-1・2026-07-27）：旧見出し「全て休眠＝挙動への影響ゼロ」は**偽**＝P0導入時の記述のまま放置されていた。
    // 現在は直下の係数群が**稼働中**（P1動学フック点火済み＋CoopPublicRegime=世論の王権支持率/王権支持度ヘッダー・ParliamentControl=議会健全性UI・
    // CoopParliamentCrown=王権と議会の協力度などに読み手あり）。正確な読み手は docs/202607/20260727_政治系の再設計_部分完了.md（依存グラフ実測367項）を参照。
    public double CoopClassAffinityWeight = 0.5;      // 協力度（議会↔王権）の階級親和項の重み：王権の基盤=旧支配層（史実精査§5判断②）と与党の給源ブロック（保守=旧支配層+1/自由=0/社会=大衆−1）の距離。稼働中
    public double CoopPolicyGapWeight = 1.0;          // 協力度（議会↔王権）の政策距離項の重み：与党綱領（→Policy目標へ写像済み）と施行済み現行法/スライダーの正規化乖離＝立法の停滞度（憲法紛争1862型の凍結が高乖離に写る）。稼働中
    public double CoopConflictMemoryWeight = 1.0;     // 協力度（議会↔王権）の紛争記憶項の重み：既存 MandateSpent ストック（余白で反対を押し切った累積＝敵対の蓄積器・史実精査§4-b「新規状態を作らず参照」）をそのまま減算。稼働中
    // ArmyPayWeight / ArmyIdeologyWeight は第3段3-2（2026-07-27）で削除＝孤児係数（唯一の読み手 CoopArmyCrown が読み手ゼロの死蔵で同時削除。軍の給与/イデオロギーは ArmyAllegiance が担う）。
    public double ArmyMilitarismAffinity = 0.25;      // **将校の任免権の所在**∈[−1,1]×これ＝軍帰属の向き（＋君主が任免／−内閣が任免／0軍が自分の主）。★2026-08-18＝旧は親軍法ONで一律王権寄り＝**符号が逆だった**（軍が王政を倒す例が反復＝伯1889/葡1910/西1931）。軍帰属（pay×(lean+これ)）に効く
    // --- 王権議会P1＝動学6フック（2026-07-10・P0の観測軸を動学化・点火済み。値は各行）---
    public double SummonParliamentRate = 0.02;      // P1-H 破産召集（1789三部会）：緊縮(Austerity>0.5)の深さ×これ/四半期でParliamentControl↑。提案0.02
    public double GrantedControlOnReform = 0.3;    // P1-A 下賜（明治1889欽定）：上からの改革の遷移時にParliamentControlの床をこの値へ（弱い議会を与える）。提案0.3
    public double ParliamentBudgetVeto = 2.0;      // P1-C 予算闘争（憲法紛争1862）：所得税スライダーの抵抗に 統制力×max(0,−協力度)×これ を加算＝非協力議会は予算を通さない。提案2.0
    public double VictoryLegitBoost = 0.05;         // P1-D 勝利の免責（ビスマルク型）：決定的勝利で正統性ストック+これ×戦勝点＝敗戦ショックの対称。0.1は工業化の差別化を壊し**0.05で採用**（bisect2026-07-10）
    public double CrownRollbackRate = 0.02;         // P1-E ストルイピン後退：敵対議会(coop<−0.5)×高正統性(>0.7)×王権寄り軍(>0.3)でParliamentControl−これ/四半期。提案0.02
    public double AllegianceCoupWeight = 0.5;      // P1-F 軍帰属のクーデタ変調：軍政支持×=max(0,1−これ×ArmyAllegiance)＝王権に忠実な軍はクーデタしにくい。提案0.5
    // --- 王権議会F1＝州一揆（2026-07-10・点火済み）---
    public double RegionalRevoltThreshold = 0.25;   // 発火閾値：州平均闘争度×主食欠乏(1−FoodFill)がこれ超で蜂起（0=無効）。提案0.25（闘争0.6×欠乏0.4級で発火）
    public double RegionalRevoltStrength = 1.0;    // 蜂起の勢い係数（熱×州大衆規模×これ vs coerce＝Transitionのchallengeと同じ物差し）
    public int RegionalRevoltCooldown = 4;         // 発火後のクールダウン（四半期）＝同一国で年に何度も燃えない
    public double RevoltSuppressDeadFrac = 0.002;  // 鎮圧の戦死＝州大衆の0.2%（1848年級。貯蓄は遺族に残る＝貨幣保存非接触・人口台帳に計上）
    public double RevoltSuppressLegitCost = 0.05;  // 鎮圧の正統性コスト（ストックへ直接＝流血の記憶。regen0.1で数年かけ回復）
    public double RevoltConcessionSpend = 0.125;   // 譲歩の政治資本消費（余白押し切り1歩と同額＝負のマンデート）
    // --- 創発的国内勢力F3＝牙と変異（2026-07-12・F3a=永続化/変異は即時・F3b=内乱化はFactionRevoltScale>0で解禁）---
    public double FactionCohesionGrowth = 0.05;    // 結束の四半期成長率×(0.5+ブロック意識)（変異済みは2倍）。観測が続く運動体だけが育つ
    public double FactionCohesionDecay = 0.10;     // 不在クラスタの結束減衰（0.05未満×8Q不在で忘却）
    public double FactionForgetQuarters = 8;       // 忘却に要する連続不在四半期数（8Q＝2年）。結束0.05未満と両方満たすと勢力を除去
    public double FactionMutationRate = 0.002;      // 変異の受理率×危機（州の飢え/敗戦ショック）。独立RNG系列・1クラスタ1回。狙い＝太平天国級が清で125年0-2回（F3aで実測して調整）
    public double FactionMutationCrisisFloor = 0.5;   // 変異ロールの危機下限（平時は絶対に変異しない）
    public double MutantCohesionFloor = 0.5;       // 変異時の結束の床（旗の下の凝集）
    public double FactionRevoltScale = 1.0;        // **F3b主フラグ・1.0点火済み（稼働中）**：内乱化の勢い係数（規模×闘争×結束×これ vs coerce+湘軍）。0で牙なし＝F3aの観察のみ
    public double FactionSeniorityQuarters = 12;   // 02断線走査2026-07-28：年季飽和の四半期数（min(1, QuartersActive/これ)をFactionStrengthに乗算）＝3年で満額。0で恒等（旧挙動）
    public double FactionCohesionFightThreshold = 0.8;   // 内乱化に要る結束（≈持続3年超の組織運動のみ＝一揆や瞬間革命と役割分担）
    public int FactionConcessionSteps = 2;         // 経済決着：要求最上位の法を2段・以下1段のむ（F1譲歩の大型版）
    public double FactionConcessionSlider = 0.15;  // 経済決着：スライダー軸の強制移動量
    public double LoyalistMilitiaWeight = 0.5;     // 湘軍項：反乱と思想距離が遠いブロックが体制側で郷勇を組む重み（F3bで0.5から掃引）
    public double LoyalistDistanceFloor = 0.5;     // 湘軍が立つ最小の思想距離（近い反乱＝フロンド型には立たない）
    public double LoyalistHeresyBoost = 1.0;       // 異端（変異）反乱への郷勇の増し（曽国藩の檄）
    // --- F4 政党統一（2026-07-12・点火済み＝DynamicParties=1）---
    public double DynamicParties = 1.0;            // **F4主フラグ**：1=クラスタ由来の動的政党（統制力>0×参政権票の運動が政党化・族内で得票分割＝PartySeats/GoverningPartyは族の互換射影で不変）。0=常設3党のみ（厳密恒等）
    public double PartyFormCohesion = 0.3;         // 政党化に要るクラスタの結束（蜂起の0.8より低い＝議会経路は組織の敷居が低い）
    // --- P3b 連続動学（2026-07-12・点火済み＝遷移グラフの置換素子。出口はP2の床交差再ラベル）---
    public double ParliamentPressureRate = 0.04;    // 議会圧力：max(0, 代議制支持−現政体支持)×これ/四半期で統制力が育つ（漸進の立憲化＝グラフのジャンプの置換）
    public double CrownPressureRate = 0.04;         // 王権圧力：max(0, 王権形支持−代議制支持)×これ×正統性で統制力を巻き戻す（一般化した反動の常時項・P1-Eクーデタ型とは別）
    public double RepublicanDeposition = 1.0;      // >0で廃位イベント解禁：統制力≥立憲床×共和支持−立憲支持>保持力差＝王冠廃止（1792/1910ポルトガル・議決＝失脚/債務否認なし）
    // 王権の形の変異（07_再設計 §1＋A1裁定・2026-07-31＝**実体駆動へ再設計して点火**）。旧の支持座標駆動は1789年に亜細亜の専制が一斉絶対王政化＝
    // Abs/Des/Shoは登録簿が歴史を運ぶ（P2知見＝軸で区別しない）ため支持駆動は不適だった。新＝形ごとに固有の実体トリガー（幕府＝外圧/内圧・専制＝行政力の継続）。
    public double CrownFormMutation = 1.0;        // 主フラグ。0で変異なし（旧＝休眠）
    public double ShogunateEndTension = 40.0;     // 幕府が倒れる外圧＝対外緊張（黒船。TraditionalistLawGate の外圧(a)と同水準）
    public double ShogunateEndMilitancy = 0.5;    // 幕府が倒れる内圧＝大衆の闘争度（同ゲートの内圧(c)と同水準）。★内圧が外圧（緊張/200）を上回れば議会つきで終わる＝A1「どちらも許す」
    public double DespoticToAbsolutistAdmin = 0.6;      // 専制→絶対王政（官僚絶対主義）の行政効率の閾値
    public double DespoticToAbsolutistQuarters = 8.0;   // 同・継続四半期数（2年＝一時的な好調では変異しない）
    public double PolityGraphRetired = 1.0;        // **P3c主フラグ**：1=平和的漸進遷移（非奪取×改革派主導）をグラフから廃止＝連続動学＋床交差が担う。暴力革命・奪取はイベントのまま。0=従来（厳密恒等）
    // --- 政体形態の実績ストック（信認⇔失望・経路依存・2026-07-13・設計doc「形態別失望ストック」）---
    // 蓄積/減衰は書くだけ（P0観測と同型）＝いつ走っても恒等。読むのは Transition の注入のみで RegimeTrackRecordWeight=0なら無効（現行0.3＝有効）。
    public double RegimeRecordAccumRate = 0.02;    // CoopPublicRegime（満足−闘争）×これ/四半期で現政体系統の実績が符号のまま積む（+信認/−失望）
    public double RegimeRecordSuccessTenureGate = 20.0;  // 正の信認が満額になる在任年数（長期成功のみ信認へ寄る＝始まったばかりの形態は実績を持てない）。負の失望は在任に関わらず即時（失敗の刻印は速い）
    public double RegimeRecordDecay = 0.00346;     // 実績の四半期減衰率（半減期50年＝2世代・ユーザー指定）。信認も失望も同率で0へ薄れる（世代交代で忘れる）
    public double RegimeTrackRecordWeight = 0.3;   // **主フラグ**：Transition の各政体支持へ符号付き乗数 (1+これ×実績) を掛ける＝信認された形態は選ばれ/粘り、失望された形態は避けられる。0=読まない＝厳密恒等。**固着⇔カオスの直接ノブ**（正の信認=安定・負の失望=多様化）
    // --- 国民意識（市民的結束＝民主主義の前提・2026-07-13・設計doc「国民意識」）。蓄積は書くだけ（実値既定） ---
    // NationalConsciousnessInitial / NationBuildRate / NationBuildReligiousDrag / NationBuildCrisisWeight は第3段3-6（2026-07-27）で削除＝v1国民意識（到達不能）の専用係数。宗教civicは第5段5-5で新設計へ。
    public double NationBuildConscript = 0.5;      // 徴兵（兵士POP比）の重み＝国民軍の国民形成（ウェーバー「軍は国民の学校」）
    public double NationBuildCivicFloor = 0.3;     // 多民族の抵抗の下限＝drag=clamp(EthnicUnity+これ,0,1)＝天井でなく抵抗（civicナショナリズムで多民族でも克服可＝米/スイス）
    public double NationalConsciousnessCorruptionWeight = 0.2;  // **主フラグ**：⚠旧・汚職チャネル（civicGraft→Fiscal leak別項）は汚職V2恒久ONにつきC2-C5で物理撤去（2026-08-16）＝現在の生き読者は2箇所＝World.civicCarriesEthnic（代議制で民族の行政痩せを切る二重計上回避ゲート）と CrownParliament の国民意識蓄積チャネルゲート。0にすると両者の挙動が変わる＝**掃除対象外（読者あり）**。ゲートの意味の再裁定は較正ラウンドへ
    // P9 国民意識v2「購入モデル」（2026-07-17）：NCは育つものでなく買うもの（機会費用＋維持費で全国飽和を根治）。主フラグは2026-07-27にNationBuildPurchaseMode=1（常にv2）を焼き込み削除済み＝v1蓄積式へ戻す道は無い
    // P8 天命 DynasticMandate v1.1（2026-07-17・プローブ検証済み仕様）：前近代の正統性＝統治パフォーマンス直結。「パンの値段→天命→正統性→革命」。
    // Legitimacy（制度のストック・既存不変）と役割を完全分離＝Mandateは民のパフォーマンス評価EMA。⚠命名：Mandate単独は既存の政治資本（MandateSpent/MandateGate/MandateWeight）と衝突するため DynMandate 接頭辞
    public double DynasticMandateEnabled = 1;   // 点火1（2026-07-18）。0=状態更新も不走行＝厳密恒等（旧挙動）
    // P10 天命v1.2「再定義された天命」＝信任帝政ルート（2026-07-18・命名層はイベント不採用で除く＝機械的実体2片）：天命を捨てず再定義して近代化する第二の道（清の「もしも」・大政奉還後の天皇制）
    public double RedefinedMandateEnabled = 1;      // 点火1（2026-07-18計測）。0=両片とも不走行＝厳密恒等
    public double RedefinedMandateFloor = 0.6;      // ①正統性の下限＝立憲君主×王冠保持×高NC×高天命の時のみ Legitimacy≥これ×Mandate（加算でなく床＝二重計上なし）。「民の信任を得た皇帝はパンの値段ではもう滅びない」
    public double RedefinedMandateNcMin = 0.5;      // 高NCの閾値（信任帝政の資格）
    public double RedefinedMandateMandateMin = 0.6; // 高天命の閾値（⚠緩いと立憲固着＋仏が共和に届かない＝難しく較正）
    // P3 アヘン依存機構（2026-07-17・一般機構＝清専用スクリプトなし）：主フラグ=OpiumAddictionGrowth（既存・0=恒等）。低満足popが嗜好品アヘンを消費→州の依存ストック→労働/満足ペナルティ＋対外流出→輸入禁止の法→輸出国と緊張→戦争は既存機構
    // P4 統一戦争の動詞（2026-07-17・変体データ駆動）：適格×ナショシェア→必要州保有国への宣戦解禁（無償＝緊張・膨張度の前提なし）。開戦経路の新設のみ＝講和/属国化/成立/厭戦/反覇権合従は既存
    public double UnificationWarEnabled = 1;        // 点火1（2026-07-18）。0=恒等（動詞消滅・旧挙動）
    public double UnificationNatioShare = 0.25;     // ナショナリズムの国民シェア閾値（Ideologies.National[4]＝エリートの熱が統一の燃料）
    public double UnificationAiPursueChance = 0.7;  // AI追求確率（70%史実/30%見送り＝非史実の彩り。専用RNG系列で1draw）
    public int UnificationAiCooldownYears = 20;     // 見送り後の再判定クールダウン（年）
    public int UnificationAiWarGapYears = 3;        // 宣戦後の次判定間隔（年）＝1864→1866→1870の連続戦争の律動
    public double OpiumMiseryScale = 2.0;        // 素のアヘン需要の困窮ゲート＝baseNeed×clamp(これ×(1−満足),0,1)。満足な民は手を出さない・中毒は満足に関わらず必要
    public double OpiumLaborPenalty = 1.0;       // 依存が労働供給を蝕む＝成人労働×(1−これ×中毒度)（床0.5）
    public double OpiumSatisfactionPenalty = 0.0;// ⚠休眠2026-08-19（作者裁定「阿片も抜く。これは後で何とかする」）：満足度への直接【減算】＝思想⑨の裏返し。
                                                 // ★正しい形の候補＝「中毒者は阿片を**需要する**」（財の需要として立てれば、買えなければ NeedMet が下がり満足度が自然に落ちる）。旧0.5
                                                 // （旧注記：1.0はハーネス13/30＝満足↓→困窮ゲート消費↑の正帰還が強すぎ→0.5へ・2026-07-18）
    public double OpiumBanTensionRate = 2.5;     // 禁令中の輸出国との緊張蓄積/月（取締り・没収が敵意を積む＝林則徐→アヘン戦争。開戦閾値160へ数年で到達する規模）
    public double OpiumBanThreshold = 0.05;      // AIが禁令を出す全国平均中毒度の閾値（解除は×0.3のヒステリシス）
    public double DynMandateSatWeight = 0.6;    // perf: 満足重み×(未教育層加重の平均満足−0.5)×2（第5段5-3＝天命の母数を未教育層へ再定義）
    public double DynMandateFoodWeight = 1.0;   // perf: 食料重み×min(0, FoodFill−アンカー)
    public double DynMandateFoodAnchor = 0.8;   // 食料アンカー＝飢饉閾値基準（プローブ検証済み：1.0基準は慢性輸入国=英を常時罰し終盤BD化→0.8で解消。罰すべきは飢饉であって輸入依存ではない）
    public double DynMandateWarWeight = 0.4;    // perf: −戦争重み×WarExhaustion
    public double DynMandateGraftWeight = 0.5;  // perf: −汚職重み×実効汚職（制度側corruptionErosionは平均意識スケール＝近代の罰・こちらは未教育シェア減衰＝前近代の民の体感＝罰の担い手がクロスフェード＝二重計上不成立）
    public double DynMandateEmaRate = 0.08;     // EMA率/四半期（時定数≈3年）
    public double MandateReligiousCircuit = 1.0;   // 第5段5-5点火（2026-07-28）：天命の宗教媒介＝dynE×(1−これ×(1−開度×容量))。開度=国教法（無神論=0）・容量=聖職者/(文盲×ClergyMediationPerCapita)飽和。聖職者未モデル世界は素通し。0で旧恒等
    public double ClergyMediationPerCapita = 0.005;   // 第5段5-5：媒介飽和の基準＝文盲人口の0.5%の聖職者で容量1.0（仏1789実測≈1%＝開始時は各国飽和・世俗化/無神論で痩せて初めて効く）
    // DynMandateNcFade（手書きのNC減衰勾配）は第5段5-3（2026-07-27）で削除＝未教育人口シェアが天命の母数を自動で痩せさせる（改革のジレンマが導出になる）
    public double DynMandateAmplify = 0.8;      // 効果幅：侵食×clamp(1−0.8e,0.2,1.8)・自然回復×clamp(1+0.8e,0.2,1.8)。対称クリップ=安全弁
    public double NationBuildAccumRate = 0.03;         // v2蓄積率
    public double NationBuildDecayRate = 0.0025;       // v2減衰/四半期（1%/年起点・較正帯1〜2%/年。原案0.5%/年は半減期139年で弱すぎ）
    public double NationBuildCrisisDefense = 0.5;      // 危機乗数：交戦中（防衛戦争の代理・速度のみ＝天井は動かさない・無償の加算項は作らない）
    public double NationBuildCrisisCivilWar = 1.0;     // 危機乗数：革命/内戦
    public double NationBuildCrisisIndependence = 2.0; // 危機乗数：独立戦争（分離で生まれた国の初期戦争＝レヴェ・アン・マス）
    public double NationBuildInitialDefault = 0.075;   // v2初期値の既定（前国民的世界0.05〜0.1帯。「買ってないのに持ってる」一律0.3を廃止）。国別上書き=world.json nationalConsciousness0
    public double RadioNationWeight = 0.5;             // E3：ラジオ項の重み＝size加重RadioFill×これ。識字不要・検閲非依存（国営宣伝は国民精神を育てるが政治意識は育てない）。1920s以前はRadioFill0＝恒等
    // ★★国民意識のPOP化（docs/202607/20260731_国民意識のPOP化_部分完了.md【一部】.md・器2026-08-01）。作者指示「国民意識を国家ラベルでなく**POPにつけたい**（教育と同じ計算法に）。
    // そして**植民地あるいは本国と離れた州、非コアのPOPは国民意識が上がりづらい**仕組みが欲しい」。⚠倍率でなく構造から出す（思想②）。
    public double NationConsciousnessPerPop = 1.0;      // ★点火2026-08-01：国の国民意識＝POPのsize加重平均（0＝旧スカラー・厳密恒等）。
                                                       // ⚠首都と同じ緯度経度で中核民族100%のPOPは旧式と**同一の伸び**＝コンパクトで単一民族の国（日本・デンマーク）は動かない。
                                                       // 動くのは広大な多民族帝国（露・墺・英印）だけ＝「植民地は国民にならない」が構造から出る。
    public double NationConsciousnessReachDecay = 800.0; // 到達が半分になる首都からの距離km。★根拠＝『農民をフランス人に』の周縁
                                                       // （ブルターニュ約400km＝×0.67で遅れて追いつく／アルジェ1350km＝×0.37／デリー6700km＝×0.11＝ほぼ届かない）。
                                                       // ⚠大圏距離であって鉄道距離ではない（山脈も海峡も無視）＝過大評価側の既知の粗さ。
    public double NationConsciousnessCoreWeight = 0.8;  // 中核民族シェア0のPOPは伸びが×0.2まで落ちる。0にしない理由＝
                                                       // 少数民族も「その国の」意識を多少は持つ（チェコ人は墺の兵士として戦った）。
    public double CivicOpennessEnabled = 1.0;  // 【点火2026-08-09 ign_p12＝硬性緑・当てがい値除去】// ★P12残渣①（原典2026-07-17 P12節・実装2026-08-09）：**主フラグ**＝多民族抵抗の置き場所の一本化。
                                                       // 0（既定）＝現行のまま＝ビット恒等：国スカラー経路は速度drag（dragV2=clamp(EthnicUnity+NationBuildCivicFloor)）・
                                                       // POP経路は速度core（1−CoreWeight×(1−CoreEthnicShare)）＝民族抵抗が両経路に**構造として二重**（PerPop=1.0の現行live構成では
                                                       // 読み手3本が消費する値はPOP平均＝core側のみだが、lever<1混合・初回四半期の種にスカラー側dragが残る）。
                                                       // 1＝原典式へ置換：dragV2/coreを1.0に畳み、民族抵抗を**天井**へ移す＝popの国民化天井=ceiling×(1−民族距離×(1−開放度))・
                                                       // 民族距離=1−CoreEthnicShare（既存POP化と同じ代理・タスクAを待たない）・開放度=CrownParliament.CivicOpenness
                                                       // （共和経験×参政権×自由度の等分＝既存政治変数のみ・国別データなし）。スカラー経路も国平均の民族距離(1−EthnicUnity)で同型の天井
                                                       // ＝NC読み手3本（汚職Fiscal/総動員Military/ナショIdeology）への民族抵抗の効きが「天井経由の一本」になる。点火帯1.0
    public double MigrantCarriesConsciousness = 1.0;  // 【点火2026-08-09 同上・NC総量保存】// ★P12残渣②（原典「移住は加重平均で混合」・0801ログ:79の既知の限界の是正）：越境移民（MoveMigrants）が
                                                       // 出身popの国民意識を持参し、到着popとSize加重平均で混合＝NC×Size総量が移動の前後で保存（湧かず消えず）。
                                                       // 0（既定）＝現行＝移動分が到着国popの値を纏う（意識が国境で消える）＝ビット恒等。点火帯1.0
    // 1934拡張E5 秘密投票（「紙の参政権」是正）：発言権の鎮静効果を選挙の実在で変調。0（既定）で reality=1.0＝現行恒等（E9で点火し帯を測る＝忠実度が大きく動きうる主変更）
    public double SecretBallotGate = 1.0;   /* E9点火（1934拡張） */              // **主フラグ**：0で秘密投票の効果なし＝恒等。>0で下の reality で politicalGap の鎮静を変調
    public double OpenBallotReality = 0.9;             // 議会政体×公開投票＝選挙は実在するが買収/脅迫で歪む（英1872以前）。E9点火（1934拡張）＝0.6→0.9に緩和（較正への衝撃を抑えつつ秘密投票に価値を残す）
    public double PaperFranchiseReality = 0.7;         // 非議会政体（専制等）＝紙の参政権＝選挙の実在なし。E9点火＝0.3→0.7に緩和（専制の参政権発行の鎮静を弱めるが較正を壊さない範囲）
    public double BureaucracyAdminSpread = 0.12;       // 1934拡張E5 官僚制度：行政効率×(1+これ×段階)（猟官−1/資格任用0/専門+1）。0（既定）で恒等。**E9点火＝0.12**（専門+12%行政・猟官−12%＝プロイセン文官改革vsオスマン縁故）。既定MeritExam(0)で恒等
    // 1934拡張E5 社会保障法（旧スライダーの置換）：0で旧スライダー駆動＝恒等／1で5段の法が福祉水準SocialSecurityと年金を駆動（スライダー廃止・年金吸収）。E9点火
    public double SocialSecurityLawGate = 1.0;         // **主フラグ**：0で旧スライダー（現行厳密一致）／1で社会保障法が駆動。E9点火（1934拡張・目標0で無福祉＝較正中立）
    public double UnemploymentInsuranceRelief = 0.5;   // 失業保険段（法≥Unemployment）で失業の闘争度寄与を×(1−これ)＝失業給付が恐慌の政治的爆発を緩衝（ファシズムの防波堤・失業保険なしの国で恐慌→失業→ファシズム）。SocialSecurityLawGate=0で不読＝恒等
    // 1934拡張E6 女性教育権：女子教育→女性識字↑。0で恒等（E9点火）
    // ★2026-08-10（女性法の統合）：「女性参政権法の前提」という役目はこの係数から外れた＝梯子の段の並び（教育権→選挙権）が構造として担う。
    //   残る役目は**識字底上げの効き**のみ＝0で効果なし（恒等）／1で女子就学が出生転換を早める。
    public double WomenEducationGate = 1.0;            // **主フラグ**：0で効果なし＝恒等／1で女性識字底上げ。E9点火（既定＝梯子は None ＝較正中立）
    public double WomenEduLitBonus = 0.25;             // 女性の権利が教育権の段以上で femaleLit ×(1+これ)（上限=全体識字）＝女子就学が出生転換を早める
    // 1934拡張E6 国教法：寛容化ほど十分の一税↓＋宗教ドラグ↓。0で恒等（E9点火）
    public double StateReligionGate = 1.0;             // **主フラグ**：0で効果なし＝恒等／1で国教法が十分の一税と宗教ドラグを変調。E9点火（既定StateChurch＝較正中立）
    public double InnerFreedomTithe = 0.6;             // 内心の自由での十分の一税倍率（教会の税権が制限される）
    public double ReligiousFreedomTithe = 0.3;         // 信仰の自由での十分の一税倍率（さらに制限＝政教分離）
    // 1934拡張E6 独占禁止法：独占レント(塩/茶)の実効倍率。0で恒等（E9点火）
    public double AntitrustGate = 1.0;                 // **主フラグ**：0で効果なし＝MonopolyRentFactor常に1.0＝恒等／1で独禁法が独占レントを変調。E9点火（既定None＝較正中立）
    public double CartelBanRent = 0.6;                 // 談合禁止での独占レント倍率（私的談合を禁じるが国家専売は残る＝中間）
    public double TrustbustRent = 0.15;                // 独占の解体での独占レント倍率（トラスト解体＝ほぼ競争的）
    // 1934拡張E6 戦時配給法：封鎖の飢餓厭戦を緩和。0で恒等（E9点火）。戦時のみ発火＝単一国較正に無影響
    public double RationingGate = 1.0;                 // **主フラグ**：0で効果なし＝恒等／1で戦時配給が封鎖厭戦を変調。E9点火（既定false・戦時のみ＝較正中立）
    public double RationingBlockadeRelief = 0.5;       // 配給ありでの封鎖厭戦倍率（公平配給で飢餓の痛みが半減＝英国型）
    // 1934拡張E6 国有化法：該当部門の利潤を国庫へ。0で恒等（E9点火）
    public double NationalizationGate = 1.0;           // **主フラグ**：0で効果なし＝Region.NationalizedMask常に0＝恒等／1で国有化（5部門＋『全て』＝§11-6d統合後の6行）が発火。E9点火（既定全false＝較正中立）
    public double NationalizationStateShare = 1.0;     // 国有化部門の国営持分。NationalizationSeizureRate=0なら EconomyStep が stateFrac の**下限**として読む（1.0＝完全国有）／>0（★現既定）＝接収の**目標**（Scale のこの割合まで BuiltScale を奪う）へ役割が変わる
    // ★所有の表現を1本化する接収（作者裁定2026-08-10）。旧＝国有化法は stateFrac に下限を課すだけ・SellFactory は
    //   BuiltScale を消すだけで**別々の変数**を触っていた＝国有化部門の工場を払い下げると代金が国庫に入ったうえに
    //   利潤も国庫に入り続ける（所有の二重表現）。点火すると stateFrac の下限をやめ、`stateFrac = BuiltScale/Scale` の一本道になる。
    // ⚠補償は払わない（接収は接収＝金は動かない・保存則は不変）。代わりに**強権で押し切る**ものにする＝
    //   抑圧力（実効圧政/上限＋政体の専制度）＜抵抗（資本家ブロックの政治力×奪われる持分）なら**その月は0件**。
    public double NationalizationSeizureRate = 0.05;   // **主フラグ**★点火2026-08-29（夜間R22単独A/B batch30＝帯中立・破綻0。⚠発火頻度はAIの国有化採用に依存＝国有化シナリオでの実測は未・要観察）：接収の月次速度（Scale に対する比／月）。0＝旧経路（stateFrac の下限）
    // 以下3本は NationalizationSeizureRate>0 の**枝の中でしか読まれない**（★2026-08-29点火＝既定0.05でlive）。
    public double SeizureResistanceWeight = 1.0;       // 抵抗＝これ×資本家ブロックの政治力（InterestGroups.Blocs.Modern）×奪われる持分。0で無抵抗＝押し切り放題（点火時は1.0を既定とする＝作者裁定「よほど強権的でないと押さえつけられない」）
    public double SeizureMilitancyCost = 0.5;          // 押し切った代償①：資本家popの闘争度＋＝これ×奪った持分
    public double SeizureInvestmentChill = 1.0;        // 押し切った代償②：資本逃避＝Region.SeizureChill＋＝これ×奪った持分（私的投資予算に ×(1−chill)）
    public double SeizureChillDecay = 0.1;             // 資本逃避の月次減衰（chill ×= 1−これ）。0で永続
    // ★不満のある資本家は工場を買わない（作者裁定2026-08-10）＝接収↔売却の往復搾取を因果で閉じる。
    //   量は既存の Pop.Militancy（闘争度0..1）＝他の「政府への不満」の読み手と同じ物差し（新しい不満の定義を作らない）。
    //   0＝ゲート無効（常に買える）＝厳密恒等。>0＝投資家popの闘争度がこれを超えると買い手がつかない。
    //   AIの投げ売り（fiscalStress）も同じ CanSellFactory を通る＝対称。
    public double SoeSaleMilitancyCeil = 0.0;
    public int StateTargetMax = 99;                    // 国営工場カウンターの上限（作者仕様＝0〜99）
    // ★「国営持分が勝手に増えるのを止める」（作者裁定2026-08-10 B節「自動的な拡張なし」）。唯一の自動拡張＝EconomyStep の RgoCapitalShare
    //   （資本家の建設予算の一部を最も採算の良いRGOの BuiltScale へ回す）。BuiltScale は同時に stateFrac でもあるので、
    //   **私的な資本が農園/鉱山の地代を静かに国庫へ移していた**（国が何もしていないのに国営部門が育ち、地代が静かに国庫へ流れる）。
    //   >0 でこの拡張を止め、国営持分はカウンター（World.SetStateTarget）経由でのみ増える。0で厳密恒等（旧挙動）。
    // ★★点火＝1.0（2026-08-10）。副作用「RGOの能力が痩せないか」は rgoprobe で実測して確認した＝
    //   RGO の能力（Scale）は採算駆動（scaleTarget=1+margin を ScaleAdjustSpeed で追う・上限 ScaleMax）で決まり、
    //   BuiltScale はその**下限（ラチェット）**を与えていただけ。旧経路が131年で積む国営持分はRGO全体の数%規模＝
    //   能力の主因ではない（番人＝StateFactoryTests「自動拡張が止まってもRGOの能力は痩せない」）。
    public double StateShareCounterOnly = 1.0;   // ★点火2026-08-30（合成先行300Q＝経済+10.0/列強+7.6/法+3.5/exact+1.5/破綻0。604Q受け入れbatch30で最終確認・記録は20260830doc）＝作者裁定2026-08-10「自動的な拡張なし」をようやく実装どおりに（§1-3の嘘コメント事件）
    // ==== 参政権の範囲2法（作者裁定2026-08-16・docs/202608/20260815_失業プールと社会移動_部分完了.md 末尾「参政権の範囲2法」節）====
    // 植民地参政権（なし/自国民のみ/全面）＋移民原住民参政権（なし/あり）＝「誰が政治的国民か」を法にする。
    public double SuffrageScopeGate = 0.0;             // **主フラグ・休眠**：0で全効果が1命令も走らない厳密恒等（法選好Pref=0＝要求にも載らない・UIの2行も非表示＝natVis と同型）。
                                                       //   >0で算入率（植民地格の州＝植民地参政権 0/CoreEthnicShare/1・本国州の非中核分＝移民原住民参政権 0/1）が
                                                       //   発言権（InterestGroups.Blocs）・課税への同意（Fiscal consent の voice）・分離圧 ×(1−算入率)・少数派闘争度 ×(1−算入) に効く。
                                                       //   ⚠点火は再較正ラウンドのみ（AI工業化バースト2026-07-27と同じ扱い＝忠実度の暗黙の土台を動かす）

    // ==== プチブル利益束（作者承認2026-08-15「それでよい」・設計doc「プチブル利益束設計」タスク#84）====
    // 法選好（PolicyPreferences）の trad/modern/mass 3束に第4束「小営業」＝職人pop＋商人pop を足す。
    // 判定は常に構造マーカー（ArtisanPopIndex/MerchantPopIndex＝自営の所得を持つ階級）＝コードに固有名詞を書かない（設計書§3）。
    public double PettyInterestGate = 0.0;             // **主フラグ・休眠**：0で束分類が従来（職人=大衆・商人=近代）とビット恒等＝**分類切替そのものをゲート**（束の判定分岐が唯一の分岐点）。
                                                       //   >0で第4束が立つ＝対象4軸のみ独自の立場（独禁=賛成:企業集中×自営所得シェア／保護関税=賛成:自財の輸入競合シェア／
                                                       //   消費税=反対:実効率そのもの／累進・所得税=弱賛成:対アッパー相対所得）・他軸は旧束の値へフォールバック（gate=0と同じ値＝安全側・対象4本から広げない）。
                                                       //   読み手＝PolicyPreferences（NetSupport/OpposingPower/SupportBreakdown/PettyStance）・FactionSnapshot（クラスタ束分類・ComputeDemands）・
                                                       //   Factions（結束の意識）・Politics（勢力強度・郷勇の分類）・Government（押し切り/阻止遺恨のpop写像）。対立の発現は既存の集計から創発＝専用機構なし（設計書§2）。
                                                       //   ⚠点火は再較正ラウンドのみ（忠実度の暗黙の土台＝SuffrageScopeGate と同じ扱い）

    // ==== AI第1波 2026-08-16（設計doc「AI動詞被覆監査」第1波「AIに使わせる・機構不接触」・実装記録「AI第1波実装」）====
    // 作者方針＝AI=プレイヤー完全等価・難易度はAIを賢くする方向で上げる。実装時は3本とも既定0＝現行AIとビット恒等（分岐の外側に1命令も足さない）。
    // ★点火の現況（2026-08-16の点火梯子）＝AiLawGateUnified と AiLawWriteCoverage は**点火済み・live**／AiMobilization のみ保留＝0。
    public double AiLawGateUnified = 1.0;   // 【点火1.0・2026-08-16 点火梯子＝単独 exact36.2→41.6・near+4.4（単独最良のnear）／合成comp4に含む。合成comp4（12本＋海0.5）で exact41.6/near77.4/法63.2/貿易0.66・硬性緑】   // **主フラグ・点火済み（live）**：幽霊戦線の根絶（監査Top10の2位＝単一最大効果）。
                                            //   >0＝AI（Apply/DecideLaws/DecideModernLaws）の全法目標を「現行法から1段・Government.GateInfo（前提DAG＋純支持＋余白）が
                                            //   いま通る段だけ」に統一（SelfPlay.GateAllLawTargets）＝到達不能な法は目標に置かない。毎四半期 want を再計算するので
                                            //   状況が変われば自然に再挑戦＝諦めの恒久化はしない。0＝旧来の無ゲート直接代入（遠い目標を置きっぱなし）＝ビット恒等。
                                            //   点火A/Bの観点：CountOpenFronts のN（現行AIは毎四半期20本前後）が数本へ落ち、政治押し予算 (1/N)^0.5 が約1/4→1近くへ回復
                                            //   ＝AIの法到達がプレイヤーの「1本ずつ置く」と同じ土俵（2〜4倍速）。効く帯＝政体exact/near（改革の速度・後進専制の近代化時期）・
                                            //   法多様性・総政変（法が通る→闘争の捌け口が変わる）。
    public double AiMobilization = 0.0;     // **休眠（2026-08-16の点火梯子では保留＝この1本だけ0のまま）**：総動員のAI分岐（監査Top10の5位＝World.Mobilized はAIに書き手ゼロだった）。
                                            //   >0＝交戦中かつ（陣営戦力比で劣勢 or 敗色が深い＝存亡）のAIが Mobilized=true（プレイヤーと同じレバー＝
                                            //   Military.cs:128 の徴兵深度 0.12→0.22）。復員＝参戦中の戦争が消えた四半期に false（SelfPlay.DecideQuarter）。
                                            //   判定材料は既存量のみ（Diplomacy.SideMilitary＝同盟込み陣営戦力・war.Score）。0＝分岐ごと不実行＝ビット恒等。
                                            //   点火A/Bの観点：劣勢側が粘る＝戦争の長期化・厭戦↑・戦死↑・労働喪失＝1917型（敗色→革命）の帯と戦争頻度/再戦の計器に効く。
                                            //   プレイヤー専用だった「自分だけ総動員」の搾取が消える。
    public double AiLawWriteCoverage = 1.0;   // 【点火1.0・2026-08-16 点火梯子＝単独 exact41.6・near+2.9。合成comp4（12本＋海0.5）で exact41.6/near77.4/法63.2/貿易0.66・硬性緑】 // **点火済み（live）**：書き手ゼロ2法（移民制限法・国教法＝監査Top10の10位）のAI書き手（SelfPlay.DecideModernLaws）。
                                            //   >0＝既存量（移民流入率×大衆失業＝PolicyPreferences と同じ材料／支配ブロックの教義 DoctrineFrom）から目標を導き、
                                            //   **必ず StepLawToward 経由**（GateInfo確認・1段ずつ）で置く＝AiLawGateUnified の値に依らず（0でも）幽霊戦線を新設しない独立設計。
                                            //   0＝ブロックごと不実行＝ビット恒等。
                                            //   点火A/Bの観点：非選挙46カ国で2法が enum 既定値から初めて動く＝流入国の移民制限（排華移民法/白豪主義の型が新大陸で創発）・
                                            //   近代エリート/大衆支配国の宗教寛容化（十分の一税↓・識字移民）。移民フロー・人口・識字の帯に効く。

    // ==== 鋼市場AI側 2026-08-16（docs/202608/20260816_鋼市場診断_部分完了.md 修正#1〜#5・実装節＝同docの末尾）====
    // 作者方針＝**鋼の数値の外科手術は禁止**。先行者レント自体は史実どおりOK＝欠けているのは第二幕（レント→AI資本の参入→価格崩壊＝1873-96大不況）
    // ＝AI資本が同じレントを追って競争し、創発的にレントを侵食する形。5本ともAI判断側のみ（市場機構側の診断#6#7#8は次ラウンド＝今回は不可侵）。
    // 実装時は全て既定0＝現行AIとビット恒等（0では新しい読み書き・World注入・ProductionDiag呼び出しがゼロ）。年号・国名・IsPlayer分岐は書かない。
    // 点火の打順＝**#4→#2→#1→#5→#3**（診断の裁定＝リスク低→高：#4=純関数の読みだけ・#2=逆インセンティブの反転・#1=第二幕の本丸だが露規模常勝の前科・
    // #5=防衛側の反射・#3=三重ガード緩和は軍事独裁34%の前科）。★**5本とも2026-08-16の点火梯子で点火済み・live**（#1のみ0.6・他は1.0）。
    public double AiSupplyChainEyes = 1.0;   // 【点火1.0・2026-08-16 点火梯子＝単独 exact+1.9。合成comp4（12本＋海0.5）で exact41.6/near77.4/法63.2/貿易0.66・硬性緑】   // **点火済み（live）**（診断#4）：AIに連鎖の律速を読む目。>0＝TryBuildFacility が需要シグナル（eff>閾値）のある候補財について
                                             //   ProductionDiag.ExplainCost（純関数・従来は生産タブUIだけが読む＝プレイヤーが「供給:n%」で律速を遡るのと同じ情報＝AI/プレイヤー対称）を読み、
                                             //   配給率（Market.LastRation）が最も低い非労働投入が AiChainStarvedFill を割っていればその**上流財を候補に足して優先**する
                                             //   （score＝下流eff×(1+これ×(1−fill))＞下流自身＝律速点から建てる。StepLawToward が GateInfo を読むのと同じ「読み取りだけ」の作法）。
                                             //   0＝ProductionDiag を一切呼ばない＝恒等。点火A/Bで見る帯：**鋼レントの侵食**（鋼・素材の世界価格）・noviceprobe順位差・工業化。
    public double AiWorldPriceEntry = 1.0;   // 【点火1.0・2026-08-16 点火梯子＝単独 exact+0.4（逆インセンティブの反転）。合成comp4（12本＋海0.5）で exact41.6/near77.4/法63.2/貿易0.66・硬性緑】   // **点火済み（live）**（診断#2）：世界相対価格の注入と参入判断＝**逆インセンティブの反転**。
                                             //   旧＝relExcess=自国価格/参照−1 だけを読む＝安い輸入が来るほど国内価格が下がり「建てない」（史実「安い英国鋼→独米が製鉄所+関税」の真逆・診断B-3）。
                                             //   >0＝MultiNationSim が四半期同期（WorldTechLevel/IndustrialFrontier と同型）で Market.Price（265州平均）を World.WorldGoodsPrices へ注入し、
                                             //   TryBuildFacility の score が max(自国relExcess, 世界relExcess−輸送楔) に開く（楔＝TransportMargin＝BilateralMarket:289 の距離0下界を流用・新距離計算なし）。
                                             //   0＝注入自体をスキップ（World側は null のまま）＝恒等。点火A/Bで見る帯：鋼レントの侵食・noviceprobe順位・貿易/GDP。
    public double AiIndustrialCeilingFrontier = 0.6;   // 【点火0.6・2026-08-16 点火梯子＝単独 exact+3.8・**貿易0.83→1.03（唯一貿易を押し上げる腕）**。合成comp4（12本＋海0.5）で exact41.6/near77.4/法63.2/貿易0.66・硬性緑】 // **点火済み（live）**（診断#1・第二幕の本丸）：AI近代化投資の自主停止2.5（SelfPlay.IndustrializationCeiling）の世界前線連動。
                                             //   >0＝α として indGap の分母＝max(2.5, α×World.IndustrialFrontier)（IndustrialFrontier は配布済み＝MultiNationSim の四半期同期）。
                                             //   ⚠経緯（SelfPlay:1021「無制限だと露が規模常勝」）＝**点火は段階掃引 α=0.6/0.8/1.0**（一気に1.0へ上げない）。
                                             //   ChooseStance の indRoom(4.0)とダンピングの後発判定(<2.5)は今回触らない（別判断＝スタンス選択/輸出補助の閾値・記録のみ）。
                                             //   0＝定数2.5＝恒等。単一国は IndustrialFrontier=0 なので α>0 でも 2.5 のまま＝較正・単体テスト不変。
                                             //   点火A/Bで見る帯：**列強再現率と露**（規模常勝の再発監視）・工業化の帯・鋼レント。
    public double AiProtectiveTariff = 1.0;   // 【点火1.0・2026-08-16 点火梯子＝単独 exact+5.6・法+4.7＝単独最良のexact。合成comp4（12本＋海0.5）で exact41.6/near77.4/法63.2/貿易0.66・硬性緑】  // **点火済み（live）**（診断#5・防衛側）：保護関税の反射。>0＝自国財の SmoothedMargin<0 かつ当該財の輸入が急増
                                             //   （ImportsByGood の対EMA比＝「前年比」の最小実装。EMAはAI個体の記憶＝UtilityAgent._importEma）のとき
                                             //   TariffTarget を max(現行目標, 現行関税+TariffReactionMax×これ) へ（振幅は既存の通商反応の較正済み量0.25を流用・
                                             //   実効上限は既存の Move クランプ[TariffFloor,1]＝新しい上限を作らない）。**条件時のみ書く**＝関税スライダーは CountOpenFronts 対象＝
                                             //   幽霊戦線を作らない（条件が引けば翌四半期は Apply のスタンス目標が上書き＝戦線は自然に閉じる）。0＝EMA更新すらしない＝恒等。
                                             //   点火A/Bで見る帯：**貿易/GDP帯**（保護の壁で世界貿易が縮みすぎないか）・secondDeliver の底上げ＝鋼レント・関税の法多様性。
    public double AiBuildGuardRelax = 1.0;   // 【点火1.0・2026-08-16 点火梯子＝単独 exact+2.2（軍事独裁の頻度は硬性緑を確認）。合成comp4（12本＋海0.5）で exact41.6/near77.4/法63.2/貿易0.66・硬性緑】   // **点火済み（live）**（診断#3）：国営着工の三重ガード緩和。>0＝(a)pendingWill（未達の意志）の全国一律 return→**州ごと**の判定
                                             //   （意志の残る州だけ静止・他州は並行着工）(b)FiscalStress>0.0 の即 return→**借金ボタンと同じ規律**（強制義務＝維持費+利払いを国庫で賄える限り建てる）。
                                             //   月次出費≤FacilityBuildOutlayShare(0.10)×バッファの律速は**残す**（これが本命の予算制約＝並行着工でも金の天井は1本）。
                                             //   ⚠2026-08-04の前科（緩和0.5→工事出費が国庫を吸い軍事独裁5%→34%＝SelfPlay:93-95）＝当時は月次出費の律速が未実装だった。
                                             //   緩和は必ずこのフラグ経由・**点火A/Bで軍事独裁の頻度（PolityDistribution）を必ず見る**。0＝三重ガードそのまま＝恒等。

    // 1934拡張E7 ファシズム：イデオロギー10番目。戦間期(1919〜)の危機で反動＋国民主義が権威主義へ結晶。0で休眠＝シェア0＝配列長9と数値等価（E9点火）
    public double FascismGate = 0.5;                   // **主フラグ**：0でファシズムのイデオロギーシェアが常に0＝恒等／>0で創発の強さ（eraFasc×dev×mil×(反動+ナショ)に乗る）。E9点火＝0.5（eraFasc=0<1919で較正/忠実度1914断面に無影響）
    // E3の掃除：NationBuildCostPerPop/NationBuildSavingsFrac は旧・抽象拠出ブロック（Fiscal）の廃止で読み手ゼロ＝削除（新聞財の市場購入に置換）
    public double NationBuildMobilizationWeight = 0.5;  // **主フラグ**：戦時徴兵の深さ（conscriptFrac）を国民意識でゲート＝大規模動員（nation-in-arms）には高い国民意識が要る。低国民意識/多民族は総動員が届かず浅い軍のみ（脱走・不服従＝1793 levée en masse vs 墺洪の限定動員）。conscriptFrac×=Max(0.05,1−これ×(1−NC))。0=恒等。EthnicUnityの軍質(UnityMilitaryQuality=量でなく質)とは別チャネル
    // --- 国家アイデンティティ（変名・formable・2026-07-12・点火済み2026-07-27）---
    public double EnableFormations = 1.0;          // **変名規則の主フラグ**：1=Formations.Rules（イタリア/北ドイツ連邦/ドイツ/神聖ローマ/ビザンツ/ローマ）を四半期チェック。0=変名は一切起きない（厳密恒等）
    public double FormationLegitimacyBoost = 0.1;  // 成立の威信：変名時に正統性へ一回加算（第4段4-2点火・2026-07-27）
    public double FormationCapitalMove = 1.0;      // 成立時の遷都（NewCapitalへ・第4段4-1配線＋点火・2026-07-27）＝約35規則の死蔵NewCapitalを活かす（伊統一→ローマ等）。0で遷都なし
    // ★植民地のラベル化（器2026-08-01）：州が「中核」と見なされる保有年数。作者裁定＝**1633年から保有**（1783−150）。
    // ⚠これは倍率でも特例でもなく**時代不変の線引き**（150年＝おおよそ5世代＝「昔から自国」と見なされる長さ）。
    // ★★変名機構の一般化（docs/202607/20260731_変名機構の一般化_部分完了.md【一部】.md・器2026-08-01）：手書き40ルールと州名500の直書きを、
    // 「文化ラベル→その文化の州の集合」から**自動生成される規則**へ置き換える。⚠州名を1つも書かないので州の増減に追随する
    //（アフリカ勢力の追加・内戦分裂の建国と**国名表を共有できる**のが本題）。判定コードは1行も足さない（既存の RequiredAll / AnyOfSet がそのまま評価する）。
    //   ★点火2026-08-13（実測10シード・硬性ゲート全緑）：帯は −3.6pt だが**変名の発生が26回→33回**＝機構が実際に働き始めた
    //   （2件の致命バグ＝UnificationTargets の AnyOfSet 盲点・存在しない文化キー2行 を同日に修正した上での点火）。
    //   作者裁定⑤「帯の悪化だけでは差し戻さない」に従い採用。
    public double CultureFormationGate = 1.0;       // 主フラグ：0＝自動生成規則を一切列挙しない＝CultureRealms 型に触れない＝厳密恒等
    public double CultureFormationNeedsGain = 1.0;  // 自動生成規則に「開幕より同文化の州を増やした」ことを要件として課す（Gate=0 では読み手ゼロ）
    public double CoreHeldYears = 150.0;
    public double SecessionSpawnsNation = 1.0;     // **分離独立の建国フラグ**：1=分離戦勝利の州をLocked休眠でなく新国家（新World＋新Power）としてスポーン。0=従来のLocked化（厳密恒等）。多国シム（StepsDiplomacy=false）でのみ実効

    // ★★内戦による国家分裂（docs/202607/20260731_内戦による国家分裂_部分完了.md【一部】.md・器2026-08-01）：
    // 0＝決着は従来の二値（挑戦力 > 圧政+民兵 で反乱勝利）＝**厳密恒等**／1＝**州が陣営を選び**、両陣営が州を保持したまま拮抗すれば国が2つに割れる。
    // ★拮抗の帯は**新設しない**——発火側にしか使われていない CivilWarLandslideRatio(1.8) を決着側にも使う（同じ定数で「拮抗か圧勝か」を分ける）。
    // ★州の陣営は Ideologies.Regional（National の反復元を r.Pops に替えた同型）＝**国名も文化名も出てこない**（思想②）。
    // ★★差し戻し2026-08-01（実測で確定）。**この機構は帝国を丸ごと解体していた。**
    // 実測（popprobe・単一シード・Q524の州数）：
    //   分裂ON  → 英1州・清1州(人口20万)・普1州     分裂OFF → 英5州・清9州(人口35万)・普5州
    // 原因＝分裂の条件「その州のPOPが反乱の目標政体を現政体より支持するか」は、**内戦中は国全体の思想が反乱側へ寄る**ため
    //   ほぼ全州で成立する。首都だけ除外しても「16州→1州」が1イベントで起きる＝「南部が離れる」と「国が消える」を区別できない。
    // ⚠人口次元の「英×0.99」「清×0.74」は**人口の話ではなく、この解体の話だった**（アメリカは5州を保ち×10.7で伸びている
    //   ＝人口モデル自体は正常）。★再点火するなら、分離する州を「首都から連続した少数派の塊」に限る設計が要る（別ラウンド）。
    public double CivilWarSplitEnabled = 1.0;   // ★再点火2026-08-29（作者裁定「硬性緑なら点火でよい」・R15 batch30＝破綻0/分裂36回/スペイン常勝は20→16へ改善。人口−5.8の代償は上の注記どおり＝英停滞の符号を含み記録済み）。器→実機能：拮抗した内戦は国を割る
    // ==== 内戦を戦争に一元化（docs/202608/20260827_内戦を戦争に一元化する_部分完了.md・2026-08-30実装）＝主フラグ点火済み・FactionJoinMilitancy のみ休眠 ====
    public double CivilWarAsWar = 1.0;   // ★点火2026-08-30（合成先行300Q＝経済+10.0/列強+7.6/法+3.5/exact+1.5/破綻0。604Q受け入れbatch30で最終確認・記録は20260830doc）              // **主フラグ**：蜂起＝即座に反乱国家を建て（SpawnNation を決着時→開戦時へ）既存の戦争システムで戦う。決着＝政府勝利→再併合／反乱勝利→親へ政体change＋再併合／白紙→分断存続（台湾型）。0＝旧・4年タイマー内戦＝厳密恒等
    public double FactionJoinMilitancy = 0.0;       // 段2a：派閥の頭数に入るPOPの闘争度の下限（0＝全員参加＝現行と厳密恒等）。運動の規模を述語から導出する第一歩
    public double FactionRejectionMutation = 0.5;   // ★点火2026-08-30（合成先行300Q＝経済+10.0/列強+7.6/法+3.5/exact+1.5/破綻0。604Q受け入れbatch30で最終確認・記録は20260830doc）   // 段3：拒否の累積が変異の引き金になる強さ（危機とmax合成）。0＝拒否カウンタは積むだけ＝読み手なし＝厳密恒等。弾圧・対決・別軸譲歩（本丸拒否）が積み、受諾で解消
    public double FactionSuppressionOmit = 1.0;   // ★点火2026-08-30（合成先行300Q＝経済+10.0/列強+7.6/法+3.5/exact+1.5/破綻0。604Q受け入れbatch30で最終確認・記録は20260830doc）＝弾圧の択は消滅（作者裁定「放置＝事実上の弾圧」）     // 段1（内戦一元化doc §5・作者裁定「弾圧は完全オミット・放置＝事実上の弾圧」）：1でAI/プレイヤーとも鎮圧の択が消える＝譲歩か対決の2択（史実の決定変数は「要求を通すか」の1本）。0＝旧3択＝厳密恒等
    public double FactionMergeRangeKm = 800.0;   // ★点火2026-08-30（合成先行300Q＝経済+10.0/列強+7.6/法+3.5/exact+1.5/破綻0。604Q受け入れbatch30で最終確認・記録は20260830doc）＝合流の距離（太平天国の北上スケール）        // 段6（内戦一元化doc・唯一の新規＝合流）：同ブロック×同イデオ×同変異状態の派閥がこの距離内なら大が小を吸収（結束継ぎ足し）。0＝1命令も走らない＝厳密恒等。太平天国の北上の物理
    public double FactionMergeCohesionGain = 0.5;   // 合流時に勝者へ継ぎ足す結束の割合（FactionMergeRangeKm>0のときのみ読む）
    // --- 王権議会P2＝ラベル導出化（2026-07-11・点火済み）---
    public double PolityLabelFromAxes = 1.0;       // P2主フラグ：1=政体ラベルを登録簿＋議会統制力から導出（EMA停止・遷移PCジャンプ・下賜はPC床のみ・床交差の再ラベル）。0=旧・ラベル真実源（厳密恒等）
    // ★2026-08-12（バグ修正・既定1.0＝是正側）：王冠も奪取も無い国で統制力が立憲床を割ったときの政体ラベル。
    //   1=共和国のまま（議会の弱い共和国）／0=旧挙動＝BourgeoisDictatorship（CrownParliament.LabelFromAxes の
    //   `_ =>` 枝＝自身のコメントが「通常到達不能」と宣言しているのに Crown=None の共和国では必ず到達していた）。
    //   旧挙動の被害＝アメリカが反動政体へ落ち、自由化ラチェットが外れて参政権と報道を各1段剥奪される（1923年 実測：
    //   AdultMale→Census・FreePress→Censorship・識字28%・技術3.25で列強から脱落）。奪った主体が居ないのに独裁を名乗らせない。
    public double CrownlessCollapseKeepsRepublic = 1.0;
    public double ConstitutionalControlFloor = 0.45;   // 立憲化の床：ParliamentControl≥これで立憲/共和ラベル（下賜0.3<床＝弱い議会ではラベル不変＝プロイセン/明治型の自然点）
    public double ConstitutionalControlExit = 0.35;    // 立憲の下抜け（ヒステリシス）：これ以下で専制系へ戻る（墺斯曼1878停止・ちらつき防止）
    // ⚠**読み手ゼロ**（2026-08-01の全数走査で確定）。値を変えても何も起きない。★削除しないのは、これが
    //   「政体ラベルを決める閾値として設計されたが実装が入っていない」＝**未実装の発見**だからである（消すと発見ごと消える）。
    public double RepublicControlFloor = 0.85;         // 軸→法：PC≥これで建国参政権AdultMale（共和級の議会支配）

    // ==== トリレンマを閉じる（2026-08-13・docs/202608/20260812_トリレンマを閉じる_完了.md）====
    // 現状は3つ（兌換の維持・資本の自由・金融政策の自律）を同時に持てていた＝トリレンマを破っていた。閉じるのに要るのは2つだけ：
    //   ①資本移動が**法**になる（いまは関税の従属変数＝「関税は高いが資本は自由」な独/米が表現できない）
    //   ②「兌換維持＋資本自由」のときだけ金利が**帰結**になる（★史実＝誰も金融政策の自律を選ばなかった）
    // ⚠新しい概念を1つも置かない——効き先も目標カバー率も既存の配線（ForeignBondCapacity / GoldCoverMin）をそのまま使う。
    public double CapitalMobilityLawGate = 1.0;        // ★点火2026-08-13（同一ソースA/B：◎7割帯 16→21・政体exact +1.8・経済規模 +2.5／人口 −2.9・領土本国 −2.5）。0で openness は旧式（関税の従属変数）＝厳密恒等／1で資本移動の法から導出＝関税との連動を切る
    public double CapitalControlOpenness = 0.25;       // 規制下の資本開放度。0にしない（★密輸と同じ理由＝規制しても抜け道はあった。1930年代の資本統制も完全ではない）
    public double CapitalControlPrefScale = 1.0;       // 資本の反対の強さ＝対外保有(CapitalAbroad÷名目GDP)に掛ける倍率。対外投資を持たない国では反対が立たない
    public double TrilemmaRateGate = 1.0;              // ★点火2026-08-13（上の資本移動の法と**対**で意味を持つ＝2つ揃って初めてトリレンマが閉じる）。0で金利は常にレバー＝厳密恒等／1で「兌換維持＋資本自由」のときだけ金利が自動（＝操作不能）
    // ==== 銀本位と大デフレ（2026-08-13・docs/202608/20260812_銀本位と大デフレ.REVERTED_部分完了.md）====
    // ★通貨制度の法を2値（不換/金）から3値（不換/銀/金）へ開き、造幣を「本位金属の準備需要」へ一般化する。
    // ⚠これで1870年代の銀暴落が**内生する**：独が金へ移る→独の銀需要が消える→他国が追随→需要曲線そのものが下へ落ちる
    //   （★価格弾力性＝需要曲線上の移動では戻せない＝これが史実の大デフレ）。
    // ★★造幣の準備需要を需要として計上する（2026-08-13・実測で発見）。0で旧来＝書かない＝厳密恒等／1で全量を計上。
    // ⚠GoldMintFraction は既定 live なので、これを点火すると**金の市場も動く**＝必ず単独バッチで測る。
    public double MintDemandCounted = 1.0;   // ★点火2026-08-14（会計の欠落の是正＝正しい挙動）。⚠帯の代償＝◎7割帯 26→21・法 −2.3・列強再現率 −2.5（政体exact +1.8・領土本国 +3.3・逸脱過多 −1）。#17の同時再較正で見直す
    // ★★自由鋳造＝価格の床（2026-08-14・作者裁定）。史実の銀の暴落は「需要曲線が下にずれた」のではなく**床が抜けた**：
    //   造幣局は平価で**数量無制限**に買う約束（free coinage）＝市場価格はその水準を割れない。独1871→ラテン同盟1874/78→米1873→印1893と
    //   各国が造幣局を閉じる（closing the mints）たびに床が消え、金銀比価は15.5:1→30:1(1890s)→39:1(1902)へ。
    //   ⚠旧実装は「産出の20%まで・国内鉱山限定」＝**上限つきの買い手**で、これを消しても需要曲線が1/6ずれるだけ＝暴落の余地が構造的に無かった。
    //   ★金と銀に非対称な規則は書かない（作者裁定＝金の暴落も原理的に起こりうる。史実で金が暴落しなかったのは覇権国が金にいたという初期条件）。
    // ★★カテゴリ別の供給弾力性（2026-08-14・作者裁定「生産力の伸びはカテゴリでキャップすべき。工業製品は工場を拡張できるため
    //   すぐに増産できても構わないが、農作物や鉱物はそうではない。掘れば掘るだけ採れるというモデルが誤っている」）。
    // ★実測の症状＝造幣の standing offer（床）に金の産出が**13.3倍**で応答し、価格が限界費用に固定された（銀/金±1.5%＝暴落不能）。
    //   鉱山が工場と同じ ScaleMax=3.0・同じ調整速度で拡張できる＝供給が完全弾力＝どんな需要ショックも価格に残らない。
    // ★史実＝石炭も金も産出は大きく伸びたが、その担い手は**新しい鉱脈の発見**（加州1848・ランド1886）＝塊で来る。
    //   既存の鉱山の増産余地は坑道の深化＝遅くて限界がある。発見の塊は既存の bonanza イベント（MineralBonanzaCeil）が担う。
    // ⚠漁獲(20)は対象外（土地を占めない唯一のRGO＝既存の記録どおり）。工場は無変更。
    // ★★鉱脈＝在庫（2026-08-14・作者裁定「自然がキャップになっていない。枯渇が確率モデルであることに問題がある。
    //   枯渇率は採掘量により増加すべき」）。旧＝年3%のサイコロ＝掘る量と無関係（触っていない鉱山と剥ぎ取っている鉱山が同率で枯れる宝くじ）。
    // ★新＝鉱脈は有限の在庫：掘った分だけ減る→残量が膝を切ると品位が落ちる（深掘り・低品位鉱へ）→産出が自然に減衰。
    //   **決定論**（サイコロなし＝採掘量の関数）。発見（bonanza）だけは塊で乱数のまま＝地質の発見は本当に偶然だった（枯渇の不満は掘削と無関係な点）。
    //   点火時は旧・確率枯渇イベントを止める（乱数は引き続ける＝RNG消費順を保つ既存の作法どおり）。
    public double DepletionFromExtraction = 1.0;  // ★点火2026-08-14（上と対＝自然の壁。作者裁定「枯渇が確率モデルであることに問題・枯渇率は採掘量により増加すべき」）。0で枯渇は従来の確率イベントのみ＝厳密恒等
    public double DepositYearsAtBirth = 100.0;    // 初期鉱脈の大きさ＝開始時の産出率で掘り続けて何年分か（3倍掘れば33年で膝に届く）
    public double DepositGradeKnee = 0.5;         // 残量がこの割合を切ると品位が線形に低下し始める（浅い高品位層が尽きる点）
    public double DepositGradeFloor = 0.15;       // 掘り尽くしたあとの品位（深部の残滓＝ゼロにしない。閉山は採算側が決める）
    public double BonanzaDepositYears = 60.0;     // 発見イベントが鉱脈に足す量（初期率換算の年数）＝発見が在庫も補充する
    // ★貴族の投資（20260814_貴族が保守に固着する理由・裁定待ち一覧§3で採用推奨）。原因の実測＝CapitalMarket の投資家判定が
    //   IsModernElite のみ＝Closed（貴族・聖職）を排除→earned が永遠に0→rentier=1→伝統が最大固定。
    //   1で Closed も投資家へ（強度の割引=6c・聖職の分離=6a は観測後）。0＝厳密恒等。
    // ★汚職の再設計 C1（20260814_汚職をサブシステムにする・作者裁定「それでよい」＝(1−行政)×(1−監視)）。
    //   旧＝(1−AdminEfficiency)×(1−CleanGovernance)＝清廉度は根絶費で買うストック（深さ3＋corruptionRoomの自己言及）。
    //   新＝監視は**法から導出**（報道自由・資格任用・議会の予算権のnoisy-or）＝動詞と自己言及が消える。
    // ★資本逃避の受け皿（2026-08-14・外交観測 diploprobe が照らした会計非対称の是正）。0＝旧（受け皿なし＝幻の対外資産）＝厳密恒等。
    public double DomesticFlightHasHost = 0.0;
    public double OversightFactorScale = 1.0;   // ★監視3因子の強度（2026-08-15・uishotで発覚した「報道の自由だけで汚職ゼロ」の是正レバー）。1.0＝旧とビット恒等（press自由1.0→noisy-or飽和→汚職0）。<1で「どの制度も単独では監視を完成させない」＝金ぴか時代の米（自由な報道×猟官制×汚職）が表現できる。設計値0.6（3つ揃えて0.94・単独0.6）。点火はA/B
    public double CorruptionCoreV2 = 1.0;   // ★点火2026-08-15（ign_corr・同一ソースA/B seeds1-10）：汚職＝(1−行政)×(1−監視noisy-or)・漏れは官職地代（99_実装ログ§4-11/§4-13）。帯＝exact+0.9/本国+4.2/列強−6.2/経済−3.8（列強はノイズ床±3-5をやや超過＝Search再較正キューで回収・方針「帯の悪化だけでは差し戻さない」）。副信号＝変名33→45・分離43→33・再戦ペア41.5→35.4＝制度疲労の会計是正で統一が進み反復戦争が減る。⚠恒久ON裁定＝旧機構（CleanGovernance/AntiCorruption系）はC2-C5で物理撤去済み（2026-08-16）＝0に戻す道は消滅・エンジンはもうこの係数で分岐しない（点火記録と番人テスト CorruptionCoreV2Tests のみが読む）
    public double NobleInvests = 0.0;
    public double RgoElasticityGate = 1.0;      // ★点火2026-08-14（n24同一ソースA/B：経済規模+15.0・列強再現率+7.5・領土植民地+5.8・人口+4.3／政体exact−1.6・⚠逸脱過多9→15＝記録）。0で全カテゴリ従来（上限・速度一律）＝厳密恒等
    public double MineralScaleCap = 1.5;        // 鉱物RGOの操業規模上限（ScaleMax=3.0の半分＝既存鉱脈の増産余地は+50%まで。大増産は発見と新州の仕事）
    public double FarmScaleCap = 3.0;           // ★2.0→3.0（2026-08-14実測＝2.0は1州国家で食料が頭打ち→ハノーファー満足度0.04＝飢餓でハーネス赤）。畑の「すぐには増やせない」は上の速度1/4が担い、上限は工場と同じ＝開墾の余地自体は否定しない
    public double RgoScaleSpeedFactor = 0.25;   // 鉱山・畑の規模調整速度の倍率（坑道・開墾＝年単位。時定数は均衡を動かさない＝掃討基準の免除カテゴリ）
    public double MintPriceFloorGate = 1.0;   // **主フラグ**★点火2026-08-29（夜間R20造幣3本クラスタA/B batch30＝列強+5.8・破綻0）：0で旧来（産出比例上限・国内鉱山限定）／1で自由鋳造＝平価未満なら在庫から買い上げる（床）
    public double MintFloorBuyRate = 0.25;    // 床モードの月次購入率（在庫のこの割合まで/月）。1.0＝即時全量は買い→価格急騰→停止→再蓄積の振動リスク
    public double MintReserveSellRate = 0.08; // 法が本位金属を捨てたあと準備を市場へ売る月次率（独1873-79のターラー銀売却＝暴落を深めた投げ売り。売り切りに約1年）
    // ==== 銀本位の史実度（2026-08-21・作者裁定「原因究明し原則に従って修正」→同日点火）====
    // 【点火1.0・2026-08-21 銀本位ラウンド＝4係数一括（SilverStandardGate/SilverLightDiscipline/GoldStandardIndThreshold 1.5→3.5/MonetaryPeerPullScale 0→5）。
    //   同一ソースA/B seeds1-10（snap5＝親基線37f6bfe系）：◎7割帯 11→17・逸脱過多 9→7・法+1.9・植民地+3.4・人口+1.4／
    //   代償=経済規模−5.0・政体exact−2.3・列強再現−2.5（記録して進む・#17再較正キューへ）。硬性全緑・savetest緑。
    //   形＝1783年[不換0/銀61/金0]の銀本位世界→70年の先行期間→1853年起点の倍々雪崩→1914年に銀圏12/14一致（清・ペルシャ・
    //   アフガニスタン・中央アジア3・アラビア・イエメン・オマーン・エチオピア・ラオス・西山朝）。休眠時は銀0/14・1803年に金16の氾濫だった。
    //   ⚠差し戻すときはこの4係数を戻せば旧挙動へ完全に帰る（SilverStandardGate=0;SilverLightDiscipline=0;GoldStandardIndThreshold=1.5;MonetaryPeerPullScale=0）】
    public double SilverStandardGate = 1.0;            // **主フラグ**：0で中段（銀）に入らず旧2値と厳密恒等／1（live）で不換→銀→金の3段の梯子が開く
    public double SilverStandardIndThreshold = 0.0;    // 銀本位に届く工業化。0＝★銀は誰でも持てる（銀貨は普遍的だった＝1783年の銀世界の前提。0.15案は19-10の金利レバー問題対策だったが SilverLightDiscipline が構造で解決）。金は GoldStandardIndThreshold ＝交易経済の制度
    public double StandardMetalMintGate = 1.0;         // **主フラグ**★点火2026-08-29（夜間R20造幣3本クラスタA/B batch30）：0で造幣は旧来どおり金鉱だけを買う／1で**本位金属**（銀本位なら銀）を買う＝需要が法に従って現れ・消える。⚠銀価格暴落の線は閉鎖のまま（20-3打ち切り線）
    // 過去の差し戻し（2026-08-13 19-6/19-10）の根＝点火が**1783年から約60カ国を近代的兌換規律の下へ置いた**こと：
    //   ①トリレンマの金利自動化で約60カ国の金利レバーが死ぬ ②GoldCoverCreditRestraint が20〜31カ国で binding ③切下げ封印が全世界で閉じる。
    // 史実の銀本位（1783年の正貨流通）は**兌換銀行券の防衛規律を持たない**——銀貨そのものが貨幣であり、改鋳（debasement）は日常だった。
    //   金利防衛（1890年代バンクレート）・発券カバー率防衛は、発達した銀行券システム＝金本位期の制度である。
    // SilverLightDiscipline：0で旧来（銀の段も金と同じ規律）＝厳密恒等／1（live）で銀の段は「軽い規律」＝
    //   金利自動化と与信抑制は**金の段のみ**・切下げは正貨比率ぶんだけ開く（改鋳の窓＝BaseMoney/BroadMoney。新しい定数ゼロ）。
    //   ＝19-6差し戻しの3killerの再発防止。実測でも19-6型の帯崩壊（8軸中6軸悪化）は再発せず（5軸改善/4軸悪化）。
    public double SilverLightDiscipline = 1.0;   // 【点火1.0・2026-08-21 銀本位ラウンド（上の墓標参照）】
    // タスク#75の再開（貨幣の脱台本・2026-08-13 20-1裁定4「目標を交易加重の相手の本位から出す」→床の閉鎖で凍結→2026-08-21作者裁定で再開・点火）：
    //   金への移行の史実の駆動＝**交易網の引力**（英に引かれて独1871→1870年代の雪崩→貿易の少ないアジアは銀圏に残る）。
    //   工業化の絶対閾（GoldStandardIndThreshold）だけでは「誰もが自力で金へ行く」＝実測1803年に16カ国・1843年に49カ国が金＝史実（1843年は英のみ）の逆。
    // MonetaryPeerPullScale：0で注入も選好も不走行＝厳密恒等／>0（live=5）で「世界貿易の金建て比率×min(1, 自国開放度/世界平均開放度)」（いずれも既存の較正済み量）を
    //   通貨制度の選好の**持てる側**（債権者・大商人＝決済と借入の相手に本位を合わせたい側）の入力に足す。政治ゲート（議会の要求・勢力の強制施行・
    //   StepEnum の力の均衡）を通るのはプレイヤーもAIも同じ＝完全対等。年号も国名も書かない——雪崩は網目の正帰還から出る。
    //   ⚠用量反応は実測でフラット（5と20で1914年金23で同着・20は銀圏構成が劣化10/14）＝5を採用。上げても効かない＝選好経路の天井。
    public double MonetaryPeerPullScale = 5.0;   // 【点火5.0・2026-08-21 銀本位ラウンド（上の墓標参照）】
    // ==== 距離定数の時代関数化（掃討doc 第2波・2026-08-13）====
    // ★「1783年と1934年で同じ距離でよい定数は無い」——鉄道と汽船と電信が「遠い」の意味を変えた。
    // ⚠新しい技術の量は1つも作らない：運賃革命と**同じ前線技術のランプ**（TransportRevolutionOnset/Span）を読むだけ。
    // ⚠1本1バッチ（全部を同時に動かすと交易も緊張も疫病も移民も同時に動き、どれが効いたか分からなくなる）。
    // 係数の符号＝★正で「遠さが縮む＝届く範囲が伸びる」／⚠負で「距離あたりの費用が下がる」。
    // ★点火2026-08-29（夜間R17群A/B＋R17b距離4本切り分け batch30×2＝両腕とも破綻0・帯同水準・スペイン23/23で植民地費犯人説は棄却→6本一括採用）。=0なら×1恒等。
    public double EraEpidemicRange = 1.0;        // 疫病の伝播距離（★1817年コレラは陸路で数年・1892年は数週間）
    public double EraTensionRange = 1.0;         // 近接の緊張が届く距離（★電信1870s＝遠方の危機が即座に本国へ届く）
    public double EraRevolutionWave = 1.0;       // 革命の波の距離（★1848年は郵便と新聞の速度・1917年は電信）
    // 【墓標2026-08-29】EraRegionalHalf＝読み手ゼロ（力学読み手 RegionalDistanceWeight は2026-08-12撤去済み・残るはUI地図表示のみ）で撤去
    public double EraMigrationScale = 1.0;       // 移民の距離減衰（★大西洋横断が6週間→6日）
    public double EraColonyCoal = -0.5;           // 植民地維持の距離あたり石炭（⚠負を入れる＝複式→三段膨張機関で燃費が改善し続けた）
    public double EraColonyFood = -0.5;           // 植民地維持の距離あたり糧食（⚠負を入れる＝缶詰・冷蔵）

    /// <summary>★距離定数の時代係数（掃討doc 第2波・2026-08-13）。前線技術のランプに沿って距離定数を伸縮させる。
    /// k=0（既定）で 1.0＝**厳密恒等**（呼び出し側は掛けても1倍）。正で伸び、負で縮む。0以下には落とさない（距離が消えると幾何が壊れる）。</summary>
    public double EraFactor(double worldTech, double k)
    {
        if (k == 0) return 1.0;
        double ramp = Math.Clamp((worldTech - TransportRevolutionOnset) / Math.Max(1e-9, TransportRevolutionSpan), 0, 1);
        if (!(ramp >= 0 && ramp <= 1)) ramp = 0;   // NaNは「技術以前」へ倒す（否定形で書く＝Clampは NaN を消さない）
        return Math.Max(0.05, 1.0 + k * ramp);
    }

    // ==== 国民意識の消費側（国民意識doc N4/N7・2026-08-13）====
    // ★蓄積（国民形成に金を投じる）だけがあって、**育った国民意識が何かを買う**経路が細かった。2本足す：
    //   N4＝国民意識の無い州からは兵が出ない（墺洪の周辺州）／N7＝国民意識が育った州は離れない（国民国家の形成そのもの）。
    // ⚠N3（蓄積）とN4（消費）を同じバッチで測っていない＝別の帯を動かす。両方とも点火済み（1.0）。
    public double ConscriptConsciousnessWeight = 1.0;   // ★点火2026-08-29（夜間R16クラスタA/B batch30＝帯中立・破綻0。N3は既点火済み＝同時測定はしていない）。徴募可能人口に (1 − これ×(1−州の国民意識)) を掛ける。1で「国民意識0の州は兵ゼロ」
    public double SecessionConsciousnessWeight = 1.0;   // ★点火2026-08-13（同一ソースA/B：経済規模 +11.2・領土本国 +5.8・列強再現率 +3.7・政体exact +1.2／法 −1.5・人口 −2.9）。分離圧力に (1 − これ×州の国民意識) を掛ける
    public double GoldDebtBurdenGate = 1.0;            // **主フラグ**★点火2026-08-29（夜間R19単独A/B batch30＝列強+2.9・破綻0・帯中立）：0で対外債務は自国通貨建てのまま／1で**金建て**＝銀安がそのまま実質負担になる（インドの Home Charges・清の庚子賠款）
    public double GoldDebtBurdenCap = 3.0;             // 実質負担の上限倍率。青天井にすると銀の谷で利払いが発散し「破綻しない」を割る（思想＝破綻しない＞正しい挙動）
    public double MintReserveTargetWeight = 1.0;       // ★点火2026-08-29（夜間R20造幣3本クラスタA/B batch30＝列強+5.8で夜間最良・破綻0）。準備不足に応じて造幣量を絞る強さ。0＝旧来の産出比例／1＝「基礎貨幣×目標カバー率−現準備」の不足度に完全比例
    public double TrilemmaRateResponse = 0.5;          // カバー率の不足に対する金利の応答。金利↑→PolicyRateCapitalDraw で正貨が来る→カバー率が戻る→金利↓＝自己安定

    // ==== 社会移動リアリティ監査 2026-08-15・作者裁定 2026-08-16（点火状況は各行参照）====
    // rank5 囲い込みプッシュ（プッシュ型離農の不在＝docs/202608/20260815_社会移動リアリティ監査_部分完了.md）：
    // 農村→都市がプル一辺倒で、史実の先行プッシュ（囲い込み約4000法・地代は穀価と倍増・ハイランド放逐）が構造的に起きない欠落の是正。
    // ⚠作者の追加条件＝「移動費が払えず貧困から抜けられない」型を潰さない：**新しい移動経路・移動補助は一切作らない**
    //   （押し出しは所得低下→既存の都市化softmax・失業プール経由のみ。都市天井・海外渡航費の既存の壁はそのまま
    //   ＝逃げ場が無い州では困窮が滞留して闘争度になるのが正しい帰結）。この2係数はどちらも所得・自給を動かすだけで移動側には触れない。
    public double RentScarcityElasticity = 1.0;   // ★点火2026-08-31（清レポ3-4＝成長→地代→旧支配層強化の負帰還・ラウンドA実測＝◎8→11/固着38→31/列強+6.2/経済+8.8）   // 地代の土地稀少弾力（EconomyStep §④）：RGOの実効RentShare=RentShare×(1+これ×稀少度)。稀少度=max(0, 農村人口/ArableLand−1)＝landFactorと同一入力（ArableLand÷農村人口）の逆数側・センチネルArableLand≥1e8は除外（LandFactorと同じ）。clamp上限＝既存の物差しFarmRentCap（土地改革/農奴解放の法上限・≤1.0＝賃金非負も保存）。土地が稀少なほど地主の取り分↑→農民のEarned↓＝プッシュ型離農の駆動。0で×1.0＝IEEE恒等（ゲート内でのみ計算＝分岐ごと不読）
    public double ParliamentStreetSupersede = 0.5;   // ★点火2026-08-31＝議会の二重票の是正（清レポ3-6）：議会がある国では3ブロックの街頭力の半分を議席チャネルへ譲る（党の選好表＝ブロックの選好表なので旧は二重加算＝共和国化で教育法が2.7倍通りにくくなった実測。1.0全譲は法一致−6.2で0.5に裁定＝ラウンドA腕2）。未代表（小営業・軍・国庫）は街頭のまま。0＝旧二重加算
    public double RumpReabsorbYears = 5.0;           // ★点火2026-08-31＝残骸国家の自然再併合：内戦の白紙分断で生まれた国が親GDP1%未満を5年続けたら平和的に再統合（ReabsorbNationsの既存機構＝保存両建て）。親が交戦中/消滅なら持ち越し。0で無効
    public double EnclosureRate = 0.0;   // rank5第2段（別A/B）＝囲い込みの自給侵食（EconomyStep.ApplyEnclosure）：RGOの資本拡張（BuiltScale増分）1単位あたり当該州農民pop（RGOの労働pop）のSubsistenceをこれ×増分だけ微減（下限0）＝プランテーション・囲い込みが自給地を市場向けに転換する物理。増分の発生源＝World.StepConstruction完成（1棟=FactoryBuildScale）とEconomyStep.RgoCapitalShare枝（休眠対照）。接収（NationalizationSeizure）は所有移転であって資本拡張でないため対象外。0で1命令も走らない＝厳密恒等
    // 出生配分の凍結分母の是正（docs/202608/20260815_失業プールと社会移動_部分完了.md「点火直後の回帰＝聖職者爆発」節・作者裁定＝年代スケール禁止・確立した形で）：
    // BirthWeight の popごと t=0 凍結分母（InitialFertileShare）は、初期構成が偏ったpop（聖職者F=0.10）が新生児蓄積で構成正常化すると
    // 分母凍結のまま分子が育ち恒久出生倍率（実測2.1倍）になる罠＝「比のガードは絶対値で書かない」と同族。
    public double FertileAbsoluteBlend = 0.0;   // ★差し戻し2026-08-30（点火bisect＝幕府転換テスト赤の単独犯・英人口が停滞→縮小0.73×へ）：凍結分母ポンプ（出生2.1倍）は較正の暗黙の土台だった＝是正は**出生率の実再較正とセット**でのみ再点火（AI工業化バーストと同型の扱い）
    public double FertileShareStd = 0.35;   // 標準構成の出産可能プール定数＝(1−0.3子供)×0.5女性=0.35。FertileAbsoluteBlend>0のときのみ読む分母の物差し（カップル律速項×(1+CoupleLimitedBirths)はBirthWeight側で乗算＝標準構成popの重み=Sizeを保ち総出生の物差しを動かさない）

    // ==== 運用コスト監査 2026-08-16（燃料系＝「金は払うが物資を消費しない運用」の物資化。#1海軍燃料／#3汽船燃料のみ休眠・#2#4は点火済み）====
    // 対象4本＝#1海軍の運用燃料／#2鉄道の運行石炭／#3汽船（民間海運）の運行燃料／#4空軍・輜重の燃料。
    // 保留（被服・港湾資材・巨大建造物維持・医薬品戦時段・馬飼料）＝docs/202608/20260816_運用コスト監査と燃料実装_部分完了.md に記録。
    // ⚠時代の表現は蒸気ゲート（SteamTechOnset）・供給実在ガード（原油）・EraFactor のみ＝年号・経過年は読まない（恒久指示）。
    public double NavalFuelPerGauge = 0.0;      // #1 海軍の運用燃料：石炭需要/月 = これ×FleetGauge×NavyUpkeep×蒸気ゲート×EraFactor(EraNavalFuel)。石炭→重油の二択と支払い経路は植民地補給線（Colonial.BuyUpkeepGood/ChooseFuelGood）と同一＝台帳は TreasuryCat.Navy（現在書き手ゼロの枠）。
    //   点火目標の導出（目盛りの錨＝ColonyUpkeepCoalPerDist=400＝植民地1つ・1万kmの汽船補給線の月次石炭・既較正）：
    //   英1914≈植民地30・平均1.2万km→補給線石炭≈400×30×1.2≈14,400/月。艦隊の運用炊き（哨戒・演習）は史実で商船隊の1〜2割の石炭消費
    //   →目標≈2,000〜4,000/月。点火時は fidelity 走行で英1914の FleetGauge×NavyUpkeep を実測し NavalFuelPerGauge=目標石炭/(FleetGauge×NavyUpkeep) で逆算＝Search再較正ラウンドと同席。
    public double NavalFuelSortieFloor = 0.4;   // #1 燃料切れ艦隊の出撃能力の下限（港湾・沿岸防衛は残る）。NavalFuelPerGauge>0のときのみ読む。⚠形を緩くする理由＝NavalPowerFromFleet の急峻min は2026-08-01に硬性ゲート赤で一度差し戻された経路＝燃料は fill線形×下限フロアの緩い乗数にする
    public double NavalFuelFillSmoothing = 0.25; // #1 燃料充足EMAの月次平滑（艦隊は数ヶ月分の炭庫を持つ＝月次の品切れで即座に港へ縛り付けない）。NavalFuelPerGauge>0のときのみ読み書き
    public double EraNavalFuel = 0.0;           // #1 艦隊燃費の時代改善（複式→三段膨張→タービン）＝⚠負を入れる（EraColonyCoal と同旨・距離あたり費用が下がる）。既定0でEraFactor=1.0＝恒等
    public double RailCoalRate = 0.22;          // ★点火2026-08-29（夜間R18燃料クラスタA/B batch30＝破綻0・列強+2.9。⚠損失financing 1/30=seed3トスカーナを記録＝広がるなら0.15へ）。導出＝0.25×(0.4×高度労働0.8+0.3×労働0.5)/石炭0.54。#2 鉄道の運行石炭：インフラ保守1単位あたりの石炭消費（×蒸気ゲート）。火夫（MaintLaborRate=0.3）は雇うのに石炭を買っていない自己矛盾の是正。
    //   点火目標の導出：19世紀鉄道の営業費構成＝人件費≈50%・燃料≈10〜15%→石炭費≈運行要員費（MaintAdvLaborRate 0.4×高度労働価格＋MaintLaborRate 0.3×労働価格）の約1/4
    //   → RailCoalRate ≈ 0.25×(0.4×AdvLabor参照価格+0.3×Labor参照価格)/石炭参照価格 を初期値に Search で再較正。投資予算の律速（maintCostPerUnit）にも同項を載せる＝InvestBudgetIncludesAllInputs と同じ作法
    public double ShipFuelRate = 0.0;           // #3 汽船（民間海運）の運行燃料：石炭需要/月 = これ×ShipCapacity×汽船比率EMA。買い手＝商人pop（Transport の船購入と同じ決済＝保存）。帆船と汽船の運航費が同一＝帆船消滅の史実主因の欠落の是正。
    //   点火目標の導出（錨＝植民地補給線の既較正ペア）：石炭400/海運占有0.12（ColonyUpkeepCoalPerDist/ColonyShipOccupyPerDist）≈ 石炭3,333/ShipCapacity単位・1万km航路換算
    //   → 平均航路をn万kmとみなし ShipFuelRate ≈ 3,333×n×(月次換算) を上限目安に、点火時は tradeprobe で燃料需要総量が補給線側と同オーダーに収まるよう再較正。
    public double ShipSteamShareSmoothing = 0.25; // #3 汽船比率EMA（購入容量ベース）の平滑。ShipFuelRate>0のときのみ読み書き（=0ではEMA自体を更新しない＝ビット恒等）
    public double AirFuelRate = 0.045;          // ★点火2026-08-29（夜間R18燃料クラスタA/B batch30・0.03〜0.06帯の中央）。#4 空軍の燃料：MilitaryScale 1あたりの原油消費/月（作戦機は飛ばすたびに燃料を焚く＝製造時の原油だけでは足りない）。充足は MilitaryAirFill に乗算合成（新フィールドなし）。
    //   点火目標の導出：飛行機の調達レート（MilitaryAirRates[0]=0.03）に対し、運用燃料は機体フローの1〜2倍/月（機体は耐久財・燃料は毎月）→ AirFuelRate ≈ 0.03〜0.06 を初期値に再較正。
    public double MotorFuelRate = 0.05;         // ★点火2026-08-29（夜間R18燃料クラスタA/B batch30）。#4b 輜重自動車（MilitaryGoods の132・rate0.02）の燃料：MilitaryScale 1あたりの原油消費/月。車両は耐久財・燃料は毎月→機体比の論法で0.02×2〜3。原油の供給実在ガード（掘削解禁前は需要を立てない）は空軍と共通

    // ==== 蜂起R群 2026-08-16（docs/202608/20260816_蜂起不発と極端プレイ診断_部分完了.md・実装時は全て休眠＝既定0で厳密ビット恒等＝0で新しい読み書きゼロ・分岐1回のみ）====
    // 診断の核＝「不満100%・意識100%でも蜂起が代数的に不能」を作る壁3つ＋minクランプ1つ。作法＝壁でなく逓減
    //（x/(1+x/cap)＝SelfPlay.Score.Military と同じ既存の逓減形）・新しい法/年号/固有名詞なし・新フィールドなし（セーブ形不変）・
    // 全て対称機構（IsPlayer不読・AI/プレイヤー同式）。
    // ★**R1〜R4は2026-08-16の点火梯子で全て点火済み・live**（R1=1.0＋水準 CoercionMax を4000→2000へ同時是正／R2=0.5／R3=1.0／R4=1.0）。
    public double CoercionSoftCap = 1.0;   // 【点火1.0・2026-08-16 点火梯子＝単独 exact+1.0（水準2000と併用＝r1b exact38.7）。合成comp4（12本＋海0.5）で exact41.6/near77.4/法63.2/貿易0.66・硬性緑】   // R1（本丸・診断A1）：coerce飽和を壁→漸近逓減＝min(x,CoercionMax)→x/(1+x/CoercionMax)（Government.CoercionTargetFromForce）。
    //   等号点の導出：Transition点火⇔challenge>coerce（Politics.cs:574）。challenge理論最大≈TotalPopulation×≈1.25（Σ Size×Consc≤Pop に窮乏チャネル・組合動員・外圧ReformPressureBoostの上乗せ）・
    //   coerce=BaseCoercion×Legitimacy×funding×Pop/PoliticalReferencePop(1000)＝人口が約分され、点火 ⇔ BaseCoercion×Leg×funding < 1000×1.25 ≈ **1250**。
    //   旧 CoercionMax=4000 はその3.2倍＝軍事費スライダー≳0.28でcap張り付き→革命が代数的に不能（クーデタIsSeizureも同じ動員ゲート従属＝大軍ほど軍事クーデタも不可能）。
    //   ソフト化はmin未満の帯でも x/(1+x/cap)<x＝平時のBaseCoercion（Politics/圧政維持費/FactionSnapshot表示の読み手）も下がる＝**形の切替であり値の縮尺でない**→0で旧minビット恒等を厳守。
    //   ★水準（CoercionMax）も点火時に同時是正済み＝4000→2000（等号点1250の1.6倍）＝POB_COEF 掃引（1500〜2000）の結論
    //  （漸近値capが等号点1250へ近づくほど「大軍でもLeg×fundingが痩せれば倒れる」帯が開く）。見る帯＝総政変・政体exact。
    public double FactionRevoltLocalCoerce = 0.5;   // 【点火0.5・2026-08-16 点火梯子＝単独 exact+1.4・法+2.7（太平天国の単位整合）。合成comp4（12本＋海0.5）で exact41.6/near77.4/法63.2/貿易0.66・硬性緑】   // R2（診断A2）：F3b点火の単位整合＝左辺FactionStrength（州×ブロック×主軸クラスタ規模）vs 右辺全国coerce の按分ブレンド（0..1）。
    //   実効coerce＝coerce×((1−f)+f×州pop/全国pop)（Politics.LocalizedHold）＝f=0旧・f=1完全按分＝「人口の大きい国ほど点火不能（太平天国が最も出にくいのは清）」の逆理の根を絶つ。
    //   LoyalistMilitia（郷勇）は全国のまま＝郷紳の金は全国から（LoyalistMilitiaの設計コメントと整合）。点火A/Bで中間値も掃引可。見る帯＝内戦分裂・清。
    public double RegionalRevoltSatGate = 1.0;   // 【点火1.0・2026-08-16 点火梯子＝単独 exact+2.8・法+2.6。合成comp4（12本＋海0.5）で exact41.6/near77.4/法63.2/貿易0.66・硬性緑】   // R3（診断A3）：F1州一揆のオフスイッチ解除＝(1−FoodFill)→(1−min(FoodFill, 州平均Satisfaction))（Politics.RegionRevoltHeat）。
    //   FoodFill=1.0が生活水準の完全遮断スイッチだった（heat≡0＝「不満70%超でも131年無風」の一因）。FoodFill=1かつSat=1（およびSat≥FoodFillの全帯）で旧と厳密同値＝恒等の帯を保つ。見る帯＝一揆頻度。
    public double ModernizationBudgetSoftCap = 1.0;   // 【点火1.0・2026-08-16 点火梯子＝単独 exact+1.5（プレイヤーの極端にだけ効く）。合成comp4（12本＋海0.5）で exact41.6/near77.4/法63.2/貿易0.66・硬性緑】   // R4（診断B3・最初の1手）：近代化投資のminクランプ→漸近逓減（World.ModernizationBudget）。
    //   旧＝min(b, 国庫×0.5) が凸コスト convex=frac/(1−frac) を食い、frac≳0.5でコストも効果もフラット＝0.6と1.0の区別が消滅（設計コメント「100%は不可能」が実挙動に不存在）。
    //   ソフト化＝b/(1+b/(国庫×0.5))＝frac=1.0の漸近値は旧の壁と同額（上限は保存）・途中の帯だけ逓減が立つ。
    //   AIは AutoModernizationFrac（indGap×財政余力×スタンス率≤0.15）でフラット帯に構造的に入らない＝**プレイヤーの極端にだけ効く**。見る帯＝noviceprobe順位。

    // ==== 海ノード吸着の是正 2026-08-16（docs/202608/20260816_海ノード吸着の是正_完了.md・実装時は休眠＝既定0で厳密ビット恒等／★点火梯子で0.5へ点火済み・live）====
    // 診断＝mapedges。SeaGraph.StitchCrossesLand は「**出港の一歩目（連続する陸）は数えない**」規則で、
    //   港が水際の町である以上、格子（Landmask＝海岸線を1マス内側へ収縮）の上では港自身が陸のマスに乗るための免除。
    //   ⚠その免除に**距離の上限が無かった**＝「線の全部が出港の一歩目」（一度も水に出ない線）まで合格する。
    //   実測（mapedges・OFF）：トリエステ(45.65,13.77)は最寄りのアドリア海北(179km)がイストリア半島で棄却され、
    //   **1,045km先のバルト南西(55.0,14.0)へ吸着**（陸上880km＝中欧を縦断する線が地図に描かれていた）。
    //   接ぎ木は SeaDistanceKm にそのまま加算され、海盆も採用ノードから継ぐので**表示だけの問題ではない**：
    //   トリエステ→ヴェネツィア 9,960km（実際150km＝×66）・トリエステの SeaBasin が Mediterranean でなく Baltic。
    //   同型は港州92件中21件（ハノイ1,036km・バンコク837・カナダ595・ブーシェフル476・ケルン352・グラスゴー143 ほか）。
    // 形＝免除に予算を持たせる：**その地点が水に出るまでの実測距離**（陸マスクの最寄り海マスまで＝トリエステで約5km、
    //   ケルンで78km、ハノイで52km＝mapedges の「港州から海までの距離」列と同じ量）× これ、を超えた先の陸は横断とみなす。
    //   ⚠固定kmのマジックナンバーを置かない（作者の流儀「固定値でなく既存の較正済み量に絡める」）＝**規模中立**＝
    //   河口や内海の港（水まで遠い町）の免除は自動的に長く、水際の港（トリエステ）の免除は自動的に短い。
    //   1.0＝「実測の出港距離ちょうどまで免除」＝物理的に必要な分だけ。免除の下限は格子1マス（11.1km）＝
    //   Landmask が海岸線を1マス内側へ収縮させてあるぶんの不確かさ（新しい数値ではなく格子の粗さの補正）。
    // ⚠1つも通らなければ**素の最寄りへ退避**する既存の規則がそのまま受ける＝トリエステはアドリア海北(179km)に落ち着く
    //   ＝「正しい海に出る」。退避が効くことは SeaGraphTests / SeaStitchBudgetTests が固定する。
    // ⚠海路距離が動く＝**較正非中立**（貿易/GDP・領土・列強の帯が動く）。点火A/Bは POB_COEF="SeaStitchLeadBudgetMult=1"
    //   で親がバッチ測定済み＝0.5を採用（1.0は地図の線が最少だが帯は0.5が上）。0＝旧規則（無制限免除）とビット恒等＝新しい実測（陸マスクの走査）は1回も走らない。
    public double SeaStitchLeadBudgetMult = 0.5;   // 【点火0.5・2026-08-16 点火梯子＝単独 exact43.3＝全16腕で最良／合成comp4で near77.4・人口28.6。1.0は地図の線は最少だが帯は0.5が上。合成comp4（12本＋海0.5）で exact41.6/near77.4/法63.2/貿易0.66・硬性緑】

    // ==== 反実仮想（測定専用・2026-08-21）＝「金詰まりで買えないのか」の因果テスト ====
    // POP の購入は demand=min(desired, RemainingBudget/buyerPrice)（EconomyStep）。この蓋だけを (1+k) 倍に緩める。
    // ⚠**採用候補ではない**：緩めた分は払えない金で買う＝保存則が破れる（leakhunt は当然赤になる）。
    //   目的は「予算が binding なら緩めたときに交易が増えるはず」という**因果の向き**を1本だけ確かめること。
    // 既定0＝分岐を1命令も通らない＝ビット恒等（×1.0 の乗算も残さない）。
    public double PopBudgetRelax = 0.0;

    // 交易量 q ∝ scaleT = max(LastDemand, LastProduced, TargetStock) であり、TargetStock も需要に比例する
    //（MarketFlow: TargetStock = max(TargetStockFloor, TargetStockBuffer×totalDemand)）。
    // つまり pop の予算制約が需要を切ると、その分だけ交易の「規模」も切られる。ここはその経路**だけ**を外して測る
    //（金の流れは1円も変えない＝保存則は保たれる＝PopBudgetRelax と違い leakhunt が緑のまま走る）。
    // 実測（budgetprobe・1793年）：世界貿易/GDP 8.31%→11.28%（+36%）。既定0＝読み手ゼロ＝ビット恒等。
    public double TradeScaleUsesDesired = 0.0;

    // ==== 環境変数による係数の上書き（測定用・2026-08-12）====
    // なぜ要るか：A/B を**同一バイナリ・同一ソースハッシュ**で取るため。従来は既定値を書き換えて2回ビルドしていたが、
    // その間に他の編集が混ざると「挙動不変のはずの変更で軌道が動く」事故になる（設計doc「測定汚染」2026-07-28 と同じ罠）。
    //   使い方: POB_COEF="CrownlessCollapseKeepsRepublic=0;BourgeoisCoupNeedsCrisis=0" bash measure.sh ...
    // 決定論：同じ環境変数なら同じ値＝再現する。未指定なら1件も触らない（＝厳密恒等）。
    // 名前を間違えたら**黙って無視せず例外**＝「掛けたつもりの実験が素通り」を構造で防ぐ（番人の空洞化対策）。
    private static readonly (string Name, double Value)[] Overrides = ParseOverrides();

    private static (string, double)[] ParseOverrides()
    {
        string? spec = System.Environment.GetEnvironmentVariable("POB_COEF");
        if (string.IsNullOrWhiteSpace(spec)) return [];
        var list = new List<(string, double)>();
        foreach (var part in spec.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            int eq = part.IndexOf('=');
            if (eq <= 0) throw new ArgumentException($"POB_COEF の書式が不正: 「{part}」（名前=値 で書く）");
            string name = part[..eq].Trim();
            var field = typeof(Coefficients).GetField(name);
            if (field is null)
                throw new ArgumentException($"POB_COEF に存在しない係数名: 「{name}」");
            if (field.IsLiteral || field.IsInitOnly ||
                !(field.FieldType == typeof(double) || field.FieldType == typeof(int) || field.FieldType == typeof(bool)))
                throw new ArgumentException($"POB_COEF が扱えない係数: 「{name}」（{field.FieldType.Name}）");
            if (!double.TryParse(part[(eq + 1)..].Trim(), System.Globalization.NumberStyles.Float,
                                 System.Globalization.CultureInfo.InvariantCulture, out double v))
                throw new ArgumentException($"POB_COEF の値が数値でない: 「{part}」");
            if (field.FieldType == typeof(int) && !(double.IsFinite(v) && v >= int.MinValue && v <= int.MaxValue))
                throw new ArgumentException($"POB_COEF の値が int の範囲外/非数: 「{part}」");
            list.Add((name, v));
        }
        return [.. list];
    }

    public Coefficients()
    {
        foreach (var (name, value) in Overrides)
        {
            var f = typeof(Coefficients).GetField(name)!;
            if (f.FieldType == typeof(double)) f.SetValue(this, value);
            else if (f.FieldType == typeof(int)) f.SetValue(this, (int)value);
            else if (f.FieldType == typeof(bool)) f.SetValue(this, value > 0.5);
            else throw new ArgumentException($"POB_COEF が扱えない型の係数: 「{name}」（{f.FieldType.Name}）");
        }
    }

    /// <summary>この走行で上書きされた係数（測定の見出しに出して「掛けたつもり」を防ぐ）。</summary>
    public static string OverrideSummary()
        => Overrides.Length == 0 ? "" : string.Join(" ", Overrides.Select(o => $"{o.Name}={o.Value:G}"));
}
