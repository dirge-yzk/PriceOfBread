﻿namespace PriceOfBread.SimCore;

/// <summary>
/// 政治（§9-E）＋外圧（§A-11）。四半期に意識・闘争度を更新し、旗の力を集計、
/// 反体制の旗が圧政を超えたら政体が転換する（ムーア機構：強い旗が型を決める）。
/// 政体→参政権・自由度を算出（段2 のスカラー仮置きを実体化）。PoliticsEnabled で段0〜2 は不動。
/// 国家レベル＝全地域の pop を集計する。
/// </summary>
public static class Politics
{
    // マジックナンバー一掃（2026-07-20・値据え置き・命名のみ）：天命による正統性増幅の対称クリップ境界（安全弁）
    private const double DynMandateMulMin = 0.2, DynMandateMulMax = 1.8;

    /// <summary>探究/革新の自由度（倍率排除②）＝政体ラベルでなく**法律状態（参政権＋報道）から創発**。
    /// 世界の技術水準閾値(0.6)は**政治的開放度と報道の自由の両方**を要する＝検閲する社会は形式的参政権があっても先端で革新できない（採用・模倣に留まる＝閉じた社会の停滞）。
    /// 自由主義革命（立憲君主制/共和）は <see cref="FoundingPress"/> で報道を解放するので閾値を越える。検閲を保つ独裁（ブルジョア/プロレタリア独裁）は越えない。
    /// 係数は制約解：Census+Censorship≥0.6（立憲）・Census+StatePress&lt;0.6（ブルジョア独裁）・AdultMale+FreePress≥0.6（共和）・AdultMale+StatePress&lt;0.6（プロ独裁）・None+FreePress&lt;0.6（無参政権は報道自由でも革新せず）。</summary>
    public static double FreedomFromLaws(Suffrage suffrage, CensorshipLaw press)
    {
        double political = suffrage switch
        {
            Suffrage.Universal => 0.65,
            Suffrage.AdultMale => 0.55,
            Suffrage.Census => 0.50,
            _ => 0.20,                            // None＝閉鎖（参政権なき社会は報道自由でも先端革新に届かない）
        };
        return Math.Clamp(political + 0.25 * PressFreedom(press), 0, 1);   // 報道自由（単一ソース）＝先端の知の流通。検閲＝情報が流れない
    }

    /// <summary>報道自由度∈[0,1]（**政治側の**単一ソース・倍率排除/長い裾）。国家報道のみ=0／検閲付=0.6／自由報道=1.0。
    /// Freedom式（先端革新の解禁）と政治意識の press 倍率が**この一実数を共有**＝検閲法→効果の3値表を一本化。
    /// ⚠ここは政治側だけの単一ソースである（2026-08-12に監査で判明・旧コメントは「単一ソース」とだけ書いて誤解を招いていた）。
    /// **技術側は別テーブル**（<see cref="TechEducation"/> の 0.5／0.75／1.0）。理由は床の有無＝政治では国家統制の
    /// 報道自由度は 0 でよいが、技術で 0 を掛けると初期が国家統制の国（1783年の大半）が吸収も革新も完全停止して
    /// 序盤で壊滅する。技術側は「検閲は技術を半減まで落とす」という別の物理を持つので、値を無理に一致させない。</summary>
    public static double PressFreedom(CensorshipLaw press) => press switch
    {
        CensorshipLaw.FreePress => 1.0,
        CensorshipLaw.Censorship => 0.6,
        _ => 0.0,                                // StatePressOnly＝国家報道のみ
    };

    /// <summary>政体が建国時に解放する報道の自由（倍率排除②）。代議制（立憲君主制/共和）は報道を自由化＝革新世界の技術水準が立つ。
    /// 独裁・権威主義は検閲を保つ＝形式的参政権があっても閉じた社会で先端革新に届かない。</summary>
    public static CensorshipLaw FoundingPress(Polity p) => p switch
    {
        Polity.Republic => CensorshipLaw.FreePress,             // 共和＝自由報道（合衆国修正1条型）
        Polity.ConstitutionalMonarchy => CensorshipLaw.Censorship,   // 立憲君主制＝比較的自由な報道（英型）
        _ => CensorshipLaw.StatePressOnly,                      // 独裁・権威主義＝検閲（floor-raise なし＝閉じたまま）
    };

    /// <summary>政体が含意する参政権（利益集団の実効発言権）。立憲君主制＝制限選挙・共和/プロ独裁＝成人男性。
    /// 法律の参政権（World.Suffrage）とこれの大きい方が実効値＝政体だけで一定の包摂が起き、法でさらに広げられる。</summary>
    public static Suffrage PolitySuffrage(Polity p) => p switch
    {
        Polity.Republic => Suffrage.AdultMale,
        Polity.ProletarianDictatorship => Suffrage.AdultMale,
        Polity.ConstitutionalMonarchy => Suffrage.Census,
        Polity.BourgeoisDictatorship => Suffrage.Census,
        _ => Suffrage.None,                      // 絶対君主・専制・幕府・無政府＝参政権なし
    };

    private static double ConsciousnessConversion(EducationLaw law) => law switch
    {
        EducationLaw.Public => 1.0,
        EducationLaw.Compulsory => 1.0,
        EducationLaw.Religious => 0.15,
        _ => 0.1,
    };

    /// <summary>政15：識字→政治意識の変換係数を「今期の教育法」でなく**popの就学履歴ストック**（Literacy蓄積と同型の緩和）から読む。
    /// 現行は法改正の瞬間に成人の変換係数が 0.15→1.0 へ跳ぶ（数十年前に教育を受けた成人まで即時）＝年齢コホート監査（テーマA）と同根の粒度問題。
    /// ConsciousnessFromSchoolingStock=0 では即時値（今期の法）をそのまま返す（**現行既定は1.0点火＝戻り値は完全にストック**・02断線走査2026-07-28注記是正）。>0 で **pop.SchoolingConvStock**（政15の専用フィールド・-1=未捕捉）を
    /// 就学履歴ストックとして、現行の即時値と (1−これ) : これ で混ぜ、ストックは今期の変換係数へ緩和更新（世代遅れ＝法改正が変換に効くまで数年）。
    /// ※嘘コメント是正（作業リスト2第2段2-6・2026-07-27）：旧記述「pop.EducationEma を使う」は誤り＝実装は当初から SchoolingConvStock（EducationEma は人13の高等教育ゲート用＝別物・本経路は触らない）。</summary>
    private static double SchoolingConversion(Pop p, double convertNow, Coefficients c)
    {
        if (c.ConsciousnessFromSchoolingStock <= 0) return convertNow;   // 0＝即時（今期の法）＝旧式（現行既定1.0）
        // 就学履歴ストック（緩和）：今期の変換係数へゆっくり寄る＝過去の教育法の名残が残る（成人の識字→意識変換が跳ばない）。
        // 未捕捉＝-1センチネル（SchoolingConvStock の初期値）→初回は convertNow で埋める＝立ち上がりの跳躍を作らない。
        double stock = p.SchoolingConvStock;
        if (stock < 0) stock = convertNow;   // -1＝未捕捉（初回）→即時値で初期化
        stock += c.SchoolingStockSpeed * (convertNow - stock);
        p.SchoolingConvStock = stock;
        double g = c.ConsciousnessFromSchoolingStock;
        return (1.0 - g) * convertNow + g * stock;   // g=0 で convertNow（現行恒等）
    }

    public static void Step(World w, Coefficients c)
    {
        if (!w.PoliticsEnabled) return;

        if (w.RuptureWindowQuarters > 0) w.RuptureWindowQuarters--;   // 第6段6-8b：断裂の窓の減衰（鎮圧・制圧・クーデタが再セット）
        if (w.LostRegionsCumulative > 1e-9)   // 機能7-2：失地ストックの半減期減衰（20年＝世代を跨ぐ遺恨・やがて風化）
            w.LostRegionsCumulative *= Math.Pow(0.5, 1.0 / Math.Max(1.0, c.LostLandHalflifeQuarters));

        double convertNow = ConsciousnessConversion(w.EducationLaw);   // 政15：今期の教育法の即時変換係数（既定はこのまま全pop一律）
        // 便乗の勢い＝前期の運動力(改革派+急進派)÷実効保持力（第5段5-1＝PoliticalQuantities一元化・前期Coercion×現人口＝従来と同時点）。革命が近いほど大衆が雪崩を打つ（仏革命の群衆）。
        double momentum = Math.Clamp((w.ReformistPower + w.RadicalPower) / Math.Max(1, PoliticalQuantities.EffectiveCoerce(w, c)) * c.BandwagonSensitivity, 0, 1);

        foreach (var p in w.AllPops())
        {
            double urban = p.IsUrban ? c.UrbanConsciousnessBoost : 1.0;
            double convert = SchoolingConversion(p, convertNow, c);   // 政15：既定は convertNow（全pop一律・現行恒等）／>0 で pop の就学履歴ストックへ
            // 便乗：勢いある運動は無学な民をも政治化する（教育に依らず＝専制の安定を崩す）。識字が低いほど便乗しやすい（群衆心理）。
            double bandwagon = c.BandwagonWeight * momentum * (1.0 - p.Literacy);
            // 報道の自由は政治意識を広める（情報の流通）。国家報道のみ＝統制で意識が育ちにくい（安定と引き換え）。
            // 検閲法→倍率の3値表を撤去し PressFreedom（Freedom式と単一ソース）から：StatePress=0.75・FreePress=1.25（厳密一致）。
            // 1934拡張E3：報道の実体＝新聞財。press の自由項を「内容の自由(PressFreedom)×紙が届いたか(NewsFill)」の積に＝
            // 買えない/刷れない社会は自由でも意識が育たない。NewsConsciousnessFloor=1.0 で旧式と厳密一致（新聞財の無い小シナリオ・較正の保護弁）。
            double newsReach = c.NewsConsciousnessFloor + (1.0 - c.NewsConsciousnessFloor) * p.NewsFill;
            double press = 0.75 + 0.5 * PressFreedom(w.Censorship) * newsReach;
            // [PORT:P2] 意識targetへの寄与＝識字×教育変換×都市化＋便乗、×報道（新聞/検閲）。時定数17年の遅い変数＝速い興奮（革命の波等）はP1へ
            double target = Math.Clamp((p.Literacy * convert * urban + bandwagon) * press, 0, 1);
            p.Consciousness += c.ConsciousnessSpeed * (target - p.Consciousness);
        }

        // 倍率排除⑥b-2：軍拡負担の闘争度直接加算（圧政>2500 の手書き絶対閾値）を撤去。軍・圧政の維持コストは
        // 既存の財政連鎖（大軍→赤字→緊縮→逆進課税/福祉削減→可処分所得↓→満足↓）が WantWeight×(1−Satisfaction) で拾う＝不満の単一ソースへ集約（⑥a/失業と同じ二重計上の解消）。
        double ethnicUnity = w.EthnicUnity;   // 倍率排除⑧：計算プロパティ（pop加重平均）をループ前に1回だけ評価＝O(pops²)回避（ループ内では不変）
        double warWeariness = w.SelfPower?.WarExhaustion ?? 0;   // 厭戦（対外戦争のみ・較正は0）。闘争度入力へ（旧：Ideology の階級分岐で直接加点）
        // 政治の空間モデル：現政体の4軸座標（実参政権でドリフト済＝第5段5-1でPoliticalQuantitiesへ一元化）をループ前に1回算出。各popの理想点との距離が政治的不満。
        double[] regimeCoord = PoliticalQuantities.DriftedPolityCoord(w.Polity, w.Suffrage, c);
        // no-inequality-relative-deprivation：国単位ジニ係数を1人あたり貯蓄から診断計算（O(n log n)）＝相対的剥奪の直接の不満駆動因。
        // 既存の wealthRel→Ideology→politicalGap の間接経路と二重計上しないよう、闘争度には gini そのものでなく (gini−GiniNeutral) 差分のみを後段で加える。InequalityMilitancy=0 で不発（現行0.15）。
        // 政6：**人口加重ジニ**（各popの1人あたり富 pc=Savings/Size を値・Size を重み）。集団ごと等ウェイトだと数千人の貴族popと数百万人の農民popが同じ1票＝規模を無視した診断値。
        // 加重ロレンツ曲線を昇順に台形則で積分（x=累積人口シェア・y=累積富シェア）し gini=1−Σ(Δx)(y_i+y_{i-1})。全popが同じ pc なら曲線が対角線＝0。
        var wpcList = new List<(double pc, double size)>();
        foreach (var gp in w.AllPops()) { if (gp.Size <= 1e-9) continue; wpcList.Add((Math.Max(0, gp.Savings) / gp.Size, gp.Size)); }
        double gini = 0;
        if (wpcList.Count > 1)
        {
            wpcList.Sort((a, b) => a.pc.CompareTo(b.pc));
            double totSize = 0, totWealth = 0; foreach (var e in wpcList) { totSize += e.size; totWealth += e.pc * e.size; }
            if (totSize > 1e-9 && totWealth > 1e-9)
            {
                double cumX = 0, cumY = 0, area = 0;   // area＝ロレンツ曲線下の面積（台形則）
                foreach (var e in wpcList)
                {
                    double prevX = cumX, prevY = cumY;
                    cumX += e.size / totSize; cumY += e.pc * e.size / totWealth;
                    area += (cumX - prevX) * (cumY + prevY);   // 台形＝Δx×(y_i+y_{i-1})/2 の /2 は最後にまとめて処理せず gini 式に吸収
                }
                gini = 1.0 - area;   // area は既に (y_i+y_{i-1}) 形＝2×(曲線下面積)。ジニ=1−2×面積 と一致
            }
        }
        w.GiniIndex = Math.Clamp(gini, 0, 1);
        // 中立アンカーの自動化（第(iv)段再設計2026-07-09）：定数GiniNeutral=0.0007は較正世界の実測であり、実国（仏1789の貴族貯蓄集中等）では
        // 初期ジニとの乖離が大きく「差分0で撹乱を断つ」原設計が不成立＝開幕から闘争度を系統的に押し上げ梯子外しテストを壊した。
        // 負のGiniNeutral＝**その世界の初回実測ジニを自動アンカー**（ドリフト分＝格差の悪化のみが不満化）。非負＝固定基準（テスト/較正用の旧挙動）。
        if (w.GiniNeutralAuto < 0) w.GiniNeutralAuto = w.GiniIndex;
        double giniNeutral = c.GiniNeutral >= 0 ? c.GiniNeutral : w.GiniNeutralAuto;
        double inequalityUnrest = c.InequalityMilitancy * Math.Max(0, w.GiniIndex - giniNeutral);   // 国一律の不満押し上げ（EthnicUnrest と同型・0で不発・現行0.15）
        // 参政権の範囲2法（作者裁定2026-08-16・SuffrageScopeGate>0のみ）：移民原住民参政権の少数派緩和は「州の格」を読む
        // ＝ループを州→popの入れ子へ（AllPops と同じ走査順・Seceded スキップ＝gate=0 で厳密恒等）。
        bool migrantIncluded = c.SuffrageScopeGate > 0 && w.EthnicEnabled && w.MigrantNativeSuffrage == MigrantNativeSuffrageLaw.Granted;
        foreach (var milReg in w.Regions)
        {
        if (milReg.Seceded) continue;
        foreach (var p in milReg.Pops)
        {
            // ★★★生活苦＝**失望**＝【低下】から生まれる（2026-08-19裁定・2026-08-21点火＝既定1.0）。⚠0に戻すと旧式（絶対水準）＝対照用。
            // ⚠参照点は【前期の値】を読む（★更新はこの pop の処理の最後＝同一ティック内で閉じない）。
            double want = 1.0 - p.Satisfaction;
            if (c.LivingRefWeight > 0)
            {
                if (p.LivingRef < 0) p.LivingRef = p.Satisfaction;   // 未捕捉＝現在値で初期化（立ち上がりの跳躍なし）
                double drop = p.LivingRef - p.Satisfaction;          // ★正＝落ちた（不満）／負＝上がった（体制への支持）
                want = (1.0 - c.LivingRefWeight) * want + c.LivingRefWeight * drop;
            }
            // 政治の空間モデル（voiceless の一般化）：政治的不満（闘争度）＝**意識 ×（1−実効発言権）× dist(POPの理想点, 現政体座標)**。
            // 旧 voiceless（参政権ギャップ＝参加1軸）を**4軸全体の乖離距離**へ。社会主義の労働者が絶対王政の下にいる＝4軸で遠い＝高い不満／保守的貴族＝近い＝満足。
            // 3つのゲートは全て実利/実状から創発：①意識（無学は政治的に受動＝徳川パス温存）②（1−発言権）＝**平和的回路の有無**（票を持つ層は不満を投票=改革へ流す＝暴動でなく National 集計で政体を引く／持たぬ層だけが暴動）③距離（理想と体制の乖離）。
            // ＝経済から創発した思想が理想点を、参政権ドリフトが現政体の参加軸を決める。参政権の広い体制ほど不満が改革へ流れ革命が減る。
            double[] ideal = Ideologies.IdealPoint(p.IdeologyShares);
            double pd2 = 0; for (int i = 0; i < 4; i++) { double x = ideal[i] - regimeCoord[i]; pd2 += x * x; }
            // 1934拡張E5 秘密投票（「紙の参政権」問題の是正）：発言権の**鎮静効果**を「選挙の実在」で変調＝専制が選挙なしで参政権を発行しても
            // 不満が満額鎮まる SelfPlay:195 の構造（太平天国が出ない一因）を封じる。議会政体×秘密投票=満額(1.0)・議会×公開投票=買収/脅迫で減(0.6)・
            // 非議会政体=紙の参政権で3割しか宥まらない(0.3)。SecretBallotGate=0 で reality=1.0＝旧式と恒等（E9で点火済み＝現行1.0）。
            double effVoice = InterestGroups.FranchiseVoice(p, w.Suffrage, c);
            if (c.SecretBallotGate > 0)
            {
                double reality = w.Polity is Polity.ConstitutionalMonarchy or Polity.Republic
                    ? (w.SecretBallot == SecretBallotLaw.Secret ? 1.0 : c.OpenBallotReality)
                    : c.PaperFranchiseReality;
                effVoice *= reality;
            }
            // 第5段5-4（2026-07-28）3層モデル＝連続分割（重みの和が厳密に1＝二重計上が構造的に不可能）：
            //   文盲 1−ℓ → 天命（素朴王政観・MandateBase）／教育 min(意識,ℓ) → 綱領政治（本項）／中間 ℓ−教育 → 危険な中間（下の midMil）。
            // 綱領政治の強度は意識のうち識字に裏打ちされた分のみ（便乗で意識だけ煽られた無学の群衆は綱領を持たない＝bandwagonMil/窮乏チャネルが担う）。
            double wEdu = Math.Min(p.Consciousness, p.Literacy);
            double wMid = p.Literacy - wEdu;
            double politicalGap = wEdu * (1.0 - effVoice) * Math.Sqrt(pd2) * 0.5;   // /2＝4軸[0,1]の最大距離2で正規化→[0,1]
            // 危険な中間（トクヴィルのパラドクス）：読み書きは覚えたが政治的意識が未成熟の層＝新聞・パンフレットに動員されやすく
            // 綱領を持たない不満の増幅器（1848の群衆）。識字化が先行し意識が追いつくまで、近代化そのものが体制を不安定にする＝飛ばせない中間。
            double midMil = c.MiddleLayerMilitancy * wMid;
            // POP動詞①（階級優遇/弾圧）は2026-07-20廃止＝ClassStance系の死蔵読み（stanceRelief・常時1.0）を第3段3-1で削除（2026-07-27・厳密恒等）。
            // 倍率排除⑥：社会保障・労働組合の不満緩和を**満足度経路に一本化**（直接の闘争度減算 −welfare −union を撤去）。
            // ⚠2026-08-21更新：旧記述「LaborWellbeing＝WelfareSatBonus×SS×Funding＋UnionSatBonus」のうち**福祉成分は物理削除済み**
            //   （思想⑨＝支出は財の購入のみで満足度を動かす。給付は WelfareCostRate/PensionCostRate の現金経路が担う・docs/202608/20260821_不満度系の棚卸し_完了.md）。
            //   現在の LaborWellbeing は UnionSatBonus（休眠0＝団体交渉権に再利用予定）のみ＝実質、直接バフの経路は空。
            //   本項の趣旨（不満の緩和は財の購入→Satisfaction→want の実体経路に一本化・直接減算を置かない）は不変。
            // 較正中立：harness は SocialSecurity=0・LaborUnion=非合法で両項とも0（NullAgent 不変）。
            // 群衆の熱：勢いある運動が「不満を持つ層」の怒りを煽る（満足した民＝低wantは勢いがあっても暴徒化しない＝豊かな自由国は安定し革新を続ける）。
            // 無学の動員は意識の便乗チャネル（上の bandwagon）が担い、ここは不満で gate ＝貧しい専制ほど暴徒化（露/オスマンの不安定化）。
            double bandwagonMil = c.BandwagonMilitancy * momentum * want;
            // 固執資材（国民的こだわり財）の機構は廃止：主食欠乏の怒りは満足度(NeedMet=主食tierが最重み)→want→WantWeight 経路が拾う。
            // 失業の怒り：職の喪失は所得の算術を超える（尊厳・規律の喪失＝失業者の行進）。主食が安く食えていても、
            // 職の無い大衆は政治化する＝**恐慌が政治を動かす主回路**（賃金の下方硬直→雇用量の調整→失業→ここ）。
            // 社会保障（welfare 項）がこれを和らげる＝福祉国家の意味（§C・改善項目1）。
            double unemployment = c.UnemploymentMilitancy * p.UnemploymentRate;
            // 1934拡張E5 失業保険：社会保障法が失業保険段以上なら失業の怒りを緩衝（給付が恐慌の政治的爆発を和らげる＝ファシズムの防波堤）。SocialSecurityLawGate=0で不読＝恒等。
            if (c.SocialSecurityLawGate > 0 && w.SocialSecurityLaw >= SocialSecurityLaw.Unemployment)
                unemployment *= 1.0 - c.UnemploymentInsuranceRelief;
            // 民族統一度（EthnicEnabled の国のみ。較正＝無効）。低統一度は分離圧力として不満の目標を押し上げる（多民族帝国の不安定化）。
            // 二重計上監査2026-07-11（B1）：EthnicUnity は CoreEthnicShare の人口加重平均そのもの＝少数派popは国項（平均内）と
            // pop項の両方に入る非対称な二重だった→**凸結合**＝国項×自分の中核度＋pop項×(1−中核度)。多数派pop(core=1)は国項のみ＝現行同値・
            // 完全少数派(core=0)はpop項のみ＝二重が厳密に消える。均質国では両項とも従来どおり（較正はEthnicEnabled=false＝中立）。
            double ethnicUnrest = w.EthnicEnabled ? c.UnitySecessionMilitancy * (1.0 - ethnicUnity) * p.CoreEthnicShare : 0;
            double minorityMil = w.EthnicEnabled ? c.MinorityMilitancy * (1.0 - p.CoreEthnicShare) : 0;
            // 参政権の範囲2法（2026-08-16）：移民原住民参政権「あり」＝本国州の非中核分(1−CoreEthnicShare)が政治的国民に算入される
            // ＝少数派の地位不満は ×(1−算入)＝算入1で0（新しい定数を作らない創発形）。植民地格の州は対象外（そちらは植民地参政権＝分離圧の緩和側）。
            if (migrantIncluded && milReg.Tier != RegionTier.Colonial) minorityMil = 0;
            // [PORT:P1] 闘争度targetへの寄与（加算項）＝生活/政治/失業/群衆/格差/民族/厭戦/革命の波。新規機構はこのポートに独立加算で接続する
            // 不満要因の内訳（診断・UI表示用。target への各寄与ぶんを記録＝計算には不使用・較正中立）。
            // 第3段3-7（2026-07-27）：PopMilDiagnostics（UIのみtrue）でゲート＝バッチでは全pop×毎四半期の死蔵書き込みを省く。
            if (w.PopMilDiagnostics)
            {
                p.MilLiving = c.WantWeight * want;
                p.MilVoice = c.PoliticalDistanceWeight * politicalGap;
                p.MilJobs = unemployment;
                p.MilWar = c.WarWearinessMilitancy * warWeariness;
                p.MilCrowd = bandwagonMil;
                p.MilGap = inequalityUnrest;
                p.MilNation = ethnicUnrest + minorityMil;
                p.MilMid = midMil;   // 第5段5-4：危険な中間（識字−意識ギャップ層）
            }
            // 外圧→闘争度の直加算（旧PressureWeight）はC裁定2026-07-09で撤去＝外圧はReformPressureBoost（改革派の力を押す）経路に一本化。p.MilForeignは常時0
            // [PORT:P1] 革命の波（2026-07-24・機構A）：他国の暴力的政変の興奮が闘争度targetを押す（1830/1848型の波及）。意識には効かせない
            //（意識は時定数17年の遅い変数＝数週間で伝わる興奮は闘争度の仕事）。RevolutionExportRate=0 で加算0（現行0.3点火）。
            double waveMil = c.RevolutionExportRate > 0 ? c.RevolutionWaveMilitancy * w.RevolutionWave : 0;
            if (w.PopMilDiagnostics) p.MilWave = waveMil;
            double target = Math.Clamp(
                c.WantWeight * want + c.PoliticalDistanceWeight * politicalGap + bandwagonMil + unemployment + ethnicUnrest + minorityMil + inequalityUnrest + c.WarWearinessMilitancy * warWeariness + waveMil + midMil, 0, 1);
            double delta = c.MilitancySpeed * (target - p.Militancy);
            // 高統一度は不満の【上昇】を鈍らせる（下降は妨げない＝「上昇率を下げる」）。同質な社会では不平が育ちにくい。
            if (delta > 0 && w.EthnicEnabled) delta *= 1.0 - c.UnityMilitancyRelief * ethnicUnity;
            p.Militancy += delta;
            // ★参照点を今の生活水準へ寄せる（⚠want を計算した【後】＝同一ティック内で閉じない）。
            if (c.LivingRefWeight > 0 && c.LivingRefSpeed > 0)
                p.LivingRef += c.LivingRefSpeed * (p.Satisfaction - p.LivingRef);
        }
        }   // 参政権の範囲2法：州→popの入れ子ループの閉じ（AllPops の展開形）

        Ideologies.UpdateShares(w);   // 各POPのイデオロギー分布を更新（段1＝創発のみ・遷移は未駆動＝較正不変）

        // 労働運動の両義性（B-5）：容認/統制の組合は組織労働として改革派を動員する＝体制への改革圧力（闘争度緩和で革命radicalは下げつつ、ここで改革reformistを上げる）。非合法＝動員なし。
        double unionMob = c.UnionMobilization * (w.LaborUnion switch { LaborUnionLaw.Tolerated => 1.0, LaborUnionLaw.Controlled => 0.5, _ => 0.0 });
        double reformist = 0, radical = 0, conscSum = 0, sizeSum = 0;
        foreach (var p in w.AllPops())
        {
            // POP動詞①（階級弾圧の表出抑制 express・常時1.0）は2026-07-20廃止＝第3段3-1で削除（2026-07-27・厳密恒等）。
            reformist += p.Size * p.Consciousness * (1 - p.Militancy);
            radical += p.Size * p.Consciousness * p.Militancy;
            if (unionMob > 0 && !p.Closed && !p.IsModernElite && !p.IsSoldier)
                reformist += p.Size * p.Consciousness * unionMob;   // 組織労働の政治動員＝改革派を押し上げ
            // 窮乏チャネル（パンの蜂起＝1789）：意識が低くても、窮乏で闘争度が暴動水準を超えた群衆は革命的脅威になる
            // （飢えた群衆そのもの＝バスティーユ）。意識ゲートとは別経路で radical 挑戦力に上乗せ。平穏な大衆には発火しない＝徳川パス温存。
            // 二重計上監査C1（2026-07-11）：高意識のmilitantは上の意識経路（politicalGap）と本経路の両方に乗る二重だった→
            // ×(1−gate×Consciousness)＝「無学の飢えた群衆」の設計意図どおりのゲート（gate=1で完全直交・0で旧＝休眠可）。
            // 失われるradicalはDesperationChallengeWeightの補償再調整とセット（較正のAbsolutist梯子帯が番人）。
            radical += p.Size * Math.Max(0, p.Militancy - c.RiotMilitancyThreshold) * c.DesperationChallengeWeight
                     * (1.0 - c.DesperationConsciousnessGate * p.Consciousness);
            conscSum += p.Consciousness * p.Size;
            sizeSum += p.Size;
        }
        reformist *= 1 + c.ReformPressureBoost * w.ExternalPressure;   // 明治の追い風（§A-11）
        w.ReformistPower = reformist;
        w.RadicalPower = radical;
        // 平均満足度＝経済危機の指標（一党支配→独裁化はこれが低い危機国だけ＝満足した安定な立憲を巻き込まない）。
        // 第5段5-1：実装をNationalScore.MeanSatisfactionへ一元化（旧＝本ループの重複集計。pop更新後の同時点で呼ぶ＝値は従来と厳密一致）。
        w.MeanSatisfactionPol = sizeSum > 1e-9 ? NationalScore.MeanSatisfaction(w) : 1.0;

        // POP動詞①（弾圧の遺恨蓄積ループ・ClassStance常時0で不発）は2026-07-20廃止＝第3段3-1で削除（2026-07-27・厳密恒等）。

        // P8 天命 DynasticMandate v2（第5段5-3・2026-07-27）：抽象EMA→**未教育層の支持**へ再定義（docs/202607/20260727_政治の中核ルールと危機の選択_部分完了.md【一部】.md §8）。
        // Mandate＝未教育層（1−意識加重）の満足の評価EMA＝支持層が実在し検算可能。満足度は未教育popを通じてのみ天命へ・教育popを通じてのみ闘争度へ（§8-3）。
        // 「食えている限りの忠誠」＝dmFood/dmWar/dmGraft が王朝循環の条件を担う（§8-6）。決定的勝敗のインパルスは読まない＝DefeatShock/VictoryLegitBoost専属・二重流入排除。
        // 効果＝正統性の**連続項のみ**非対称増幅（離散インパルス＝敗戦ショック/戦勝/破産/鎮圧/建国には掛けない）。
        double dynErodeMul = 1.0, dynRegenMul = 1.0;
        if (c.DynasticMandateEnabled > 0.5)
        {
            if (w.DynasticMandate < 0) w.DynasticMandate = 0.5;   // 未捕捉のみ初期化（0.5=中立・跳躍なし）
            double dmPrev = w.DynasticMandate;
            // 5-3/5-4：文盲層（重み＝1−識字）の加重満足＝天命の母数（PoliticalQuantities.MandateBase＝UIと共有の唯一実装。母数ゼロ＝全pop平均へ退避）。
            // 3層分割（5-4）＝各popの重みが文盲(1−ℓ)/教育(min(意識,ℓ))/中間(残り)へ厳密に1へ分割：文盲→天命（素朴王政観）・
            // 教育→綱領政治(politicalGap)・中間→危険な中間（下の闘争度項）＝同じ根（満足）が式でなく人口で分割され二重計上が構造的に不可能（規約3を構造で満たす）。
            var (uneduShare, uneduSatAvg) = PoliticalQuantities.MandateBase(w);
            double dmSat = c.DynMandateSatWeight * ((uneduSatAvg >= 0 ? uneduSatAvg : w.MeanSatisfactionPol) - 0.5) * 2.0;
            double dmFood = c.DynMandateFoodWeight * Math.Min(0, w.FoodFill - c.DynMandateFoodAnchor);
            double dmWar = -c.DynMandateWarWeight * (w.SelfPower?.WarExhaustion ?? 0);
            double dmGraft = -c.DynMandateGraftWeight * w.EffectiveCorruption;
            double dynPerf = dmSat + dmFood + dmWar + dmGraft;
            double dmTarget = Math.Clamp(0.5 + dynPerf, 0, 1);
            w.DynasticMandate += c.DynMandateEmaRate * (dmTarget - w.DynasticMandate);
            if (w.Explain != null)   // 説明API：天命の内訳（合計＝最終値の厳密分解）
            {
                double r = c.DynMandateEmaRate;
                w.Explain.Reset("DynasticMandate");
                w.Explain.Add("DynasticMandate", "前期からの天命(履歴の累積)", dmPrev);
                w.Explain.Add("DynasticMandate", "中立への回帰", r * (0.5 - dmPrev));
                w.Explain.Add("DynasticMandate", "未教育層の満足(天命の母数)", r * dmSat);
                w.Explain.Add("DynasticMandate", "飢えの評価", r * dmFood);
                w.Explain.Add("DynasticMandate", "戦争疲弊の評価", r * dmWar);
                w.Explain.Add("DynasticMandate", "汚職の体感", r * dmGraft);
                double dmClamp = r * ((dmTarget - 0.5) - dynPerf);
                if (dmClamp != 0) w.Explain.Add("DynasticMandate", "評価の飽和", dmClamp);
            }
            // 第5段5-3（2026-07-27）：手書きのNC減衰（ncFade=1−1.2×NC・DynMandateNcFade削除）→**文盲人口シェア**（5-4で1−識字に確定）へ。
            // 識字が広がるほど天命の母数が自動的に痩せる（改革のジレンマが導出になる＝係数1本消滅）。
            double dynE = (w.DynasticMandate - 0.5) * 2.0 * uneduShare;
            // 第5段5-5（2026-07-28）宗教＝文盲層の政治回路：天命は聖職者（教会）に媒介されて王座へ流れる（§8-10）。
            // 開度＝国教法（国教のみ1.0→内心の自由0.85→信仰の自由0.7→国家無神論0）×容量＝聖職者の実在（文盲人口あたり・飽和）。
            // 公教育の代償が導出になる：識字↑→母数痩せ（5-3/5-4）＋教会収入↓（十分の一税・教育需要）→聖職者減→媒介痩せ＝天命の供給元の破壊。
            // 聖職者が未モデルの世界（合成較正・最小テスト）＝素通し1.0（機構は制度が実在する世界でのみ差を作る）。MandateReligiousCircuit=0で恒等。
            if (c.MandateReligiousCircuit > 0)
            {
                double lawOpen = w.StateReligion switch { StateReligionLaw.InnerFreedom => 0.85, StateReligionLaw.ReligiousFreedom => 0.7, StateReligionLaw.StateAtheism => 0.0, _ => 1.0 };
                bool clergyModeled = false; double clergySize = 0;
                foreach (var p in w.AllPops()) if (p.ClassId == PopClass.Clergy) { clergyModeled = true; clergySize += p.Size; }
                double illit = uneduShare * w.TotalPopulation;
                double capacity = clergyModeled && illit > 1e-9 ? Math.Min(1.0, clergySize / (illit * c.ClergyMediationPerCapita)) : 1.0;
                dynE *= 1.0 - c.MandateReligiousCircuit * (1.0 - lawOpen * capacity);
            }
            dynErodeMul = Math.Clamp(1.0 - c.DynMandateAmplify * dynE, DynMandateMulMin, DynMandateMulMax);   // [PORT:P3] 天命→正統性の連続項レバー（侵食/回復の対称クリップ乗数）。名君＝侵食が鈍る／暗君＝加速
            dynRegenMul = Math.Clamp(1.0 + c.DynMandateAmplify * dynE, DynMandateMulMin, DynMandateMulMax);   // 対称クリップ＝安全弁（開幕即崩壊と無制限加速の両防止）
        }
        double avgConsc = sizeSum > 1e-9 ? conscSum / sizeSum : 0;
        // 倍率排除⑥：政体別 erosion(絶対/専制/幕府=0.07・軍政=0.22)を**制度ギャップ**で一本化（恒久的な罠を作らない＝やがて革命）。
        // 意識ある社会が要求する代表/自由(RepresentationThreshold)と実効(Freedom＝参政権＋報道法から創発)の差が正統性を侵食する。
        // ＝閉じた体制(低Freedom)ほど・意識が高いほど削れ、代表的な体制(Freedom≥閾値)は自動で侵食ゼロ（政体ラベルでなく制度実数から創発）。
        double institutionalGap = avgConsc * Math.Max(0, c.RepresentationThreshold - w.Freedom);
        // 腐敗→正統性侵食（corruption-only-fiscal-leak）：縁故主義・公共財の毀損は制度不信を生む。意識ある社会(avgConsc)ほど腐敗を許さない＝institutionalGap と同型ゲート。
        // 較正中立：合成較正は行政財なしで AdminEfficiency=1.0＝(1−AdminEfficiency)=0 で侵食0（係数0.015は実世界で効く）。腐敗は財政漏れ(Fiscal)に加え政治的代償を持つ。
        double corruptionErosion = c.CorruptionLegitimacyErosion * avgConsc * Math.Max(0, 1.0 - w.AdminEfficiency);   // C2-C5撤去2026-08-16：末尾の ×(1−CleanGovernance) を物理削除（V2恒久ONで清廉度は恒等0＝×1.0はIEEE754で厳密恒等）。⚠監視(OversightV2)はここに掛けない＝掛けると挙動変更（掃除の範囲外・要裁定なら較正ラウンドで）
        // 政1：全侵食項を erosion に集約（無状態版 leg=1−erosion／ストック版は前期値からこの erosion を差し引き緩慢に再生）。
        double erosion = (c.LegitimacyErosionRate * institutionalGap + corruptionErosion) * dynErodeMul + c.DefeatShockLegitWeight * w.DefeatShock;   // 敗戦ショックが正統性を一時的に大きく削る（敗戦→革命）。較正は DefeatShock=0＝中立。P8天命は連続項のみ変調（×1.0で恒等・敗戦インパルスは除外）
        // 説明API（#63）：正統性の内訳を実寄与量で記帳。既定は LegitimacyIsStock=1.0＝**ストック**（履歴が累積する経路依存量）。
        // 代数：leg = (1−s)·1 + s·P + s·regen − erosion − mandate（P=前期の正統性・侵食は s に依らず全額）。ゆえに「前期からの正統性（履歴）＋今期の回復−侵食−マンデート＋後続イベント（戦勝/デフォルト/内戦…）」に分解される。
        // null 条件のため説明モードオフでは丸ごと短絡＝本計算はビット恒等。侵食の各項はこの下で個別に負記帳する。
        if (w.Explain != null)
        {
            w.Explain.Reset("Legitimacy");
            w.Explain.Add("Legitimacy", "前期からの正統性(履歴の累積)", w.Legitimacy);
            w.Explain.Add("Legitimacy", "自然回復(安定期の信任回復)", c.LegitimacyRegenRate * Math.Max(0, 1 - w.Legitimacy) * dynRegenMul);
            w.Explain.Add("Legitimacy", "制度ギャップ侵食(意識と参政権・報道の乖離)", -c.LegitimacyErosionRate * institutionalGap * dynErodeMul);
            w.Explain.Add("Legitimacy", "腐敗侵食(縁故主義・公共財の毀損)", -corruptionErosion * dynErodeMul);
            w.Explain.Add("Legitimacy", "敗戦ショック", -c.DefeatShockLegitWeight * w.DefeatShock);
        }
        // 議会の力学（ParliamentEnabled のみ＝合成較正は従来どおり）：既存の正統性に信号を流し、遷移を創発させる（外科的フリップなし）。
        if (w.ParliamentEnabled)
        {
            double maxSeat = Math.Max(w.PartySeats[0], Math.Max(w.PartySeats[1], w.PartySeats[2]));
            // 立憲君主制：議会の反王党派（自由+社会）の議席が王冠の正統性を削る＝議会優勢→共和（君主の形骸化）。
            if (w.Polity == Polity.ConstitutionalMonarchy)
            {
                double constErode = c.ConstMonarchyErosion * (w.PartySeats[1] + w.PartySeats[2]) * dynErodeMul;
                erosion += constErode;
                w.Explain?.Add("Legitimacy", "議会の反王党派議席(立憲君主の形骸化)", -constErode);
            }
            // 一党支配（共和制・立憲君主制）：閾値超の支配が多元的正統性を削る→権威主義へ漂流（正統性↓→保持力↓→内戦なし即時）。
            // **危機国（平均満足度＜閾値）のみ**＝経済が破綻した社会の支配的政党だけが独裁に転ぶ（ワイマール→ナチ型）。満足した安定な一党優位（英・米の自由党多数等）は無傷で侵食しない。
            if (w.Polity is Polity.ConstitutionalMonarchy or Polity.Republic && maxSeat > c.PartyDominanceThreshold && w.MeanSatisfactionPol < c.DominanceInstabilitySatisfaction)
            {
                double domErode = c.DominanceLegitimacyErosion * (maxSeat - c.PartyDominanceThreshold) / (1 - c.PartyDominanceThreshold) * dynErodeMul;
                erosion += domErode;
                w.Explain?.Add("Legitimacy", "一党支配の私物化(多元的正統性の毀損)", -domErode);
            }
        }
        // 政1：正統性＝**ストック**（前期値から侵食を減算し、上限1へ緩慢に再生＝内戦ドレイン等が累積する経路依存量）。
        // 第3段3-4/3-5（2026-07-27）＝旧・フロー/ストック混合（LegitimacyIsStock）を1.0焼き込みで簡約：
        // legFlow（毎期計算して重み0で捨てる死荷重）と (1−s)×MandateSpent（同じく重み0の死項）を削除。s=1.0は2026-07-10点火以来の既定＝厳密恒等。
        double leg = w.Legitimacy - erosion + c.LegitimacyRegenRate * Math.Max(0, 1 - w.Legitimacy) * dynRegenMul;   // ストック（前期値から侵食・再生）。P8天命＝回復の変調（×1.0で恒等）
        // 政治資本の請求（マンデート余白・Government.MandateGate）：余白で反対を押し切った分だけ正統性を削る。
        // ストック正統性では前期の減算が残留する→毎期ストック全額を引くと増幅率≈1/RegenRate=50倍の二重計上
        // （一歩ΔM=0.125で累積≈6.25＝即崩壊・2026-07-10再設計）→**今期増分 MandateSpentNew だけを一回減算**し、回復は再生項に一本化。
        // 実効圧政（下の Coercion=BaseCoercion×Legitimacy×funding）も連動して弱まる＝押し切る統治は鎮圧力も燃やす（意図した結合）。
        // MandateSpent（減衰ストック）は強権UI表示・CrownParliamentの紛争記憶が読む現役フィールド＝存続。
        double mandateClaim = w.MandateSpentNew;
        leg -= mandateClaim;
        w.Explain?.Add("Legitimacy", "マンデート行使(政治資本で反対を押し切る)", -mandateClaim);
        w.MandateSpentNew = 0;
        w.MandateSpent *= 1.0 - c.MandateRecoveryRate;   // 強権の回復を正統性再生率から分離（2026-07-26ユーザー裁定：取得率をやや下げ＝旧0.1共用→専用0.07）
        double legClamped = Math.Clamp(leg, 0, 1);
        if (w.Explain != null && legClamped != leg)
            w.Explain.Add("Legitimacy", legClamped > leg ? "下限クランプ(0未満を切上げ)" : "上限クランプ(1超を切下げ)", legClamped - leg);
        w.Legitimacy = legClamped;
        // [PORT:P3] P10①信任帝政の正統性の下限（2026-07-18・RedefinedMandateEnabled=0で不走行＝恒等）：立憲君主×王冠保持×高NC×高天命の時のみ Legitimacy≥floor×Mandate の床。
        // 「民の信任を得た皇帝はパンの値段ではもう滅びない」。⚠稀であるべき＝条件を厳しく（緩いと立憲固着＋仏が共和に届かない）。加算でなく床＝天命との二重計上なし。
        if (c.RedefinedMandateEnabled > 0.5 && w.DynasticMandate >= 0
            && w.Polity == Polity.ConstitutionalMonarchy && w.Crown != CrownForm.None
            && w.NationalConsciousness >= c.RedefinedMandateNcMin && w.DynasticMandate >= c.RedefinedMandateMandateMin)
        {
            double floorLeg = c.RedefinedMandateFloor * w.DynasticMandate;
            if (w.Legitimacy < floorLeg)
            {
                w.Explain?.Add("Legitimacy", "信任帝政の下限(民の信任を得た皇帝)", floorLeg - w.Legitimacy);
                w.Legitimacy = floorLeg;
            }
        }
        w.DefeatShock *= c.DefeatShockDecay;   // 敗戦ショックは四半期で減衰（leg が今期の全幅を浴びた後・数年で消える）。Politics.Step は四半期1回
        w.VictoryShock *= c.VictoryShockDecay;   // 機能8-②（2026-07-28）：戦勝の熱狂も同様に数年で冷める（r[4]/r[8]の持続はこの減衰だけが決める＝Ideologyは毎期クリア再構成）
        // 機能8-④（2026-07-28）：飢えの記憶＝ストック＋減衰（RegimeTrackRecordと同じ様式）。アンカーは天命と同じ飢饉基準（DynMandateFoodAnchor＝単一ソース）。
        // 「パンの値段」の題名に最も近い機構＝飢饉は過ぎ去っても急進思想（共和/社会）として残る（1789の記憶）。
        w.FamineMemory = w.FamineMemory * c.FamineMemoryDecay + Math.Max(0, c.DynMandateFoodAnchor - w.FoodFill);

        // P7 制度疲労の脱出動学（2026-07-17・RNGなし決定論・主フラグ全0で不走行＝恒等）：下げ＝ショックのみ（小改革の積み重ねでは下がらない＝日清敗北なくして戊戌変法なし）／
        // 再成長＝反動（旧支配層優位×検閲が続く限り天井へ）／ロックイン（公教育以上・立憲/議会・工業化・清廉継続のいずれか）で再成長停止＝定着。クランプ[0,天井]＝初期0の国は恒久0
        if ((c.DecayReformResistWeight > 0 || c.DecayTechAdoptWeight > 0 || c.DecayMilitaryWeight > 0) && w.InstitutionalDecayCeiling > 1e-9)
        {
            if (w.Explain != null)   // 説明API：毎期Resetして前期値から積む（Resetなしの逐次Addは台帳が無限蓄積する）
            {
                w.Explain.Reset("InstitutionalDecay");
                w.Explain.Add("InstitutionalDecay", "前期からの制度疲労(履歴の累積)", w.InstitutionalDecay);
            }
            if (w.DecayShockCooldown > 0) w.DecayShockCooldown--;
            bool shock = false;
            bool defeatNow = w.DefeatShock >= 0.5;                            // 決定的敗戦（ResolvePeace が 1.0 を注入した直後の高水準・減衰済み残滓と区別）
            if (defeatNow && !w.DecayPrevDefeatShock) shock = true;
            w.DecayPrevDefeatShock = defeatNow;
            bool cwNow = w.CivilWarYears > 0;                                 // 大規模反乱（内戦の勃発エッジ）
            if (cwNow && !w.DecayPrevCivilWar) shock = true;
            w.DecayPrevCivilWar = cwNow;
            if (w.HadSovereignDefault && !w.DecayPrevDefault) shock = true;   // 国家破産（恒久フラグの立ち上がり）
            w.DecayPrevDefault = w.HadSovereignDefault;
            // C-中9（史実検証2026-07-22）：上の恒久boolでは破産は1ゲーム1回しか窓を開かない（オスマン1875→ミドハト憲法1876、エジプト1876、西は19世紀に6回デフォルト）。
            // さらに Prev の更新が下のクールダウン判定の外にあるため、破産が別ショックの20四半期クールダウン中に起きると唯一のエッジが消費され緩和が永久に失われる（オスマン1875破産→1877露土敗戦が実例）。
            // 回数エッジ＋保留ラッチで両方を解消。DecayShockRepeatable=0 で両方とも不読＝厳密恒等。
            if (c.DecayShockRepeatable > 0)
            {
                if (w.SovereignDefaultCount > w.DecayPrevDefaultCount) shock = true;
                w.DecayPrevDefaultCount = w.SovereignDefaultCount;
                if (shock) w.DecayShockPending = true;
                shock = w.DecayShockPending;
            }
            if (shock && w.DecayShockCooldown <= 0)
            {
                double before = w.InstitutionalDecay;
                w.InstitutionalDecay = Math.Max(0, w.InstitutionalDecay - c.DecayShockRelief);
                w.DecayShockCooldown = c.DecayShockCooldownQuarters;
                w.DecayShockPending = false;
                w.Explain?.Add("InstitutionalDecay", "ショックの改革の窓", w.InstitutionalDecay - before);
            }
            else
            {
                bool lockin = w.EducationLaw is EducationLaw.Public or EducationLaw.Compulsory
                           || w.Polity is Polity.ConstitutionalMonarchy or Polity.Republic
                           || w.MeanIndustrialization >= c.DecayLockinIndustrialization;   // C2-C5撤去2026-08-16：清廉度ロックイン（CleanGovernance≥DecayLockinCleanGov）を物理削除＝V2恒久ONで清廉度は恒等0＝この枝は常に偽の死骸だった
                if (!lockin && w.Censorship != CensorshipLaw.FreePress)
                {
                    var (tradP, modernP, massP) = InterestGroups.Blocs(w);
                    if (tradP >= modernP && tradP >= massP)
                    {
                        double before = w.InstitutionalDecay;
                        w.InstitutionalDecay = Math.Min(w.InstitutionalDecayCeiling, w.InstitutionalDecay + c.DecayReactionRegrowth * (w.InstitutionalDecayCeiling - w.InstitutionalDecay));
                        w.Explain?.Add("InstitutionalDecay", "反動の再硬直", w.InstitutionalDecay - before);
                    }
                }
            }
            double idBeforeClamp = w.InstitutionalDecay;
            w.InstitutionalDecay = Math.Clamp(w.InstitutionalDecay, 0, w.InstitutionalDecayCeiling);
            if (w.Explain != null && w.InstitutionalDecay != idBeforeClamp)
                w.Explain.Add("InstitutionalDecay", w.InstitutionalDecay > idBeforeClamp ? "下限クランプ" : "天井クランプ(初期の構造硬直)", w.InstitutionalDecay - idBeforeClamp);
        }
        // 圧政と軍事のリンク(A)：軍は内外を兼ねる一つの武力＝戦時は軍が前線へ取られ国内の鎮圧力が下がる（厭戦＝長期戦ほど大→本国で革命機会＝1917型）。
        // 機能6-1（第7段第2波・2026-07-28）：戦時の結束（rally around the flag）＝開戦直後は保持力が上がるが厭戦で減衰し（WarRallyDecayPoint超でゼロ）、
        // 長期戦はドレインが上回る＝1914年8月の熱狂→1917年の崩壊が単一項で出る。恒常抑制にしない（二月革命型を殺さない）。WarRallyCoercion=0で旧恒等。
        double warExh = w.SelfPower?.WarExhaustion ?? 0;
        double warDrain = 1.0
            + (Government.AtWar(w) ? c.WarRallyCoercion * Math.Max(0, 1.0 - warExh / Math.Max(1e-9, c.WarRallyDecayPoint)) : 0)
            - c.WarCoercionDrain * warExh;   // [PORT:P5] 戦時ドレイン→保持力の乗数（軍は内外を兼ねる一つの武力）
        w.Coercion = w.BaseCoercion * w.Legitimacy * w.FiscalFundingRatio * warDrain;   // §6.2（絶対値＝犯罪の秩序カバレッジはこのまま人口あたりで評価）
        double coerce = PoliticalQuantities.EffectiveCoerce(w, c);   // 政体力学の実効保持力＝人口あたり強度（第5段5-1＝一元化・今期導出値＝従来と同時点）

        // 財政破綻は外科的な政体フリップでなく**経済悪化（信用収縮＝Credit）**として効かせ、政治的帰結は通常の遷移に委ねる（債務不履行→経済悪化の段階）。
        Factions.Step(w, c);   // F3a：国内勢力の永続化と変異（牙＝下の CheckFactionRevolt・FactionRevoltScale=1.0 稼働中）
        if (w.CivilWarYears > 0) ProcessCivilWar(w, c, reformist + radical, coerce);   // 内戦中は通常遷移せず戦乱を進める
        else
        {
            Transition(w, c, reformist, radical, coerce);
            if (w.CivilWarYears <= 0) CheckSecession(w, c, coerce);   // 革命が起きなければ分離独立を判定（保持力は人口項を内包・政5で coerce=軍/警察由来の保持力を渡す）
            if (w.CivilWarYears <= 0) CheckFactionRevolt(w, c, coerce);   // F3b 組織運動の内乱（結束した国内勢力＝太平天国型・FactionRevoltScale=1.0稼働・0で観察のみ）
            if (w.CivilWarYears <= 0) CheckRegionalRevolt(w, c, coerce);   // F1 州一揆（王権議会F1・RegionalRevoltThreshold=0で無効・現行0.25）
        }

        w.Freedom = FreedomFromLaws(w.Suffrage, w.Censorship);   // 倍率排除②：政体ラベルでなく参政権＋報道法から創発

        // 王権議会（CrownParliament）：議会統制力・協力度3チャネル・軍帰属を毎四半期導出＝財政（Fiscal/Government）・外交・議会・政体遷移が読む。RNGなし＝決定論。
        CrownParliament.Step(w, c);
    }

    /// <summary>
    /// 政体転換（§9-E・利益集団駆動）。動員（改革派＋急進派）が現体制の保持力（圧政×正統性）を超えると倒れ、
    /// **支配的になる勢力と移行の仕方が目標政体を決める**：漸進改革→立憲君主制（明治型）／革命は主力が大衆ならプロレタリア独裁・
    /// ブルジョワなら共和制。権威主義（絶対/専制/幕府）からの転換が主。自由な政体ではブルジョワが大衆の脅威に独裁化、
    /// 貴族が極端なら反動・復古。絶対君主制は貴族が衰え官僚軍が空白を埋めると専制君主制（上からの近代化）へ。
    /// </summary>
    private static void Transition(World w, Coefficients c, double reformist, double radical, double coerce)
    {
        double challenge = reformist + radical;
        // 画一的な政体遷移（イデオロギー駆動）：国民イデオロギー集計→各政体の支持→引力点。
        // 引力点が現政体と異なり、支持差が保持力（PolityInertia×正統性）を超えれば遷移。任意→任意が単一式で出る。
        // 旧来の手書き分岐（軍クーデタ・1917・ブルジョワ反動・独裁の出口…）はこの一式に吸収（軍の力・厭戦は支持に上乗せ/イデオロギー経由）。
        var agg = Ideologies.National(w);
        double soldierForce = SoldierForce(w, c);
        // 一党支配（議会のある政体）：与党の独裁形態の引力を押し上げ＝支配的政党が体制を私物化（社会→プロ独裁／自由→ブルジョア独裁／保守→軍政）。
        // 正統性侵食（上）と対で働き、支配が極まると独裁が引力点になる。多元的な選挙（拮抗）では発火しない＝外科的でなく支配度で連続。
        Polity? domDictator = null; double domExcess = 0;
        // 一党支配→独裁化は**危機国（平均満足度＜閾値）のみ**＝満足した安定な立憲/共和（英・米の一党優位）は独裁の引力を受けない＝立憲を巻き込まずに稀な独裁を出す。
        if (w.ParliamentEnabled && w.Polity is Polity.ConstitutionalMonarchy or Polity.Republic && w.MeanSatisfactionPol < c.DominanceInstabilitySatisfaction)
        {
            double maxSeat = Math.Max(w.PartySeats[0], Math.Max(w.PartySeats[1], w.PartySeats[2]));
            if (maxSeat > c.PartyDominanceThreshold)
            {
                domExcess = (maxSeat - c.PartyDominanceThreshold) / (1 - c.PartyDominanceThreshold);
                domDictator = w.GoverningParty switch
                {
                    2 => Polity.ProletarianDictatorship,
                    1 => Polity.BourgeoisDictatorship,
                    _ => Polity.MilitaryDictatorship,
                };
            }
        }
        // 倍率排除⑧段階2：現政体の参加軸を**実際の参政権**へドリフト（控えめ）。広い参政権の立憲＝高参加で安定／狭い立憲＝低参加で共和へ押される
        // ＝政体ラベルでなく実法律が政体の引力を動かす（①②③の総仕上げ）。較正中立：sweep は実参政権＝政体の建国参政権でドリフト≒0。
        double[] curCoord = PoliticalQuantities.DriftedPolityCoord(w.Polity, w.Suffrage, c);
        // 法多様性（政体・2026-07-07）：大衆闘争×ブルジョワ勢力＝ブルジョア独裁の引き金（下記 AvgMassMilitancy の設計コメントの配線＝
        // 高闘争の議会制国家でエリートが秩序回復の独裁を敷く）。議会制の立憲/共和のみ＝較正（ParliamentEnabled=false）遮蔽。
        // ★2026-08-12：**危機ゲートの非対称を解消**（BourgeoisCoupNeedsCrisis=1で有効・0で旧挙動）。
        //   すぐ上の一党支配→独裁化（domDictator）は「満足した安定な立憲/共和は独裁の引力を受けない」という危機ゲート
        //   （MeanSatisfactionPol < DominanceInstabilitySatisfaction）を持つのに、**同じ「議会制国家がエリート独裁に転ぶ」
        //   現象を測るこの項だけが素通り**していた。近代ブロックが厚い国ほど値が大きくなるので、最も厚いアメリカ
        //   （貴族18 に対し 資本家429・専門職143）が最も転びやすい＝1923年に BourgeoisDictatorship で反動剥奪を受け、
        //   参政権と報道を1段ずつ失って識字26%・技術2.64まで落ちる（実測）。秩序回復の独裁は**回復すべき無秩序**を要る。
        double bourgeoisCoup = 0;
        if (c.BourgeoisCoupWeight > 0 && w.ParliamentEnabled && w.Polity is Polity.ConstitutionalMonarchy or Polity.Republic
            && (c.BourgeoisCoupNeedsCrisis <= 0 || w.MeanSatisfactionPol < c.DominanceInstabilitySatisfaction))
        {
            var (_, modernPower, _) = InterestGroups.Blocs(w);
            bourgeoisCoup = c.BourgeoisCoupWeight * modernPower * AvgMassMilitancy(w);
        }
        Polity attractor = w.Polity; double best = double.NegativeInfinity, cur = 0;
        foreach (var pol in Ideologies.Polities)
        {
            double s = Ideologies.SupportAt(agg, pol == w.Polity ? curCoord : Ideologies.BasePolityCoord(pol), c.IdeologyAffinitySlope);
            if (pol == Polity.MilitaryDictatorship)
                // P1-F 軍帰属の変調（AllegianceCoupWeight=0で恒等・現行0.5）：王権に忠実な軍(ArmyAllegiance>0)はクーデタしにくく、未払い/自律(≈0)・反王権(<0)の軍はしやすい（プロヌンシアミエントの物理）。
                s += c.MilitaryCoupSupport * soldierForce / Math.Max(1.0, coerce)
                   * Math.Max(0, 1.0 - c.AllegianceCoupWeight * w.ArmyAllegiance);   // 軍部の力（クーデタは銃が要る＝イデオロギーだけでない）
            if (domDictator is { } dd && pol == dd) s += c.DominanceCoupWeight * domExcess;   // 一党支配→その独裁形態の引力
            if (pol == Polity.BourgeoisDictatorship) s += bourgeoisCoup;   // 法多様性：大衆闘争が高いほどブルジョワが独裁へ傾く
            // 政体形態の実績ストック（信認⇔失望・docs/2026-07-13_形態別失望ストック.md）：その形態系統の実績で支持を符号付きに増減
            // ＝信認された形態（正）は選ばれ/現体制なら粘り（entrench）、失望された形態（負）は避けられる→両穏健形が負なら極端が浮上（ワイマール/1917）。
            // 現政体 cur にも掛かる（成功体制は保持力↑=固着方向・失敗体制は保持力↓=変化方向）。乗数は Max(0.05,..) で符号保存。0で恒等（現行0.3）。
            if (c.RegimeTrackRecordWeight > 0)   // [PORT:P4] 実績ストック→遷移支持の乗数（Max(0.05,·)＝符号保存）
                s *= Math.Max(0.05, 1.0 + c.RegimeTrackRecordWeight * w.RegimeTrackRecord[CrownParliament.RegimeFamily(pol)]);
            if (pol == w.Polity) cur = s;
            if (s > best) { best = s; attractor = pol; }
        }
        if (attractor == w.Polity || best - cur <= c.PolityInertia * w.Legitimacy) return;   // 現状が引力点 or イデオロギー差が保持力に届かない＝変化なし
        // 政2：上からの改革（明治型・欽定憲法・露大改革）＝支配ブロック自身が主導する代議制/近代化への移行。大衆動員(challenge)が圧政を超えずとも遷移できる例外チャネル。
        // ReformFromAboveEnabled=0 では下の challenge<=coerce ゲートが無条件で効く＝旧挙動（明治1889/プロイセン欽定/露大改革は不能・現行1.0点火）。
        // >0 で「①引力点が別政体（上の第1ゲートを通過済＝支配層含む国民集計で現政体より別政体の支持が高い）②正統性侵食が進行中(Legitimacy<閾値)③遷移先が反動的奪取でない代議制方向」の三条件が揃えば coerce ゲートを免除。
        // ＝支配層が自ら立憲化/近代化するので暴動を要しない。奪取(独裁/無政府)や急進暴力革命は対象外＝あくまで漸進の上からの改革のみ。
        // C-高1(1)（史実検証2026-07-22）：anticipation＝大衆動員圧(challenge/coerce)＋外圧が高いほど発火閾値が上がる（革命の予感が王を動かす＝
        // 自由民権運動1874-84・ハイドパーク暴動1866→第二次選挙法）。旧＝正統性ストック平衡が完全閉鎖でも0.895・恒常内戦でも0.445で閾値0.4を割らず
        // 窓がデフォルト/敗戦/失脚の直後2-3年のみ＝事実上のno-op だった。Weight=0 で加算0＝厳密恒等。
        // ⚠初版は外圧 w.ExternalPressure（死んだ定数0.3）を常時加算していたため閾値が0.72-0.92へ張り付き「上からの改革」が乱発＝
        // 日本/プロイセン/蘭/西が逸脱過多へ崩れた（batch2026-07-23実測）。動員圧のみへ絞る＝正統性が侵食され**かつ**動員が高まった時だけ窓が開く。
        double anticipation = c.ReformAnticipationWeight > 0
            ? c.ReformAnticipationWeight * PoliticalQuantities.ChallengeRatio(challenge, coerce)
            : 0;
        bool reformFromAbove = c.ReformFromAboveEnabled > 0 && !IsSeizure(attractor)
                             && w.Legitimacy < c.ReformFromAboveLegitThreshold + anticipation;
        if (challenge <= coerce && !reformFromAbove) return;   // 動員（改革派＋急進派）が実効圧政を超えない＝国家が鎮圧＝高圧政の権威主義は工業化しても徳川に留まる（上からの改革チャネルのみ免除）
        // P3c 遷移グラフの廃止（PolityGraphRetired=0で従来どおり・現行1.0）：**平和的な漸進遷移**（非奪取×改革派主導）はグラフのジャンプから外す＝
        // 連続動学（P3b＝議会/王権圧力→統制力→床交差の再ラベル・廃位・王権の形の変異）が同じ帰結を漸進で出す。
        // 暴力革命（急進主導）と奪取（独裁/無政府）は史実どおり不連続イベント＝ExecuteRegimeChange のまま。
        // C-高1(2)：改革派主導の平和的遷移でも「上からの改革」が発火しているなら下賜（ExecuteRegimeChange の GrantedControlOnReform）に到達させる
        //（旧＝この早期returnが下賜の点火口を殺し、欽定憲法が原理的に不能だった）。ReformGrantPcWidth=0 では旧条件のまま＝厳密恒等。
        if (c.PolityGraphRetired > 0 && !IsSeizure(attractor) && radical <= reformist && !(reformFromAbove && c.ReformGrantPcWidth > 0)) return;
        ExecuteRegimeChange(w, c, attractor, reformFromAbove, reformist, radical, challenge, coerce);
    }

    /// <summary>奪取＝討議でなく実力で押し込む政体（独裁・無政府）。様態判定と政2の適用除外で共有。</summary>
    private static bool IsSeizure(Polity p) => p is Polity.BourgeoisDictatorship or Polity.ProletarianDictatorship
                                                 or Polity.MilitaryDictatorship or Polity.Anarchy;

    // P3a 奪取イベント化（2026-07-12・ビット同一抽出）：政体変更の**実行部**＝様態（拮抗の暴力転換→内戦／圧勝・平和→即時）→
    // 登録簿（ApplyRegime）→建国制度→債務→失脚、を Transition（引力点グラフ）から分離。将来のP3b（連続動学＝統制力の床交差・
    // 廃位イベント・王権の形の変異）が同じ実行部を呼ぶ＝政体変更の単一の書き込み経路。条件・呼び出し順とも旧 Transition 本文のまま。
    internal static void ExecuteRegimeChange(World w, Coefficients c, Polity target, bool reformFromAbove,
                                             double reformist, double radical, double challenge, double coerce)
    {
        // 様態：独裁・無政府への奪取 or 急進主導＝暴力（拮抗なら内戦・圧勝なら即時）／代議制への漸進＝平和即時。
        // 政2：上からの改革は支配層主導の平穏な漸進＝暴力(内戦)経路を通さず平和即時遷移（既定 reformFromAbove=false で従来どおり）
        bool violent = (IsSeizure(target) || radical > reformist) && !reformFromAbove;
        if (violent && challenge < coerce * c.CivilWarLandslideRatio)
        {
            w.CivilWarYears = c.CivilWarDurationYears; w.CivilWarTarget = target; w.HadCivilWar = true;   // 拮抗した暴力転換＝内戦（数年）
            return;
        }
        // 革命の輸出（2026-07-24・機構A）：暴力的な即時転換＝倒れる旧政体を放送（この時点の w.Polity は旧政体。四半期末にMultiNationSimが回収）。
        // 平和的漸進・上からの改革は放送しない（隣の玉座が「落ちた」事実だけが波を作る）。回収側は RevolutionExportRate=0 で不加算（現行0.3点火）。
        if (violent)
        {
            w.RevolutionBroadcast = w.Polity;
            RevolutionAwakensNation(w, c);
            // 第6段6-8b：奪取型の暴力転換（軍政・独裁＝クーデタ）＝断裂の窓（ナポレオン3世1851・ストルイピン1907型の書き換え解禁）。
            if (IsSeizure(target)) w.RuptureWindowQuarters = Math.Max(w.RuptureWindowQuarters, (int)c.RuptureWindowQuartersOnCrush);
        }
        // ★親軍法の撤去（2026-08-18）：軍事独裁への遷移で法を立てる行を削除。政体由来の軍事費の床も撤去済み（Government・2026-08-19）
        //   ＝軍政の軍国性は PoliticalQuantities.MilitaryPoliticalRatio 等の導出量が担う。
        // P1-A 下賜（明治1889・欽定憲法型）：上からの改革での遷移は「弱い議会を王権が与える」＝統制力の床を下賜値へ（GrantedControlOnReform=0で休眠・現行0.3）。
        // C-高1(2)（史実検証2026-07-22）：下賜PCの連続化＝床0.3に動員圧比例の幅を加算（強い議会圧力ほど厚い譲歩＝予算協賛権つきの欽定憲法。
        // 幅0.15で最大0.45＝立憲床に到達＝日本/プロイセン/オーストリアの exact=CM 要求と設計意図の矛盾を解く一般則）。Width=0 で加算0＝厳密恒等。
        if (reformFromAbove && c.GrantedControlOnReform > 0)
        {
            double grant = c.GrantedControlOnReform
                + c.ReformGrantPcWidth * PoliticalQuantities.ChallengeRatio(challenge, coerce);
            w.ParliamentControl = Math.Clamp(Math.Max(w.ParliamentControl, grant), 0, 1);
            w.ReformGrantCount++;   // C-高1完成検証（2026-07-25）：下賜の発生数（診断＝chronicleが集計。挙動非依存）
        }
        // P2（flag=1）：上からの改革は**PC床（上の下賜）だけ**を書きラベルは導出に委ねる＝下賜0.3<立憲床0.45なら幕府/専制のまま
        // 「近代法を持つが議会に権力を渡さない」プロイセン/明治型が自然点になる（ラベルが後日 床交差で変わった時だけ建国制度が走る）。
        if (reformFromAbove && c.PolityLabelFromAxes > 0) return;
        CrownParliament.ApplyRegime(w, c, target);   // 登録簿＋政体キャッシュ（flag=1はPCジャンプも）＝単一の書き込み口（P2）
        RaiseFoundingInstitutions(w, allowRevoke: true, c);   // 新政体の含意参政権・報道へ（自由化＝拡張／反動＝剥奪＝ラチェット解除・反革命の波。政3：c 渡しで自由化はラチェット可）
        RepudiateDebt(w, c, target);          // 既定は債務継承（史実）。急進革命のみ否認＝下記
        var (dt, dm, dmass) = Dispossessed(target);
        ResolveRevolt(w, c, dt, dm, dmass);   // 敗れたブロックが失脚（既存の失脚スパイクを流用＝反革命の芽）
        // ★革命は土地権力を壊す（2026-08-04・列強再現率の診断）。史実のフランス革命の核心＝**封建地代の廃止**
        //   （1789年8月4日・biens nationaux）。旧＝政変後も貴族の地代＝政治力（LandedPowerCapitalization）が無傷で、
        //   新体制→旧支配層の復権→反動→再革命のピンポンで130年が浪費され、仏の技術が0.28に沈んでいた
        //   （scorebreak実測＝上位がポーランド/ラオス等の平和な小国・仏47位）。
        //   共和革命＝土地改革（限定的）・プロレタリア独裁＝全面（集産化）。**書くのは既存の法**＝FarmRentCap が
        //   地代を削り、地代の資本化＝旧支配層の政治力が一緒に痩せる（機構は全て既存・この1本だけが欠けていた）。
        //   ⚠検地台帳の前提は迂回＝没収に台帳は要らない（参政権の floor-raise と同じ扱い）。
        //   ⚠立憲君主制には適用しない＝地主との妥協の産物（英・七月王政）。RevolutionLandReform=0 で厳密恒等。
        if (c.RevolutionLandReform > 0 && dt)
        {
            var floor = target == Polity.ProletarianDictatorship ? ReformLevel.Full
                      : target == Polity.Republic ? ReformLevel.Limited
                      : (ReformLevel?)null;
            if (floor is { } fl && (int)w.LandReform < (int)fl)
            {
                w.LandReform = fl;
                w.Policy.LandReform = (ReformLevel)Math.Max((int)w.Policy.LandReform, (int)fl);   // 新体制の目標にも＝Government が巻き戻さない
            }
        }
    }

    /// <summary>政体が含意する参政権・報道の自由を法へ一回 floor-raise（倍率排除②）。法と標準政策の両方を下限へ上げ、以後 Freedom/eff＝法律値で動く
    /// （毎期の政体→スカラー写像を廃止）。下限は上げるのみ＝反動政体への転落で自動的に剥奪はしない（参政権・報道はラチェット＝制限は別途立法を要する）。
    /// 代議制（立憲/共和）は報道も解放＝革新世界の技術水準が立つ。独裁は検閲を保つ＝形式的参政権があっても閉じた社会で停滞。</summary>
    public static void RaiseFoundingInstitutions(World w, bool allowRevoke = false, Coefficients? c = null)
    {
        var sufTarget = PolitySuffrage(w.Polity);
        var pressTarget = FoundingPress(w.Polity);
        // ★政変は梯子を一括で配らない（2026-08-04・作者指摘「あまりに早期に近代的な法律を取り入れすぎる」）。
        //   ── 実測で判ったこと ────────────────────────────────────────────────
        //   `lawtiming` で見ると 日本1797・オーストリア1813・清1819 で「代議制へ」「制限選挙」「男性普通選挙」
        //   「秘密投票」が**全て同年**だった。政変1回で近代法制が丸ごと手に入っていた＝強権のたまりの問題ではなく、
        //   **この関数が政体の含意水準へ一足飛びに書いていた**のが早期近代化の実体だった（門を通らない直接代入）。
        //   ── 直し方 ──────────────────────────────────────────────────────────
        //   政変が動かすのは**1段だけ**。その先は立法（Government の門＝支持と議会）を通して一段ずつ登る。
        //   史実の梯子＝英1832→1867→1884→1918、仏1791制限→1792男子普選（革命は連続した政変として表現される）。
        //   ⚠上げも下げも1段＝反動の剥奪も一括では起きない（対称）。
        //   ⚠初期化（allowRevoke=false）は対象外＝シナリオの開始値はそのまま尊重する。
        //   ⚠StagePrereq=0 で従来と厳密一致（現行1.0点火）。
        if (allowRevoke && c is not null && c.StagePrereq > 0)
        {
            int su = (int)w.Suffrage, pr = (int)w.Censorship;
            sufTarget = (Suffrage)Math.Clamp((int)sufTarget, su - 1, su + 1);
            pressTarget = (CensorshipLaw)Math.Clamp((int)pressTarget, pr - 1, pr + 1);
        }
        if (allowRevoke)
        {
            // 反革命の波（復古王政・ビスマルク反社会主義法・ナポレオン3世のクーデタ）：政体転換は参政権・報道を**政体の含意水準へ上げも下げも**＝ラチェット解除。
            // 下げても大衆の支持が強ければ AI/議会が翌期に自らの選好で再拡大しうる＝19世紀の振り子（剥奪は反動ブロックの支配が続く間だけ保つ）。
            // 政3：縮小方向（剥奪）を反動系政体への遷移時のみに限定するラチェット。SuffrageRatchetOnLiberalize=0（または c=null の初期化パス）では従来どおり上げも下げも
            // （立憲化で参政権が Census へ縮む旧バグ＝現行1.0点火で解消済み）。>0 かつ遷移先が代議制（反動系でない）なら floor-raise のみ＝自由化はラチェット（19世紀に立憲化が選挙権を狭めた例はない）。
            bool ratchet = c is not null && c.SuffrageRatchetOnLiberalize > 0 && !IsReactionaryPolity(w.Polity);
            if (ratchet)
            {
                // 自由化遷移＝下限を上げるのみ（剥奪しない）。反動政体への遷移(下の else 相当の剥奪)だけがラチェットを解除する。
                var sufFloorL = (Suffrage)Math.Max((int)w.Suffrage, (int)sufTarget);
                w.Suffrage = sufFloorL;
                w.Policy.Suffrage = (Suffrage)Math.Max((int)w.Policy.Suffrage, (int)sufFloorL);
                var pressFloorL = (CensorshipLaw)Math.Max((int)w.Censorship, (int)pressTarget);
                w.Censorship = pressFloorL;
                w.Policy.Censorship = (CensorshipLaw)Math.Max((int)w.Policy.Censorship, (int)pressFloorL);
            }
            else
            {
                w.Suffrage = sufTarget;
                w.Policy.Suffrage = sufTarget;
                w.Censorship = pressTarget;
                w.Policy.Censorship = pressTarget;
            }
        }
        else
        {
            // 初期化：与えられた初期状態を尊重＝floor-raise のみ（剥奪しない）。
            var sufFloor = (Suffrage)Math.Max((int)w.Suffrage, (int)sufTarget);
            w.Suffrage = sufFloor;
            w.Policy.Suffrage = (Suffrage)Math.Max((int)w.Policy.Suffrage, (int)sufFloor);   // 建国の参政権を標準政策へ＝Government が漸進で巻き戻さない（AIは翌期に自らの選好で上書きしうる）
            var pressFloor = (CensorshipLaw)Math.Max((int)w.Censorship, (int)pressTarget);
            w.Censorship = pressFloor;
            w.Policy.Censorship = (CensorshipLaw)Math.Max((int)w.Policy.Censorship, (int)pressFloor);   // 建国の報道自由も標準政策へ（同上）
        }
    }

    /// <summary>政3：参政権・報道の剥奪（縮小方向）を許す「反動系」政体か。代議制（立憲君主制・共和）＝自由化方向のみ false（自由化はラチェット）。
    /// 絶対君主・専制・幕府・各独裁・無政府＝反動/権威主義への遷移＝剥奪を許す（復古王政・ビスマルク反社会主義法・ナポレオン3世のクーデタ・プロ独裁の集権）。</summary>
    private static bool IsReactionaryPolity(Polity p) => p is not (Polity.ConstitutionalMonarchy or Polity.Republic);

    /// <summary>政権交代に伴う国債の扱い。**既定は継承**（史実：復古フランスも明治政府も旧体制の債務を引き継いだ）。
    /// **急進革命（プロレタリア独裁・無政府）のみ債務を否認**する（ソ連1917のツァーリ債務否認）＝例外。
    /// これにより「借金を貯めてから政体を変えれば財政リセット」という非現実的な攻略を封じる。
    /// 否認の代償＝国際信用の崩壊：兌換停止→外資は CapitalMarket で逃避し当面借りられない（砲艦外交・国際財政管理の含意）。
    /// GovDebt は通貨でなく請求権の数値なので、ゼロ化は基礎貨幣保存に影響しない（債権者＝資本家の保有分が焦げ付くのは別途その貯蓄で表現済み）。</summary>
    private static void RepudiateDebt(World w, Coefficients c, Polity newPolity)
    {
        if (newPolity is not (Polity.ProletarianDictatorship or Polity.Anarchy)) return;   // 継承（リセットしない）＝攻略封じ＋史実
        w.GovDebt = 0; w.ForeignDebt = 0;
        w.OnGoldStandard = false; w.GoldStandardSuspendedInCrisis = true;   // 対外信用の崩壊＝兌換崩壊→外資逃避（CapitalMarket）。当面 借りられない
        // C-中1（史実検証2026-07-22）：革命的否認に信用市場の代償が無かった（BorrowCooldown も触らないため即座に再起債できる＝一過性Anarchyが債務ロンダリング装置になる）。
        // 史実の代償は「永久追放」でなく長期市場からの排除＋高コスト短期化（ソヴィエト1918否認→ジェノヴァ1922決裂、以後も短期の供給者信用は継続）。
        // ※制度疲労ショックとは切り離す（HadSovereignDefault/SovereignDefaultCount は立てない＝革命そのものが既に体制転換なので二重計上を避ける）。RepudiationCreditPenalty=0で不読（現行1.0点火）。
        if (c.RepudiationCreditPenalty > 0) w.BorrowCooldown = c.DefaultCooldownQuarters;
    }

    // 各政体が成立時に失脚させる（特権を奪う）ブロック：旧→新で誰が権力を失うか。
    private static (bool trad, bool modern, bool mass) Dispossessed(Polity target) => target switch
    {
        Polity.Absolutist or Polity.Despotic or Polity.Shogunate => (false, true, true),    // 復古＝近代エリート・大衆を抑える
        Polity.ConstitutionalMonarchy or Polity.Republic         => (true, false, false),   // 自由化＝旧支配層が特権を失う
        Polity.BourgeoisDictatorship                             => (false, false, true),   // 大衆を抑圧
        Polity.ProletarianDictatorship                           => (true, true, false),    // 旧支配層・ブルジョワが失脚
        Polity.MilitaryDictatorship                              => (true, false, true),     // 軍政＝旧支配層も民衆も抑える
        Polity.Anarchy                                           => (true, true, true),      // 秩序崩壊＝全員
        _                                                        => (false, false, false),
    };

    // 内戦の進行（拮抗した暴力革命・分離独立）：四半期ごとに戦死・正統性低下、年数が尽きたら決着。
    // 決着：動員（reformist+radical）が圧政を依然超えていれば反乱勝利＝目標政体へ／さもなくば中央が鎮圧（闘争度緩和）。
    private static void ProcessCivilWar(World w, Coefficients c, double challenge, double coerce)
    {
        foreach (var p in w.AllPops())
        {
            if (p.Closed || p.IsModernElite) continue;   // 戦死は大衆・兵士（特権身分・近代エリートは戦場外）
            double dead = p.Size * c.CivilWarCasualtyRate;
            p.Size -= dead;
            w.PopulationDelta -= dead; w.WarDeadCumulative += dead;   // 人口保存（戦死を台帳に計上）
        }
        // 動員：大衆を兵士へ徴集（労働喪失→生産減・火器需要↑が創発。外科的な生産penaltyの代わり）。
        double conscripted = 0;   // 政13：今期の内戦徴集量（反乱側の仮想戦力へ回す分の基礎）
        foreach (var r in w.Regions)
        {
            if (r.State != RegionState.Active) continue;
            var soldier = r.Pops.Find(p => p.IsSoldier);   // 兵士はフラグで判定（ClassId==5 直書きを排除）
            if (soldier is null) continue;
            var peasant = r.Pops.Find(p => p.ClassId == c.SoldierRecruitClassA);   // 徴集プールは Military.cs と同じ設定（農民）
            var worker = r.Pops.Find(p => p.ClassId == c.SoldierRecruitClassB);    // 同（都市労働者）
            if (peasant is not null) { double m = peasant.Size * c.CivilWarConscriptRate; Military.MoveCohort(peasant, soldier, m); conscripted += m; }
            if (worker is not null) { double m = worker.Size * c.CivilWarConscriptRate; Military.MoveCohort(worker, soldier, m); conscripted += m; }
        }
        // 政13：内戦に反乱側がなく、徴集が国家の兵士pop（→CoercionTarget→鎮圧力）へ一方的流入＝内戦激化が政府の鎮圧力を機械的に高める（恐怖政治で貴族が最も死んだ仏革命と逆）。
        // 徴集の一部を challenge 側の仮想戦力として分離計上する（反乱側も動員する）。累積で持ち、決着時の challenge に加算＝内戦が長引くほど反乱側も増強され、政府の一方的な鎮圧力上昇を相殺。
        // CivilWarRebelSide=0 では累積ゼロ＝決着判定の challenge は旧式のまま。>0（現行0.5）で徴集量のその割合を反乱戦力として蓄積。
        w.CivilWarRebelStrength += c.CivilWarRebelSide * conscripted;
        double legBeforeCivilWar = w.Legitimacy;
        w.Legitimacy = Math.Clamp(w.Legitimacy - c.CivilWarLegitimacyDrain, 0, 1);
        w.Explain?.Add("Legitimacy", "内戦の消耗(戦乱が信任を削る)", w.Legitimacy - legBeforeCivilWar);   // 説明API（#63）
        // #136 内戦の民間人死（2026-07-25）：内戦は兵士だけでなく民間を殺す（太平天国の主死因は戦闘でなく飢餓・虐殺・流民）。
        // 四半期率×非兵士人口を規模按分で減算＝Diplomacy.WarCasualties と同じ保存作法（Size減算＋PopulationDelta台帳）。
        // CivilWarCivilianToll=0 で不発（現行0.005）。
        if (c.CivilWarCivilianToll > 0)
        {
            double civPop = 0; foreach (var p in w.AllPops()) if (!p.IsSoldier) civPop += p.Size;
            if (civPop > 1e-9)
            {
                double toll = civPop * c.CivilWarCivilianToll;
                foreach (var p in w.AllPops()) if (!p.IsSoldier) p.Size -= toll * (p.Size / civPop);
                w.PopulationDelta -= toll; w.WarDeadCumulative += toll;
            }
        }
        w.CivilWarYears -= 1.0 / Calendar.QuartersPerYear;
        if (w.CivilWarYears > 0) return;
        w.CivilWarYears = 0;
        challenge += w.CivilWarRebelStrength;   // 政13：反乱側の累積動員を決着判定へ（CivilWarRebelSide=0で加算なし・現行0.5）。決着後にリセット（下）
        w.CivilWarRebelStrength = 0;   // 内戦終了＝反乱側戦力をクリア（次の内戦は新規に積む）
        if (w.SecedingRegion is { } reg)   // 分離戦の決着：中央が弱い（動員>圧政）と離脱成功＝州喪失、さもなくば再統合
        {
            w.SecedingRegion = null;
            if (challenge > coerce && reg.State == RegionState.Active)   // 離脱成功＝州は連邦から脱退
            {
                // 建国モード（SecessionSpawnsNation>0）：多国シム（共有外交あり＝StepsDiplomacy=false）でのみ建国要求を親Worldへ記録し、
                // MultiNationSim が四半期末に新国家として実体化する（ベルギー独立型）。単一国シム/較正には回収者がいないため従来のLocked経路へ。
                if (c.SecessionSpawnsNation > 0 && !w.StepsDiplomacy && w.SelfPower is not null)
                {
                    w.PendingSecessionRegion = reg;
                    foreach (var p in reg.Pops) p.Militancy *= c.ReformMilitancyRelief;   // 独立達成＝闘争の目的を得た（鎮圧側:下の緩和と同形・フィルタなし）
                }
                else
                {
                // 集計是正（監査2026-07-14）：seceded州の住民は国家会計から抜ける＝TotalPopulation除外の対称として PopulationDelta を同額引く
                // （割譲 CedeTerritory の loser.PopulationDelta -= P と同作法）。人口保存不変量 TotalPopulation==初期+PopulationDelta を維持。貨幣は非接触（ユーザー指定＝人口・識字・食料のみ）。
                w.PopulationDelta -= reg.SumPopulation();
                reg.State = RegionState.Locked; reg.Infra = 0;
                reg.Seceded = true;   // 監査2026-07-11（他2）：分離喪失州の印＝辺境開発（懐柔）の対象外。旧＝無償の自動開発が約100ヶ月でActiveへ戻し元の国へ自動復帰＝分離独立が「8年の休眠ペナルティ」に退化していた。復帰は武力（ForceUnlock＝再征服・国庫と闘争度の実費）のみ
                foreach (var m in reg.Markets) { m.PrevStock = m.Stock; m.LastProduced = m.LastSold = m.LastImport = m.LastExport = m.LastShortage = 0; m.PopBought = null; }   // 財収支の恒等式を保つ
                }
            }
            else   // 中央が鎮圧＝再統合（その州の闘争度緩和）
                foreach (var p in reg.Pops) p.Militancy *= c.ReformMilitancyRelief;
            // F3b 分離戦の主体（民族分岐で記録）も決着で燃え尽きる（成功＝独立を達成し国内運動でなくなる／鎮圧＝組織壊滅）。
            // CheckSecession 発の分離戦は主体なし（null）＝従来どおり。
            if (w.RevoltingFaction is { } sf) sf.Cohesion = 0;
            w.RevoltingFaction = null;
            return;
        }
        // F3b 湘軍項：反乱の主体（RevoltingFaction）と思想距離が遠い有産ブロックが体制側で郷勇を組む＝決着判定の保持側へ加算
        // （曽国藩＝異端の大反乱ほど郷紳が王朝側に立つ。国家革命＝主体なしの内戦では従来どおり0）。
        double militia = w.RevoltingFaction is { } rfm ? LoyalistMilitia(w, c, rfm) : 0;
        // F3b 決着の対称性（2026-07-12）：勢力の内乱は発火と同じ物差し（勢力強度＝現在値を再計測）で決着する。
        // 国民総動員(challenge)で測ると無選挙権の一クラスタの蜂起が国全体の不満を背負って勝ってしまう（英の社会主義蜂起が政権を取る等）
        // ＝勝敗の非対称バグ。国家革命（主体なし＝Transition/分離発）は従来どおり challenge（政13の反乱側累積動員も challenge 側のみ）。
        double attack = w.RevoltingFaction is { } rfa ? FactionStrength(w, c, rfa) : challenge;
        // ★内戦による国家分裂（点火2026-08-01・docs/202607/20260731_内戦による国家分裂_部分完了.md【一部】.md）。
        // ── なぜ要るか ────────────────────────────────────────────────────────
        // 内戦の決着が「反乱が勝つ／中央が勝つ」の二値しかないのは史実の姿ではない。**どちらも押し切れないと国が割れる**
        // （アメリカ南北戦争1861・グラン・コロンビアの解体1831・墨の連邦派対中央派）。
        // ── どう判定するか ──────────────────────────────────────────────────
        // ①拮抗＝どちらの戦力も相手の CivilWarLandslideRatio 倍に届かない。★**新しい帯を作らない**——発火側にしか
        //   使われていなかった同じ定数を決着側にも使う（同じ定数で「圧勝か拮抗か」を測る＝物差しが1本）。
        // ②州が陣営を選ぶ＝その州のPOPの思想分布が、反乱の目標政体を現政体より支持するか（Ideologies.Regional）。
        //   ⚠**国名も文化名も出てこない**（思想②）。アメリカ南部が離れるのは南部のpopの思想分布がそうさせるからで、
        //   「南部だから」ではない。だから同じ条件が揃えば清でも墺でも起きる。
        // ③首都（Id0）は必ず中央に残る＝親が消滅しない・首都不変条件を壊さない。
        if (c.CivilWarSplitEnabled > 0 && w.RevoltingFaction is null && !w.StepsDiplomacy
            && w.SelfPower is not null && w.Regions.Count > 1
            && attack < (coerce + militia) * c.CivilWarLandslideRatio
            && coerce + militia < attack * c.CivilWarLandslideRatio)
        {
            // ★★再点火の是正（2026-08-13・差し戻しの根を断つ）＝**傾きを絶対値でなく国の平均との差で測る**。
            // 旧＝「反乱の目標政体を現政体より支持するか」を各州で**絶対値**判定していた。⚠内戦中は国全体の思想が反乱側へ寄るので
            //   ほぼ全州で成立し、16州→1州が1イベントで起きた（帝国の解体）＝「南部が離れる」と「国が消える」が区別できなかった。
            // ★新＝各州の傾き edge を出し、**国の平均より反乱側へ寄っている州だけ**が離れる。
            //   ⚠国が一様に反乱側なら平均を超える州は出ない＝分裂しない（それは分裂でなく**革命**であり、下の通常決着が受ける）。
            // ★さらに、離脱側が多数派になる場合も分裂ではない（それは中央が負けたということ）＝通常決着へ落とす。
            // ⚠新しい帯も閾値も1つも足していない——平均という物差しは分布そのものから出る。
            double edgeSum = 0; int edgeN = 0;
            foreach (var r in w.Regions)
            {
                if (r.State != RegionState.Active) continue;
                var agg0 = Ideologies.Regional(w, r);
                edgeSum += Ideologies.Support(agg0, w.CivilWarTarget, c.IdeologyAffinitySlope)
                         - Ideologies.Support(agg0, w.Polity, c.IdeologyAffinitySlope);
                edgeN++;
            }
            double edgeMean = edgeN > 0 ? edgeSum / edgeN : 0;
            if (!(edgeMean > double.NegativeInfinity && edgeMean < double.PositiveInfinity)) edgeMean = 0;   // NaNは平均0へ倒す（否定形で書く）
            System.Collections.Generic.List<Region>? rebels = null;
            foreach (var r in w.Regions)
            {
                if (r.Id == 0 || r.State != RegionState.Active) continue;
                var agg = Ideologies.Regional(w, r);
                double edge = Ideologies.Support(agg, w.CivilWarTarget, c.IdeologyAffinitySlope)
                            - Ideologies.Support(agg, w.Polity, c.IdeologyAffinitySlope);
                if (edge > edgeMean) (rebels ??= []).Add(r);   // 平均より反乱側＝この国の中で相対的に離れたい塊
            }
            if (rebels is not null && rebels.Count * 2 >= edgeN) rebels = null;   // 多数派の離脱は分裂でない＝通常決着（革命）へ
            w.CivilWarSplitCandidateRegions = rebels?.Count ?? 0;
            if (rebels is { Count: > 0 })
            {
                w.PendingSplitRegions = rebels;
                w.PendingSplitPolity = w.CivilWarTarget;   // 離脱側は自分たちの目標政体を持って出る（親の政体更新後では取れないので凍結）
                w.CivilWarSplitCount++;
                foreach (var p in w.AllPops()) p.Militancy *= c.ReformMilitancyRelief;   // 割れた＝両陣営とも矛を収める（勝敗と同じ緩和）
                w.LogAdd($"{w.Year} {w.SelfPower.Name}の内戦が決着せず国が割れた({rebels.Count}州)");
                return;
            }
        }
        if (attack > coerce + militia)   // 反乱が依然優勢＝革命勝利→目標政体へ（失脚で不安定）
        {
            if (w.RevoltingFaction is { } rf && w.CivilWarTarget == w.Polity)
            {
                // F3b 経済決着：政体は変わらない＝運動の要求をのませる（F1譲歩の大型版＝要求top-kを複数段・政治資本を大量に燃やす）。
                // 緩和は運動の本拠州の大衆のみ（全国一律にしない＝Transition鎮圧緩和との二重を作らない）。
                ConcedeToFaction(w, c, rf);
                foreach (var p in rf.Region.Pops) if (!p.Closed && !p.IsSoldier) p.Militancy *= c.ReformMilitancyRelief;
                w.LogAdd($"{w.Year} {w.SelfPower?.Name}が{Factions.DisplayName(rf)}の要求をのんだ");
            }
            else
            {
                w.RevolutionBroadcast = w.Polity;   // 革命の輸出（2026-07-24・機構A）：内戦の反乱勝利＝暴力的転換の成立。倒れる旧政体を放送（回収側は RevolutionExportRate=0 で不加算・現行0.3点火）
                RevolutionAwakensNation(w, c);      // 第5段5-6：内戦を経た革命の勝利も国民意識の直接回路（即時転換と対称）
                CrownParliament.ApplyRegime(w, c, w.CivilWarTarget);   // P2：登録簿＋政体キャッシュの単一の書き込み口（flag=0では従来のPolity書きと恒等）
                RaiseFoundingInstitutions(w, allowRevoke: true, c);   // 内戦勝利の新政体へ（反動勝利＝剥奪・自由革命＝拡張。政3：c 渡しで自由化はラチェット可）
                RepudiateDebt(w, c, w.CivilWarTarget);   // 内戦の政権交代も既定は継承・急進革命のみ否認
                // wave2b：即時転換側（ExecuteRegimeChange L640）と同じ失脚規則を使う（旧＝ここだけ手書きの近似で
                // BourgeoisDictatorship/MilitaryDictatorship/Anarchy 系の失脚対象がずれていた）。
                var (dt, dm, dmass) = Dispossessed(w.CivilWarTarget);
                ResolveRevolt(w, c, dt, dm, dmass);
                if (IsSeizure(w.CivilWarTarget)) w.RuptureWindowQuarters = Math.Max(w.RuptureWindowQuarters, (int)c.RuptureWindowQuartersOnCrush);   // 奪取系への内戦勝利も断裂の窓（即時転換側 L620 と対称）
                if (c.RevolutionLandReform > 0 && dt)   // 内戦を経た革命勝利も土地改革の floor-raise を適用（即時転換側 L650-660 と対称）
                {
                    var floor = w.CivilWarTarget == Polity.ProletarianDictatorship ? ReformLevel.Full
                              : w.CivilWarTarget == Polity.Republic ? ReformLevel.Limited
                              : (ReformLevel?)null;
                    if (floor is { } fl && (int)w.LandReform < (int)fl)
                    {
                        w.LandReform = fl;
                        w.Policy.LandReform = (ReformLevel)Math.Max((int)w.Policy.LandReform, (int)fl);
                    }
                }
            }
        }
        else   // 中央が持ちこたえた＝反乱鎮圧（闘争度緩和）
        {
            foreach (var p in w.AllPops()) p.Militancy *= c.ReformMilitancyRelief;
            // 第6段6-8b：内戦の制圧＝断裂の窓（1849年の反動＝墺1851大晦日勅令・普三級選挙法）。
            w.RuptureWindowQuarters = Math.Max(w.RuptureWindowQuarters, (int)c.RuptureWindowQuartersOnCrush);
        }
        // F3b 決着＝運動の燃え尽き（2026-07-12）：鎮圧＝組織壊滅（1849年の反動・指導部の処刑流刑）／勝利＝要求は法へ・運動は解散。
        // 結束を残すと同じ運動が数年おきに再蜂起し続ける（蘭で実測6回/125年）＝再蜂起には組織の再建（結束の再成長≈20年）が要る。
        if (w.RevoltingFaction is { } spent) spent.Cohesion = 0;
        w.RevoltingFaction = null;   // 決着＝内乱の主体を解放（勝敗どちらでも）
    }

    // F3b 組織運動の内乱（牙と変異・2026-07-12）：結束した国内勢力（F3a＝州×階級×主軸のクラスタ）が保持力を上回ると内乱化。
    // Transition＝国家集計の即時革命／F1＝無組織の食料一揆（即時・小）／F3b＝**持続した組織運動の大内乱**（結束ゲート0.5≈3年超）＝
    // 同じ闘争度を読むが関数形と時定数が別・CivilWarYearsゲート＋共有クールダウンで排他。決着はクラスタ性格で3分岐（裁定2026-07-11）＝
    // 民族（本拠州が少数派）→分離戦／政治（主軸の最寄り政体≠現政体）→政体戦（勝利時はApplyRegimeが登録簿へ）／経済→要求戦（ConcedeToFaction）。
    private static void CheckFactionRevolt(World w, Coefficients c, double coerce)
    {
        if (c.FactionRevoltScale <= 0 || w.FactionRng is null) return;
        if (w.RevoltCooldownQuarters > 0) return;   // F1と共有のクールダウン（減算はF1側＝同四半期の二重発火を構造的に防止）
        FactionState? best = null; double bestStrength = 0;
        foreach (var f in w.Factions)
        {
            if (f.Cohesion < c.FactionCohesionFightThreshold) continue;
            if (f.Region.State != RegionState.Active) continue;
            double strength = FactionStrength(w, c, f);
            if (strength > bestStrength) { bestStrength = strength; best = f; }
        }
        if (best is null) return;
        double hold = LocalizedHold(w, c, best, coerce);   // R2 蜂起R群2026-08-16：F3b保持力の州按分（FactionRevoltLocalCoerce=0＝coerceのまま＝ビット恒等／★既定は点火0.5＝半按分）
        double militia = LoyalistMilitia(w, c, best);   // 郷勇（全国）＝発火と圧倒判定で共有
        if (bestStrength <= hold + militia) return;
        // 第6段6-5①（2026-07-28）結束の予算化＝一斉投入のタイミング（中核ルールdoc §3-3①/§3-4）：閾値を越えても体制が健在なら
        // 待って蓄積を続け（静かな数十年＝結束は減らずに積み上がる）、弱み（低正統性・交戦・恐慌）か圧倒（保持力の大差超え）で打つ
        // ＝賢い挑戦者は歴史を平坦にせず遅らせて凝縮する（1848/1917の形）。FactionOpportunism=0で旧＝閾値即発火。
        if (c.FactionOpportunism > 0)
        {
            bool weakness = w.Legitimacy < c.FactionStrikeLegitimacy
                         || w.GdpDrawdown > c.FactionStrikeDrawdown
                         || Government.AtWar(w);
            if (!weakness && bestStrength < (hold + militia) * c.FactionOverwhelmFactor) return;   // R2：圧倒判定も同じ実効保持力を読む（フラグ0では hold==coerce＝ビット恒等）
        }
        // === 国内危機イベント（2026-07-20・戦争ポップアップ#106と同型）：蜂起寸前の択。プレイヤーは時間停止して選ぶ、AIは即決。 ===
        // 鎮圧は闘争度に触れず、その回の蜂起を打ち消して余剰戦力を消費するだけ（勢力は残り再燃）＝経済・政治の便益経路に漏れない＝非決定的（連発は余剰戦力上限で律速）。
        if (w.SelfPower?.IsPlayer == true)
        {
            if (w.PendingFactionCrisis is null)
            {
                w.PendingFactionCrisis = best;
                var d0 = FactionSnapshot.ComputeDemands(w, best.Bloc);
                w.PendingFactionCrisisDemands = d0.Count > 0
                    ? string.Join("・", d0.ConvertAll(d => FactionSnapshot.DemandJa(d.Axis, d.Increase)))
                    : "体制への漠然とした不満";
            }
            return;   // 択が済むまで蜂起は保留（UIが時間停止＝再発火しない）
        }
        // AI（プレイヤーと同じ択を自動で・賢く）：非議会系で余剰戦力があれば鎮圧（体制維持）。体制内の要求（最寄り政体＝現政体）は受諾（改革で回避）。止められない革命は蜂起させる。
        if (!(c.FactionSuppressionOmit > 0) && w.Polity is not (Polity.ConstitutionalMonarchy or Polity.Republic) && w.ExpansionWill >= c.SuppressFactionWillCost)
        {
            // ★段1（内戦一元化doc §5）：FactionSuppressionOmit>0 ではこの分岐ごと消える＝AIの択は「受諾か対決」の2つ（放置＝事実上の弾圧＝過激化は段3が担う）
            w.ExpansionWill -= c.SuppressFactionWillCost;   // 鎮圧＝余剰戦力を消費・闘争度は不変（勢力は残り再燃）＝非決定的
            best.Rejections += 1;   // ★段3：弾圧＝拒否の累積（読み手は FactionRejectionMutation>0 のみ＝既定恒等）
            SuppressionPoliticalCost(w, c);   // 第4段4-7：政治的代償（プレイヤーの鎮圧と対称）
            w.RevoltCooldownQuarters = c.RegionalRevoltCooldown;
            w.LogAdd($"{w.Year} {w.SelfPower?.Name}が{Factions.DisplayName(best)}の蜂起を武力で鎮圧");
            return;
        }
        if (NearestPolity(best.Ideo) == w.Polity)   // 体制内の要求（革命でない）＝要求を受け入れて回避（改革）
        {
            best.Rejections = 0;   // ★段3：受諾＝怨嗟の解消（チャーティズムが法で溶けた物理）
            ConcedeToFaction(w, c, best);
            w.RevoltCooldownQuarters = c.RegionalRevoltCooldown;
            w.LogAdd($"{w.Year} {w.SelfPower?.Name}が{Factions.DisplayName(best)}の要求を受け入れた");
            return;
        }
        // 第6段6-6（AI対称・2026-07-28）：革命的な運動（現政体と異なる引力）には本丸を拒み別の軸で埋め合わせる（ビスマルク反射＝
        // 参政権は拒み社会保険を与える）。副次要求の無い単一争点運動には効かない＝従来どおり蜂起へ。政治資本を燃やし運動は痩せて再来する。
        if (c.FactionCompensation > 0 && FactionSnapshot.ComputeDemands(w, best.Bloc) is { Count: >= 2 } demands)
        {
            best.Rejections += 1;   // ★段3：本丸の拒否＝穏健派は買われても核の怨嗟は積もる
            CompensateFaction(w, c, best, demands);
            w.RevoltCooldownQuarters = c.RegionalRevoltCooldown;
            w.LogAdd($"{w.Year} {w.SelfPower?.Name}が{Factions.DisplayName(best)}へ別の軸で譲歩した(本丸の要求は拒否)");
            return;
        }
        TriggerFactionRevolt(w, c, best);   // 止められない革命＝蜂起させる（従来通り）
    }

    // 蜂起の点火（CheckFactionRevolt のAI fall-through／プレイヤーの「対決」から共有）。性格で3分岐＝民族分離／政体戦／体制内要求戦。
    private static void TriggerFactionRevolt(World w, Coefficients c, FactionState best)
    {
        w.RevoltCooldownQuarters = c.RegionalRevoltCooldown;
        w.FactionRevolts++;
        best.Rejections += 1;   // ★段3：対決＝最後の拒否（内戦へ到達＝怨嗟は満額）
        // ★内戦一元化（CivilWarAsWar・2026-08-30・doc §3）：蜂起＝即座に反乱国家を建て、既存の戦争システムで戦う。
        //   本拠州が首都（Id0）の運動は州を割れない＝旧経路へフォールバック（doc ③首都は必ず中央に残る）。
        //   単国シム（StepsDiplomacy=true）には建国の回収者がいない＝旧経路（較正・テスト世界の挙動を変えない）。
        // ★是正2026-08-30（幕府テスト赤の根因）：**首都発の運動は戦争化しない**＝仏1789・明治維新型の首都革命は
        //   その場の政変（旧経路＝挑戦vs保持力の即時決着）が史実の形。初版は首都運動を地方へ旗揚げさせて全蜂起を戦争化し、
        //   「教育改革→近代政体」の平和的転換まで分離戦争に化けさせていた（Shogunate が永続）。
        //   戦争化するのは**本拠が地方の運動だけ**（太平天国・南北戦争・ヴァンデ型）＝一元化の対象は「地図の上の戦闘」であり宮廷政変ではない。
        if (c.CivilWarAsWar > 0 && !w.StepsDiplomacy && w.SelfPower is not null && w.Regions.Count > 1
            && best.Region.Id != 0 && w.Regions.Contains(best.Region))
        {
            Region baseReg = best.Region;
            w.PendingRebelRegions = [baseReg];
            w.PendingRebelPolity = NearestPolity(best.Ideo);
            w.HadCivilWar = true;
            w.RevoltingFaction = best;   // 決着（Diplomacy.ResolvePeace の内戦分岐→再併合）で運動は燃え尽きる
            w.LogAdd($"{w.Year} {w.SelfPower?.Name}で{Factions.DisplayName(best)}が蜂起し{baseReg.Name}に拠って立った（内戦）");
            return;
        }
        // 【民族】本拠州が少数派（中核度<0.5）＝分離の内乱（CheckSecessionの発火と完全同型→既存の分離戦処理が全て担う）
        if (best.Region.Id != 0 && AvgRegionCoreShare(best.Region) < 0.5)
        {
            w.SecedingRegion = best.Region;
            w.CivilWarYears = c.CivilWarDurationYears; w.CivilWarTarget = w.Polity;
            w.HadCivilWar = true; w.HadSecession = true;
            w.RevoltingFaction = best;   // 主体の記録＝分離戦の決着でも運動は燃え尽きる（下の SecedingRegion 分岐）
            w.LogAdd($"{w.Year} {w.SelfPower?.Name}で{Factions.DisplayName(best)}が分離の内乱を起こした");
            return;
        }
        // 【政治】主軸イデオロギーの最寄り政体が現政体と異なる＝政体戦（勝利時は既存のApplyRegime経路が登録簿・建国制度・債務否認まで処理）
        Polity target = NearestPolity(best.Ideo);
        w.CivilWarYears = c.CivilWarDurationYears;
        w.HadCivilWar = true;
        w.RevoltingFaction = best;
        if (target != w.Polity)
        {
            w.CivilWarTarget = target;
            w.LogAdd($"{w.Year} {w.SelfPower?.Name}で{Factions.DisplayName(best)}が蜂起した");
        }
        else
        {
            // 【経済】現体制の枠内の要求戦（チャーティスト・パンと土地）＝政体は変えず要求をのませる内乱
            w.CivilWarTarget = w.Polity;
            w.LogAdd($"{w.Year} {w.SelfPower?.Name}で{Factions.DisplayName(best)}が要求を掲げて蜂起した");
        }
    }

    // 国内危機イベントの決着（UIから）。mode: 0=要求受諾（改革）／1=武力鎮圧（余剰戦力消費）／2=対決（蜂起させる）。PendingFactionCrisis をクリア。プレイヤー経路のみ。
    // 第4段4-7（2026-07-27）：鎮圧の政治的代償＝旧・余剰戦力のみのコストでは実質無料の支配戦略だった。
    // 自由・共和派の反発（TensionPolitics と同じイデオロギー物差し・参政権voice加重）×係数を正統性から減算。AI/プレイヤー対称＝両鎮圧サイトから呼ぶ。
    private static void SuppressionPoliticalCost(World w, Coefficients c)
    {
        // 第6段6-8b（2026-07-28）：弾圧の成立＝断裂の窓が開く（運動の壊滅直後だけ反動が法を巻き戻せる＝仏1850・ストルイピン1907）。
        w.RuptureWindowQuarters = Math.Max(w.RuptureWindowQuarters, (int)c.RuptureWindowQuartersOnCrush);
        if (c.SuppressFactionLegitCost <= 0) return;
        var agg = Ideologies.National(w);
        double dove = agg[2] + agg[3];
        double cost = Math.Min(c.SuppressFactionLegitCost * (0.5 + dove), w.Legitimacy);
        w.Explain?.Add("Legitimacy", "武力鎮圧への反発(自由・共和派)", -cost);
        w.Legitimacy -= cost;
    }

    public static void ResolveFactionCrisis(World w, Coefficients c, int mode)
    {
        if (w.PendingFactionCrisis is not { } f) return;
        w.PendingFactionCrisis = null; w.PendingFactionCrisisDemands = "";
        if (mode == 1 && !(c.FactionSuppressionOmit > 0) && w.ExpansionWill >= c.SuppressFactionWillCost)   // 鎮圧（段1オミット時はUIが択を出さない＝二重防御）
        {
            f.Rejections += 1;   // ★段3（対称）
            w.ExpansionWill -= c.SuppressFactionWillCost;
            SuppressionPoliticalCost(w, c);   // 第4段4-7：政治的代償（対称）
            w.RevoltCooldownQuarters = c.RegionalRevoltCooldown;
            w.LogAdd($"{w.Year} {w.SelfPower?.Name}が{Factions.DisplayName(f)}の蜂起を武力で鎮圧");
            return;
        }
        if (mode == 0)   // 要求受諾（改革）
        {
            f.Rejections = 0;   // ★段3：受諾＝怨嗟の解消（プレイヤー側も対称）
            ConcedeToFaction(w, c, f);
            w.RevoltCooldownQuarters = c.RegionalRevoltCooldown;
            w.LogAdd($"{w.Year} {w.SelfPower?.Name}が{Factions.DisplayName(f)}の要求を受け入れた");
            return;
        }
        if (mode == 3 && c.FactionCompensation > 0)   // 第6段6-6：別の軸で埋め合わせる（ビスマルク）
        {
            f.Rejections += 1;   // ★段3（対称）：本丸拒否
            CompensateFaction(w, c, f, FactionSnapshot.ComputeDemands(w, f.Bloc));
            w.RevoltCooldownQuarters = c.RegionalRevoltCooldown;
            w.LogAdd($"{w.Year} {w.SelfPower?.Name}が{Factions.DisplayName(f)}へ別の軸で譲歩した(本丸の要求は拒否)");
            return;
        }
        TriggerFactionRevolt(w, c, f);   // mode==2（対決）or 鎮圧不能＝蜂起を受けて立つ
    }

    /// <summary>第6段6-6（2026-07-28）三行目「別の軸で埋め合わせる」＝要求の本丸（top-1の軸）は拒み、2番目以降の要求を与える
    /// （参政権は拒み社会保険を与えるビスマルク1883-89・中核ルールdoc §2-4）。挙動は手動の法変更と同じ経路（ApplyDemand＝ConcedeToFactionと共有）。
    /// 代償構造＝本丸は満たされない：闘争度の緩和は受諾より弱く・結束は半分残る（穏健派だけ買われて剥がれる＝分断）＝運動は痩せて再来する。
    /// 2番目以降の要求が無い運動（単一争点）には効かない＝圧力は溜まる（拒否と同じ）。AI/プレイヤー対称。FactionCompensation=0で旧3択。</summary>
    private static void CompensateFaction(World w, Coefficients c, FactionState f, List<FactionSnapshot.Demand> demands)
    {
        int steps = 0;
        for (int i = 1; i < demands.Count; i++)
            steps += ApplyDemand(w, c, demands[i].Axis, demands[i].Increase, i == 1 ? c.FactionConcessionSteps : 1);
        double spend = c.RevoltConcessionSpend * Math.Max(1, steps);
        w.MandateSpent += spend;
        w.MandateSpentNew += spend;
        if (steps > 0)
        {
            foreach (var p in f.Region.Pops) if (!p.Closed && !p.IsSoldier) p.Militancy *= c.CompensationMilitancyRelief;
            f.Cohesion *= c.CompensationCohesionRetain;   // 穏健派が剥がれる＝組織は痩せるが核は残る（急進派は次へ）
        }
    }

    // F3b 勢力強度＝熱×頭数×結束×組織核×回路なし（challenge/coerceと同じ物差し・発火と決着で共有＝対称）。
    // 【回路なし】平和的回路のガス抜き：票を持つブロックの組織運動は議会経路へ向かい武装蜂起しない
    // ＝チャーティズムが参政権拡大で政党化して消えた物理（MilVoiceと同じ階級ゲート・**法を読む＝MilVoiceのFranchiseVoiceと同じ物差し**。
    // 専制のAIが革命回避で発行する紙の参政権も回路と数える＝闘争度側と整合。「選挙の実在」ゲート版は2026-07-12に実測比較し
    // 列強立憲圏の早期独裁化カスケード＝exact36を招いたため不採用＝f3iバッチ参照）。女性係数は掛けない。
    // 旧支配層(bloc0)は宮廷権力＝常に回路あり（ヴァンデ/カルリスタ型の反動蜂起は Transition の国家集計が担う）。
    // 【組織核】未変異の運動は意識ある成員しか動員できない（無学の1.8億は一つの軍にならない＝統治スパンと対称の組織の物理）。
    // **変異＝旗こそが組織技術**（教義・細胞・位階が識字を代替＝白蓮教/太平天国）＝org 1.0で頭数の全量を動員できる
    // ＝「旗が掲がった時だけ大衆の海が蜂起になる」点火構造。欧州の識字ある運動は未変異でも組織できる（1848）。
    public static double FactionStrength(World w, Coefficients c, FactionState f)
    {
        double voice = f.Bloc == 0 ? 1.0
                     : f.Bloc == 1 ? (w.Suffrage >= Suffrage.Census ? 1.0 : c.ModernEliteSubCensusVoice)
                     : (w.Suffrage >= Suffrage.AdultMale ? 1.0 : 0.0);   // 大衆と第4束「小営業」(bloc3)＝男子普選まで声なし（制限選挙が店主・親方を締め出した物理＝1848の母体。プチブル利益束2026-08-15）
        double org = 1.0;
        if (!f.Mutated)
        {
            double s = 0, cs = 0;
            var petty = w.Coef.PettyInterestGate > 0 ? InterestGroups.PettyPops(w) : null;   // 第4束＝クラスタ分類と同じ物差し（gate=0で従来とビット恒等）
            foreach (var p in f.Region.Pops)
            {
                int b = p.Closed ? 0 : petty != null && petty.Contains(p) ? PolicyPreferences.PettyBloc : p.IsModernElite ? 1 : 2;
                if (b != f.Bloc || p.IsSoldier) continue;
                if (c.FactionJoinMilitancy > 0 && p.Militancy < c.FactionJoinMilitancy) continue;   // ★段2a（内戦一元化doc §5・2026-08-30）：不満が閾値未満のPOPは運動に参加しない（0＝全員参加＝厳密恒等）
                s += p.Size; cs += p.Consciousness * p.Size;
            }
            org = s > 1e-9 ? cs / s : 0;
        }
        // 02断線走査2026-07-28：年季飽和＝「何十年続いた運動か」（QuartersActiveの唯一の読み手）。速い結束（Cohesion）と遅い年季の2軸で
        // 太平天国型の長期潜伏と1848型の突発を分ける。FactionSeniorityQuarters=0で恒等（係数側で無効化可能）
        double seniority = c.FactionSeniorityQuarters > 0 ? System.Math.Min(1.0, f.QuartersActive / c.FactionSeniorityQuarters) : 1.0;
        return f.Size * f.AvgMilitancy * f.Cohesion * org * seniority * (1.0 - voice) * c.FactionRevoltScale;
    }

    // 主軸イデオロギーに4軸座標が最も近い政体（新表なし＝既存座標の純関数。one-hotのIdealPoint＝その思想自身の座標）。
    private static Polity NearestPolity(int ideo)
    {
        var oneHot = new double[Ideologies.Count]; oneHot[ideo] = 1.0;
        var coord = Ideologies.IdealPoint(oneHot);
        Polity best = Ideologies.Polities[0]; double bd = double.MaxValue;
        foreach (var pol in Ideologies.Polities)
        {
            var pc = Ideologies.BasePolityCoord(pol);
            double d = 0; for (int i = 0; i < 4; i++) { double x = coord[i] - pc[i]; d += x * x; }
            if (d < bd) { bd = d; best = pol; }
        }
        return best;
    }

    // F3b 湘軍：反乱と思想距離が遠い**有産ブロック**（旧支配層・近代エリート）が体制側で郷勇を組む＝保持側の加算項。
    // 距離が LoyalistDistanceFloor 未満（思想的に近い反乱＝フロンド型）には立たない。異端（変異）の反乱には増し（曽国藩の檄）。
    // internal（2026-08-16）：戦争タブの国内勢力行が強さ比（FactionStrength÷(EffectiveCoerce+郷勇)）を表示するための読み取り専用公開
    //   （純関数・World非変更・InternalsVisibleTo("PriceOfBread.App")）。エンジン側の呼び出しは従来どおり同クラス内のみ。
    internal static double LoyalistMilitia(World w, Coefficients c, FactionState f)
    {
        if (c.LoyalistMilitiaWeight <= 0) return 0;
        var oneHot = new double[Ideologies.Count]; oneHot[f.Ideo] = 1.0;
        var fCoord = Ideologies.IdealPoint(oneHot);
        double militia = 0;
        var petty = w.Coef.PettyInterestGate > 0 ? InterestGroups.PettyPops(w) : null;   // 第4束＝分類の物差しを揃える（商人が自束(bloc3)の反乱の郷勇資金源に数えられない。gate=0で従来とビット恒等）
        // 有産ブロックのみ（大衆は郷勇の資金源にならない。小営業(bloc3)も源にしない＝郷勇は郷紳・大資本の金）。
        // AllPops を1回だけ走査し bloc0/bloc1 を同時に集計（各ブロックへの積算順序は従来の2回走査と同一＝ビット恒等）。
        var size = new double[2];
        var shares = new double[2][] { new double[Ideologies.Count], new double[Ideologies.Count] };
        foreach (var p in w.AllPops())
        {
            int pb = p.Closed ? 0 : petty != null && petty.Contains(p) ? PolicyPreferences.PettyBloc : p.IsModernElite ? 1 : 2;
            if (pb >= 2 || pb == f.Bloc || p.IsSoldier) continue;
            size[pb] += p.Size;
            for (int i = 0; i < Ideologies.Count; i++) shares[pb][i] += p.IdeologyShares[i] * p.Size;
        }
        for (int b = 0; b < 2; b++)
        {
            if (b == f.Bloc || size[b] <= 1e-9) continue;
            for (int i = 0; i < Ideologies.Count; i++) shares[b][i] /= size[b];
            var ideal = Ideologies.IdealPoint(shares[b]);
            double d = 0; for (int i = 0; i < 4; i++) { double x = ideal[i] - fCoord[i]; d += x * x; }
            double dist = Math.Sqrt(d);
            militia += size[b] * Math.Max(0, dist - c.LoyalistDistanceFloor) * (f.Mutated ? 1.0 + c.LoyalistHeresyBoost : 1.0);
        }
        return c.LoyalistMilitiaWeight * militia;
    }

    /// <summary>R2 蜂起R群2026-08-16（診断A2）：F3b点火の単位整合。FactionRevoltLocalCoerce=0＝coerceをそのまま返す＝**ビット恒等・新しい読み書きゼロ**。
    /// 何が壊れていたか：左辺 FactionStrength＝**州×ブロック×主軸クラスタ**の規模なのに、右辺は**全国**coerce＝
    /// 人口の大きい国ほど構造的に点火不能（太平天国が最も出にくいのは清、という逆理の根）。式自体（発言権×組織核）は正しく、殺しているのは右辺のスケール。
    /// 実効coerce＝coerce×((1−f)+f×州pop/全国pop)＝f=0旧・f=1完全按分の**0..1ブレンド**（点火A/Bで中間値を掃引可。見る帯＝内戦分裂・清）。
    /// 州popは TotalPopulation と同じ物差し（Region.SumPopulation＝全pop）＝比の分子分母の定義を揃える（「比のガードは絶対値で書かない」の同族対策）。
    /// LoyalistMilitia（郷勇）は呼び手で**全国のまま**加算＝郷紳の金は全国から（LoyalistMilitia の設計コメントと整合）。
    /// internal＝ON経路テスト用（InternalsVisibleTo）。</summary>
    internal static double LocalizedHold(World w, Coefficients c, FactionState f, double coerce)
    {
        if (!(c.FactionRevoltLocalCoerce > 0)) return coerce;   // ⚠否定形＝フラグNaNも旧側（全国）へ倒す
        double blend = Math.Clamp(c.FactionRevoltLocalCoerce, 0, 1);
        double share = f.Region.SumPopulation() / Math.Max(1.0, w.TotalPopulation);
        if (!(share >= 0 && share <= 1)) share = 1.0;   // ⚠否定形＝NaN/比の暴れは全国（旧挙動）へ倒す（Clamp/Min/MaxはNaNを除去しない）
        return coerce * ((1.0 - blend) + blend * share);
    }

    // F3b 経済決着：運動の要求top-k（ブロックのPref×残り可動域＝FactionSnapshotと同じ導出）をのませる。
    // 最上位はFactionConcessionSteps段・以下1段。現行値とPolicy目標の両方を書く（書かないとGovernmentが翌期戻す）＝ConcedeToRevoltと同作法。
    private static void ConcedeToFaction(World w, Coefficients c, FactionState f)
    {
        var demands = FactionSnapshot.ComputeDemands(w, f.Bloc);
        int steps = 0;
        for (int i = 0; i < demands.Count; i++)
            steps += ApplyDemand(w, c, demands[i].Axis, demands[i].Increase, i == 0 ? c.FactionConcessionSteps : 1);
        double spend = c.RevoltConcessionSpend * Math.Max(1, steps);
        w.MandateSpent += spend;        // 上限廃止（2026-07-26ユーザー裁定）
        w.MandateSpentNew += spend;
    }

    // 要求1軸の強制施行（enum＝n段・スライダー＝FactionConcessionSlider×n・bool＝反転）。動いた段数を返す（政治資本の請求単位）。
    // internal（2026-08-10）：番人テストが軸ごとの施行経路を直接叩けるように（private のままだと「case を足したか」を
    // 政党構成や勢力の巡り合わせ越しにしか観測できず、テストが脆くなる）。呼び出し元は従来どおり同クラス内のみ。
    internal static int ApplyDemand(World w, Coefficients c, PolicyAxis a, bool inc, int n)
    {
        var p = w.Policy;
        int StepEnumAxis(int cur, int max, Action<int> set)
        {
            int v = Math.Clamp(cur + (inc ? n : -n), 0, max);
            // 前提法DAG（E4・2026-07-19）：勢力の経済決着による直接施行も前提を飛び越えない（男女普選←女性法の漏れを塞ぐ）。
            // 前提未達の段まで v を切り下げる＝譲歩は「前提が整う段まで」しか進めない（相互ロックなし＝非循環DAG）。
            if (inc) while (v > cur && !Government.LawPrereq(w, a, v, c).Ok) v--;
            set(v); return Math.Abs(v - cur);
        }
        int Slide(double cur, Action<double> set)
        {
            double v = Math.Clamp(cur + (inc ? 1 : -1) * c.FactionConcessionSlider * n, 0, 1);
            set(v); return Math.Abs(v - cur) > 1e-9 ? 1 : 0;
        }
        int Flip(bool cur, Action<bool> set) { if (cur == inc) return 0; set(inc); return 1; }
        return a switch
        {
            PolicyAxis.Suffrage => StepEnumAxis((int)w.Suffrage, 3, v => { w.Suffrage = (Suffrage)v; p.Suffrage = w.Suffrage; }),
            PolicyAxis.EducationLaw => StepEnumAxis((int)w.EducationLaw, 3, v => { w.EducationLaw = (EducationLaw)v; p.EducationLaw = w.EducationLaw; }),
            PolicyAxis.Censorship => StepEnumAxis((int)w.Censorship, 2, v => { w.Censorship = (CensorshipLaw)v; p.Censorship = w.Censorship; }),
            PolicyAxis.LaborUnion => StepEnumAxis((int)w.LaborUnion, 2, v => { w.LaborUnion = (LaborUnionLaw)v; p.LaborUnion = w.LaborUnion; }),
            PolicyAxis.ShorterHours => StepEnumAxis((int)w.WorkHours, 3, v => { w.WorkHours = (WorkHours)v; p.WorkHours = w.WorkHours; }),
            PolicyAxis.CornLaws => StepEnumAxis((int)w.CornLaws, 2, v => { w.CornLaws = (ReformLevel)v; p.CornLaws = w.CornLaws; }),
            PolicyAxis.LandReform => StepEnumAxis((int)w.LandReform, 2, v => { w.LandReform = (ReformLevel)v; p.LandReform = w.LandReform; }),
            PolicyAxis.SerfEmancipation => StepEnumAxis((int)w.SerfEmancipation, 2, v => { w.SerfEmancipation = (ReformLevel)v; p.SerfEmancipation = w.SerfEmancipation; }),
            // ★女性の権利の梯子（統合法・2026-08-10）：勢力の経済決着による直接施行も**段を飛ばさない**（StepEnumAxis が前提DAG＝StagePrereq で切り下げる）。
            PolicyAxis.WomenRights => StepEnumAxis((int)w.WomenRights, 3, v => { w.WomenRights = (WomenRightsLaw)v; p.WomenRights = w.WomenRights; }),
            PolicyAxis.IncomeTax => Slide(w.TaxRate, v => { w.TaxRate = v; p.IncomeTaxTarget = v; }),
            PolicyAxis.SocialSecurity => Slide(w.SocialSecurity, v => { w.SocialSecurity = v; p.SocialSecurityTarget = v; }),
            PolicyAxis.Tariff => Slide(w.Tariff, v => { w.Tariff = v; p.TariffTarget = v; }),
            PolicyAxis.PollTax => Slide(w.PollTax, v => { w.PollTax = v; p.PollTaxTarget = v; }),
            PolicyAxis.ConsumptionTax => Slide(w.ConsumptionTax, v => { w.ConsumptionTax = v; p.ConsumptionTaxTarget = v; }),
            PolicyAxis.ProgressiveTax => Slide(w.ProgressiveTax, v => { w.ProgressiveTax = v; p.ProgressiveTaxTarget = v; }),
            // 02断線走査（2026-07-28）：施行できない11軸のうち表示つき3軸＋E5/E6の8軸を接続＝「要求受諾が政治資本だけ燃やすno-op」の解消。
            // 圧政の緩和＝ポップアップに表示されながら唯一実装されていなかった大衆の第一要求（CoercionFollowsForce下では次期に軍規模へ再追従＝一時的緩和として正しい）。
            PolicyAxis.Coercion => Slide(Math.Clamp(w.BaseCoercion / Math.Max(1e-9, c.CoercionMax), 0, 1), v => { w.BaseCoercion = v * c.CoercionMax; p.CoercionTarget = v * c.CoercionMax; }),
            PolicyAxis.EducationSpending => Slide(w.EducationSpending, v => { w.EducationSpending = v; p.EducationSpendingTarget = v; }),
            PolicyAxis.LandTax => Slide(w.LandTax, v => { w.LandTax = v; p.LandTaxTarget = v; }),
            PolicyAxis.ConscriptionLaw => StepEnumAxis((int)w.ConscriptionLaw, 2, v => { w.ConscriptionLaw = (ConscriptionLaw)v; p.ConscriptionLaw = w.ConscriptionLaw; }),
            PolicyAxis.SecretBallot => StepEnumAxis((int)w.SecretBallot, 1, v => { w.SecretBallot = (SecretBallotLaw)v; p.SecretBallot = w.SecretBallot; }),
            PolicyAxis.Bureaucracy => StepEnumAxis((int)w.Bureaucracy, 2, v => { w.Bureaucracy = (BureaucracyLaw)v; p.Bureaucracy = w.Bureaucracy; }),
            PolicyAxis.ChildLabor => Flip(w.ChildLaborAllowed, v => { w.ChildLaborAllowed = v; p.ChildLaborAllowed = v; }),   // 児童労働法（02断線走査2026-07-28）
            PolicyAxis.StateReligion => StepEnumAxis((int)w.StateReligion, 2, v => { w.StateReligion = (StateReligionLaw)v; p.StateReligion = w.StateReligion; }),   // 上限=信仰の自由（国家無神論は政体の属性＝要求で到達しない）
            PolicyAxis.Antitrust => StepEnumAxis((int)w.Antitrust, 2, v => { w.Antitrust = (AntitrustLaw)v; p.Antitrust = w.Antitrust; }),
            PolicyAxis.WartimeRationing => Flip(w.WartimeRationing, v => { w.WartimeRationing = v; p.WartimeRationing = v; }),
            PolicyAxis.MilitaryExport => Flip(w.MilitaryExportBan, v => { w.MilitaryExportBan = v; p.MilitaryExportBan = v; }),   // 軍需輸出の法（禁制品doc C5・2026-07-30）
            PolicyAxis.OpiumPossession => StepEnumAxis((int)w.OpiumPossession, 2, v => { w.OpiumPossession = (ReformLevel)v; p.OpiumPossession = w.OpiumPossession; }),   // 阿片の保有法（C3・2026-07-30）
            PolicyAxis.OpiumExport => Flip(w.OpiumExportBan, v => { w.OpiumExportBan = v; p.OpiumExportBan = v; }),   // 阿片の輸出法（C3・2026-07-30）
            // 国有化＝未点灯の最初の1部門を灯す（部門順は enum 順＝決定論）。減少向き＝点灯中の最後の1部門を消す。
            PolicyAxis.Nationalization => StepNationalization(w, p, inc),
            // ★是正2026-08-01：この2軸は選好（PolicyPreferences）が点火済みで要求リストに載るのに、
            // ここに case が無く `_ => 0` へ落ちていた＝**要求は成立するが施行されない**＝勢力が永久に同じ要求を出し続ける。
            PolicyAxis.ImmigrationRestriction => StepEnumAxis((int)w.ImmigrationRestriction, 2, v => { w.ImmigrationRestriction = (ImmigrationLaw)v; p.ImmigrationRestriction = w.ImmigrationRestriction; }),
            PolicyAxis.SpecialistExitBan => StepEnumAxis((int)w.SpecialistExitLaw, 2, v => { w.SpecialistExitLaw = (SpecialistExitLaw)v; p.SpecialistExitLaw = w.SpecialistExitLaw; }),   // ★段⑤
            // ★3値化2026-08-13（点火1.0=2026-08-21銀本位ラウンド）：銀を経由する梯子では1段ずつ譲る（gate=0に戻せば旧 Flip と同じ両端＝厳密恒等）
            PolicyAxis.MonetaryStandard => c.SilverStandardGate > 0
                ? StepEnumAxis((int)w.MonetaryLaw, 2, v => { w.MonetaryLaw = (MonetaryStandardLaw)v; p.MonetaryTarget = v; })
                : Flip(w.MonetaryLaw == MonetaryStandardLaw.Gold, v => { w.MonetaryLaw = v ? MonetaryStandardLaw.Gold : MonetaryStandardLaw.Fiat; p.MonetaryTarget = v ? 2 : 0; }),
            PolicyAxis.CapitalMobility => Flip(w.CapitalControlLaw, v => { w.CapitalControlLaw = v; p.CapitalControlTarget = v; }),   // ★資本移動の法（トリレンマdoc・2026-08-13）
            // 参政権の範囲2法（2026-08-16）：休眠中は Pref=0＝要求に載らず不到達。点火時に case が無いと「要求は成立するが施行されない」no-op要求（2026-08-01の前例）になるので先に配線。
            PolicyAxis.ColonialSuffrage => StepEnumAxis((int)w.ColonialSuffrage, 2, v => { w.ColonialSuffrage = (ColonialSuffrageLaw)v; p.ColonialSuffrage = w.ColonialSuffrage; }),
            PolicyAxis.MigrantNativeSuffrage => StepEnumAxis((int)w.MigrantNativeSuffrage, 1, v => { w.MigrantNativeSuffrage = (MigrantNativeSuffrageLaw)v; p.MigrantNativeSuffrage = w.MigrantNativeSuffrage; }),
            // ★海軍維持費（2026-08-10 作者裁定「陸軍と海軍の注力レバーは廃止し、海軍維持費と陸軍維持費で表現する」）。
            //   「海軍の増強」は抽象的な注力度でなく**金の要求**＝海軍維持費（実効値と目標）を上げる。旧・海軍偏重の軸はここへ振り替えた。
            //   ⚠AIもプレイヤーも同じ経路（勢力への譲歩／議会の綱領／財政タブの陸軍維持費・海軍維持費）を通る＝対称。
            PolicyAxis.NavyUpkeep => ConcedeNavyUpkeep(w, p, inc, c.FactionConcessionSlider * n),
            _ => 0,   // 行政費等の内部事項は要求として強制しない
        };
    }

    // ★海軍維持費の要求施行（2026-08-10）＝実効値と目標を同時に書く（書かないと Government が翌期戻す＝他のスライダー軸と同作法）。
    // 合計（陸＋海）が1.0を超える分だけ陸軍から出す＝上限に張り付いた時だけ内訳が動き、普段は海軍の純増（＝軍拡）。動いたら1を返す。
    private static int ConcedeNavyUpkeep(World w, NationPolicy p, bool inc, double step)
    {
        double navy = Math.Clamp(w.NavyUpkeep + (inc ? step : -step), 0, 1);
        if (Math.Abs(navy - w.NavyUpkeep) <= 1e-9) return 0;
        w.SetMilitaryUpkeep(w.ArmyUpkeep, navy);
        p.NavyUpkeepTarget = navy;
        p.ArmyUpkeepTarget = Math.Min(p.ArmyUpkeepTarget, 1.0 - navy);
        return 1;
    }

    // 02断線走査（2026-07-28）：国有化要求の施行＝enum順で未点灯の最初の部門を灯す／減少向きは点灯中の最後を消す（決定論）。動いた部門数を返す。
    private static int StepNationalization(World w, NationPolicy p, bool inc)
    {
        var flags = new (bool Cur, System.Action<bool> Set)[]
        {
            (w.NationalizeRailways, v => { w.NationalizeRailways = v; p.NationalizeRailways = v; }),
            (w.NationalizeMines, v => { w.NationalizeMines = v; p.NationalizeMines = v; }),
            (w.NationalizeMilitary, v => { w.NationalizeMilitary = v; p.NationalizeMilitary = v; }),
            (w.NationalizeOil, v => { w.NationalizeOil = v; p.NationalizeOil = v; }),
            (w.NationalizeElectricity, v => { w.NationalizeElectricity = v; p.NationalizeElectricity = v; }),
        };
        if (inc)
        {
            foreach (var f in flags) if (!f.Cur) { f.Set(true); return 1; }
            // 最終段『全て』（§11-6d）＝残り全産業の一括国有化。譲歩でも前提DAG（プロレタリア独裁のみ＋官僚制度）を踏む＝LawPrereq が単一ソース。
            if (!w.NationalizeAll && Government.LawPrereq(w, PolicyAxis.NationalizationAll, 1, w.Coef).Ok)
            { w.NationalizeAll = true; p.NationalizeAll = true; return 1; }
            return 0;
        }
        if (w.NationalizeAll) { w.NationalizeAll = false; p.NationalizeAll = false; return 1; }
        for (int i = flags.Length - 1; i >= 0; i--) if (flags[i].Cur) { flags[i].Set(false); return 1; }
        return 0;
    }

    // F1 州一揆（王権議会F1・2026-07-10）：飢えた州の大衆蜂起（パンの一揆＝1789地方蜂起・シレジア織工・チャーティスト）。
    // 発火＝州の平均闘争度×主食欠乏(1−Region.FoodFill)>閾値（年に何度も燃えないよう四半期クールダウン）。政府の裁定は決定論2分岐＝
    // **鎮圧**（州の蜂起勢力≤中央保持力＝戦死（人口台帳）・闘争度は部分緩和・正統性ストックに流血の傷＝ペテルルー）／
    // **譲歩**（勝てない＝大衆要求の優先梯子〔穀物法撤廃→労働時間短縮→年金→農奴解放→参政権〕を1段のみ、政治資本を燃やす＝負のマンデート）。
    // 3択目の宥和（福祉・減税）は既存のAI/プレイヤー動詞が常設＝ここでは扱わない。RegionalRevoltThreshold=0 で無効（現行0.25＝稼働）。決定論＝RNGなし。
    private static void CheckRegionalRevolt(World w, Coefficients c, double coerce)
    {
        if (w.RevoltCooldownQuarters > 0) { w.RevoltCooldownQuarters--; return; }   // F3bと共有のクールダウン＝F1休眠時も減る（threshold=0.25では順序不問）
        if (c.RegionalRevoltThreshold <= 0) return;
        Region? worst = null; double worstHeat = 0;
        foreach (var r in w.Regions)
        {
            if (r.State != RegionState.Active) continue;
            double heat = RegionRevoltHeat(r, c);   // R3 蜂起R群2026-08-16：RegionalRevoltSatGate=0＝旧式（闘争度×主食欠乏）とビット恒等／★既定は点火1.0＝満足度も遮断を解く
            if (heat > worstHeat) { worstHeat = heat; worst = r; }
        }
        if (worst is null || worstHeat <= c.RegionalRevoltThreshold) return;
        w.RevoltCooldownQuarters = c.RegionalRevoltCooldown;
        double crowd = 0; foreach (var p in worst.Pops) if (!p.Closed && !p.IsSoldier) crowd += p.Size;
        double strength = worstHeat * crowd * c.RegionalRevoltStrength;   // 蜂起の勢い＝熱×州大衆の規模（challenge/coerce と同じ人口スケールの物差し）
        if (strength <= coerce)
        {
            // 鎮圧：戦死は台帳（PopulationDelta/WarDeadCumulative）・貯蓄は遺族に残る＝貨幣保存非接触。
            double dead = Math.Min(crowd * c.RevoltSuppressDeadFrac, crowd);
            if (dead > 1e-9 && crowd > 1e-9)
            {
                foreach (var p in worst.Pops) if (!p.Closed && !p.IsSoldier) p.Size -= p.Size / crowd * dead;
                w.PopulationDelta -= dead; w.WarDeadCumulative += dead;
            }
            foreach (var p in worst.Pops) if (!p.Closed && !p.IsSoldier) p.Militancy *= c.ReformMilitancyRelief;   // 首謀者の除去＝既存の鎮圧緩和率を流用
            double legBeforeRevolt = w.Legitimacy;
            w.Legitimacy = Math.Max(0, w.Legitimacy - c.RevoltSuppressLegitCost);   // 流血の記憶＝ストック正統性への直接の傷（regenで数年かけ回復）
            w.Explain?.Add("Legitimacy", "一揆鎮圧の流血(ストック正統性への傷)", w.Legitimacy - legBeforeRevolt);   // 説明API（#63）
            w.LogAdd($"{w.Year} {w.SelfPower?.Name}が{worst.Name}の一揆を鎮圧(死者{dead:F0})");   // 3桁区切りは全廃（作者裁定2026-08-10・外交ログはUIの出来事へそのまま出る）
        }
        else
        {
            ConcedeToRevolt(w, c);
            foreach (var p in worst.Pops) if (!p.Closed && !p.IsSoldier) p.Militancy *= c.ReformMilitancyRelief;
            w.LogAdd($"{w.Year} {w.SelfPower?.Name}が{worst.Name}の一揆に譲歩");
        }
    }

    // 譲歩＝大衆の窮乏に直結する順の優先梯子を1段（パンの一揆→穀物法撤廃が先頭＝1846年）。現行値と目標の両方を動かす
    // （目標を動かさないと Government が翌期一段戻す）。政治資本の消費は Government.Spend と同じ両台帳記帳（負のマンデート）。
    private static void ConcedeToRevolt(World w, Coefficients c)
    {
        var p = w.Policy;
        if (w.CornLaws > ReformLevel.None) { w.CornLaws = (ReformLevel)((int)w.CornLaws - 1); p.CornLaws = w.CornLaws; }
        else if (w.WorkHours > WorkHours.Eight) { w.WorkHours = (WorkHours)((int)w.WorkHours - 1); p.WorkHours = w.WorkHours; }
        else if (w.SocialSecurityLaw < SocialSecurityLaw.Pension)
        {
            // 02断線走査（2026-07-28）：旧・w.Pension直書きはGovernmentが翌期に無条件上書き＝譲歩梯子が年金段で恒久停止し
            // 政治資本だけ燃えていた（1846年以降の英国型が凍る）。社会保障法の1段引き上げ＋目標更新へ置換＝恒久化する譲歩。
            w.SocialSecurityLaw = (SocialSecurityLaw)((int)w.SocialSecurityLaw + 1);
            w.SocialSecurity = (int)w.SocialSecurityLaw / 3.0;
            p.SocialSecurityTarget = System.Math.Max(p.SocialSecurityTarget, (int)w.SocialSecurityLaw / 3.0);
        }
        else if (w.SerfEmancipation < ReformLevel.Full) { w.SerfEmancipation = (ReformLevel)((int)w.SerfEmancipation + 1); p.SerfEmancipation = w.SerfEmancipation; }
        else if (w.Suffrage < Suffrage.AdultMale) { w.Suffrage = (Suffrage)((int)w.Suffrage + 1); p.Suffrage = w.Suffrage; }
        else return;   // のむものが残っていない＝闘争度緩和のみ
        w.MandateSpent += c.RevoltConcessionSpend;        // 上限廃止（2026-07-26ユーザー裁定）
        w.MandateSpentNew += c.RevoltConcessionSpend;
    }

    // 分離独立（§9-E拡張）：州の関税利害が国政策と乖離＋州の不満が高いと分離圧力。中央の保持力を超える州があれば離脱→内戦（再統合戦）。稀に発生。
    private static void CheckSecession(World w, Coefficients c, double coerce)
    {
        if (w.Regions.Count < 2) return;
        double stance = w.Tariff * 2 - 1;   // 国の関税姿勢（−1自由貿易..+1保護）
        double hold = w.Legitimacy / (1 + w.TotalPopulation * c.SecessionHoldPerPop);   // 中央の保持力（大国ほど辺境を抑えにくい）
        // 政5：中央保持力に軍・警察(Coercion)由来の項を加える。現行の hold は Legitimacy/(1+…)≤1 で、閾値 SecessionThreshold=1.43>1 のため第2条件 worstPressure>hold が常に真＝デッドコード
        // ＋大軍の帝国でも分離率が変わらない（Coercion 不在）。SecessionHoldCoercion=0 では加算項ゼロ＝従来の hold 式のまま。>0（現行1.0）で軍事鎮圧力を [0,閾値) 帯へ飽和写像して hold に足し、
        // 第2条件を活性化（大軍の帝国ほど分離を抑える／圧政の弱い国は圧力次第で割れる）。SecessionThreshold と桁を揃えるため飽和上限は SecessionThreshold 基準で正規化。
        hold += c.SecessionHoldCoercion * c.SecessionThreshold * (coerce / (coerce + c.PoliticalReferencePop));   // coerce/(coerce+基準人口)∈[0,1)＝軍事保持力の飽和・0で無加算
        var cap = w.Regions[0];   // #13 中核（首都）の文化/宗教＝国民的アイデンティティの基準
        Region? worst = null; double worstPressure = 0;
        foreach (var r in w.Regions)
        {
            if (r.State != RegionState.Active || r.Id == 0) continue;   // 首都は離脱しない
            r.TariffInterest = RegionTariffInterest(r);   // 倍率排除：州の関税利害を**実利（競争力）から毎期算出**（静的ラベルを廃止）
            // #13 文化/宗教の異質性：首都(中核)と文化・宗教が違う州ほど分離志向が強い（言語/信仰の少数派＝ナショナリズムの分離圧力）。同一/未設定なら0＝較正中立。
            double cultDist = ((r.Culture.Length > 0 && cap.Culture.Length > 0 && r.Culture != cap.Culture) ? 0.5 : 0)
                            + ((r.Religion.Length > 0 && cap.Religion.Length > 0 && r.Religion != cap.Religion) ? 0.5 : 0);
            double mil = AvgRegionMilitancy(r);
            double pressure = Math.Abs(stance - r.TariffInterest) * mil * c.SecessionPressureScale * (1 + c.CultureSecessionWeight * cultDist);   // 関税乖離(0..2)×州不満×文化異質性
            // 政14：分離の駆動因が関税利害の乗算に一元化（関税乖離0なら文化がどれだけ異質でも圧力0）。19世紀の分離は民族・宗教が主因＝**独立の加算圧力**を用意（MinorityMilitancy と接続）。
            // SecessionCultureAdditive=0 では加算ゼロ＝乗算のみの旧式。>0（現行3.0）で「文化/宗教距離 × 州の少数派度(1−平均CoreEthnicShare) × 州不満」を関税と独立に足す
            // ＝関税乖離0の異民族州でも分離圧力が立つ（民族主因の分離）。EthnicEnabled の国のみ（少数派度は民族機構が有効な世界でのみ意味を持つ）。
            if (c.SecessionCultureAdditive > 0 && w.EthnicEnabled)
                pressure += c.SecessionCultureAdditive * c.MinorityMilitancy * cultDist * (1.0 - AvgRegionCoreShare(r)) * mil;
            // ★N7 分離割引（国民意識doc・2026-08-13）：**国民意識が育った州は、条件が揃っても離れない。**
            //   国民国家の形成とは「離れない州を作ること」そのものだから、分離圧力にこの割引が無いのは機構の欠落だった
            //   （国民形成に投じた金が、分離という最も分かりやすい帰結に一切効いていなかった）。
            //   ⚠読むのは州のPOPの国民意識のsize加重平均だけ＝国名も文化名も出てこない。SecessionConsciousnessWeight=0＝掛けず旧式（現行1.0点火）。
            if (c.SecessionConsciousnessWeight > 0)
            {
                double nc = AvgRegionConsciousness(r);
                pressure *= Math.Max(0, 1.0 - c.SecessionConsciousnessWeight * nc);
            }
            // 参政権の範囲2法（作者裁定2026-08-16・SuffrageScopeGate>0のみ）：植民地参政権で政治的国民に算入された植民地格の州は
            // 分離圧力が算入率ぶん緩む＝×(1−算入率)。算入率＝なし0／自国民のみ=州の平均中核度（UnitySecession 系と同じ AvgRegionCoreShare の言語）／全面1
            // ＝代表を得た州は離れない（N7 分離割引と同型の乗算・新しい定数なし）。gate=0 では分岐に入らない＝厳密恒等。
            if (c.SuffrageScopeGate > 0 && r.Tier == RegionTier.Colonial)
            {
                double inc = w.ColonialSuffrage switch
                {
                    ColonialSuffrageLaw.Full => 1.0,
                    ColonialSuffrageLaw.OwnNationals => AvgRegionCoreShare(r),
                    _ => 0.0,
                };
                pressure *= 1.0 - inc;
            }
            if (pressure > worstPressure) { worstPressure = pressure; worst = r; }
        }
        w.SecessionWorstRegion = worst?.Name ?? "";   // 診断（UI）：分離リスクの可視化（書くだけ＝挙動非依存）
        w.SecessionWorstPressure = worstPressure;
        w.SecessionHold = hold;
        if (worst is not null && worstPressure > c.SecessionThreshold && worstPressure > hold)
        {
            w.SecedingRegion = worst;
            w.CivilWarYears = c.CivilWarDurationYears;
            w.CivilWarTarget = w.Polity;   // 分離戦＝政体は変わらない（再統合 or 喪失）
            w.HadCivilWar = true; w.HadSecession = true;
        }
    }

    /// <summary>州の関税利害を**実利から創発**（倍率排除：静的な資源ラベル写像を撤去）。
    /// 各生産財の国内価格を世界参照価格(RefPrice)と比べ、安く作れる州＝競争力＝輸出で潤う＝**自由貿易が得(−)**、
    /// 高い州＝高コスト/品薄＝輸入に脅かされる＝**保護が得(+)**。生産額で加重。
    /// ＝競争力ある工業輸出都市（マンチェスター）は自由貿易へ寄り、自由貿易国策との乖離が消えて分離が止む。幼稚産業州は保護へ寄る（リスト型）。</summary>
    private static double RegionTariffInterest(Region r)
    {
        double pull = 0, weight = 0;
        foreach (var good in r.Goods)
        {
            if (good.Id < 0 || good.Id >= r.Markets.Length || good.RefPrice <= 1e-9) continue;
            var m = r.Markets[good.Id];
            if (m.LastProduced <= 1e-9) continue;   // その州が実際に作っている財だけ＝その州の産業利害
            double competitiveness = Math.Clamp((m.Price - good.RefPrice) / good.RefPrice, -1.0, 1.0);   // >0 高コスト→保護・<0 競争力→自由貿易
            double wgt = m.LastProduced * good.RefPrice;   // 生産額で加重（大産業ほど州の関税姿勢を支配）
            pull += wgt * competitiveness; weight += wgt;
        }
        return weight > 1e-9 ? Math.Clamp(pull / weight, -1.0, 1.0) : 0.0;
    }

    private static double AvgRegionMilitancy(Region r)
    {
        double mil = 0, size = 0;
        foreach (var p in r.Pops) if (!p.Closed && !p.IsSoldier) { mil += p.Militancy * p.Size; size += p.Size; }
        return size > 1e-9 ? mil / size : 0;
    }

    /// <summary>R3 蜂起R群2026-08-16（診断A3）：F1州一揆の熱。RegionalRevoltSatGate=0＝旧式（州平均闘争度×max(0,1−FoodFill)）と**ビット恒等**。
    /// 何が壊れていたか：旧式は **FoodFill=1.0 で heat≡0**＝生活水準が逓減でなく完全遮断スイッチ
    /// （高生活水準×高圧政の「不満70%超でも131年無風」の一因）。ゲート&gt;0 で欠乏の物差しに州平均満足を併置＝
    /// 1−min(FoodFill, 州平均Satisfaction)：パンが足りていても満足の低い州には熱が立つ（政治的窮乏）。
    /// FoodFill=1かつSat=1で旧と厳密同値・**Sat≥FoodFillの全帯で旧と同値**＝恒等の帯を保つ（壁でなく逓減の作法・新閾値ゼロ）。
    /// 点火A/Bで見る帯＝一揆頻度。internal＝ON経路テスト用（InternalsVisibleTo）。</summary>
    internal static double RegionRevoltHeat(Region r, Coefficients c)
    {
        double lack = 1.0 - r.FoodFill;
        if (c.RegionalRevoltSatGate > 0) lack = 1.0 - Math.Min(r.FoodFill, AvgRegionSatisfaction(r));
        return AvgRegionMilitancy(r) * Math.Max(0, lack);
    }

    /// <summary>州の平均満足（人口加重・AvgRegionMilitancy と同じ走査＝閉鎖/兵士popを除く）。popなし＝1.0
    /// （min(FoodFill, 1.0)=FoodFill で旧式に一致＝中立。どのみち熱は闘争度0で消える）。読み手はR3のみ＝ゲート0では不呼。</summary>
    private static double AvgRegionSatisfaction(Region r)
    {
        double sat = 0, size = 0;
        foreach (var p in r.Pops) if (!p.Closed && !p.IsSoldier) { sat += p.Satisfaction * p.Size; size += p.Size; }
        return size > 1e-9 ? sat / size : 1.0;
    }

    /// <summary>★州の国民意識（N7・2026-08-13）＝POPの国民意識のsize加重平均。未捕捉(-1)のpopは平均から除く
    /// （国スカラーで代用すると州差が消える＝この機構の目的そのものが失われる）。1つも捕捉されていなければ0＝割引なし。</summary>
    private static double AvgRegionConsciousness(Region r)
    {
        double nc = 0, size = 0;
        foreach (var p in r.Pops) if (!p.IsSoldier && p.NationalConsciousness >= 0) { nc += p.NationalConsciousness * p.Size; size += p.Size; }
        return size > 1e-9 ? Math.Clamp(nc / size, 0, 1) : 0;
    }

    // 政14：州の平均中核民族割合（人口加重・兵士除く）。(1−これ)＝州の少数派度＝民族主因の分離圧力の源（均質州=1で加算0）。
    private static double AvgRegionCoreShare(Region r)
    {
        double core = 0, size = 0;
        foreach (var p in r.Pops) if (!p.IsSoldier) { core += p.CoreEthnicShare * p.Size; size += p.Size; }
        return size > 1e-9 ? core / size : 1.0;   // pop なし＝1.0（少数派度0＝加算なし＝中立）
    }

    // 兵士の政治力＝規模×(0.2+不満)×係数。不満な大軍ほどクーデター力が高い（給与・補給が切れた軍＝新軍主義）。
    private static double SoldierForce(World w, Coefficients c)
    {
        double f = 0;
        foreach (var p in w.AllPops()) if (p.IsSoldier) f += p.Size * (0.2 + p.Militancy);
        double warExh = w.SelfPower?.WarExhaustion ?? 0;   // 厭戦軍ほどクーデタ力が高い（戦争崩壊型）。単一国較正は SelfPower=null で0＝無影響
        return f * c.MilitaryCoupWeight * (1 + c.WarExhaustionCoupBoost * warExh);
    }

    /// <summary>第5段5-6（2026-07-28）革命→国民意識（ナポレオンの鎖①・中核ルールdoc §11）：暴力革命の成立は天命の媒介回路（聖職者・領主）を
    /// 破壊し国家→市民の直接回路へ置き換える（臣民→国民・1793 levée en masse）。学校天井（NC蓄積のlawCeil×識字）をバイパスする直接加算＝
    /// それが「直接回路」の意味。受け皿＝Military の徴兵深度上限（国民意識ゲート・既配線）→革命が国を軍事的に強くする経路が繋がる。
    /// 加算はCrownParliamentのNC台帳では翌期の「前期からの国民意識」に折り込まれる（Reset前の一回性インパルス）。RevolutionConsciousness=0で恒等。</summary>
    private static void RevolutionAwakensNation(World w, Coefficients c)
    {
        if (c.RevolutionConsciousness <= 0) return;
        // ⚠★是正2026-08-01（敵対レビューで確定）：国民意識のPOP化（NationConsciousnessPerPop>0）では、
        //   World.NationalConsciousness の setter が書く _ncScalar を getter が**一切読まない**ため、
        //   ここでスカラーへ足しても無音で捨てられていた＝**革命が国を軍事的に強くする経路が丸ごと死んでいた**。
        //   POP化のときは同じインパルスをPOPへ直接与える（未初期化POPには国別初期値を先に与えてから足す）。
        if (c.NationConsciousnessPerPop > 0)
        {
            double seed = w.InitialNationalConsciousness >= 0 ? w.InitialNationalConsciousness : c.NationBuildInitialDefault;
            foreach (var p in w.AllPops())
            {
                double v = p.NationalConsciousness >= 0 ? p.NationalConsciousness : seed;
                p.NationalConsciousness = Math.Clamp(v + c.RevolutionConsciousness * (1.0 - v), 0, 1);
            }
            return;
        }
        if (w.NationalConsciousness < 0)
            w.NationalConsciousness = w.InitialNationalConsciousness >= 0 ? w.InitialNationalConsciousness : c.NationBuildInitialDefault;
        w.NationalConsciousness = Math.Clamp(w.NationalConsciousness + c.RevolutionConsciousness * (1.0 - w.NationalConsciousness), 0, 1);
    }

    /// <summary>機能6-2（2026-07-28）：国内の革命圧力∈[0,1]＝動員（改革派＋急進派）÷実効保持力のクランプ比（Transitionと同じ物差し＝新概念なし）。
    /// 講和意欲の実効閾値（Diplomacy）が読む＝内戦の懸念がある国は余力を残して降伏（独1918/露1917）。</summary>
    public static double RevolutionPressure(World w)
        => PoliticalQuantities.ChallengeRatio(w.ReformistPower + w.RadicalPower, PoliticalQuantities.EffectiveCoerce(w, w.Coef));

    // 大衆（労働者・農民。兵士除く）の平均闘争度（人口に依らない水準）。高ければブルジョワが独裁化（ブルジョア独裁の引き金）
    public static double AvgMassMilitancy(World w)   // 戦争熱＝外征の出口にも使う
    {
        double mil = 0, size = 0;
        foreach (var p in w.AllPops())
            if (!p.Closed && !p.IsModernElite && !p.IsSoldier) { mil += p.Militancy * p.Size; size += p.Size; }
        return size > 1e-9 ? mil / size : 0;
    }

    // 政変後：勝者・中立の不満は緩和、失脚した集団のPOPは反革命の激しい不満を抱く（国内が不安定化＝仏革命の再現）。
    private static void ResolveRevolt(World w, Coefficients c, bool depTrad, bool depModern, bool depMass)
    {
        // 恐怖政治（タスクB/R5）＝一過性イベント：**急進革命(共和/プロレタリア独裁/アナーキー)の勝利時のみ**、失脚した旧支配層を
        // 物理的に粛清・亡命でSize削減＋資産没収する（仏革命の断頭台＝貴族が最も死んだ／ロシア革命の白系亡命）。緩やかな立憲化(立憲君主制)等の
        // 穏健革命は対象外＝過剰適用を避ける。RevolutionTerror=0 で terror=false＝不発（現行0.25採用）。
        bool terror = c.RevolutionTerror > 0
                   && w.Polity is Polity.Republic or Polity.ProletarianDictatorship or Polity.Anarchy;
        double confiscated = 0;
        foreach (var p in w.AllPops())
        {
            bool deposed = (depTrad && p.Closed)
                        || (depModern && p.IsModernElite)
                        || (depMass && !p.Closed && !p.IsModernElite && !p.IsSoldier);
            if (deposed)
            {
                p.Militancy = Math.Clamp(p.Militancy + c.DeposedMilitancySpike, 0, 1);   // 失脚＝反革命の激しい不満
                if (terror && !p.IsSoldier && p.Size > 0)
                {
                    double purged = p.Size * c.RevolutionTerror;
                    p.Size -= purged;
                    w.PopulationDelta -= purged; w.WarDeadCumulative += purged;   // 人口保存（粛清・亡命を戦死累計へ計上）
                    w.TerrorPurgeCumulative += purged;   // 診断（UI）：粛清量の累計＝書くだけ（挙動非依存）。UIがニュース化に使う
                    double seized = Math.Max(0, p.Savings) * c.RevolutionTerror;   // 資産没収（貴族の所領・資本の没収）
                    p.Savings -= seized; confiscated += seized;
                }
            }
            else p.Militancy *= c.ReformMilitancyRelief;                                            // 勝者・中立＝緩和
        }
        // 没収資産を大衆pop（非特権・非エリート・非兵士）へSize按分で再分配＝革命の余剰再分配（保存＝pop→pop純移転・貨幣不変）。受け手不在は全popへ按分。
        if (confiscated > 0)
        {
            double ms = 0; foreach (var p in w.AllPops()) if (!p.Closed && !p.IsModernElite && !p.IsSoldier) ms += p.Size;
            if (ms > 1e-9) { foreach (var p in w.AllPops()) if (!p.Closed && !p.IsModernElite && !p.IsSoldier) p.Savings += confiscated * (p.Size / ms); }
            else { double t = 0; foreach (var p in w.AllPops()) t += p.Size; if (t > 1e-9) foreach (var p in w.AllPops()) p.Savings += confiscated * (p.Size / t); }
        }
    }
}
