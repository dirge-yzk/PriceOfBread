﻿namespace PriceOfBread.SimCore;

/// <summary>
/// イデオロギーの創発（§政体・画一遷移の力ベクトル）。各POPのイデオロギー分布を
/// 階級の基本傾向（経済導出）× 条件（意識・闘争度）× 時代（年）× 戦争（厭戦）から毎四半期に更新する。
/// 段2稼働＝集計（<see cref="National"/>/<see cref="Regional"/>）→政体親和（<see cref="SupportAt"/>）を Transition・CrownParliament・PowerAffinity が読む。
/// 重み（BaseWeights・更新式）はコード定数。インデックスは <see cref="Ideology"/> enum と一致（0..10・9=ファシズム・10=王党派）。
/// </summary>
public static class Ideologies
{
    public const int Count = 11;   // 9ファシズム（1934拡張E7）・10王党派（2026-08-19）を追加。各ゲート0でそのシェアは常に0＝短い配列と数値等価（総和/ArgMax/加重平均に無影響）
    // 0伝統 1反動 2自由 3共和 4ナショ 5社会 6共産 7無政府 8帝国 9ファシズム 10王党派
    // マジックナンバー一掃（2026-07-20・値据え置き・命名のみ）：平均超の相対的富の上限（0..3＝失う物）。正規化と再スケールで同値を共有
    private const double WealthExcessCap = 3.0;

    public static void UpdateShares(World w)
    {
        // 国民平均の1人あたり富（相対的富＝イデオロギーの導出に使う）。富で「失う物」が決まる＝保守/急進の分岐。
        double totSav = 0, totPop = 0, urbanPop = 0;
        foreach (var p in w.AllPops()) { totSav += System.Math.Max(0, p.Savings); totPop += p.Size; if (p.IsUrban) urbanPop += p.Size; }
        double meanWealth = totPop > 1e-9 ? totSav / totPop : 1;

        double year = w.Year;
        // イデオロギー創発の暦年オンセットと立ち上がり幅（マジックナンバー一掃2026-07-20＝値据え置き・命名のみ）
        const int SocialismOnsetYear = 1830, CommunismOnsetYear = 1848, ImperialismOnsetYear = 1860, FascismOnsetYear = 1919;
        const double IdeologyEraSpanYears = 40.0, FascismEraSpanYears = 15.0;
        double eraSoc  = Clamp01((year - SocialismOnsetYear) / IdeologyEraSpanYears);   // 社会主義＝1830s〜
        double eraComm = Clamp01((year - CommunismOnsetYear) / IdeologyEraSpanYears);   // 共産主義＝1848（共産党宣言）〜
        double eraImp  = Clamp01((year - ImperialismOnsetYear) / IdeologyEraSpanYears);   // 帝国主義＝19c後半〜
        double eraFasc = Clamp01((year - FascismOnsetYear) / FascismEraSpanYears);   // ファシズム（E7）＝両大戦間（1919〜）。第一次大戦後の危機で結晶
        // ※ナショナリズムは時代ゲートを廃止＝**ボナパルティズムとしても扱う**：仏革命〜ナポレオン(1789〜)の革命的ナショナリズム
        //   ＝軍事的強権・国民動員は初期から存在する（MilitaryDictatorship への親和が高い＝ボナパルト型）。よって1850ゲートを掛けない。
        // ※社会/共産/帝国の暦年ゲートは観念論の例外に見えるが**実証上 load-bearing**（2026-06-18 検証で撤去を試行）：撤去すると
        //   工業化したほぼ全社会で社会主義が創発し、共和(親和1.0)＞立憲(0.5)の差で政体が共和へ homogenize（立憲君主制 51%→9%・希少政体消滅）。
        //   史実でも工業化した英独日伊北欧は立憲君主制のまま＝ゲートは「立憲君主制を中道として生存させる」役割を担う。よって暦年ゲートは保持する。
        // 政16（暦年ゲート→発展度ゲート・現行 IdeologyGateFromDevelopment=0.5＝暦年と発展度の50/50ブレンド・load-bearing）：暦年の一次関数ゲートは
        //   「工業化が早い世界線でも1830年まで社会主義ゼロ」という観念論の例外。g の分だけ暦年を「世界最先端の工業化度＋都市労働者シェア」から創発する
        //   発展度スカラー dev へ置換する（era=(1-g)×暦年+g×発展度・g=0 で暦年ゲートを厳密再現）。
        //   立憲温存効果の維持：発展度ゲートは社会主義を早期に**全開にしない**よう onset+span で段階的に開く（下の Onset/Span 係数）。
        //   ★「世界最先端の工業化度」は w.IndustrialFrontier（WorldTechLevel と同型・MultiNationSim が各国最高の MeanIndustrialization を毎四半期注入）。
        //   単一国較正/多国の初四半期は注入前で 0 のため、自国 MeanIndustrialization をフォールバック下限に用いる（active-path では常に自国値以上＝下限は縮退時のみ効く）。
        double frontierInd = System.Math.Max(w.IndustrialFrontier, w.MeanIndustrialization);   // 世界最先端の工業化度（未注入=0 なら自国工業化へフォールバック）
        double urbanWorkerShare = totPop > 1e-9 ? urbanPop / totPop : 0;                 // 都市労働者シェア（プロレタリア化の度合い）
        // 発展度スカラー dev∈[0,1]＝工業化度（IdeologyGateIndScale で0..1へ）と都市労働者シェアの加重（IdeologyGateUrbanWeight）。
        double dev = Clamp01((1.0 - w.Coef.IdeologyGateUrbanWeight) * Clamp01(frontierInd / w.Coef.IdeologyGateIndScale)
                           + w.Coef.IdeologyGateUrbanWeight * urbanWorkerShare);
        double devSoc  = Clamp01((dev - w.Coef.IdeologyGateSocOnset)  / w.Coef.IdeologyGateSpan);   // 社会主義＝発展度で最初に開く
        double devComm = Clamp01((dev - w.Coef.IdeologyGateCommOnset) / w.Coef.IdeologyGateSpan);   // 共産主義＝次に開く
        double devImp  = Clamp01((dev - w.Coef.IdeologyGateImpOnset)  / w.Coef.IdeologyGateSpan);   // 帝国主義＝最も遅く開く（暦年 1830<1848<1860 の順序を発展度で再現）
        double g = w.Coef.IdeologyGateFromDevelopment;                                   // 暦年と発展度のブレンド比
        // #17：ブレンド比を自国工業化度で動的化＝工業国ほどg→1（イデオロギーが自国の発展度から創発）・未工業国はbaseGのまま。IdeologyGateIndDynamic=0で固定g＝厳密恒等。
        if (w.Coef.IdeologyGateIndDynamic > 0)
            g += w.Coef.IdeologyGateIndDynamic * (1.0 - g) * Clamp01(w.MeanIndustrialization / w.Coef.IdeologyGateIndScale);
        eraSoc  = (1.0 - g) * eraSoc  + g * devSoc;
        eraComm = (1.0 - g) * eraComm + g * devComm;
        eraImp  = (1.0 - g) * eraImp  + g * devImp;
        // 厭戦（war exhaustion）はイデオロギーへ直接加点しない＝Politics で闘争度入力へ移管（倍率排除/長い裾）。闘争→既存の mil 項（閉鎖階級→反動・大衆→共和/社会/共産）が拾う。

        // 機能7-1/7-2（第7段第2波・2026-07-28）：敗戦ショック（短期＝DefeatShock減衰0.85/四半期）＋失地ストック（長期＝半減期20年）→
        // r[4]ナショナリズムの噴出（刺され伝説1918独・アルザス1871→1914）。ループ前に1回評価＝O(pops)回避。
        // 二重計上裁定（機能7-6＝案A）：RevanchismTensionは「特定の相手国への対外敵意（緊張・ワンショット）」・本項は「国内イデオロギー分布（持続）」＝出力先が異なる。
        // 機能8-②/⑤（2026-07-28）：戦勝→主戦論（日本型・敗戦のr[4]+r[1]に対する対称）＋外圧→攘夷/富国強兵（清の反帝国主義）もr[4]へ。
        double nationalismSurge = w.Coef.DefeatNationalism * w.DefeatShock + w.Coef.LostLandNationalism * w.LostRegionsCumulative
            + w.Coef.VictoryNationalism * w.VictoryShock + w.Coef.ExternalPressureNationalism * w.ExternalPressure;
        double victoryImp = w.Coef.VictoryImperialism * w.VictoryShock;   // 機能8-②：戦勝→帝国主義（植民地熱）
        // 機能8-③（2026-07-28）：恐慌→両極化（左＝社会/共産・右＝反動。ワイマール型）。恐慌は平均60.8回/試合＝係数は小さく（1項ずつ--zero帰属）。
        double dd = w.GdpDrawdown;
        double depSoc = w.Coef.DepressionSocialism * dd, depComm = w.Coef.DepressionCommunism * dd, depReact = w.Coef.DepressionReaction * dd;
        // 機能8-④（2026-07-28）：飢えの記憶→急進側（共和1789/社会）。「パンの値段」の題名に最も近い機構。
        double famRep = w.Coef.FamineRepublicanism * w.FamineMemory, famSoc = w.Coef.FamineSocialism * w.FamineMemory;

        // 王党派の供給源（★ループ前に1回＝O(pops)回避。nationalismSurge と同じ作法）。RoyalistGate=0 なら読まない。
        double royalPrivilege = w.Coef.RoyalistGate > 0 ? PowerShares.PrivilegeIntact(w) : 0;
        double royalPatronage = w.Coef.RoyalistGate > 0 ? PowerShares.StatePatronage(w) : 0;
        // ★反動の担い手＝**地位を失いつつある層**（2026-08-20・休眠）。ループ前に1回（O(pops)回避・上と同じ作法）。
        //   ⚠特権の毀損＝農奴解放・免税の廃止・身分制の解体が進むほど大きい＝**旧秩序が現に壊されている度合い**。
        //   ★史実の順序どおり＝1861年の農奴解放が貴族の反動を生み、1876年の秩禄処分が士族反乱を生んだ。
        double privLoss = w.Coef.ReactionFromLoss > 0 ? 1.0 - PowerShares.PrivilegeIntact(w) : 0;
        if (!(privLoss >= 0 && privLoss <= 1)) privLoss = 0;
        foreach (var p in w.AllPops())
        {
            var r = p.IdeologyShares;
            double rich = BaseWeights(p, r, meanWealth);                  // 平均超の富（0..3＝失う物）
            double cons = p.Consciousness, mil = p.Militancy;
            // 啓蒙・過激化は**加算**（基盤0からでも生まれる＝農民でも意識が上がれば自由主義が芽生える）。
            // 倍率排除/長い裾：反動の Closed ハードコードを廃し**相対的富（失う物）から連続化**。富裕ほど旧秩序を脅かす急進左派を恐れ反動化
            // ＝1848のブルジョワ反動。進歩傾向（意識→自由/共和、闘争→左派）は失う物の少ない層ほど強い＝(1−執着)。
            // 富裕な閉鎖貴族は conserv≈1 で旧「反動のみ」を再現／無産大衆は conserv≈0 で旧「進歩のみ」。
            double conserv = Clamp01(rich / 2.0);                        // 反動への執着（富裕ほど強い・wealthRel≥3 で飽和）
            double prog = 1.0 - conserv;
            // ★反動＝旧式は「脅かされた失う物のある層」＝闘争度×富。⚠ReactionFromLoss>0 で**地位の喪失**へ差し替える（休眠・既定0で厳密恒等）。
            //   ⚠旧式は闘争度と富の両立を要求するが現物では両立しない＝実測で反動が全期間ほぼ0（→ファシズムの燃料も枯れる）。
            if (w.Coef.ReactionFromLoss > 0)
            {
                // ★★担い手は**大衆を含む**（2026-08-21 第2走の是正）。第1走は閉鎖階級と兵士に絞って外した：
                //   ⚠実測＝閉鎖階級は人口の2〜6%で、基底が伝統4+2×富/反動2と厚いので0.5を足してもPOP内シェアが動かず、
                //     国全体の反動は**1%が構造上の上限**だった（測定値0.01と一致）。
                //   ⚠しかも自分の史実と矛盾していた＝**ヴァンデの反革命は農民**・国家人民党の基盤は農業経営者と俸給生活者＝**反動は大衆現象**。
                // ★大衆の門＝(1−意識)。同じ大衆の不満が**政治意識で左右に割れる**：意識の高い不満層は左へ（既存経路）、
                //   **意識の低い不満層は、旧秩序が現に壊されているとき反動へ**＝素朴王政観の層は普段は天命を支え、
                //   その世界が壊されると反革命になる（ヴァンデ）。3層分割（文盲→天命）と整合。
                double gate = (p.Closed || p.IsSoldier) ? 1.0 : Clamp01(1.0 - cons);
                r[1] += 2.0 * mil * w.Coef.ReactionFromLoss * privLoss * gate;
            }
            else
                r[1] += 2.0 * mil * conserv;                             // 反動（脅かされた失う物のある層）
            r[2] += 2.5 * cons * prog;                                   // 啓蒙→自由主義
            r[3] += (1.5 * cons + 1.0 * mil) * prog;                     // 共和主義（啓蒙＋過激）
            r[5] += (1.0 * cons + 1.5 * mil) * prog;                     // 社会主義
            r[6] += 2.0 * mil * prog;                                    // 共産主義（過激）
            r[7] += 1.0 * mil * prog;                                    // 無政府主義（過激）
            // 倍率排除⑥/長い裾：伝統の意識減衰 r[0]*=1−0.7cons を撤去。意識・闘争が r[2..7] を加点し Normalize で総和1へ割られるため伝統シェアは自動低下＝明示倍率は二重計上。正規化に委ねる。
            // 戦争崩壊（1917／敗戦の反動）の厭戦は闘争度経由（Politics）で上の mil 項が拾う＝Ideology からの直接加点は撤去（倍率排除/長い裾）。
            r[4] += nationalismSurge;   // 機能7-1/7-2/8-②/8-⑤：敗戦＋失地＋戦勝＋外圧→ナショナリズム（時代ゲート・ファシズム式の前＝r[9]の燃料として自動で効く）
            // 独統一トリガー解錠B（wf_d460b52d調査2・2026-08-08）：国民意識の高い国は平時もナショナリズムが底上げされる
            // （統一運動＝1848の前提。旧＝ナショはイベント駆動のみで、125年×53カ国で統一閾値0.25に誰も届かなかった）。
            // ⚠既定0＝加算ごとスキップ＝厳密恒等。国名なし＝国民意識という既存の実数から創発。
            if (w.Coef.NationalismFromConsciousness > 0)
                r[4] += w.Coef.NationalismFromConsciousness * System.Math.Max(0, w.NationalConsciousness);
            // ★マニフェストの達成（作者指示2026-08-24）＝加担した思想へ支持が乗る（減衰ストック・Parliament.StepManifesto が積む）。
            //   出来事→思想の既存パターン（上の nationalismSurge・depSoc と同じ位置・同じ物差し）＝新しい経路を作らない。
            if (w.ManifestoIdeology >= 0 && w.ManifestoIdeology < r.Length && w.ManifestoCredit > 0)
                r[w.ManifestoIdeology] += w.ManifestoCredit;
            r[8] += victoryImp;         // 機能8-②：戦勝→帝国主義（時代ゲートeraImpが早期を抑える）
            r[1] += depReact;           // 機能8-③：恐慌→反動（右極化）
            r[3] += famRep;             // 機能8-④：飢えの記憶→共和（1789）
            r[5] += depSoc + famSoc;    // 機能8-③/④：恐慌＋飢え→社会主義
            r[6] += depComm;            // 機能8-③：恐慌→共産（時代ゲートeraCommが早期を抑える）
            // 時代ゲート（後発イデオロギーは早期0）＝加算後に掛ける。※ナショ(4)はゲート無し＝ボナパルティズムとして初期から存在。
            r[5] *= eraSoc; r[6] *= eraComm; r[8] *= eraImp;
            // ファシズム（E7・E9点火）：戦間期(eraFasc)の発展した経済(dev)で危機(mil)が高いほど、反動(r[1])と国民主義(r[4])が権威主義へ結晶＝それらから recruit（反共・国家動員）。FascismGate=0で不発＝r[9]=0＝配列長9と数値等価。
            if (w.Coef.FascismGate > 0) r[9] += w.Coef.FascismGate * eraFasc * dev * mil * (r[1] + r[4]);
            // ★★★10 王党派（2026-08-19・作者裁定）：**政治意識を持つ王権支持者**＝「意識が上がる＝議会支持」という一本道を断つ。
            //   供給＝**王権から実際に利益を得ている層** × 政治意識。誰が利益を得ているかは既存の唯一実装を読む
            //   （PowerShares.PrivilegeIntact＝農奴制/免税/身分、PowerShares.StatePatronage＝関税/国家発注/秩序）。
            //   ⚠閉鎖階級→特権／近代エリート→恩顧／それ以外→供給チャネルなし＝PowerShares.PopExecutiveLean と同じ写像。
            //   ⚠⚠次段の課題：この2関数は観測層(PowerShares)にあり、エンジンが観測層を呼ぶのは依存の向きとして逆。
            //     ただし「実装を2つ作らない」規律を優先した（旧doc §6-2 危険7）。移すならエンジン側の適切な場所へ。
            //   RoyalistGate=0 で1行も走らず r[10]=0 ＝ 配列長10と数値等価（9ファシズムと同じ作法）。
            if (w.Coef.RoyalistGate > 0)
            {
                double royalSupply = p.Closed ? royalPrivilege : (p.IsModernElite ? royalPatronage : 0);
                if (royalSupply > 0) r[10] += w.Coef.RoyalistGate * cons * royalSupply;
            }
            Normalize(r);
        }
    }

    // 階級の基本傾向を**経済属性から導出**（手書き階級スイッチを廃止）。[Trad,React,Lib,Repub,Nat,Soc,Comm,Anarch,Imp]（9ファシズム・10王党派は UpdateShares の下段で加点）
    // 物質的立場＝地代依存度（農地の旧秩序）／相対的富（失う物＝保守 vs 窮乏＝急進）／特権(Closed)／教育エリート／都市／兵士。
    // ＝同じ階級でも富/所得源が変わればイデオロギーが動く（没落貴族の急進化等）＝創発。意識・闘争・時代の変調は下段（従来）で掛かる。
    // 返り値＝平均超の富 rich（呼び手の conserv 用＝同じ式を2度書かない）。
    private static double BaseWeights(Pop p, double[] r, double meanWealth)
    {
        System.Array.Clear(r, 0, r.Length);
        double rent = System.Math.Max(0, p.LandRent), earned = System.Math.Max(0, p.Earned);
        double rentier = (rent + earned) > 1e-9 ? rent / (rent + earned) : 0;          // 地代への依存度（地主＝旧秩序）
        double wpc = p.Size > 1e-9 ? System.Math.Max(0, p.Savings) / p.Size : 0;
        double wealthRel = meanWealth > 1e-9 ? wpc / meanWealth : 1;                    // 相対的富（1=平均）
        double rich = Clamp01((wealthRel - 1) / WealthExcessCap) * WealthExcessCap;                             // 平均超の富（0..3＝失う物）
        double poor = Clamp01(1 - wealthRel);                                           // 平均未満の窮乏（0..1）

        if (p.Closed)            // 特権身分（貴族・聖職）＝旧秩序の受益者＝伝統・反動（富で増す）
        {
            r[0] = 4 + 2 * rich; r[1] = 2; r[8] = rich; r[4] = 0.5;
        }
        else if (p.IsSoldier)    // 兵士＝武力と国家＝ナショ・帝国
        {
            r[4] = 4; r[8] = 2; r[0] = 1; r[1] = 1;
        }
        else
        {
            r[0] = 2 * rentier + 0.5;                                  // 伝統＝地代（農地の旧秩序）依存
            r[2] = (p.IsModernElite ? 3.0 : 1.0) + 3 * rich * (1 - rentier);   // 自由＝資本（富裕非地代）・教育
            r[3] = p.IsModernElite ? 2.0 : 1.0;                        // 共和＝市民・教育
            r[5] = 2 * poor * (1 - rentier) + (p.IsUrban ? 1.0 : 0);   // 社会＝賃金窮乏・都市
            r[6] = 1.5 * poor * (p.IsUrban ? 1.0 : 0);                 // 共産＝都市の窮乏
            r[7] = poor;                                               // 無政府＝窮乏（無産）
            r[8] = (p.IsModernElite ? 1.0 : 0) + rich * (1 - rentier); // 帝国＝資本
            r[4] = 0.5;
        }
        return rich;
    }

    private static void Normalize(double[] r)
    {
        double sum = 0;
        for (int i = 0; i < r.Length; i++) { if (!(r[i] >= 0)) r[i] = 0; sum += r[i]; }   // 否定形＝NaN も 0 へ倒す（有限値では r[i] < 0 と同値）
        if (sum < 1e-9) { r[0] = 1; return; }   // 退避：伝統100%（早期で全ゲート0等）
        for (int i = 0; i < r.Length; i++) r[i] /= sum;
    }

    private static double Clamp01(double x) => !(x >= 0) ? 0 : x > 1 ? 1 : x;   // 否定形＝NaN は 0 へ（有限値では x < 0 と同値・−0.0 も素通し）

    // ===== 画一遷移（段2）：国民イデオロギー集計 → 政体親和の内積 → 引力点 =====

    // アナルシーは引力点から廃止（一過性の秩序崩壊は政体選択肢にしない）。財政破綻は経済悪化(Credit)で表現。
    public static readonly Polity[] Polities =
        [Polity.Absolutist, Polity.Despotic, Polity.Shogunate, Polity.ConstitutionalMonarchy,
         Polity.Republic, Polity.BourgeoisDictatorship, Polity.ProletarianDictatorship,
         Polity.MilitaryDictatorship];

    // 政体×イデオロギー親和（倍率排除⑧＝制度座標化）：手書き9×9を廃し、政体・思想を**4軸の制度座標**の点として置き、
    // 親和＝座標の近さ（距離）から創発させる。軸（すべて0..1）：
    //   軸0 参加（一人/エリート 0 ↔ みんな 1）＝参政権の広さ
    //   軸1 強権（合意・伝統 0 ↔ 武力・弾圧 1）
    //   軸2 経済（労働/再分配 0 ↔ 資本 0.5 ↔ 地主/伝統 1）
    //   軸3 国家軍（控えめ 0 ↔ 国家/軍/民族が前へ 1）
    // 段階1＝固定座標（法律連動のズレは段階2で追加）。年代ゲート（社会/共産/帝国）は UpdateShares で従来どおり維持。
    // 親和 = clamp(AffMax − AffSlope×距離, AffMin, AffMax)＝近い思想ほど高く、遠いほど低い（旧 −1..+2 のレンジを再現）。
    public const double AffMax = 2.0, AffMin = -1.0;   // ★2026-08-19：PowerAffinity が親和のレンジを読むため公開（アクセス修飾子のみ＝挙動不変）

    // 思想座標（0伝統 1反動 2自由 3共和 4ナショ 5社会 6共産 7無政府 8帝国 9ファシズム 10王党派）。
    private static readonly double[][] IdeologyCoord =
    [           // 参加  強権  経済  国家軍
        [ 0.00, 0.40, 1.00, 0.25 ],   // 0 伝統＝旧秩序・地主・低参加
        [ 0.00, 0.75, 1.00, 0.40 ],   // 1 反動＝強権で旧秩序を守る
        [ 0.60, 0.10, 0.50, 0.20 ],   // 2 自由＝制限選挙の立憲自由主義（古典的自由主義は財産制限選挙＝立憲君主制を好む。普通選挙は共和へ）・資本
        [ 1.00, 0.10, 0.45, 0.20 ],   // 3 共和＝最も広い参加・自由・市民
        [ 0.45, 0.50, 0.50, 1.00 ],   // 4 ナショ＝国家動員（ボナパルティズム）
        [ 0.75, 0.30, 0.00, 0.20 ],   // 5 社会＝広い参加・労働・再分配
        [ 0.30, 0.85, 0.00, 0.20 ],   // 6 共産＝前衛・強権・労働
        [ 0.70, 0.00, 0.20, 0.00 ],   // 7 無政府＝反国家・無強権・無産
        [ 0.30, 0.60, 0.55, 1.00 ],   // 8 帝国＝資本＋国家/軍の対外膨張
        [ 0.35, 0.90, 0.55, 1.00 ],   // 9 ファシズム（E7）＝大衆動員だが真の参政権なし・最高強権・資本コーポラティズム・国家/民族/軍が全面。軍事独裁座標[0.15,0.75,0.60,0.85]/反動/帝国に最近接＝軍事独裁へ写像が座標系から創発
        [ 0.55, 0.55, 0.90, 0.50 ],   // 10 王党派（2026-08-19・★座標は仮置き＝調整でいじる前提）：参加を求めるが秩序と財産を重んじる。
                                      //    ⚠国家軍を 0.50 に抑えるのが要点＝1.00 にするとナショ/帝国/ファシズムと同じく**軍部**へ流れて意味が無くなる（実測で確認済み）。
    ];

    // 政体座標（(int)Polity と一致：Absolutist=0..Anarchy=8）。固定（段階2で法律連動のズレを足す）。
    private static readonly double[][] PolityCoord =
    [           // 参加  強権  経済  国家軍
        [ 0.00, 0.50, 1.00, 0.30 ],   // 0 Absolutist＝王が決める・伝統・地主
        [ 0.05, 0.80, 0.50, 0.60 ],   // 1 Despotic＝近代化する強権（上からの自由化・国家主導）
        [ 0.00, 0.55, 1.00, 0.15 ],   // 2 Shogunate＝封建・鎖国（国家膨張は低い）
        [ 0.60, 0.20, 0.55, 0.30 ],   // 3 ConstitutionalMonarchy＝制限参加・自由・資本
        [ 0.95, 0.10, 0.40, 0.25 ],   // 4 Republic＝広い参加・自由・資本/労働
        [ 0.30, 0.60, 0.50, 0.45 ],   // 5 BourgeoisDictatorship＝資本＋武力で労働を抑える
        [ 0.30, 0.85, 0.00, 0.20 ],   // 6 ProletarianDictatorship＝労働＋前衛の強権
        [ 0.15, 0.75, 0.60, 0.85 ],   // 7 MilitaryDictatorship＝武力＋国家/軍が前面、かつ反動/帝国の権威主義クラスタに近い（保守支配の危機で軍政coupが立つ＝旧表で反動1.0/帝国1.0に正の親和）
        [ 0.70, 0.00, 0.20, 0.00 ],   // 8 Anarchy＝反国家（引力点からは除外＝Polities に非掲載）
    ];

    /// <summary>制度座標の近さ→親和（倍率排除⑧）。距離が近い思想ほど高い親和。</summary>
    public static double AffinityOf(double[] polity, double[] ideology, double slope)   // ★2026-08-19：PowerAffinity が機関同士の近さを読むため公開（アクセス修飾子のみ＝振舞い不変）
    {
        double d2 = 0;
        for (int i = 0; i < 4; i++) { double x = polity[i] - ideology[i]; d2 += x * x; }
        return System.Math.Clamp(AffMax - slope * System.Math.Sqrt(d2), AffMin, AffMax);
    }

    /// <summary>国民イデオロギーの集計＝Σ POPのイデオロギー分布 ×（規模×政治的重み）。意識ある層が政治を動かす。正規化。</summary>
    public static double[] National(World w) => Aggregate(w, w.AllPops());

    /// <summary>州スコープのイデオロギー集計＝<see cref="National"/> の反復元を r.Pops に替えた同型。
    /// 内戦による国家分裂（docs/202607/20260731_内戦による国家分裂_部分完了.md【一部】.md）の「州が陣営を選ぶ」物差し＝Politics の州陣営判定（内戦一元化）が読む。
    /// ★思想②を1ミリも侵さない——国名も文化名も出てこない。アメリカ南部が離れるのは**南部の pop の思想分布がそうだから**であって「南部」と書いたからではない。</summary>
    public static double[] Regional(World w, Region r) => Aggregate(w, r.Pops);

    private static double[] Aggregate(World w, IEnumerable<Pop> pops)
    {
        var agg = new double[Count];
        double total = 0;
        foreach (var p in pops)
        {
            // 倍率排除②：政体引力を動かすのは**意識ある層**だが、参政権を持つ層ほど寄与が大きい（票が声を増幅）。
            // 参政権ゲート外でも公共圏（サロン・新聞・示威＝1789/1848）で一定は寄与（floor）＝参政権ゼロでも自由化の機運は育つ。
            // 票はその上に乗る増幅＝参政権拡大が国民集計を左へ動かす。完全排除は「無参政権→自由化不能」の罠を生むため floor で回避。
            double voice = w.Coef.IdeologyVoiceFloor + (1.0 - w.Coef.IdeologyVoiceFloor) * InterestGroups.FranchiseVoice(p, w.Suffrage, w.Coef);
            double weight = p.Size * p.Consciousness * voice;
            if (!(weight > 0)) continue;   // 否定形＝NaN も除外（有限値では weight <= 0 と同値）
            var s = p.IdeologyShares;
            for (int k = 0; k < Count; k++) agg[k] += s[k] * weight;
            total += weight;
        }
        if (total > 1e-9) for (int k = 0; k < Count; k++) agg[k] /= total;
        return agg;
    }

    /// <summary>政体の静的基準座標（段階2のドリフト前）。返り値は内部配列の参照＝呼び出し側は破壊変更しない（ドリフトは複製して行う）。</summary>
    public static double[] BasePolityCoord(Polity pol) => PolityCoord[(int)pol];

    /// <summary>参政権→参加軸の開放度（0..1・倍率排除⑧段階2）。現政体の参加軸を実際の参政権へドリフトさせるのに使う。</summary>
    public static double Openness(Suffrage s) => s switch
    {
        Suffrage.Universal => 0.95, Suffrage.AdultMale => 0.80, Suffrage.Census => 0.55, _ => 0.00,
    };

    /// <summary>POPの**4軸理想点**＝その思想混合(IdeologyShares)を思想座標で加重平均（政治の空間モデル）。
    /// 各popの経済から創発した思想分布が、4軸空間の1点（その層が望む体制の位置）に集約される。現政体座標との距離が政治的不満を生む。</summary>
    public static double[] IdealPoint(double[] shares)
    {
        var pt = new double[4];
        double tot = 0;
        for (int k = 0; k < Count; k++)
        {
            double s = shares[k];
            if (s <= 0) continue;
            var co = IdeologyCoord[k];
            for (int i = 0; i < 4; i++) pt[i] += s * co[i];
            tot += s;
        }
        if (tot > 1e-9) for (int i = 0; i < 4; i++) pt[i] /= tot;
        return pt;
    }

    /// <summary>与えた政体座標での支持＝国民イデオロギー集計 · 親和（座標の近さから創発）。段階2は現政体に法律連動でドリフトした座標を渡す。</summary>
    public static double SupportAt(double[] agg, double[] polityCoord, double affinitySlope)
    {
        double s = 0;
        for (int k = 0; k < Count; k++) s += agg[k] * AffinityOf(polityCoord, IdeologyCoord[k], affinitySlope);
        return s;
    }

    /// <summary>ある政体への支持＝静的基準座標で評価（Runner診断・後方互換）。遷移本体は SupportAt にドリフト座標を渡す。</summary>
    public static double Support(double[] agg, Polity pol, double affinitySlope) => SupportAt(agg, PolityCoord[(int)pol], affinitySlope);
}
